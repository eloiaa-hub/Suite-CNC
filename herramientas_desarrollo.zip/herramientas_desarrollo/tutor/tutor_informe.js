// ════════════════════════════════════════════════
//  🧾 Informe de ✍ Practicar para Aules (solo en el Tutor)
//  Un PDF con el programa escrito y cómo se ha hecho: líneas a la primera, con fallos y vistas, pistas,
//  los errores más repetidos y cada intento fallido, con un código de comprobación. El Corrector lo lee
//  en «Toda la clase» (como el informe del Simulador): corrige el programa y comprueba el código.
//  Usa pdfCadena, infAncho e infPartir (de informe_entrega.js) y codigoInforme (de entregas_comun.js).
// ════════════════════════════════════════════════
let tuInf = null, tuInfImg = null;
function tuNotaPractica(p, total) { return total ? Math.round(10 * (p.bien + 0.5 * p.ayuda) / total * 10) / 10 : 0; }
function tuDatosInforme() {
    const p = TU.practica, L = TU.prog.lineas, ahora = new Date(), dd = v => String(v).padStart(2, '0');
    const lineas = [];
    L.forEach((l, i) => {
        if (l.sep || l.titulo) return;
        const r = (p.registro && p.registro[i]) || { fallos: [] };
        lineas.push({ n: i + 1, txt: p.junto && p.junto[i] !== undefined ? `(en la línea ${p.junto[i] + 1})` : p.escritas[i] !== undefined ? p.escritas[i] : l.cod, estado: p.estado[i] || '', pista: !!r.pista, fallos: r.fallos.map(f => ({ txt: f.txt, msg: f.msg, cat: f.cat })) });
    });
    const cats = {}; lineas.forEach(x => x.fallos.forEach(f => { cats[f.cat] = (cats[f.cat] || 0) + 1; }));
    const total = lineas.length, programa = normalizarPrograma(tuTextoActivo());
    const ver = (document.querySelector('.ver-suite') || {}).textContent || '';
    const nombre = TU.ejercicio ? (TU.ejercicio.nombre || TU.prog.nombre) : (TU.prog.nombre || document.getElementById('projectName').value);
    return {
        v: 1, simulador: 'tutor', version: ver.trim(), alumno: '', grupo: '', ejercicio: String(nombre || '').trim(),
        archivo: String(nombre || 'programa').replace(/[\\/:*?"<>|]+/g, '_') + '.nc',
        fecha: `${dd(ahora.getDate())}/${dd(ahora.getMonth() + 1)}/${ahora.getFullYear()} ${dd(ahora.getHours())}:${dd(ahora.getMinutes())}`,
        programa, lineas: programa.split('\n').length, errores: 0, avisos: 0, plano: null,
        tutor: { tipo: TU.ejercicio ? 'ejercicio' : 'libre', coord: tuCoord(), comp: tuComp(), total, bien: p.bien, ayuda: p.ayuda, vistas: p.vistas,
                 pistas: p.pistas || 0, fallos: p.fallos, nota: tuNotaPractica(p, total), cats, lineas } };
}
function tuAbrirInforme() {
    const p = TU.practica; if (!p || !p.fin) { snack('El informe se hace al terminar el programa'); return; }
    tuInf = tuDatosInforme();
    let guard = {}; try { guard = JSON.parse(localStorage.getItem('suiteCNC:alumno') || '{}') || {}; } catch (e) {}
    const g = id => document.getElementById(id);
    g('tuInfAlumno').value = guard.alumno || ''; g('tuInfGrupo').value = guard.grupo || ''; g('tuInfEjercicio').value = tuInf.ejercicio;
    tuInfImg = tuCapturaInforme();
    tuActualizarInforme();
    g('tuModalInforme').classList.add('visible'); setTimeout(() => g('tuInfAlumno').focus(), 50);
}
function tuCerrarInforme() { document.getElementById('tuModalInforme').classList.remove('visible'); }
// el dibujo con el recorrido del programa escrito, terminado
function tuCapturaInforme() {
    try {
        if (TU.sim) { tuPausa(); tuFin(); }
        render();
        const k = Math.min(1, 1400 / Math.max(1, cv.width)), c2 = document.createElement('canvas');
        c2.width = Math.max(1, Math.round(cv.width * k)); c2.height = Math.max(1, Math.round(cv.height * k));
        const g = c2.getContext('2d'); g.fillStyle = '#ffffff'; g.fillRect(0, 0, c2.width, c2.height); g.drawImage(cv, 0, 0, c2.width, c2.height);
        const url = c2.toDataURL('image/jpeg', 0.88), bin = atob(url.split(',')[1]), datos = new Uint8Array(bin.length);
        for (let i = 0; i < bin.length; i++) datos[i] = bin.charCodeAt(i);
        return { url, datos, w: c2.width, h: c2.height };
    } catch (e) { return null; }
}
function tuActualizarInforme() {
    const d = tuInf; if (!d) return;
    const g = id => document.getElementById(id), t = d.tutor;
    d.alumno = g('tuInfAlumno').value.trim().replace(/\s+/g, ' '); d.grupo = g('tuInfGrupo').value.trim(); d.ejercicio = g('tuInfEjercicio').value.trim();
    d.huella = huellaPrograma(d.programa); d.codigo = codigoInforme(d);
    const top = Object.entries(t.cats).sort((a, b) => b[1] - a[1]).slice(0, 3).map(([k, n]) => `${tuEsc(tuNombreCategoria(k))} (${n})`).join(', ');
    g('tuInfResumen').innerHTML = `<div><b>${t.bien}</b> de ${t.total} líneas a la primera · ${t.ayuda} con algún fallo · ${t.vistas} vistas · ${t.pistas} pistas · nota orientativa <b>${String(t.nota).replace('.', ',')}</b></div>`
        + `<div>${t.fallos ? `Intentos fallidos: <b>${t.fallos}</b>${top ? ' · más repetidos: ' + top : ''}` : 'Ningún intento fallido.'}</div>`
        + `<div class="tu-gris">${t.tipo === 'ejercicio' ? '🎓 Ejercicio del profesor' : 'Práctica libre'} · ${t.coord === 'mixta' ? 'mixta' : t.coord} · ${tuEsc(d.fecha)}</div>`
        + `<div class="tu-inf-cod">Código de comprobación <b>${d.codigo}</b></div>`;
    g('tuInfDescargar').disabled = !d.alumno;
    g('tuInfDescargar').title = d.alumno ? 'Descarga el PDF para subirlo a Aules' : 'Escribe antes tu nombre';
}
function tuDescargarInforme() {
    tuActualizarInforme(); const d = tuInf; if (!d || !d.alumno) { snack('Escribe tu nombre'); return; }
    try { localStorage.setItem('suiteCNC:alumno', JSON.stringify({ alumno: d.alumno, grupo: d.grupo })); } catch (e) {}
    let blob; try { blob = tuPDFInforme(d, tuInfImg); } catch (e) { console.error(e); snack('No se ha podido crear el PDF: ' + e.message); return; }
    const limpio = t => String(t).replace(/[\\/:*?"<>|]+/g, ' ').replace(/\s+/g, ' ').trim();
    const a = document.createElement('a'); a.href = URL.createObjectURL(blob);
    a.download = `Informe del Tutor - ${limpio(d.alumno)} - ${limpio(d.ejercicio || 'programa')}.pdf`;
    document.body.appendChild(a); a.click(); setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 2000);
    tuCerrarInforme(); snack(`Informe descargado (código ${d.codigo}). Súbelo a Aules`);
}
// PDF A4 con las fuentes estándar del lector (sin incrustar) y la imagen del dibujo, como el informe del Simulador
function tuPDFInforme(d, jpeg) {
    const W = 595.28, H = 841.89, M = 42, AZUL = '0 0.353 0.612', GRIS = '0.38 0.42 0.48', VERDE = '0.1 0.5 0.27', ROJO = '0.72 0.16 0.12', NARANJA = '0.72 0.42 0.02';
    const t = d.tutor, paginas = []; let c, y;
    const nueva = () => { c = []; paginas.push(c); y = H - M; };
    const txt = (x, yy, s, f = 'F1', tm = 10, col = '0.1 0.12 0.15') => c.push(`BT /${f} ${tm} Tf ${col} rg ${x.toFixed(2)} ${yy.toFixed(2)} Td (${pdfCadena(s)}) Tj ET`);
    const rect = (x, yy, w, h, rel, borde) => c.push(`${rel ? rel + ' rg ' : ''}${borde ? borde + ' RG 0.8 w ' : ''}${x.toFixed(2)} ${yy.toFixed(2)} ${w.toFixed(2)} ${h.toFixed(2)} re ${rel && borde ? 'B' : rel ? 'f' : 'S'}`);
    const sitio = h => { if (y - h < M + 24) { nueva(); return true; } return false; };
    const parrafo = (s, f = 'F1', tm = 9.5, col, sangria = 0, inter = 1.32) => infPartir(s, W - 2 * M - sangria, f, tm).forEach(l => { sitio(tm * inter); y -= tm * inter; txt(M + sangria, y, l, f, tm, col); });
    const titulo = s => { sitio(40); y -= 22; txt(M, y, s, 'F2', 12, AZUL); y -= 4; };
    nueva();
    // cabecera
    rect(0, H - 64, W, 64, AZUL);
    txt(M, H - 34, 'Informe de práctica', 'F2', 18, '1 1 1');
    txt(M, H - 51, `Tutor G-Code ${d.version || ''} · Suite CNC · Practicar`.replace(/\s+·/, ' ·'), 'F1', 9.5, '0.85 0.92 1');
    txt(W - M - infAncho(d.fecha, 'F2', 11), H - 34, d.fecha, 'F2', 11, '1 1 1');
    y = H - 64 - 22;
    const comp = { G40: 'sin compensación (G40)', auto: 'G41/G42 según el trazado', G41: 'G41', G42: 'G42' }[t.comp] || t.comp;
    [['Alumno/a', d.alumno || '—'], ['Grupo', d.grupo || '—'], ['Ejercicio', (d.ejercicio || '—') + (t.tipo === 'ejercicio' ? '  (ejercicio del profesor)' : '  (práctica libre)')],
     ['Programación', `${t.coord === 'mixta' ? 'mixta (G90 y G91)' : t.coord} · ${comp}`], ['Programa', `${t.total} líneas que escribir (${d.lineas} con los comentarios)`]]
        .forEach(([k, v]) => { txt(M, y, k, 'F1', 9.5, GRIS); infPartir(v, W - 2 * M - 110, k === 'Alumno/a' ? 'F2' : 'F1', 10.5).forEach((l, i) => { if (i) y -= 13; txt(M + 110, y, l, k === 'Alumno/a' ? 'F2' : 'F1', 10.5); }); y -= 15.5; });
    // resultado
    titulo('Resultado');
    const pc = n => t.total ? Math.round(100 * n / t.total) + ' %' : '';
    [[`A la primera`, `${t.bien} líneas (${pc(t.bien)})`, VERDE], [`Con algún fallo`, `${t.ayuda} líneas (${pc(t.ayuda)})`, NARANJA], [`Vistas («Ver la línea»)`, `${t.vistas} líneas (${pc(t.vistas)})`, ROJO],
     [`Pistas`, `${t.pistas}`, GRIS], [`Intentos fallidos`, `${t.fallos}`, t.fallos ? ROJO : VERDE], [`Nota orientativa`, `${String(t.nota).replace('.', ',')} / 10  (1 por línea a la primera y 0,5 con fallos, sobre 10)`, AZUL]]
        .forEach(([k, v, col]) => { sitio(16); y -= 15.5; txt(M, y, k, 'F1', 9.5, GRIS); txt(M + 150, y, v, 'F2', 10.5, col); });
    // dónde se ha equivocado más
    const cats = Object.entries(t.cats).sort((a, b) => b[1] - a[1]);
    titulo('Errores más repetidos');
    if (!cats.length) parrafo('Ningún intento fallido.', 'F2', 10.5, VERDE);
    cats.forEach(([k, n]) => {
        const ej = (() => { for (const l of t.lineas) for (const f of l.fallos) if (f.cat === k) return f; return null; })();
        sitio(30); y -= 15; txt(M, y, `${n} veces`.replace(/^1 veces$/, '1 vez'), 'F2', 10.5, ROJO); txt(M + 52, y, tuNombreCategoria(k), 'F2', 10.5);
        if (ej) parrafo(`Por ejemplo: «${ej.txt}» · ${ej.msg}`, 'F1', 8.5, GRIS, 52, 1.25);
    });
    // la imagen
    if (jpeg) {
        const maxW = W - 2 * M, maxH = 250, k = Math.min(maxW / jpeg.w, maxH / jpeg.h), iw = jpeg.w * k, ih = jpeg.h * k, ix = M + (maxW - iw) / 2;
        sitio(ih + 30); y -= 14 + ih; c.push(`q ${iw.toFixed(2)} 0 0 ${ih.toFixed(2)} ${ix.toFixed(2)} ${y.toFixed(2)} cm /Im1 Do Q`); rect(ix, y, iw, ih, null, '0.75 0.78 0.82');
        y -= 12; txt(M, y, 'El dibujo con el recorrido del programa escrito', 'F1', 8, GRIS);
    }
    // código de comprobación
    sitio(78); y -= 18;
    rect(M, y - 52, W - 2 * M, 52, '0.95 0.97 1', '0.55 0.68 0.82');
    txt(M + 12, y - 17, 'Código de comprobación', 'F1', 9, GRIS);
    txt(M + 12, y - 40, d.codigo, 'F4', 20, AZUL);
    infPartir(`Huella del programa: ${d.huella}. El profesor lo comprueba con el Corrector (Toda la clase). Si se cambia el programa o este informe, el código deja de coincidir.`, W - 2 * M - 250, 'F1', 8).forEach((l, i) => txt(M + 236, y - 15 - i * 10, l, 'F1', 8, GRIS));
    y -= 52;
    // línea a línea
    nueva(); txt(M, y - 4, 'Línea a línea', 'F2', 12, AZUL); y -= 12;
    parrafo('OK: a la primera · OK tras N: después de N intentos fallidos · vista: con «Ver la línea» · pista: con «Pista». Debajo de cada línea, sus intentos fallidos y lo que dijo el Tutor.', 'F1', 8.5, GRIS);
    y -= 4;
    const T = 8.6;
    t.lineas.forEach(l => {
        sitio(T * 1.4); y -= T * 1.45;
        const est = l.estado === 'bien' ? ['OK', VERDE] : l.estado === 'ayuda' ? [l.fallos.length ? `OK tras ${l.fallos.length}` : 'OK con pista', NARANJA] : l.estado === 'vistas' ? ['vista', ROJO] : ['—', GRIS];
        if (l.estado !== 'bien') rect(M - 2, y - 2.4, W - 2 * M + 4, T * 1.45, l.estado === 'vistas' ? '1 0.92 0.9' : '1 0.96 0.86');
        txt(M, y, String(l.n).padStart(3, ' '), 'F3', T, '0.55 0.58 0.62');
        txt(M + 24, y, String(l.txt).slice(0, 70), 'F3', T);
        txt(W - M - 70, y, est[0] + (l.pista && l.fallos.length ? ' · pista' : ''), 'F2', 8, est[1]);
        l.fallos.slice(0, 5).forEach(f => infPartir(`«${f.txt}» — ${f.msg}`, W - 2 * M - 40, 'F1', 7.8).forEach(s => { sitio(10); y -= 9.6; txt(M + 34, y, s, 'F1', 7.8, ROJO); }));
        if (l.fallos.length > 5) { sitio(10); y -= 9.6; txt(M + 34, y, `… y ${l.fallos.length - 5} intentos más`, 'F1', 7.8, GRIS); }
    });
    // el programa completo (el que se corrige)
    nueva(); txt(M, y - 4, 'Programa', 'F2', 12, AZUL); txt(M + 64, y - 4, d.archivo || '', 'F1', 9.5, GRIS); y -= 20;
    const TP = 8.4, maxCar = Math.floor((W - 2 * M - 34) / (0.6 * TP)), prog = d.programa.split('\n'), anchoN = String(prog.length).length;
    prog.forEach((l, i) => { for (let k = 0; k < Math.max(1, l.length); k += maxCar) { if (sitio(TP * 1.25)) y -= 6; y -= TP * 1.25; if (!k) txt(M, y, String(i + 1).padStart(anchoN, ' '), 'F3', TP, '0.55 0.58 0.62'); txt(M + 34, y, l.slice(k, k + maxCar), 'F3', TP); } });
    // pie de página
    paginas.forEach((pg, i) => { c = pg; c.push(`${GRIS} RG 0.5 w ${M} ${M - 4} m ${W - M} ${M - 4} l S`); txt(M, M - 16, `${d.alumno || ''} · ${d.ejercicio || ''}`.replace(/^ · | · $/g, ''), 'F1', 7.5, GRIS);
        const pie = `Código ${d.codigo} · página ${i + 1} de ${paginas.length}`; txt(W - M - infAncho(pie, 'F1', 7.5), M - 16, pie, 'F1', 7.5, GRIS); });
    // ensamblado (los datos van dentro, en /SuiteCNC, para que el Corrector los lea)
    const bytes = s => { const u = new Uint8Array(s.length); for (let i = 0; i < s.length; i++) u[i] = s.charCodeAt(i) & 255; return u; };
    const objs = [], partes = []; let pos = 0;
    const meter = u => { partes.push(u); pos += u.length; };
    const obj = (n, cuerpo, flujo) => { objs[n] = pos; meter(bytes(`${n} 0 obj\n${cuerpo}\n`)); if (flujo) { meter(bytes('stream\n')); meter(flujo); meter(bytes('\nendstream\n')); } meter(bytes('endobj\n')); };
    const nPag = paginas.length, primera = 9;
    const b64 = (() => { const u = new TextEncoder().encode(JSON.stringify(d)); let s = ''; for (let i = 0; i < u.length; i += 8192) s += String.fromCharCode.apply(null, u.subarray(i, i + 8192)); return btoa(s); })();
    meter(bytes('%PDF-1.4\n%\xe2\xe3\xcf\xd3\n'));
    obj(1, '<< /Type /Catalog /Pages 2 0 R >>');
    obj(2, `<< /Type /Pages /Count ${nPag} /Kids [${paginas.map((pg, i) => `${primera + 2 * i} 0 R`).join(' ')}] >>`);
    ['Helvetica', 'Helvetica-Bold', 'Courier', 'Courier-Bold'].forEach((f, i) => obj(3 + i, `<< /Type /Font /Subtype /Type1 /BaseFont /${f} /Encoding /WinAnsiEncoding >>`));
    if (jpeg) obj(7, `<< /Type /XObject /Subtype /Image /Width ${jpeg.w} /Height ${jpeg.h} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${jpeg.datos.length} >>`, jpeg.datos);
    else obj(7, '<< >>');
    obj(8, `<< /Title (${pdfCadena('Informe de práctica · ' + (d.ejercicio || ''))}) /Author (${pdfCadena(d.alumno || '')}) /Subject (${pdfCadena('Código de comprobación ' + d.codigo)}) /Creator (${pdfCadena('Tutor G-Code · Suite CNC')}) /SuiteCNC (${b64}) >>`);
    paginas.forEach((pg, i) => {
        const cont = bytes(pg.join('\n'));
        obj(primera + 2 * i, `<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${W} ${H}] /Resources << /Font << /F1 3 0 R /F2 4 0 R /F3 5 0 R /F4 6 0 R >>${jpeg ? ' /XObject << /Im1 7 0 R >>' : ''} >> /Contents ${primera + 2 * i + 1} 0 R >>`);
        obj(primera + 2 * i + 1, `<< /Length ${cont.length} >>`, cont);
    });
    const n = primera + 2 * nPag, xref = pos;
    let x = `xref\n0 ${n}\n0000000000 65535 f \n`; for (let i = 1; i < n; i++) x += String(objs[i]).padStart(10, '0') + ' 00000 n \n';
    meter(bytes(x + `trailer\n<< /Size ${n} /Root 1 0 R /Info 8 0 R >>\nstartxref\n${xref}\n%%EOF\n`));
    return new Blob(partes, { type: 'application/pdf' });
}
