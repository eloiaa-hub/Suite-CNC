"""Calcador v106 / Corrector v51: corrección masiva con las variantes de un examen (🎲 Variantes…).
Cada programa se corrige contra todas las variantes elegidas (de la carpeta Variantes de la biblioteca, o archivos JSON)
y se queda la que mejor encaja. Si el nombre del archivo, la carpeta del alumno o el principio del programa dicen qué
variante le tocaba («12B», «variante B»), se corrige con esa y se avisa si encaja mejor con otra; si dos encajan casi
igual, se avisa de que no está claro. La variante sale junto al nombre, en el CSV y en su informe (con su dibujo).
Uso: python3 variantes_masiva.py <carpeta de la suite>   (construir_calcador.sh lo pone tras editar_centro.py)"""
import sys, os
AQUI = os.path.dirname(os.path.abspath(__file__))
P = os.path.join(sys.argv[1] if len(sys.argv) > 1 else '.', 'calcador.html')
s = open(P, encoding='utf-8').read()
def rep(a, b, cnt=1):
    global s
    n = s.count(a); assert n == cnt, f'{n} apariciones (se esperaban {cnt}) de: {a[:100]}'
    s = s.replace(a, b)
JS = open(os.path.join(AQUI, 'variantes_masiva.js'), encoding='utf-8').read()
rep("// Arrastrar archivos a la ventana de corrección masiva; ordenar por columna", JS + "// Arrastrar archivos a la ventana de corrección masiva; ordenar por columna")
# el botón, junto a los del ejercicio
rep("""title="Abre el JSON del ejercicio: la lista se recorrige con esa pieza y sus requisitos">📂 Abrir ejercicio…</button>""",
    """title="Abre el JSON del ejercicio: la lista se recorrige con esa pieza y sus requisitos">📂 Abrir ejercicio…</button>
                <button class="btn-action sec" id="mvBtnVar" onclick="elegirVariantesMasiva()" title="Corregir con las variantes del examen (12A, 12B…): cada programa se corrige con todas y se queda la que mejor encaja; avisa si no es la que le tocaba">🎲 Variantes…</button>""")
rep("    .mv-inf { font-size:12px; cursor:help; }",
    """    .mv-var { display:inline-block; font-size:11px; font-weight:700; padding:0 5px; margin-left:4px; border-radius:4px; background:var(--accent-light); color:var(--accent); cursor:help; }
    .mv-var.mal { background:#fde3df; color:#b0301f; }
    #mvBtnVar.activo { background:var(--accent); color:#fff; border-color:var(--accent); }
    .var-carpeta { border:1px solid var(--border-color); border-radius:8px; padding:6px 10px; margin:6px 0; }
    .var-tit { display:block; margin-bottom:4px; } .var-item { display:block; margin-left:20px; font-size:13px; }
    .mv-inf { font-size:12px; cursor:help; }""")
# junto al nombre del alumno
rep("""${it.formato ? ` <span class="mv-inf mal" title="${esc(it.formato)}">📄⚠️</span>` : ''}</td>""",
    """${it.formato ? ` <span class="mv-inf mal" title="${esc(it.formato)}">📄⚠️</span>` : ''}${it.variante ? ` <span class="mv-var${it.varAviso ? ' mal' : ''}" title="${esc(it.varTxt + (it.varAviso ? ' · ⚠️ ' + it.varAviso : ''))}">${esc(it.variante)}${it.varAviso ? ' ⚠️' : ''}</span>` : ''}</td>""")
# CSV
rep("""'Informe de entrega', 'Formato del archivo', 'Observaciones']];""",
    """'Informe de entrega', 'Formato del archivo', ...(masiva.variantes.length ? ['Variante', 'Aviso de variante'] : []), 'Observaciones']];""")
rep("""(e => e ? e.txt : '')(estadoInforme(it)), it.formato || 'Correcto', obs]); });""",
    """(e => e ? e.txt : '')(estadoInforme(it)), it.formato || 'Correcto', ...(masiva.variantes.length ? [it.variante || '', it.varAviso || ''] : []), obs]); });""")
# informe de cada alumno
rep("""            ${it.formato ? `<div class="ar" style="margin:-4px 0 8px;color:#b0301f;font-weight:600">⚠️ ${esc(it.formato)}</div>` : ''}""",
    """            ${it.formato ? `<div class="ar" style="margin:-4px 0 8px;color:#b0301f;font-weight:600">⚠️ ${esc(it.formato)}</div>` : ''}
            ${it.variante ? `<div class="ar" style="margin:-4px 0 8px;${it.varAviso ? 'color:#b0301f;font-weight:600' : ''}">🎲 ${esc(it.varTxt)}${it.varAviso ? '<br>⚠️ ' + esc(it.varAviso) : ''}</div>` : ''}""")
# la ayuda
rep("""se corrige igual, pero se avisa de que el formato de archivo es incorrecto (📄⚠️ junto al nombre, en el resumen, en el CSV y en su informe).""",
    """se corrige igual, pero se avisa de que el formato de archivo es incorrecto (📄⚠️ junto al nombre, en el resumen, en el CSV y en su informe). Con <strong>🎲 Variantes…</strong> se corrige un examen con variantes (12A, 12B…): marca las variantes (de la carpeta Variantes de la biblioteca, o sus JSON) y cada programa se corrige con todas y se queda la que mejor encaja; la variante sale junto al nombre, en el CSV y en su informe. Si el nombre del archivo, la carpeta del alumno o un comentario al principio del programa dicen la variante que le tocaba («12B», «variante B»), se corrige con esa y se avisa (⚠️) si encaja mejor con otra; también si dos variantes encajan casi igual.""")
open(P, 'w', encoding='utf-8').write(s)
print('Calcador: corrección masiva con las variantes de un examen')
