"""Calcador v107 / Corrector v52: corrección masiva, 👥 programas muy parecidos entre alumnos.
Cuenta lo que solo comparten dos alumnos en la clase (las mismas líneas escritas igual sin contar los números de bloque,
trozos de comentario iguales y los mismos errores), con más peso cuanto más rara es la coincidencia. Marca 👥 junto al
nombre, la cuenta en el resumen, la ventana con las parejas y la comparación lado a lado, y la columna del CSV.
Uso: python3 parecidos_masiva.py <carpeta de la suite>   (construir_calcador.sh lo pone tras variantes_masiva.py)"""
import sys, os
AQUI = os.path.dirname(os.path.abspath(__file__))
P = os.path.join(sys.argv[1] if len(sys.argv) > 1 else '.', 'calcador.html')
s = open(P, encoding='utf-8').read()
def rep(a, b, cnt=1):
    global s
    n = s.count(a); assert n == cnt, f'{n} apariciones (se esperaban {cnt}) de: {a[:100]}'
    s = s.replace(a, b)
JS = open(os.path.join(AQUI, 'parecidos_masiva.js'), encoding='utf-8').read()
rep("// Arrastrar archivos a la ventana de corrección masiva; ordenar por columna", JS + "// Arrastrar archivos a la ventana de corrección masiva; ordenar por columna")
rep("""title="Resumen de la clase y una hoja por alumno">🖨 Informes de todos</button>""",
    """title="Resumen de la clase y una hoja por alumno">🖨 Informes de todos</button>
                <button class="btn-action sec" id="mvBtnPar" onclick="verParecidos()" title="Programas muy parecidos entre alumnos: las mismas líneas, comentarios o errores que no tiene nadie más en la clase (un indicio de copia, no una prueba)">👥 Parecidos</button>""")
rep("    .mv-inf { font-size:12px; cursor:help; }",
    """    .mv-par { font-size:12px; cursor:pointer; padding:0 3px; border-radius:4px; background:#fff1d6; }
    .mv-par.alto { background:#fde3df; }
    #mvBtnPar.activo { background:#b0301f; color:#fff; border-color:#b0301f; }
    .par-tabla { width:100%; border-collapse:collapse; font-size:13px; margin:6px 0 10px; } .par-tabla th, .par-tabla td { border-bottom:1px solid var(--border-color); padding:4px 6px; text-align:left; vertical-align:middle; }
    .par-tabla td.n { font-weight:700; color:#b07000; white-space:nowrap; } .par-tabla td.n.alto { color:#b0301f; } .par-tabla .btn-action { width:auto; padding:3px 10px; white-space:nowrap; }
    .par-ley { font-size:12px; color:var(--text-muted); margin:6px 0; } .par-ley i { display:inline-block; width:12px; height:12px; border-radius:2px; vertical-align:-2px; margin:0 3px 0 10px; }
    .par-lado { display:grid; grid-template-columns:1fr 1fr; gap:8px; }
    .par-col { min-width:0; border:1px solid var(--border-color); border-radius:6px; overflow:hidden; } .par-nom { padding:4px 8px; background:var(--accent-light); font-weight:600; font-size:13px; } .par-nom small { font-weight:400; color:var(--text-muted); }
    .par-prog { font:12px/1.45 ui-monospace, Consolas, monospace; max-height:420px; overflow:auto; padding:4px 0; } .par-prog div { padding:0 8px; white-space:pre; }
    .par-prog .ex, .par-ley i.ex { background:#f8c9c2; } .par-prog .cm, .par-ley i.cm { background:#f9e2a8; } .par-prog .co, .par-ley i.co { background:#e6e6e6; }
    .mv-inf { font-size:12px; cursor:help; }""")
# CSV: la columna «Parecido con» (si hay alguna pareja)
rep("""...(masiva.variantes.length ? ['Variante', 'Aviso de variante'] : []), 'Observaciones']];""",
    """...(masiva.variantes.length ? ['Variante', 'Aviso de variante'] : []), ...((masiva.parejas || []).length ? ['Parecido con'] : []), 'Observaciones']];""")
rep("""...(masiva.variantes.length ? [it.variante || '', it.varAviso || ''] : []), obs]); });""",
    """...(masiva.variantes.length ? [it.variante || '', it.varAviso || ''] : []), ...((masiva.parejas || []).length ? [(it.parecidos || []).length ? textoParecidos(it) : ''] : []), obs]); });""")
# la ayuda
rep("""también si dos variantes encajan casi igual.""",
    """también si dos variantes encajan casi igual. <strong>👥 Parecidos</strong> busca programas muy parecidos entre alumnos: como dos programas bien hechos de la misma pieza se parecen sin haberse copiado, solo cuenta lo que tienen esos dos y nadie más en la clase (las mismas líneas escritas igual aunque cambien los números de bloque, trozos de comentario iguales, los mismos errores). Sale 👥 junto al nombre, la ventana con las parejas y su porcentaje, la comparación lado a lado y la columna «Parecido con» del CSV. Es un indicio, no una prueba.""")
open(P, 'w', encoding='utf-8').write(s)
print('Calcador: corrección masiva, programas muy parecidos entre alumnos')
