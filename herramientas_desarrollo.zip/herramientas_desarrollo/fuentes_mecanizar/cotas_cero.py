#!/usr/bin/env python3
"""Calcador v127: las cotas automáticas se reparten como en Contornos sencillos: filas desde el cero pieza, por su lado.
Los archivos anteriores conservan el reparto por lados.
Uso: python3 cotas_cero.py CARPETA_DE_LA_SUITE (después de hoja_datos.py)."""
import os, re, sys
d = sys.argv[1] if len(sys.argv) > 1 else '.'
p = os.path.join(d, 'calcador.html'); s = open(p, encoding='utf-8').read()
def rep(a, b):
    global s
    assert s.count(a) == 1, (s.count(a), a[:80]); s = s.replace(a, b)
rep("let cfgCotas = { ver:false, nivel:'todo', incl:'proy',", "let cfgCotas = { ver:false, nivel:'todo', dist:'cero', incl:'proy',")
# opción en el panel
rep('''                    <div class="param-line">Rectas inclinadas
                        <select id="selIncl"''', '''                    <div class="param-line">Reparto
                        <select id="selDist" title="Cómo se organizan las cotas en el dibujo">
                            <option value="cero" selected>Desde el cero pieza</option>
                            <option value="lados">Por lados</option>
                        </select>
                    </div>
                    <div class="param-line">Rectas inclinadas
                        <select id="selIncl"''')
rep("document.getElementById('selIncl').addEventListener('change', e =>", "document.getElementById('selDist').addEventListener('change', e => { cfgCotas.dist = e.target.value; render(); guardarAuto(); });\ndocument.getElementById('selIncl').addEventListener('change', e =>")
rep("    document.getElementById('selIncl').value = cfgCotas.incl || 'proy';", "    document.getElementById('selDist').value = cfgCotas.dist || 'lados';\n    document.getElementById('selIncl').value = cfgCotas.incl || 'proy';")
rep("\ndocument.getElementById('selIncl').value = cfgCotas.incl || 'proy';", "\ndocument.getElementById('selDist').value = cfgCotas.dist || 'lados';\ndocument.getElementById('selIncl').value = cfgCotas.incl || 'proy';")
rep("['chkCotas', 'selNivelCotas', 'selIncl',", "['chkCotas', 'selNivelCotas', 'selDist', 'selIncl',")
# archivos anteriores: como se guardaron
rep("asignarCfg(snapCfg, d.snapCfg); asignarCfg(cfgCotas, d.cfgCotas);", "asignarCfg(snapCfg, d.snapCfg); asignarCfg(cfgCotas, d.cfgCotas); if (esObj(d.cfgCotas) && !d.cfgCotas.dist) cfgCotas.dist = 'lados';")
rep("if (esObj(d.calcador.cfgCotas)) { asignarCfg(cfgCotas, d.calcador.cfgCotas); sincronizarControlesCotas(); }", "if (esObj(d.calcador.cfgCotas)) { asignarCfg(cfgCotas, d.calcador.cfgCotas); if (!d.calcador.cfgCotas.dist) cfgCotas.dist = 'lados'; sincronizarControlesCotas(); }")
# clave y menú
rep("        case 'man': return `man|${r.id}`;", "        case 'man': return `man|${r.id}`;\n        case 'zc': return `zc|${r.eje}|${r.k}`;")
rep("""${ref.tipo !== 'cen' ? '<button id="ccEditar">✎ Cambiar la medida…</button>' : '<div class="ctx-nota">Cota de referencia (centro de arco)</div>'}""",
    """${ref.tipo === 'zc' ? '<div class="ctx-nota">Cota de situación: cambia el punto en el dibujo</div>' : ref.tipo !== 'cen' ? '<button id="ccEditar">✎ Cambiar la medida…</button>' : '<div class="ctx-nota">Cota de referencia (centro de arco)</div>'}""")
# el reparto
rep("    if (!opts.sinAuto) lista.forEach((c, i) => {\n        if (c.pts.length < 2 || c.texto || c.deTexto) return;\n        const circ = esCirculoContorno(c);",
r"""    // ── Reparto desde el cero (como Contornos sencillos): las situaciones, en filas por el lado del cero, de menor a mayor,
    //    y fuera del todo las medidas totales. Junto a cada elemento, solo lo suyo: radio, chaflán, cuerda, tamaño ──
    const modoCero = cfgCotas.dist === 'cero' && !!bb && !opts.sinAuto;
    const cotasDesdeCero = () => {
        const vivos = lista.map((c, i) => ({ c, i })).filter(o => o.c.pts.length >= 2 && !o.c.texto && !o.c.deTexto);
        const cand = vivos.filter(o => o.c.cerrado && tipos[o.i] !== 'interior' && !esCirculoContorno(o.c) && !esRanuraContorno(o.c));
        const area = o => { const q = bboxPts(o.c.pts); return (q.x1 - q.x0) * (q.y1 - q.y0); };
        const ex = cand.length ? cand.reduce((a, b) => area(b) > area(a) ? b : a) : null;
        const B = ex ? bboxPts(ex.c.pts) : bb, M = bboxPts([].concat(...vivos.map(o => muestrearContorno(o.c).concat(o.c.pts))));
        const zx = Math.abs(B.x0 - O.x) <= Math.abs(B.x1 - O.x) ? B.x0 : B.x1, zy = Math.abs(B.y0 - O.y) <= Math.abs(B.y1 - O.y) ? B.y0 : B.y1;
        const ox = zx === B.x0 ? B.x1 : B.x0, oy = zy === B.y0 ? B.y1 : B.y0, sx = zx === B.x0 ? -1 : 1, sy = zy === B.y0 ? -1 : 1;
        const Z = { x:zx, y:zy }, cx = (B.x0 + B.x1) / 2, cy = (B.y0 + B.y1) / 2, todo = nivel === 'todo', E = 1e-6;
        const fueraX = zx === B.x0 ? B.x0 - M.x0 : M.x1 - B.x1, fueraY = zy === B.y0 ? B.y0 - M.y0 : M.y1 - B.y1;
        const filaX = new Set(), filaY = new Set();
        const sitX = x => { if (todo && Math.abs(x - zx) > E && Math.abs(x - ox) > E) filaX.add(+x.toFixed(4)); };
        const sitY = y => { if (todo && Math.abs(y - zy) > E && Math.abs(y - oy) > E) filaY.add(+y.toFixed(4)); };
        const sit = q => { sitX(q.x); sitY(q.y); };
        const zc = (eje, k, valor) => ({ tipo:'zc', eje, k, valor });
        const medH = (A, C, y, k) => { if (todo && Math.abs(A.x - C.x) > E) cotaEntre(A, C, { x:A.x, y }, { x:C.x, y }, fmt(Math.abs(A.x - C.x)), zc('x', k, Math.abs(A.x - C.x)), true); };
        const medV = (A, C, x, k) => { if (todo && Math.abs(A.y - C.y) > E) cotaEntre(A, C, { x, y:A.y }, { x, y:C.y }, fmt(Math.abs(A.y - C.y)), zc('y', k, Math.abs(A.y - C.y)), true); };
        const radioCruz = (C, r, ang, ref, cruz2) => {
            if (cfgCotas.centros !== false) { ejes(C, 2.5); if (cruz2) ejes(cruz2, 2.5); }
            const e = { x:Math.cos(ang), y:Math.sin(ang) }, tip = add(C, mulv(e, r));
            grupo(ref, () => { linea(C, tip); flecha(tip, e); conHombro(tip, e, 'R' + fmt(r), ref); });
        };
        if (ex) {
            const ts = tramos(ex.c), n = ts.length, ci = ex.i, cerr = ex.c.cerrado;
            const vec = (t, o) => { const j = t.i + o; return (j >= 0 && j < n) || cerr ? ts[(j + n) % n] : null; };
            const esH = t => !t.b && Math.abs(t.p1.y - t.p2.y) < E, esV = t => !t.b && Math.abs(t.p1.x - t.p2.x) < E;
            const tang = (u1, u2) => { const a = tangenteFinal(u1.p1, u1.p2, u1.b), b = tangenteInicial(u2.p1, u2.p2, u2.b); return Math.abs(cross(a, b)) < .01 && dot(a, b) > 0; };
            const empalme = t => { const a = vec(t, -1), b = vec(t, 1); return !!t.b && a && b && !a.b && !b.b && tang(a, t) && tang(t, b); };
            const enLado = t => { const a = vec(t, -1), b = vec(t, 1); if (!t.b || !a || !b) return false; return (esH(a) && esH(b) && Math.abs(a.p1.y - b.p1.y) < E) || (esV(a) && esV(b) && Math.abs(a.p1.x - b.p1.x) < E); };
            const chaflan = t => { const a = vec(t, -1), b = vec(t, 1); return !t.b && !esH(t) && !esV(t) && a && b && ((esH(a) && esV(b)) || (esV(a) && esH(b))); };
            const corte = (a, b) => { const r = sub(a.p2, a.p1), q = sub(b.p2, b.p1), dn = cross(r, q); if (Math.abs(dn) < 1e-9) return null; return add(a.p1, mulv(r, cross(sub(b.p1, a.p1), q) / dn)); };
            ts.forEach(t => {
                if (!t.b) {
                    if (chaflan(t)) {
                        const a = vec(t, -1), b = vec(t, 1), C = corte(a, b), ph = esH(a) ? t.p1 : t.p2, pv = esH(a) ? t.p2 : t.p1, ax = C.x > cx ? 1 : -1, ay = C.y > cy ? 1 : -1;
                        medH(C, ph, C.y + ay * sep * .6, 'chH' + t.i); medV(C, pv, C.x + ax * sep * .6, 'chV' + t.i);
                        return;
                    }
                    if (esH(t)) sitY(t.p1.y); if (esV(t)) sitX(t.p1.x);
                    [[-1, t.p1], [1, t.p2]].forEach(([o, fin]) => {
                        const v = vec(t, o);
                        if (!v) { sit(fin); return; }
                        if (enLado(v)) return;
                        if (empalme(v) || chaflan(v)) { const w = vec(v, o); sit((w && corte(t, w)) || fin); return; }
                        sit(fin);
                    });
                    if (!esH(t) && !esV(t) && todo && cfgCotas.incl !== 'proy') {
                        const l = dist(t.p1, t.p2), w = norm(sub(t.p2, t.p1)), nOut = mulv({ x:w.y, y:-w.x }, areaFirmada(muestrearContorno(ex.c)) >= 0 ? 1 : -1);
                        alineada(t.p1, t.p2, nOut, sep, fmt(l), { tipo:'lin', ci, si:t.i, valor:l });
                        if (cfgCotas.incl === 'ang') anguloTramo(t, ci);
                    }
                    return;
                }
                const a = arcoDeBulge(t.p1, t.p2, t.b); if (!a) return;
                const lateral = enLado(t), hor = lateral && Math.abs(t.p1.y - t.p2.y) < E, am = a.a1 + a.theta / 2, descentrado = lateral && Math.abs(hor ? a.c.y - t.p1.y : a.c.x - t.p1.x) > E;
                radioCruz(a.c, a.r, am + (descentrado ? .2 : 0), { tipo:'rad', ci, sis:[t.i], valor:a.r });
                if (empalme(t)) return;       // redondeo: basta su radio
                if (!lateral) { sit(t.p1); sit(t.p2); if (cfgCotas.centros !== false) sit(a.c); return; }
                const m = { x:(t.p1.x + t.p2.x) / 2, y:(t.p1.y + t.p2.y) / 2 }, d0 = hor ? Math.abs(a.c.y - m.y) : Math.abs(a.c.x - m.x), cuerda = dist(t.p1, t.p2), conCuerda = d0 > E && Math.round(cuerda) % 4 === 0;
                const extra = sep * (conCuerda ? 1.7 : 1);
                if (hor) {
                    if (Math.abs(m.y - oy) < E) { const u0 = m.y > cy ? 1 : -1, sal = u0 > 0 ? M.y1 - B.y1 : B.y0 - M.y0; medH({ x:zx, y:m.y }, m, m.y + u0 * (sal + extra), 'sit' + t.i); } else sitX(m.x);
                } else {
                    if (Math.abs(m.x - ox) < E) { const u0 = m.x > cx ? 1 : -1, sal = u0 > 0 ? M.x1 - B.x1 : B.x0 - M.x0; medV({ x:m.x, y:zy }, m, m.x + u0 * (sal + extra), 'sit' + t.i); } else sitY(m.y);
                }
                if (d0 > E) {     // Pitágoras: la cuerda o la distancia al centro
                    const np = hor ? (m.y > cy ? 1 : -1) : (m.x > cx ? 1 : -1), lat = cuerda / 2 + sep * .8;
                    if (conCuerda) { if (hor) medH(t.p1, t.p2, m.y + np * sep * .8, 'cu' + t.i); else medV(t.p1, t.p2, m.x + np * sep * .8, 'cu' + t.i); }
                    else if (hor) medV(m, { x:m.x, y:a.c.y }, a.c.x + lat, 'dc' + t.i);
                    else medH(m, { x:a.c.x, y:m.y }, a.c.y + lat, 'dc' + t.i);
                }
            });
        }
        vivos.filter(o => o !== ex).forEach(({ c, i }) => {
            const circ = esCirculoContorno(c), ran = !circ && esRanuraContorno(c);
            if (circ) {
                sit(circ.c); if (cfgCotas.centros !== false) ejes(circ.c, 2.5);
                const ref = { tipo:'diam', ci:i, valor:2 * circ.r }, e = { x:Math.SQRT1_2, y:Math.SQRT1_2 }, q = sub(circ.c, mulv(e, circ.r)), tip = add(circ.c, mulv(e, circ.r));
                grupo(ref, () => { linea(q, tip); flecha(q, mulv(e, -1)); flecha(tip, e); conHombro(tip, e, 'Ø' + fmt(2 * circ.r), ref); });
                return;
            }
            if (ran) {
                const Zq = { x:zx, y:zy }, [c1, c2] = dist(ran.c1, Zq) <= dist(ran.c2, Zq) ? [ran.c1, ran.c2] : [ran.c2, ran.c1], hz = Math.abs(c1.y - c2.y) < E;
                const si = tramos(c).findIndex(t => t.b && dist(arcoDeBulge(t.p1, t.p2, t.b).c, c2) < E);
                sit(c1); if (cfgCotas.centros !== false) linea(c1, c2);
                radioCruz(c2, ran.r, hz ? (c2.x >= c1.x ? 0 : Math.PI) : (c2.y >= c1.y ? Math.PI / 2 : -Math.PI / 2), { tipo:'rad', ci:i, sis:[si < 0 ? 1 : si], valor:ran.r }, c1);
                if (hz) medH(c1, c2, c1.y + ran.r + sep * .6, 'ran' + i); else medV(c1, c2, c1.x + ran.r + sep * .6, 'ran' + i);
                return;
            }
            const q = bboxPts(muestrearContorno(c));
            sit({ x:Math.abs(q.x0 - zx) <= Math.abs(q.x1 - zx) ? q.x0 : q.x1, y:Math.abs(q.y0 - zy) <= Math.abs(q.y1 - zy) ? q.y0 : q.y1 });
            medH({ x:q.x0, y:q.y1 }, { x:q.x1, y:q.y1 }, q.y1 + sep * .6, 'an' + i); medV({ x:q.x1, y:q.y0 }, { x:q.x1, y:q.y1 }, q.x1 + sep * .6, 'al' + i);
            const radios = new Map();
            tramos(c).forEach(t => { if (!t.b) return; const a = arcoDeBulge(t.p1, t.p2, t.b); if (!a) return; const k = a.r.toFixed(4); if (radios.has(k)) { radios.get(k).n++; radios.get(k).sis.push(t.i); } else radios.set(k, { a, n:1, sis:[t.i] }); });
            radios.forEach(({ a, n, sis }) => conHombro(a.apice, norm(sub(a.apice, a.c)), (n > 1 ? n + '×' : '') + 'R' + fmt(a.r), { tipo:'rad', ci:i, sis, valor:a.r }));
        });
        let dy = fueraY + sep * .9, dx = fueraX + sep * .9; const paso = sep * .85;
        [...filaX].sort((a, b) => Math.abs(a - zx) - Math.abs(b - zx)).forEach(x => { cotaEntre(Z, { x, y:zy }, { x:zx, y:zy + sy * dy }, { x, y:zy + sy * dy }, fmt(Math.abs(x - zx)), zc('x', 'f' + x.toFixed(3), Math.abs(x - zx)), true); dy += paso; });
        [...filaY].sort((a, b) => Math.abs(a - zy) - Math.abs(b - zy)).forEach(y => { cotaEntre(Z, { x:zx, y }, { x:zx + sx * dx, y:zy }, { x:zx + sx * dx, y }, fmt(Math.abs(y - zy)), zc('y', 'f' + y.toFixed(3), Math.abs(y - zy)), true); dx += paso; });
        const piv = { x:B.x0, y:B.y0 };
        cotaEntre(Z, { x:ox, y:zy }, { x:zx, y:zy + sy * dy }, { x:ox, y:zy + sy * dy }, fmt(B.x1 - B.x0), { tipo:'tot', eje:'x', piv, valor:B.x1 - B.x0 }, true);
        cotaEntre(Z, { x:zx, y:oy }, { x:zx + sx * dx, y:zy }, { x:zx + sx * dx, y:oy }, fmt(B.y1 - B.y0), { tipo:'tot', eje:'y', piv, valor:B.y1 - B.y0 }, true);
        return { x:dy, y:dx };
    };
    const fueraCero = modoCero ? cotasDesdeCero() : null;
    if (!opts.sinAuto && !modoCero) lista.forEach((c, i) => {
        if (c.pts.length < 2 || c.texto || c.deTexto) return;
        const circ = esCirculoContorno(c);""")
rep("    if (bb && !opts.sinAuto) {\n        const dT = sep *", "    if (fueraCero) { totalesFuera.x = fueraCero.x; totalesFuera.y = fueraCero.y; }\n    if (bb && !opts.sinAuto && !modoCero) {\n        const dT = sep *")
rep("const extraX = enCadena ? Math.max(extra, totalesFuera.x + sep * 1.2) : extra, extraY = enCadena ? Math.max(extra, totalesFuera.y + sep * 1.2) : extra;", "const extraX = enCadena || modoCero ? Math.max(extra, totalesFuera.x + sep * 1.2) : extra, extraY = enCadena || modoCero ? Math.max(extra, totalesFuera.y + sep * 1.2) : extra;")
rep("    if (cfgCotas.cadena !== false) evitarSolapesTextos(", "    if (cfgCotas.cadena !== false || modoCero) evitarSolapesTextos(")
# ayuda
rep("<p>Activa «Acotar automáticamente» en Dibujo: longitud de cada recta (por fuera de cada contorno; los lados paralelos iguales se acotan una sola vez),", "<p>Con <strong>Reparto: Desde el cero pieza</strong> (como en Contornos sencillos), las situaciones van en filas por el lado del cero, de menor a mayor, con los totales fuera; junto a cada elemento, solo lo suyo. <strong>Por lados</strong> es el reparto anterior, y los archivos antiguos lo conservan.</p>\n            <p>Activa «Acotar automáticamente» en Dibujo: longitud de cada recta (por fuera de cada contorno; los lados paralelos iguales se acotan una sola vez),")
m = re.search(r'vertical-align:middle">v(\d+)</span></span>', s); assert m
s = s.replace(m.group(0), m.group(0).replace('v' + m.group(1), 'v127'), 1)
open(p, 'w', encoding='utf-8').write(s); print('calcador.html: reparto de cotas desde el cero, v127')
