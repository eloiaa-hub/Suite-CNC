"""Calcador v105 / Corrector v50: la interfaz reordenada (probada antes como Calcador_Beta.html).
 1. Vista, arriba a la derecha del dibujo: ◧ ◨ │ 👁 Rejilla · 🏷 Nombres · 📏 Cotas (sincronizados con sus casillas).
 2. ↶ Deshacer, ↷ Rehacer, ⭘ Cerrar y ✓ Terminar, al pie de la barra de herramientas (se ven con los paneles ocultos).
 3. Pestaña Dibujo: «Cotas y marcas» y «Ajustar medidas» en desplegables, como Imanes y Comprobar con la fresa.
 4. Mecanizado: «Orden» en la misma fila que su desplegable; la casilla 📍 del programa, con texto («📍 Absolutas»).
 5. Arriba: 🖼 Fondo junto a Abrir y ⬇ Exportar ▾ (DXF, SVG y sus opciones) junto a Guardar; abajo a la izquierda, solo Fondo.
    «Cotas y marcas» y «Ajustar medidas», abiertos por defecto.
 7. «◠ Hacer arco» (A) con los puntos elegidos: un arco tangente a los tramos de al lado o por los puntos (hacer_arco.js).
 6. Herramienta nueva, «Seleccionar puntos» (doble flecha, tecla I): ventana para elegir vértices y Supr para borrarlos (seleccionar_puntos.py).
Uso: python3 interfaz_ordenada.py <carpeta de la suite>   (después de interfaz_paneles.py y antes de construir_corrector.py)
En el Corrector (data-visor) solo cambian los botones de vista: sin barra de herramientas, sin Dibujo y con su Exportar."""
import sys, os
D = sys.argv[1] if len(sys.argv) > 1 else '.'
OUT = os.path.join(D, 'calcador.html')
s = open(os.path.join(D, 'calcador.html'), encoding='utf-8').read()
def rep(a, b, cnt=1):
    global s
    n = s.count(a); assert n == cnt, f'{n} apariciones (se esperaban {cnt}) de: {a[:100]}'
    s = s.replace(a, b)
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from seleccionar_puntos import rep_puntos
s = rep_puntos(s)
import re
CSS = """
    /* ═══ Interfaz ordenada (v105) ═══ */
    .vista-controls .vsep { width: 8px; }
    #btnVerNombres.visible, #btnVerCotas.visible { background: var(--accent); color: #fff; border-color: var(--accent); }
    .tool-strip .tool-acc { border: none; background: transparent; color: var(--text-main); border-radius: 5px; font-size: 16px; padding: 0; cursor: pointer; }
    .tool-strip .tool-acc:hover:not(:disabled) { background: var(--accent-light); color: var(--accent); }
    .tool-strip .tool-acc:disabled { opacity: .3; cursor: default; }
    .c2-cotas > .param-line, .c2-ajuste > .param-line { margin-top: 5px; }
    .c2-cotas > button, .c2-ajuste > button { margin-top: 7px; width: 100%; }
    .tu-mec-grid label[for=tuOrden] { grid-column: 1; }
    #btnHacerArco { position: absolute; z-index: 6; background: var(--accent); color: #fff; border-color: var(--accent); font-weight: 600; box-shadow: 0 3px 10px rgba(0,0,0,.18); }
    .exp-menu { position: relative; display: inline-flex; }
    .exp-lista { position: absolute; top: calc(100% + 6px); left: 0; z-index: 200; background: var(--bg-panel); border: 1px solid var(--border-color); border-radius: 6px;
        box-shadow: 0 8px 24px rgba(0,0,0,.18); padding: 8px; display: grid; grid-template-columns: 1fr 1fr; gap: 6px; width: 290px; }
    .exp-lista[hidden] { display: none; }
    .exp-lista .c2-opciones { grid-column: 1 / 3; }
    #c2Tabs3.solo-fondo button { flex: 0 0 100%; cursor: default; }
"""
rep('</style>\n</head>', CSS + '</style>\n</head>')
rep('<label title="En las líneas en G91, el punto en el que queda la fresa (en absolutas)"><input id="tuAbs" type="checkbox"> 📍</label>',
    '<label title="En las líneas en G91, el punto en el que queda la fresa (en absolutas)"><input id="tuAbs" type="checkbox"> 📍 Absolutas</label>')
JS = r"""
// ═══ Interfaz ordenada (v105), después de que la interfaz del Calcador haya montado las pestañas ═══
window.addEventListener('load', () => setTimeout(() => {
    const $ = id => document.getElementById(id), VIS = document.documentElement.dataset.visor === '1';
    // 1) Vista: 🏷 Nombres y 📏 Cotas, junto a 👁 Rejilla (las casillas de siempre siguen y van a la par)
    const vc = document.querySelector('.vista-controls');
    if (vc) {
        const sep = document.createElement('span'); sep.className = 'vsep'; vc.insertBefore(sep, $('btnVerRejilla'));
        const boton = (id, txt, chk, tOn, tOff) => { const b = document.createElement('div'); b.className = 'zoom-btn btn-vista'; b.id = id; b.textContent = txt;
            b.onclick = () => { const c = $(chk); if (c) c.click(); pintar(); }; vc.appendChild(b); return () => { const c = $(chk), on = !!(c && c.checked); b.classList.toggle('visible', on); b.title = on ? tOn : tOff; }; };
        const p1 = boton('btnVerNombres', '🏷 Nombres', 'tuNombres', 'Ocultar los nombres de los puntos (P1, P2… A1…)', 'Ver los nombres de los puntos (P1, P2… A1…)');
        const p2 = boton('btnVerCotas', '📏 Cotas', 'chkCotas', 'Ocultar las cotas automáticas («Acotar automáticamente»)', 'Ver las cotas automáticas («Acotar automáticamente»)');
        function pintar() { p1(); p2(); }
        ['tuNombres', 'chkCotas'].forEach(id => { const c = $(id); if (c) c.addEventListener('change', pintar); });
        pintar(); setInterval(pintar, 600);      // también cuando cambian al abrir un ejercicio
    }
    // 2) Deshacer, Rehacer, Cerrar y Terminar, al pie de la barra de herramientas
    const st = $('toolStrip'), dibP = $('c2PaneDib');
    if (st && dibP && !VIS) {
        const div = document.createElement('div'); div.className = 'tool-divider'; st.appendChild(div);
        const mover = (el, ico, tip) => { if (!el) return; el.className = 'tool-btn tool-acc'; el.textContent = ico; el.title = tip; el.dataset.tip = tip; st.appendChild(el); };
        mover(dibP.querySelector('button[onclick="deshacer()"]'), '↶', 'Deshacer (Ctrl+Z)');
        mover(dibP.querySelector('button[onclick="rehacer()"]'), '↷', 'Rehacer (Ctrl+Y)');
        mover($('btnCerrar'), '⭘', 'Cerrar: une el último punto con el primero');
        mover($('btnTerminar'), '✓', 'Terminar: deja el contorno abierto (Esc)');
        dibP.querySelectorAll(':scope > .btn-row').forEach(r => { if (!r.children.length) r.remove(); });
        try { ajustarBarraHerramientas(); } catch (e) {}
    }
    // 3) Dibujo: «Cotas y marcas» y «Ajustar medidas» plegados
    if (dibP && !VIS) {
        const det = (cls, titulo) => { const d = document.createElement('details'); d.className = 'c2-opciones ' + cls; d.innerHTML = '<summary>' + titulo + '</summary>'; return d; };
        const cotas = det('c2-cotas', 'Cotas y marcas'), linea = id => { const e = $(id); return e && e.closest('.param-line'); };
        ['chkCotas', 'selNivelCotas', 'selIncl', 'chkCero', 'chkEntrada', 'chkSentido', 'chkCentros', 'chkCadena', 'chkVerOcultas'].forEach(id => { const l = linea(id); if (l) cotas.appendChild(l); });
        const rest = dibP.querySelector('button[onclick="restaurarCotas()"]'); if (rest) cotas.appendChild(rest);
        const aj = dibP.querySelector('.ajuste-box'), ajuste = det('c2-ajuste', 'Ajustar medidas');
        if (aj) { [...aj.children].forEach(ch => ajuste.appendChild(ch)); aj.remove(); }
        cotas.open = true; ajuste.open = true;       // abiertos por defecto (se usan mucho); se pueden plegar
        dibP.appendChild(cotas); dibP.appendChild(ajuste);
    }
    // 5) Barra de arriba: 🖼 Fondo (junto a Abrir) y ⬇ Exportar ▾ (junto a Guardar); la pestaña Exportar desaparece
    const barra = document.querySelector('.c2-archivo');
    if (barra && !VIS) {
        const bAbrir = [...barra.children].find(b => /Abrir/.test(b.textContent)), bGuardar = [...barra.children].find(b => /Guardar/.test(b.textContent));
        const bf = document.createElement('button'); bf.className = 'btn-manual'; bf.textContent = '🖼 Fondo';
        bf.title = 'Carga el plano a calcar (foto o imagen PNG/JPG, SVG o DXF). Sus ajustes —opacidad, ancho real, calibrar, vectorizar…— están en la pestaña Fondo del panel izquierdo';
        bf.onclick = () => $('fileFondo').click();
        if (bAbrir) bAbrir.after(bf);
        // al cargar el fondo, se enseñan sus ajustes
        const ff = $('fileFondo'); if (ff) ff.addEventListener('change', () => setTimeout(() => {
            if (document.documentElement.classList.contains('sin-izq') && typeof alternarPanel === 'function') alternarPanel('izq', false);
            const t = document.querySelector('button[data-p="c2PaneFondo"]'); if (t) t.click();
            const pf2 = $('c2PaneFondo'); if (pf2) pf2.scrollIntoView({ block: 'nearest', behavior: 'smooth' }); }, 300));
        const caja = document.createElement('span'); caja.className = 'exp-menu';
        caja.innerHTML = '<button class="btn-manual" id="btnExportar" title="El dibujo en DXF o SVG (para CAD, corte o grabado), con sus opciones">⬇ Exportar ▾</button><div class="exp-lista" id="expLista" hidden>'
            + '<button class="btn-action sec" onclick="exportarDXF(); cerrarExpMenu()">⬇ DXF</button><button class="btn-action sec" onclick="exportarSVG(); cerrarExpMenu()">⬇ SVG</button></div>';
        if (bGuardar) bGuardar.after(caja);
        const lista = $('expLista'), op = $('c2Opciones'); if (op) lista.appendChild(op);
        window.cerrarExpMenu = () => { lista.hidden = true; };
        $('btnExportar').onclick = e => { e.stopPropagation(); lista.hidden = !lista.hidden; };
        document.addEventListener('pointerdown', e => { if (!lista.hidden && !caja.contains(e.target)) lista.hidden = true; });
        document.addEventListener('keydown', e => { if (e.key === 'Escape') lista.hidden = true; });
        // abajo, en el panel izquierdo, solo queda Fondo
        const t3 = $('c2Tabs3'), pf = $('c2PaneFondo'), pe = $('c2PaneExp');
        if (t3 && pf) { const tf = t3.querySelector('button[data-p="c2PaneFondo"]'); if (tf) tf.click(); const te = t3.querySelector('button[data-p="c2PaneExp"]'); if (te) te.remove(); t3.classList.add('solo-fondo'); }
        if (pe) pe.hidden = true;
    }
}, 60));
"""
rep("La barra de herramientas se ve siempre, y el dibujo se encuadra para llenar la zona.</p>",
    "Junto a ellos, <strong>🏷 Nombres</strong> y <strong>📏 Cotas</strong> enseñan u ocultan los nombres de los puntos y las cotas automáticas. La barra de herramientas se ve siempre, con ↶ ↷ (deshacer, rehacer) y ⭘ ✓ (cerrar, terminar) al pie, y el dibujo se encuadra para llenar la zona. En la barra superior, <strong>🖼 Fondo</strong> carga el plano a calcar y <strong>⬇ Exportar ▾</strong> guarda el DXF o el SVG.</p>")
i = s.rindex('</body>'); s = s[:i] + '<script>' + JS + '</script>\n' + s[i:]
open(OUT, 'w', encoding='utf-8').write(s)
print('Calcador: interfaz ordenada (vista, deshacer en la barra, Dibujo en desplegables, Fondo y Exportar arriba, seleccionar puntos y hacer arco)')
