// ── Avisar de los códigos que no se han dado en clase (no baja la nota) ──
// G y M que no están en la lista de clase (configurable, se guarda en el navegador), el número de programa (O1000) y «%»,
// la D (en clase no se escribe), la herramienta con otro formato (T1, T1 M6 → T101 M06) y el husillo al revés (M03 S12000 → S12000 M03).
const CODIGOS_CLASE_DEF = 'G0 G1 G2 G3 G15 G16 G17 G18 G19 G40 G41 G42 G70 G71 G73 G80 G81 G82 G83 G90 G91 G98 G99 M2 M3 M4 M5 M6 M30';
const CODIGOS_CLASE_CLAVE = 'calcador_codigos_clase';
const cfgClase = (() => { try { const v = JSON.parse(localStorage.getItem(CODIGOS_CLASE_CLAVE) || 'null'); if (v && typeof v === 'object') return { activo: v.activo !== false, codigos: String(v.codigos || CODIGOS_CLASE_DEF) }; } catch (e) {} return { activo: true, codigos: CODIGOS_CLASE_DEF }; })();
function guardarCfgClase() { try { localStorage.setItem(CODIGOS_CLASE_CLAVE, JSON.stringify(cfgClase)); } catch (e) {} }
const normCod = w => { const m = /^([GM])0*(\d+)(?:\.(\d+))?$/i.exec(w); return m ? m[1].toUpperCase() + m[2] + (m[3] && +m[3] ? '.' + m[3] : '') : w.toUpperCase(); };
const codigosClase = () => new Set(String(cfgClase.codigos).split(/[\s,;]+/).filter(Boolean).map(normCod));
const QUE_ES = { G4: 'pausa', G20: 'pulgadas (en clase, G70)', G21: 'milímetros (en clase, G71)', G28: 'volver al punto de referencia', G43: 'compensación de longitud de la herramienta', G44: 'compensación de longitud',
    G49: 'anular la compensación de longitud', G53: 'coordenadas de máquina', G54: 'origen de pieza (en clase, el cero pieza del plano)', G55: 'origen de pieza', G56: 'origen de pieza', G57: 'origen de pieza', G92: 'cambiar el origen',
    G94: 'avance por minuto', G95: 'avance por vuelta', G61: 'parada exacta', G64: 'modo continuo', G68: 'giro de coordenadas', G69: 'anular el giro', M0: 'parada', M1: 'parada opcional', M7: 'refrigerante', M8: 'refrigerante', M9: 'parar el refrigerante', M19: 'orientar el husillo', M98: 'llamada a subprograma', M99: 'fin de subprograma' };
function avisosClase(texto) {
    const lineas = String(texto || '').replace(/\r/g, '').split('\n'), set = codigosClase(), porCod = new Map(), otros = [];
    const apunta = (clave, li, et, msg) => { if (!porCod.has(clave)) porCod.set(clave, { li, et, msg, n: 0 }); porCod.get(clave).n++; };
    lineas.forEach((l0, li) => {
        const l = l0.replace(/\([^)]*\)/g, ' ').replace(/;.*$/, '').trim().toUpperCase(); if (!l) return;
        const nW = /^N\s*(\d+)/.exec(l), et = nW ? 'N' + nW[1] : 'línea ' + (li + 1);
        if (/^%/.test(l)) { apunta('%', li, et, '«%» al principio o al final del programa no se ha dado en clase (es de otras máquinas).'); return; }
        if (/^O\d+/.test(l)) apunta('O', li, et, `${/^O\d+/.exec(l)[0]}: el número de programa no se ha dado en clase (el programa empieza con su nombre entre paréntesis).`);
        const W = l.match(/[A-Z][-+]?\d*\.?\d*/g) || [];
        W.forEach(w => {
            if (/^[GM]\d/.test(w)) { const c = normCod(w); if (!set.has(c)) apunta(c, li, et, `${w}${QUE_ES[c] ? ` (${QUE_ES[c]})` : ''}: no está entre los códigos dados en clase.`); }
            else if (/^D\d/.test(w)) apunta('D', li, et, `${w}: en clase no se escribe D (el radio de la fresa lo sabe la máquina por la herramienta T…).`);
        });
        const T = W.find(w => /^T\d/.test(w)), M6 = W.some(w => /^M0*6$/.test(w));
        if (T && (!/^T\d{3,}$/.test(T) || !M6)) apunta('T', li, et, `${W.filter(w => /^T\d|^M0*6$/.test(w)).join(' ')}: en clase, el cambio de herramienta se escribe así: T101 M06 (la T con tres cifras y M06 en la misma línea).`);
        const iS = W.findIndex(w => /^S\d/.test(w)), iM = W.findIndex(w => /^M0*[34]$/.test(w));
        if (iS >= 0 && iM >= 0 && iM < iS) apunta('S', li, et, `${W[iM]} ${W[iS]}: en clase se escribe primero la velocidad y después el giro: ${W[iS]} M0${W[iM].replace(/^M0*/, '')}.`);
    });
    return [...porCod.values()].map(x => ({ tipo: 'aviso', cat: 'clase', linea: x.li, msg: `${x.et}: ${x.msg}${x.n > 1 ? ` (y ${x.n - 1} vez${x.n - 1 === 1 ? '' : 'es'} más)` : ''}` }));
}
const _corregirProgramaClase = corregirPrograma;
corregirPrograma = function (texto) {
    const r = _corregirProgramaClase.apply(this, arguments);
    if (cfgClase.activo && r && !r.error && Array.isArray(r.hallazgos)) {
        const A = avisosClase(texto); if (A.length) { r.hallazgos.push(...A); if (typeof r.avisos === 'number') r.avisos += A.length; }
    }
    return r;
};
function editarCodigosClase() {
    let ov = document.getElementById('modalCodClase');
    if (!ov) { ov = document.createElement('div'); ov.className = 'modal-overlay'; ov.id = 'modalCodClase'; ov.onclick = e => { if (e.target === ov) ov.classList.remove('visible'); }; document.body.appendChild(ov); }
    ov.innerHTML = `<div class="help-modal" style="width:min(560px,100%)"><div class="help-header"><h2>✎ Códigos dados en clase</h2><button class="help-close" onclick="document.getElementById('modalCodClase').classList.remove('visible')">✕</button></div>
        <div class="help-content"><p class="ctx-nota" style="margin-top:0">El Corrector avisa (sin bajar la nota) de las G y M que no están en esta lista, del número de programa (O1000) y «%», de la D, de la herramienta escrita de otra forma que <b>T101 M06</b> y del husillo escrito <b>M03 S12000</b> en lugar de <b>S12000 M03</b>.</p>
        <label class="aules-op"><input type="checkbox" id="ccActivo" ${cfgClase.activo ? 'checked' : ''}> Avisar de los códigos no dados en clase</label>
        <textarea id="ccLista" rows="4" style="width:100%;box-sizing:border-box;margin-top:8px;font:13px/1.5 Consolas,monospace;padding:6px 8px;border:1px solid var(--border-color);border-radius:6px">${cfgClase.codigos}</textarea>
        <p class="ctx-nota">Separados por espacios. G01 y G1 son el mismo código. Se guarda en este navegador, para todos los ejercicios.</p>
        <div class="btn-row"><button class="btn-action sec" id="ccDef">Volver a la lista de partida</button><button class="btn-action" id="ccOk">Guardar y recorregir</button></div></div></div>`;
    ov.querySelector('#ccDef').onclick = () => { ov.querySelector('#ccLista').value = CODIGOS_CLASE_DEF; };
    ov.querySelector('#ccOk').onclick = () => { cfgClase.activo = ov.querySelector('#ccActivo').checked; cfgClase.codigos = ov.querySelector('#ccLista').value.trim() || CODIGOS_CLASE_DEF; guardarCfgClase();
        const c = document.getElementById('mvClase'); if (c) c.checked = cfgClase.activo; ov.classList.remove('visible');
        if (typeof recorregirMasiva === 'function' && masiva.lista.length) recorregirMasiva(); if (document.getElementById('crTexto') && document.getElementById('crTexto').value.trim() && typeof ejecutarCorreccion === 'function') try { ejecutarCorreccion(); } catch (e) {}
        snack(cfgClase.activo ? 'Códigos de clase guardados' : 'Sin avisos de códigos no dados en clase'); };
    ov.classList.add('visible');
}
function cambiarAvisoClase(chk) { cfgClase.activo = chk.checked; guardarCfgClase(); if (masiva.lista.length) recorregirMasiva(); }
