// ── 📊 Los errores más repetidos de la clase ──
// Los errores y avisos de toda la corrección masiva, juntando los del mismo tipo (sin las coordenadas, los números de
// bloque ni el código citado), ordenados por cuántos alumnos los tienen: qué repasar en la próxima clase.
function claveError(h) {
    return String(h.msg).replace(/«[^»]*»/g, '').replace(/^\s*(N\d+|l[ií]nea \d+|Al final)\s*:\s*/i, '').replace(/\b(N\d+|l[ií]nea \d+)\b/gi, '#')
        .replace(/\b[A-Z]-?\d+(\.\d+)?\b/g, m => /^[GMT]\d/.test(m) ? m.replace(/^([GM])0*(\d)/, '$1$2') : '#').replace(/-?\d+([.,]\d+)?/g, '#')
        .replace(/\(y # (vez|veces|bloques?) más\)/g, '').replace(/\s+/g, ' ').replace(/\s+([.,:;])/g, '$1').trim();
}
function erroresClase(items) {
    const G = new Map();
    (items || masiva.lista).forEach(it => {
        if (!it.r || !it.r.hallazgos || !it.v || it.v.veredicto === 'pendiente') return;
        const vistos = new Set();
        it.r.hallazgos.forEach(h => {
            if (h.resumen || (h.tipo !== 'error' && h.tipo !== 'aviso')) return;
            const k = h.tipo + '|' + claveError(h); if (vistos.has(k)) return; vistos.add(k);
            if (!G.has(k)) G.set(k, { tipo: h.tipo, cat: h.cat || '', titulo: String(h.msg).replace(/^\s*(N\d+|l[ií]nea \d+)\s*:\s*/i, '').replace(/\s*\(y \d+ (vez|veces) más\)/, ''), ejemplo: h.msg, pista: h.pista || '', alumnos: [] });
            G.get(k).alumnos.push(it.alumno);
        });
    });
    return [...G.values()].sort((a, b) => b.alumnos.length - a.alumnos.length || (a.tipo === 'error' ? -1 : 1) - (b.tipo === 'error' ? -1 : 1));
}
const CAT_ERR = { geometria: 'Geometría', compensacion: 'Compensación', requisito: 'Lo pedido', herramienta: 'Herramienta', seguridad: 'Seguridad', clase: 'Códigos de clase' };
function tablaErroresClase(sel, max) {
    const its = (sel || masiva.lista.map((_, k) => k)).map(k => masiva.lista[k]).filter(Boolean), E = erroresClase(its).filter(e => e.alumnos.length >= 2).slice(0, max || 12);
    if (!E.length) return '';
    const esc = t => String(t).replace(/&/g, '&amp;').replace(/</g, '&lt;');
    return `<h2>Los errores más repetidos</h2><table class="tr err-clase"><tr><th>Alumnos</th><th>Error o aviso</th><th>Quiénes</th></tr>${E.map(e => `<tr><td class="n"><b>${e.alumnos.length}</b> de ${its.length}</td><td><span style="color:${e.tipo === 'error' ? '#b0301f' : '#a86b00'}">${e.tipo === 'error' ? 'Error' : 'Aviso'}${CAT_ERR[e.cat] ? ' · ' + CAT_ERR[e.cat] : ''}</span> — ${esc(e.titulo)}${e.pista ? `<br><i>Pista: ${esc(e.pista)}</i>` : ''}</td><td style="font-size:85%">${esc(e.alumnos.join(', '))}</td></tr>`).join('')}</table>`;
}
function verErroresClase() {
    if (!masiva.lista.length) { snack('No hay programas en la lista'); return; }
    let ov = document.getElementById('modalErrClase');
    if (!ov) { ov = document.createElement('div'); ov.className = 'modal-overlay'; ov.id = 'modalErrClase'; ov.onclick = e => { if (e.target === ov) ov.classList.remove('visible'); }; document.body.appendChild(ov); }
    const E = erroresClase(), n = masiva.lista.filter(it => it.r && it.v && it.v.veredicto !== 'pendiente').length, esc = t => String(t).replace(/&/g, '&amp;').replace(/</g, '&lt;');
    let filtro = 'todos';
    const pintar = () => {
        const L = E.filter(e => filtro === 'todos' || e.tipo === filtro);
        ov.querySelector('#errLista').innerHTML = L.length ? `<table class="par-tabla err-tabla"><tr><th>Alumnos</th><th>Error o aviso</th></tr>${L.map((e, i) => `<tr><td class="n">${e.alumnos.length}<small> de ${n}</small><div class="err-barra"><i style="width:${Math.round(e.alumnos.length / n * 100)}%;background:${e.tipo === 'error' ? '#d83a3a' : '#e0a21e'}"></i></div></td>
            <td><span class="err-tipo ${e.tipo}">${e.tipo === 'error' ? 'Error' : 'Aviso'}${CAT_ERR[e.cat] ? ' · ' + CAT_ERR[e.cat] : ''}</span> ${esc(e.titulo)}${e.pista ? `<div class="ctx-nota" style="margin:2px 0 0">💡 ${esc(e.pista)}</div>` : ''}
            <details><summary>${e.alumnos.length === 1 ? '1 alumno' : e.alumnos.length + ' alumnos'}</summary><div class="ctx-nota" style="margin:2px 0">${esc(e.alumnos.join(', '))}</div><div class="ctx-nota" style="margin:2px 0">(El texto es el del primero; en los demás puede ser en otra línea o con otros valores.)</div></details></td></tr>`).join('')}</table>`
            : '<p>Ningún error ni aviso. 🎉</p>';
    };
    ov.innerHTML = `<div class="help-modal" style="width:min(820px,100%)"><div class="help-header"><h2>📊 Los errores más repetidos de la clase</h2><button class="help-close" onclick="document.getElementById('modalErrClase').classList.remove('visible')">✕</button></div>
        <div class="help-content"><p class="ctx-nota" style="margin-top:0">${n} programas corregidos. Se juntan los errores del mismo tipo aunque sean en otra línea o con otras coordenadas: lo que más se repite es lo que conviene repasar en clase.</p>
        <div class="btn-row"><label class="aules-op" style="display:inline"><input type="radio" name="errF" value="todos" checked> Todos</label> <label class="aules-op" style="display:inline"><input type="radio" name="errF" value="error"> Solo errores</label> <label class="aules-op" style="display:inline"><input type="radio" name="errF" value="aviso"> Solo avisos</label>
        <button class="btn-action sec" id="errImp" style="margin-left:auto;width:auto">🖨 Imprimir</button></div>
        <div id="errLista"></div></div></div>`;
    ov.querySelectorAll('input[name="errF"]').forEach(r => r.onchange = () => { filtro = r.value; pintar(); });
    ov.querySelector('#errImp').onclick = () => {
        const w = window.open('', '_blank'); if (!w) { snack('El navegador ha bloqueado la ventana de impresión: permite las ventanas emergentes para este archivo'); return; }
        const L = E.filter(e => filtro === 'todos' || e.tipo === filtro);
        w.document.open(); w.document.write(`<!DOCTYPE html><html lang="es"><head><meta charset="utf-8"><title>Errores más repetidos — ${esc(cfgHoja.titulo || nombreProyecto())}</title><style>
            @page { size: A4; margin: 12mm; } body { font: 10pt/1.35 Arial, sans-serif; color: #222; } h1 { font-size: 15pt; margin: 0 0 4px; } table { width: 100%; border-collapse: collapse; }
            th, td { border-bottom: 1px solid #ccc; padding: 4px 6px; text-align: left; vertical-align: top; } td.n { white-space: nowrap; font-weight: bold; } .e { color: #b0301f; } .a { color: #a86b00; } .q { font-size: 85%; color: #555; }</style></head><body>
            <h1>Los errores más repetidos · ${esc(cfgHoja.titulo || nombreProyecto())}</h1><p>${n} programas corregidos · ${new Date().toLocaleDateString('es-ES')}</p>
            <table><tr><th>Alumnos</th><th>Error o aviso</th></tr>${L.map(e => `<tr><td class="n">${e.alumnos.length} de ${n}</td><td><span class="${e.tipo === 'error' ? 'e' : 'a'}">${e.tipo === 'error' ? 'Error' : 'Aviso'}${CAT_ERR[e.cat] ? ' · ' + CAT_ERR[e.cat] : ''}</span> — ${esc(e.titulo)}${e.pista ? `<br><i>Pista: ${esc(e.pista)}</i>` : ''}<div class="q">${esc(e.alumnos.join(', '))}</div></td></tr>`).join('')}</table>
            <script>window.onload = () => setTimeout(() => window.print(), 250);<\/script></body></html>`); w.document.close(); };
    pintar(); ov.classList.add('visible');
}
