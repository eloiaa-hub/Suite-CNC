#!/usr/bin/env python3
"""Interfaz del Calcador (v95), la del Tutor: se aplica a calcador.html al final de construir_calcador.sh
(después de hacer el Corrector y el Tutor, que salen de la interfaz anterior). Lo que tiene:
a la derecha, ⚙️ Mecanizado con todas sus opciones y, en pestañas, el programa (la solución como en los apuntes
o el de la máquina), la tabla de puntos y los contornos; a la izquierda, arriba, abrir, guardar, exportar,
ejercicios y corrección (en la barra de arriba, Nuevo, Abrir, Guardar y Biblioteca).
Uso: python3 interfaz_calcador.py CARPETA_DE_LA_SUITE   (escribe calcador.html; con SALIDA=otro.html, en otro archivo)"""
import os, re, sys
AQUI = os.path.dirname(os.path.abspath(__file__))
DEV = os.path.dirname(AQUI)
d = sys.argv[1] if len(sys.argv) > 1 else '.'
leer = lambda *p: open(os.path.join(*p), encoding='utf-8').read()
s = leer(d, 'calcador.html')
sim = leer(d, 'simulador3d.html')

def rep(a, b, cnt=1):
    global s
    n = s.count(a)
    assert n == cnt, f'esperaba {cnt} y hay {n}: {a[:90]}'
    s = s.replace(a, b)

def funcion(texto, nombre):
    i = texto.index('function ' + nombre + '(')
    j = texto.index('{', i); prof = 0
    for k in range(j, len(texto)):
        if texto[k] == '{': prof += 1
        elif texto[k] == '}':
            prof -= 1
            if prof == 0: return texto[i:k + 1]
    raise ValueError(nombre)
exp = leer(DEV, 'fuentes_mecanizar', 'explicar_linea.js')
exp = exp[exp.index('const EXPL_G'):exp.index('let explicaciones')]
TUTSIM = ('const TUTSIM = (() => {\nconst Z_SEGURIDAD = 10;\n'
          + '\n'.join(funcion(sim, f) for f in ['parsearGcode3D', 'normT', 'centroArcoIJ', 'centroArcoR', 'entidadDeMovimiento'])
          + '\n' + exp + '\nreturn { parsear: parsearGcode3D, explicar: explicarPrograma };\n})();\n')

def quitar_viejos():
    global s
    i = s.index('                <div class="section-label">Ejercicio</div>'); j = s.index('                <div class="section-label">Fondo</div>')
    s = s[:i] + s[j:]
    i = s.index('<div class="params-box visor-si">'); j = s.index('<div class="section-label', i) if '<div class="section-label' in s[i:] else s.index('</div>\n            </div>', i)
    caja = s[i:j]
    caja2 = re.sub(r'\n\s*<button class="btn-action[^"]*" onclick="(exportarJSON|abrirMec|abrirEnSimulador|abrirCuestionario|abrirVariantes|abrirCorregir|abrirMasiva|exportarEjercicioTutor)\(\)"[^\n]*</button>', '', caja)
    caja2 = re.sub(r'\n\s*<div class="btn-row">\s*<button class="btn-action sec" onclick="(exportarDXF|abrirHoja|document.getElementById\(\'fileJSON\'\).click)\(\)?[^\n]*\n(?:[^\n]*\n)*?\s*</div>', '', caja2)
    s = s[:i] + caja2 + s[j:]
assert 'data-calc2' not in s, 'la interfaz ya está aplicada: rehaz antes calcador.html (sh construir_calcador.sh)'
s = s.replace('<html lang="es">', '<html lang="es" data-calc2="1">', 1)
# ayuda rápida: dónde están ahora Guardar y Mecanizar
rep('<tr><td>5. Guardar</td><td>💾 Guardar (.json): lo abren el Calcador, el Corrector y los Simuladores.</td></tr>',
    '<tr><td>5. Guardar</td><td>💾 Guardar, en la barra de arriba (.json): lo abren el Calcador, el Corrector, el Tutor y el Simulador.</td></tr>')
rep('<tr><td>6. Mecanizar</td><td>⚙️ Mecanizar (G-code): herramienta de la base, pasadas, acabado, puentes, grabados y cajeras; vista previa, descarga del .nc y ➜ Simulador. La operación de cada contorno se elige en el panel derecho (Mecanizado).</td></tr>',
    '<tr><td>6. Mecanizar</td><td>Panel derecho: en ⚙️ Mecanizado, la herramienta de la base, las coordenadas, la compensación, las pasadas y el acabado; arriba, «📋 Solución» (el programa como en los apuntes) o «⚙️ Máquina» (con grabados, cajeras y puentes). En la pestaña 📜 Programa, el G-code línea a línea con su explicación, ⬇ Guardar .nc y ➜ Simulador 3D. La operación de cada contorno, en la pestaña ◯ Contornos.</td></tr>')

# textos que hablaban de la interfaz antigua (sección Fresa, panel derecho de contornos, «Abrir .json»)
rep('con el diámetro de la sección Fresa', 'con el Ø de ⚙️ Mecanizado', 2)
rep('El mismo de la sección Fresa del panel izquierdo', 'El mismo Ø de ⚙️ Mecanizado, en el panel derecho')
rep('en el panel derecho, Mecanizado', 'en la pestaña ◯ Contornos del panel derecho')
rep('Invertir en el panel derecho', 'Invertir, en la pestaña ◯ Contornos', 2)
rep('se eligen en el panel derecho, en <strong>Mecanizado</strong>', 'se eligen en la pestaña ◯ Contornos del panel derecho, en <strong>Mecanizado</strong>')
rep("'Abre un ejercicio con «📂 Abrir .json» o desde la 🗂 Biblioteca'", "'Abre un ejercicio con «📂 Abrir» o desde la 🗂 Biblioteca, en la barra de arriba'")

# ── El panel de la derecha: el del Tutor, con la fuente del programa y todas las opciones de ⚙️ Mecanizar ──
panel = leer(AQUI, 'tutor_panel.html')
i = panel.index('                <div class="tu-modos" role="tablist">'); j = panel.index('            </div>\n            <div class="tu-ejercicio"', i)
panel = panel[:i] + '''                <div class="tu-modos" role="tablist">
                    <button id="tuFuenteSol" onclick="tuFuente('solucion')" title="El programa de la solución, como en los apuntes y los programas resueltos: un comentario en cada línea">📋 Solución</button>
                    <button id="tuFuenteMaq" onclick="tuFuente('maquina')" title="El programa de la máquina (el de ⚙️ Mecanizar): pasadas, acabado, grabados, cajeras, puentes y una herramienta por contorno">⚙️ Máquina</button>
                </div>
''' + panel[j:]
panel = panel.replace('''⬇ Guardar .nc</button>''', '''⬇ Guardar .nc</button>
                        <button onclick="tuEnviarSimulador()" title="Abre el Simulador 3D con el plano y el programa de este panel (la solución o el de la máquina)">➜ Simulador 3D</button>''')
panel = panel.replace('''                    <div id="tuHerrNota" class="tu-herr-nota"></div>''', '''                    <div id="tuHerrNota" class="tu-herr-nota"></div>
                    <label for="tuHbSel">De la base</label><span class="ancho" style="display:flex;gap:4px"><select id="tuHbSel" style="flex:1;min-width:0" title="Elige una fresa de la base de herramientas (la misma del Corrector y del Simulador)"></select><button type="button" onclick="HB.abrir(h => { aplicarHerramientaCalc(h); Object.assign(cfgMec, { T: h.T, F: h.F, S: h.S }); if (h.Fz > 0) cfgMec.Fz = h.Fz; if (h.paso > 0) cfgMec.paso = h.paso; tuPintarMec(); tuRefrescar(true); })" title="Base de herramientas: añadir, editar, exportar o importar la lista" style="padding:1px 6px">🧰</button></span>''')
panel = panel.replace('''                    <label class="ancho" style="grid-column:3/5;display:flex;gap:4px;align-items:center;justify-content:flex-end" title="Los nombres P1''', '''                    <label for="tuF0">Rápido G0</label><input id="tuF0" type="number" min="1" step="100" title="Avance de los rápidos, en mm/min (para el tiempo)">
                    <label for="tuZseg" title="Altura a la que sube la fresa para desplazarse en rápido">Z seguridad</label><input id="tuZseg" type="number" min="0" step="1">
                    <label for="tuOrden">Orden</label><select id="tuOrden" class="ancho" title="Qué se corta antes. Las entradas E1, E2… del plano siguen este orden"><option value="int">Interiores primero, después exteriores</option><option value="ext">Exteriores primero, después interiores</option></select>
                    <label for="tuEstr" class="tu-solo-maq">Estrategia</label><select id="tuEstr" class="ancho tu-solo-maq" title="Sentido de corte: el dibujado en el plano, o el que da fresado en concordancia u oposición"><option value="plano">Según el plano (sentido dibujado)</option><option value="concordancia">Concordancia</option><option value="oposicion">Oposición</option></select>
                    <label for="tuAcab" class="tu-solo-maq" title="Sobreespesor que dejan las pasadas de desbaste; una última pasada a la profundidad total recorre el contorno exacto. 0 = sin acabado">Acabado</label><input id="tuAcab" class="tu-solo-maq" type="number" min="0" step="0.1">
                    <label for="tuUnid" class="tu-solo-maq">Unidades</label><select id="tuUnid" class="tu-solo-maq"><option value="G71">G71 · mm</option><option value="G70">G70 · pulgadas</option></select>
                    <button type="button" class="c2-ventana-mec" onclick="abrirMec()" title="La ventana ⚙️ Mecanizar de siempre: vista previa con los colores de cada profundidad, resumen (pasadas, recorrido, tiempo estimado y bloques), avisos, copiar y descargar">⚙️ Ventana de Mecanizar: vista previa, resumen y tiempo…</button>
                    <label class="ancho" style="grid-column:3/5;display:flex;gap:4px;align-items:center;justify-content:flex-end" title="Los nombres P1''')
if 'panel' not in os.environ.get('SKIP', ''): rep('        <div class="right-panel">\n', panel + '        <div class="right-panel">\n')

# ── A la izquierda, arriba: archivo, exportar, ejercicios y corrección ──
IZQ = '''                <div class="section-label c2-abajo">Exportar</div>
                <div class="params-box c2-botones c2-abajo">
                    <button class="btn-action sec" onclick="exportarDXF()" title="El dibujo en DXF (opciones, debajo)">⬇ DXF</button>
                    <button class="btn-action sec" onclick="exportarSVG()" title="El dibujo en SVG (opciones, debajo)">⬇ SVG</button>
                    <details class="c2-opciones" id="c2Opciones"><summary>Opciones de DXF y SVG</summary></details>
                </div>
                <div class="tu-tabs c2-tabs-izq" id="c2Tabs" role="tablist"><button class="activo" data-p="c2PaneEj" onclick="c2Pestana(this)">🧩 Ejercicios</button><button data-p="c2PaneCorr" onclick="c2Pestana(this)">✅ Corregir</button></div>
                <div class="params-box c2-botones" id="c2PaneEj">
                    <button class="btn-action sec" onclick="abrirGenerador()" title="Genera ejercicios al azar con las formas del Calcador, con cotas enteras y sitio para la fresa">🧩 Aleatorio…</button>
                    <button class="btn-action sec" onclick="abrirHoja()" title="A4 con el plano acotado y cajetín, para el alumno">🖨 Hoja</button>
                    <button class="btn-action sec" onclick="abrirTabla()" title="Tabla, ISO y hoja de soluciones">📋 Soluciones</button>
                    <button class="btn-action sec" onclick="abrirVariantes()" title="Varias versiones del ejercicio con la misma dificultad y distinta solución, para exámenes">🎲 Variantes…</button>
                    <button class="btn-action sec" onclick="abrirCuestionario()" title="Preguntas para un cuestionario de Aules (Moodle XML) sobre este ejercicio">📝 Aules…</button>
                    <button class="btn-action sec" onclick="exportarEjercicioTutor()" title="Guarda el ejercicio para el Tutor G-Code del alumno: verá el plano, pero no el programa. Las coordenadas y la compensación son las de ⚙️ Mecanizado">🎓 Para el Tutor</button>
                </div>
                <div class="params-box c2-botones" id="c2PaneCorr" hidden>
                    <button class="btn-action sec" onclick="abrirCorregir()" title="Compara el programa ISO de un alumno con la pieza dibujada">✅ Un programa</button>
                    <button class="btn-action sec" onclick="abrirMasiva()" title="Corrige los programas de toda la clase: tabla, nota orientativa, CSV e informes">📚 Toda la clase</button>
                </div>

'''
if 'izq' not in os.environ.get('SKIP', ''): rep('                <div class="section-label">Ejercicio</div>', IZQ + '                <div class="section-label">Ejercicio</div>')
quitar_viejos()

CSS = leer(AQUI, 'tutor.css') + '''    /* ═══ Calcador2 (prueba): la interfaz del Tutor ═══ */
    .top-bar-right > .btn-manual[onclick*="abrirBiblioteca"], .sim-plano { display: none !important; }
    .c2-archivo { display: flex; gap: 4px; }
    .c2-archivo .btn-manual { white-space: nowrap; }
    .params-box[hidden] { display: none !important; }
    .section-label:has(+ .params-box button[onclick="abrirGenerador()"]:only-child), .params-box:has(> button[onclick="abrirGenerador()"]:only-child),
    .section-label.visor-si, .params-box.visor-si { display: none !important; }
    .c2-botones { display: grid !important; grid-template-columns: 1fr 1fr; gap: 6px; }
    .c2-botones .btn-action { margin: 0; padding-left: 4px; padding-right: 4px; font-size: 12.5px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .c2-opciones { grid-column: 1 / 3; font-size: 12px; }
    .c2-opciones summary { cursor: pointer; color: var(--text-muted); padding: 2px 0; }
    .c2-opciones .param-line { margin-top: 5px; }
    #tutorPanel:not(.maquina) .tu-solo-maq { display: none !important; }
    #tuHbSel { font-size: 12px; }
    .c2-ventana-mec { grid-column: 1 / 5; font-size: 12px; padding: 4px 6px; margin-top: 2px; }
    /* el panel izquierdo, más ancho y con sitio para la barra de desplazamiento */
    .action-panel { width: 292px !important; padding-right: 10px !important; }
    html[data-calc2] #fresaLista { display: block !important; }
    .c2-comprobar > .param-line, .c2-comprobar > .ctx-nota { margin: 6px 0; }
    .c2-tabs-izq { padding: 0 2px; margin-bottom: -10px; flex-shrink: 0; border-bottom: 1px solid var(--border-color); }
    .c2-tabs-izq button { flex: 1; font-size: 12.5px; white-space: nowrap; padding-left: 6px; padding-right: 6px; }
    #c2PaneEj, #c2PaneCorr, .c2-pane { border-top-left-radius: 0; border-top-right-radius: 0; border-top: 0; }
    .c2-botones[hidden] { display: none !important; }
    .c2-imanes { grid-column: auto; margin-bottom: 4px; }
    .c2-imanes > .params-box { margin-top: 6px; }
'''
if 'css' not in os.environ.get('SKIP', ''): rep('</style>\n</head>', CSS + '</style>\n</head>')

# Enganches (como en el Tutor, sin ejercicios ni niveles)
rep("    actualizarLista(); actualizarEstado(); programarFresa(); render(); guardarAutoPronto();\n}",
    "    actualizarLista(); actualizarEstado(); programarFresa(); render(); guardarAutoPronto();\n    if (typeof tutorRefrescar === 'function') tutorRefrescar();\n}")
rep("    dibujarCaja();\n    dibujarSnap();\n}", "    dibujarCaja();\n    if (typeof tutorDibujar === 'function') tutorDibujar();\n    dibujarSnap();\n}")
# La reproducción, en el panel del programa: las flechas la manejan (la barra de arriba del Calcador no se ve)
rep("""        if (e.key === 'ArrowUp') simPlanoPlay(); else if (e.key === 'ArrowDown') simPlanoPausa();
        else if (e.shiftKey) (e.key === 'ArrowLeft' ? simPlanoInicio : simPlanoFin)();
        else simPlanoPaso(e.key === 'ArrowRight' ? 1 : -1);""", """        if (e.key === 'ArrowUp') { if (!TU.sim || !TU.sim.jugando) tuPlay(); } else if (e.key === 'ArrowDown') tuPausa();
        else if (e.shiftKey) (e.key === 'ArrowLeft' ? tuInicio : tuFin)();
        else tuPaso(e.key === 'ArrowRight' ? 1 : -1);""")
# Nuevo, Abrir, Guardar y Biblioteca, en la barra de arriba (entre el nombre y el manual)
rep('<input class="project-name" id="projectName" type="text" value="calco_sin_nombre" placeholder="Nombre del proyecto">',
    '<input class="project-name" id="projectName" type="text" value="calco_sin_nombre" placeholder="Nombre del proyecto">\n            <div class="c2-archivo"><button class="btn-manual" onclick="nuevo()" title="Empieza de cero (se puede deshacer)">🗋 Nuevo</button><button class="btn-manual" onclick="document.getElementById(\'fileJSON\').click()" title="Abre un proyecto .json del Calcador o del Corrector">📂 Abrir</button><button class="btn-manual" onclick="exportarJSON()" title="Guarda el proyecto en un archivo JSON: lo abren el Calcador, el Corrector, el Tutor y el Simulador (como plano del ejercicio)">💾 Guardar</button><button class="btn-manual" onclick="abrirBiblioteca()" title="Tus ejercicios: buscar, abrir e imprimir sus hojas">🗂 Biblioteca</button></div>')

ENGANCHES = '''
function c2Pestana(b) { b.parentElement.querySelectorAll('button').forEach(x => { x.classList.toggle('activo', x === b); document.getElementById(x.dataset.p).hidden = x !== b; }); }
// al elegir una forma o las auxiliares, se abre su pestaña
const _c2SetHerramienta = setHerramienta;
setHerramienta = function (h) { const r = _c2SetHerramienta.apply(this, arguments);
    const p = ['rectangulo', 'poligono', 'estrella', 'elipse'].includes(h) ? 'c2PaneFormas' : h === 'auxiliar' ? 'c2PaneCons' : 'c2PaneDib';
    const b = p && document.querySelector(`#c2Tabs2 button[data-p="${p}"]`); if (b && !b.classList.contains('activo')) c2Pestana(b); return r; };
let _c2SelAnt = '';
const _c2ActualizarLista = actualizarLista;
actualizarLista = function () { const r = _c2ActualizarLista.apply(this, arguments);
    try { const k = seleccionados().join(','); if (k !== _c2SelAnt) { _c2SelAnt = k; if (k && herramienta === 'editar' && typeof TU !== 'undefined' && TU.pestana !== 'contornos') tuPestana('contornos'); } } catch (e) {}
    return r; };
// al cerrar la ventana ⚙️ Mecanizar, el panel recoge lo que se haya cambiado en ella
window.addEventListener('DOMContentLoaded', () => { const _c2CerrarMec = cerrarMec;
    cerrarMec = function () { const r = _c2CerrarMec.apply(this, arguments); try { tuPintarMec(); tuRefrescar(true); } catch (e) {} return r; }; });
const _tuAbrirJSONDatos = abrirJSONDatos;
abrirJSONDatos = function (d) { const r = _tuAbrirJSONDatos.apply(this, arguments); setTimeout(() => tuAlAbrirJSON(d), 0); return r; };
window.addEventListener('load', () => setTimeout(() => {
    // las opciones de DXF y SVG del panel Exportar del Calcador pasan a «Opciones de DXF y SVG»
    const op = document.getElementById('c2Opciones');
    document.querySelectorAll('.params-box.visor-si > .param-line').forEach(el => { if (el.style.display !== 'none') op.appendChild(el); });
    // orden del panel izquierdo: Ejercicios / Corregir (pestañas), Dibujo (con los imanes plegados), Construcción, Formas, Fondo y, abajo, Archivo y Exportar
    const ap = document.querySelector('.action-panel');
    const sec = t => { const l = [...ap.querySelectorAll(':scope > .section-label')].find(x => x.textContent.trim().toLowerCase() === t); return l ? [l, l.nextElementSibling] : []; };
    const dib = sec('dibujo'), ima = sec('imanes');
    if (dib.length && ima.length) { const det = document.createElement('details'); det.className = 'c2-opciones c2-imanes'; det.innerHTML = '<summary>Imanes</summary>'; det.appendChild(ima[1]); ima[0].remove(); dib[1].insertBefore(det, dib[1].firstChild); }
    // «Comprobar mecanizado» (de la sección Fresa, que queda oculta: el Ø está en ⚙️ Mecanizado), plegado dentro de Dibujo
    if (dib.length) { const det = document.createElement('details'); det.className = 'c2-opciones c2-comprobar'; det.innerHTML = '<summary>Comprobar con la fresa</summary>';
        const chk = document.getElementById('chkFresa'); [chk && chk.closest('.param-line'), document.getElementById('fresaResumen'), document.getElementById('fresaLista')].forEach(el => el && det.appendChild(el));
        const ima2 = dib[1].querySelector('.c2-imanes'); dib[1].insertBefore(det, ima2 ? ima2.nextSibling : dib[1].firstChild); }
    // Dibujo / Construcción / Formas, en pestañas
    const con = sec('construcción'), formas = sec('formas'), t2 = document.createElement('div');
    t2.className = 'tu-tabs c2-tabs-izq'; t2.id = 'c2Tabs2'; t2.setAttribute('role', 'tablist');
    [[dib, 'c2PaneDib', 'Dibujo'], [con, 'c2PaneCons', 'Construcción'], [formas, 'c2PaneFormas', 'Formas']].forEach(([sx, id, nom], k) => {
        if (!sx.length) return; sx[1].id = id; sx[1].classList.add('c2-pane'); if (k) sx[1].hidden = true; sx[0].remove();
        const b = document.createElement('button'); b.dataset.p = id; b.textContent = nom; b.onclick = () => c2Pestana(b); if (!k) b.classList.add('activo'); t2.appendChild(b); });
    const fondo = sec('fondo'), expo = [...document.querySelectorAll('.action-panel > .c2-abajo')], t3 = document.createElement('div');
    t3.className = 'tu-tabs c2-tabs-izq'; t3.id = 'c2Tabs3'; t3.setAttribute('role', 'tablist');
    [[fondo, 'c2PaneFondo', 'Fondo'], [expo, 'c2PaneExp', 'Exportar']].forEach(([sx, id, nom], k) => {
        if (sx.length < 2) return; sx[1].id = id; sx[1].classList.add('c2-pane'); if (k) sx[1].hidden = true; sx[0].remove();
        const b = document.createElement('button'); b.dataset.p = id; b.textContent = nom; b.onclick = () => c2Pestana(b); if (!k) b.classList.add('activo'); t3.appendChild(b); });
    [document.getElementById('c2Tabs'), document.getElementById('c2PaneEj'), document.getElementById('c2PaneCorr'), t2, dib[1], con[1], formas[1], t3, fondo[1], expo[1]].forEach(el => el && ap.appendChild(el));
    tutorIniciar();
}, 0));
'''
rep('// ── Inicio ──\nleerColores();', TUTSIM + 'const TU_EJEMPLOS = [];\nconst TU_C2 = true;      // Calcador2: sin Practicar, ejercicios ni niveles\n' + leer(AQUI, 'tutor.js') + ENGANCHES + '\n// ── Inicio ──\nleerColores();')
open(os.path.join(d, os.environ.get('SALIDA', 'calcador.html')), 'w', encoding='utf-8').write(s)
print(f'calcador.html: interfaz nueva aplicada ({len(s) // 1024} KB)')
