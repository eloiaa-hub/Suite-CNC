"""Calcador v108: 🎲 Variantes con otras medidas. Opción «Otras medidas (mm)»: alarga o acorta la pieza por un corte
vertical (ancho) u horizontal (alto) que solo cruza rectas perpendiculares a él; lo que queda a un lado se desplaza. Los
arcos y agujeros no cambian, se conservan las tangencias, y cambian las cotas. Se combina con las simetrías, el cero y la escala.
Uso: python3 variantes_medidas.py <carpeta de la suite>   (construir_calcador.sh lo pone tras aules_notas.py)"""
import sys, os
AQUI = os.path.dirname(os.path.abspath(__file__))
P = os.path.join(sys.argv[1] if len(sys.argv) > 1 else '.', 'calcador.html')
s = open(P, encoding='utf-8').read()
def rep(a, b, cnt=1):
    global s
    n = s.count(a); assert n == cnt, f'{n} apariciones (se esperaban {cnt}) de: {a[:100]}'
    s = s.replace(a, b)
JS = open(os.path.join(AQUI, 'variantes_medidas.js'), encoding='utf-8').read()
rep("function datosDeEstado(est, hoja, nombre) {", JS + "function datosDeEstado(est, hoja, nombre) {")
rep("""<input type="text" id="varFac" value="90, 110" style="width:70px" onchange="cambiarVariantes()"></label>""",
    """<input type="text" id="varFac" value="90, 110" style="width:70px" onchange="cambiarVariantes()"></label>
                <label class="param-line var-chk" title="Alarga o acorta la pieza (el ancho, el alto o los dos) por donde solo hay rectas: los arcos, los radios y los agujeros no cambian, y las tangencias se conservan. Valores en mm separados por comas: positivos alargan, negativos acortan"><input type="checkbox" id="varMed" onchange="cambiarVariantes()"> Otras medidas (mm) <input type="text" id="varMm" value="10, -10" style="width:70px" onchange="cambiarVariantes()"></label>""")
rep("""<p class="ctx-nota">Se conservan el sentido de recorrido, el punto de entrada, el mecanizado y los requisitos de corrección. La escala puede dar medidas con decimales.</p>""",
    """<p class="ctx-nota">Se conservan el sentido de recorrido, el punto de entrada, el mecanizado y los requisitos de corrección. La escala puede dar medidas con decimales. «Otras medidas» alarga o acorta la pieza por donde solo hay rectas, sin tocar arcos ni agujeros.</p>""")
rep("""(las de 🎲 Variantes: simetrías, giro, otro cero pieza, escala)""", """(las de 🎲 Variantes: simetrías, giro, otro cero pieza, escala, otras medidas)""")
open(P, 'w', encoding='utf-8').write(s)
print('Calcador: variantes con otras medidas')
