"""Ajustes comunes de los manuales y apuntes en HTML (los usa anidador_calculadora/construir_manual.py):
- CSS: en pantalla, la hoja centrada, con márgenes y fondo, para que el texto no quede pegado a los bordes del
  navegador (al imprimir y en el PDF mandan los márgenes de @page).
- JS: cada título (h2.cap, h3) se une a lo que le sigue (el párrafo que lo presenta y el dibujo, la lista… que viene después) en un bloque que no se parte, para que en el PDF ningún
  título quede solo al final de una página.
Uso suelto, para meterlos en manuales ya hechos: python3 margen_pantalla.py archivo.html [...]"""
import sys, re
MARCA = '/* margen-pantalla */'
CSS = MARCA + """
@media screen {
  html { background: #e9edf2; }
  body { max-width: 190mm; margin: 0 auto; padding: 14mm 16mm 20mm; background: #fff; box-shadow: 0 2px 16px rgba(20,40,70,.13); box-sizing: border-box; }
}
@media screen and (max-width: 760px) { body { padding: 18px 16px 30px; box-shadow: none; } html { background: #fff; } }
.junto { break-inside: avoid; page-break-inside: avoid; }"""
JS = """<script>/* titulos-juntos */
document.querySelectorAll('h2.cap, h3, h4').forEach(h => {
  if (!h.nextElementSibling || !h.parentNode || h.parentNode.classList.contains('junto')) return;
  // el título, el párrafo que lo presenta y lo primero que no sea un párrafo (un dibujo, una lista, un programa…)
  const d = document.createElement('div'); d.className = 'junto'; h.parentNode.insertBefore(d, h); d.appendChild(h);
  for (let k = 0; k < 3; k++) { const sig = d.nextElementSibling; if (!sig || /^H[1-4]$/.test(sig.tagName)) break; d.appendChild(sig); if (sig.tagName !== 'P') break; }
});
</script>"""
if __name__ == '__main__':
    for f in sys.argv[1:]:
        s = open(f, encoding='utf-8').read()
        if MARCA not in s: s = s.replace('</style>', CSS + '\n</style>', 1)
        if 'titulos-juntos' not in s: s = s.replace('</body>', JS + '\n</body>', 1)
        if 'name="viewport"' not in s: s = s.replace('<meta charset="utf-8">', '<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">', 1)
        open(f, 'w', encoding='utf-8').write(s); print('ajustado', f)
