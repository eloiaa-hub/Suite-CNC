"""Simulador 3D V43: aviso con M04 (giro antihorario). Con una fresa normal (a derechas) no corta: el giro habitual es M03.
Uso: python3 simulador_m04.py <carpeta de la suite>      (ya aplicado: no se vuelve a ejecutar)"""
import sys, os
RUTA = os.path.join(sys.argv[1] if len(sys.argv) > 1 else '.', 'simulador3d.html')
s = open(RUTA, encoding='utf-8').read()
def rep(a, b, cnt=1):
    global s
    assert s.count(a) == cnt, (a[:70], s.count(a)); s = s.replace(a, b)
rep("            if (m === 3 || m === 4) husillo = true;", "            if (m === 3 || m === 4) { husillo = true; if (m === 4 && !meta.m04) meta.m04 = idx + 1; }")
rep("    if (meta.g28) add(meta.g28, 'aviso',", "    if (meta.m04) add(meta.m04, 'aviso', 'M04: giro antihorario. Con una fresa normal (a derechas) no corta; el giro habitual es M03.');\n    if (meta.g28) add(meta.g28, 'aviso',")
rep("    4: 'arranca el husillo en sentido antihorario.',", "    4: 'arranca el husillo en sentido antihorario. Con una fresa normal (a derechas) no corta: lo habitual es M03.',")
rep('vertical-align:middle">V42</span>', 'vertical-align:middle">V43</span>')
open(RUTA, 'w', encoding='utf-8').write(s)
print('Simulador V43: aviso con M04')
