#!/usr/bin/env python3
"""Portátiles y pantallas pequeñas (Calcador v120, Corrector v65, Tutor v6): cuando la zona de dibujo es estrecha, el recuadro de
Coordenadas sube por encima de los botones de zoom y no se pisan; los botones de vista pasan a otra fila si no caben.
Uso: python3 pantallas_pequenas.py CARPETA_DE_LA_SUITE"""
import os, sys
d = sys.argv[1] if len(sys.argv) > 1 else '.'
CSS = """
    /* ═══ Pantallas pequeñas ═══ */
    .canvas-wrap, #canvasWrap { container-type: inline-size; }
    .vista-controls { max-width: calc(100% - 24px); flex-wrap: wrap; justify-content: flex-end; }
    .cmd-bar { max-width: calc(100% - 24px); min-width: 0; } .cmd-bar input { min-width: 70px; flex-shrink: 1; }
    .cmd-bar .cmd-ej { min-width: 0; overflow: hidden; white-space: nowrap; text-overflow: ellipsis; }
    @container (max-width: 900px) { .cmd-bar { bottom: 52px; } }
    @container (max-width: 520px) { .cmd-bar .cmd-ej { display: none; } .cmd-bar { left: 8px; } .zoom-controls { right: 8px; bottom: 8px; } }
</style>
</head>"""
for f in ('calcador.html', 'tutor.html'):
    p = os.path.join(d, f); s = open(p, encoding='utf-8').read()
    assert s.count('</style>\n</head>') == 1, f
    s = s.replace('</style>\n</head>', CSS.lstrip('\n')); open(p, 'w', encoding='utf-8').write(s)
print('Calcador y Tutor: Coordenadas y zoom ya no se pisan')
