"""Pone los números de las zonas sobre la captura de la pantalla (capturas/pantalla.png → pantalla_num.png)."""
import os
from PIL import Image, ImageDraw, ImageFont
C = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'capturas') + '/'
im = Image.open(C + 'contornos.png')
if im.height > 640: im.crop((0, 0, im.width, 622)).save(C + 'contornos.png')
im = Image.open(C + 'pantalla.png').convert('RGB'); d = ImageDraw.Draw(im)
f = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf', 20)
for n, x, y in [(1, 600, 34), (2, 945, 70), (3, 64, 560), (4, 372, 262), (5, 700, 140), (6, 470, 820), (7, 860, 815), (8, 1410, 163), (9, 1370, 515)]:
    r = 16; d.ellipse((x - r, y - r, x + r, y + r), fill=(214, 104, 30), outline='white', width=3)
    w = d.textlength(str(n), font=f); d.text((x - w / 2, y - 12), str(n), font=f, fill='white')
im.save(C + 'pantalla_num.png')
