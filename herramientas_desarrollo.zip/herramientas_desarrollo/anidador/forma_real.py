"""Anidador v8: anidado por la forma real (las piezas curvas se encajan unas en los huecos de otras).
Uso: python3 forma_real.py <carpeta de la suite>   (sobre el anidador v7: anidador_v6.html + cantos_coste.py)
"""
import sys, os
AQUI = os.path.dirname(os.path.abspath(__file__))
P = os.path.join(sys.argv[1] if len(sys.argv) > 1 else '.', 'anidador.html')
s = open(P, encoding='utf-8').read()
assert 'function anidarForma' not in s, 'ya aplicado'
def rep(a, b, cnt=1):
    global s
    n = s.count(a); assert n == cnt, f'{n} apariciones (se esperaban {cnt}) de: {a[:100]}'
    s = s.replace(a, b)
JS = open(os.path.join(AQUI, 'forma_real.js'), encoding='utf-8').read()

rep('<span class="ver" title="Versión del programa">v7</span>', '<span class="ver" title="Versión del programa">v8</span>')
rep('<h3>🪵 Anidador de tableros <span class="ver">v7</span></h3>', '<h3>🪵 Anidador de tableros <span class="ver">v8</span></h3>')
rep("""  #vista .pz.sel .caja { stroke-opacity: .95; stroke-width: 1.6; }""",
    """  #vista .pz.sel .caja { stroke-opacity: .95; stroke-width: 1.6; }
  #vista .pz .caja.marco { fill: none !important; pointer-events: none; stroke-width: 1 !important; }""")
# el campo
rep("""<label>El tablero tiene veta <small>(a lo largo, en X)</small></label><input type="checkbox" id="tVeta" checked></div>""",
    """<label>El tablero tiene veta <small>(a lo largo, en X)</small></label><input type="checkbox" id="tVeta" checked></div>
      <div class="fila" title="Cómo se colocan las piezas. Por su rectángulo: rápido, y lo mejor para piezas rectangulares. Por su forma real: las piezas curvas se encajan unas junto a otras y las pequeñas aprovechan los huecos de las grandes (también al colocarlas a mano). Siempre con la separación de la fresa entre piezas"><label>Colocar las piezas</label>
        <select id="tModo"><option value="rect">Por su rectángulo</option><option value="forma">Por su forma real</option></select></div>""")
# el código
rep("function datosTablero() {", JS + "\nfunction datosTablero() {")
# calcular: las colocadas a mano se comprueban por su forma; el anidado, por la forma (y se compara con el de rectángulos)
rep("""  const W = T.L - 2 * T.M + T.sep, H = T.A - 2 * T.M + T.sep, items = [], fijos = [];""",
    """  const W = T.L - 2 * T.M + T.sep, H = T.A - 2 * T.M + T.sep, items = [], fijos = [], fijosF = [], forma = modoForma();""")
rep("""        if (g.w > 0 && g.h > 0 && cabeFija(T, f.t, f.x, f.y, g.w, g.h, fijos)) { fijos.push({ t: f.t, x: f.x - T.M, y: f.y - T.M, w: g.w + T.sep, h: g.h + T.sep, it: { ref: p, k }, fija: true, g: norm90(f.g) }); continue; }""",
    """        if (g.w > 0 && g.h > 0 && (forma ? cabeForma(T, f.t, p, norm90(f.g), f.x, f.y, fijosF) : cabeFija(T, f.t, f.x, f.y, g.w, g.h, fijos))) {
          fijos.push({ t: f.t, x: f.x - T.M, y: f.y - T.M, w: g.w + T.sep, h: g.h + T.sep, it: { ref: p, k }, fija: true, g: norm90(f.g) });
          fijosF.push({ t: f.t, p, g: norm90(f.g), x: f.x, y: f.y, it: { ref: p, k } }); continue; }""")
rep("""      items.push({ w: g.w + T.sep, h: g.h + T.sep, girable: giroAuto(p) && !(T.veta && p.veta), ref: p, k });""",
    """      items.push({ w: g.w + T.sep, h: g.h + T.sep, girable: giroAuto(p) && !(T.veta && p.veta), ref: p, k, gs: girosPermitidos(p, T) });""")
rep("""  const r = anidar(items, W, H, fijos);
  resultado = { T, tableros: r.tableros.map(t => ({ col: t.col.map(c => ({ p: c.it.ref, k: c.it.k, rot: c.rot || 0, fija: !!c.fija,
                  g: c.fija ? c.g : norm90(giroBase(c.it.ref) + (c.rot ? 90 : 0)), x: T.M + c.x, y: T.M + c.y, w: c.w - T.sep, h: c.h - T.sep })) })),
                sinColocar: [...new Set(r.fuera.map(it => it.ref))], nFuera: r.fuera.length, nItems: items.length + fijos.length };""",
    """  const r = anidar(items, W, H, fijos);
  let tabs = r.tableros.map(t => t.col.map(c => ({ p: c.it.ref, k: c.it.k, rot: c.rot || 0, fija: !!c.fija,
                  g: c.fija ? c.g : norm90(giroBase(c.it.ref) + (c.rot ? 90 : 0)), x: T.M + c.x, y: T.M + c.y, w: c.w - T.sep, h: c.h - T.sep })));
  let fuera = r.fuera, porForma = false;
  if (forma && items.length) {
    // por la forma real; se queda con el de rectángulos si este cabe en menos tableros (o en el mismo, más corto)
    const clave = JSON.stringify([T, items.map(it => [it.ref.id, it.k, it.gs, it.ref.tipo === 'rect' ? [it.ref.L, it.ref.A] : escalaDe(it.ref)]), fijosF.map(f => [f.p.id, f.it.k, f.t, f.g, f.x, f.y])]);
    let rf = calcular.memo && calcular.memo.clave === clave ? calcular.memo.r : null;
    if (!rf) { rf = anidarForma(items, T, fijosF); calcular.memo = { clave, r: rf }; }
    const tabsF = rf.tableros.map(t => t.col.map(c => c.fija ? { p: c.p, k: c.it.k, rot: 0, fija: true, g: c.g, x: c.x, y: c.y, w: c.w, h: c.h }
                                                              : { p: c.p, k: c.k, rot: c.rot ? 1 : 0, fija: false, g: c.g, x: c.x, y: c.y, w: c.w, h: c.h }));
    const largo = ts => ts.length ? Math.max(0, ...ts[ts.length - 1].map(c => c.x + c.w)) : 0;
    const peor = (rf.fuera.length - fuera.length) || (tabsF.length - tabs.length) || (largo(tabsF) - largo(tabs) > 1e-6 ? 1 : 0);
    if (peor <= 0) { tabs = tabsF; fuera = rf.fuera; porForma = true; }
  }
  resultado = { T, tableros: tabs.map(col => ({ col })), porForma, forma,
                sinColocar: [...new Set(fuera.map(it => it.ref))], nFuera: fuera.length, nItems: items.length + fijos.length };""")
# colocar a mano, girar y pasar a otro tablero: «¿cabe?» por la forma en ese modo
rep("""  return { x, y, ok: cabeFija(T, tableroVisto, x, y, c.w, c.h, fijasDelTablero(tableroVisto, c)) };""",
    """  return { x, y, ok: cabeAqui(T, tableroVisto, c, c.g, x, y, c) };""")
rep("""  if (!cabeFija(T, tableroVisto, x, y, d.w, d.h, fijasDelTablero(tableroVisto, c))) {""",
    """  if (!cabeAqui(T, tableroVisto, c, g, x, y, c)) {""")
rep("""    ys.forEach(y => xs.forEach(x => { if (cabeFija(T, t, x, y, c.w, c.h, otros) && (!mejor || y < mejor.y - 1e-9 || (Math.abs(y - mejor.y) < 1e-9 && x < mejor.x))) mejor = { x, y }; }));""",
    """    const sirve = (x, y) => modoForma() ? cabeForma(T, t, c.p, c.g, x, y, otros.formas) : cabeFija(T, t, x, y, c.w, c.h, otros);
    ys.forEach(y => xs.forEach(x => { if (sirve(x, y) && (!mejor || y < mejor.y - 1e-9 || (Math.abs(y - mejor.y) < 1e-9 && x < mejor.x))) mejor = { x, y }; }));""")
rep("""  const sitio = buscar(todas.map(rect)) || buscar(todas.filter(o => o.fija).map(rect));""",
    """  const conFormas = l => Object.assign(l.map(rect), { formas: l.map(o => ({ t, p: o.p, g: o.g, x: o.x, y: o.y })) });
  const sitio = buscar(conFormas(todas)) || buscar(conFormas(todas.filter(o => o.fija)));""")
# el dibujo: en el modo de forma, la pieza se rellena por su forma (y se coge por ella); la caja, solo como marco
rep("""<rect class="caja" x="${a.x.toFixed(1)}" y="${a.y.toFixed(1)}" width="${r.w.toFixed(1)}" height="${r.h.toFixed(1)}" fill="${col}" fill-opacity=".13" stroke="${col}" stroke-opacity="${c.fija ? '.7' : '.4'}"${c.fija ? '' : ' stroke-dasharray="3 3"'} vector-effect="non-scaling-stroke"/>`;
    const polis = cont.map(kk => poliContorno(kk)), clases = clasesDe(cont, polis), color = { exterior: col, interior: v('--interior'), grabado: v('--verde'), cajera: v('--naranja') };""",
    """<rect class="caja${resultado.forma ? ' marco' : ''}" x="${a.x.toFixed(1)}" y="${a.y.toFixed(1)}" width="${r.w.toFixed(1)}" height="${r.h.toFixed(1)}" fill="${col}" fill-opacity=".13" stroke="${col}" stroke-opacity="${resultado.forma ? '.25' : c.fija ? '.7' : '.4'}"${c.fija ? '' : ' stroke-dasharray="3 3"'} vector-effect="non-scaling-stroke"/>`;
    const polis = cont.map(kk => poliContorno(kk)), clases = clasesDe(cont, polis), color = { exterior: col, interior: v('--interior'), grabado: v('--verde'), cajera: v('--naranja') };
    if (resultado.forma) { const d = cont.map((kk, ik) => kk.cerrado && (clases[ik] === 'exterior' || clases[ik] === 'interior') ? polis[ik].map((q, j) => { const z = P(q); return (j ? 'L' : 'M') + z.x.toFixed(1) + ' ' + z.y.toFixed(1); }).join(' ') + ' Z' : '').join(' ');
      if (d.trim()) s += `<path class="caja solido" d="${d}" fill="${col}" fill-opacity=".16" fill-rule="evenodd" stroke="${col}" stroke-opacity="${c.fija ? '.7' : '.3'}" vector-effect="non-scaling-stroke"/>`; }""")
# aprovechamiento: con la superficie real en el modo de forma
rep("""  const areaPiezas = t ? t.col.reduce((a, c) => a + c.w * c.h, 0) : 0, areaTab = T.L * T.A;""",
    """  const areaPiezas = t ? t.col.reduce((a, c) => a + (resultado.forma ? formaPieza(c.p, c.g).area : c.w * c.h), 0) : 0, areaTab = T.L * T.A;""")
rep("""'Superficie de las piezas (su rectángulo envolvente) sobre la del tablero'],""",
    """resultado.forma ? 'Superficie real de las piezas (sin sus huecos) sobre la del tablero' : 'Superficie de las piezas (su rectángulo envolvente) sobre la del tablero'],""")
rep("""  if (piezas.some(p => p.tipo === 'json') && n) av += `<p class="nota">""",
    """  if (resultado.forma && n && !resultado.porForma && piezas.length) av += `<p class="nota">Por su forma real no salía mejor que por el rectángulo: se usa el anidado por rectángulos (las piezas siguen pudiendo colocarse a mano por su forma).</p>`;
  if (piezas.some(p => p.tipo === 'json') && n) av += `<p class="nota">""")
# estado, eventos y tablero guardado
rep("""    ['tL', 'tA', 'tG', 'tP', 'tM', 'hD', 'hH'].forEach(id => d.v[id] = $(id).value);""",
    """    ['tL', 'tA', 'tG', 'tP', 'tM', 'hD', 'hH', 'tModo'].forEach(id => d.v[id] = $(id).value);""")
rep("""['tVeta', 'tCero'].forEach(id => $(id).addEventListener('change', todo));""",
    """['tVeta', 'tCero', 'tModo'].forEach(id => $(id).addEventListener('change', todo));""")
rep("""anidador: { version: 4, tablero: { largo: T.L, ancho: T.A, grosor: T.G, margen: T.M, separacion: T.sep, cero: T.cero },""",
    """anidador: { version: 4, tablero: { largo: T.L, ancho: T.A, grosor: T.G, margen: T.M, separacion: T.sep, cero: T.cero, modo: modoForma() ? 'forma' : 'rect' },""")
rep("""  if (['ii', 'si', 'id', 'sd', 'c'].includes(tb.cero)) $('tCero').value = tb.cero;""",
    """  if (['ii', 'si', 'id', 'sd', 'c'].includes(tb.cero)) $('tCero').value = tb.cero;
  if (tb.modo === 'forma' || tb.modo === 'rect') $('tModo').value = tb.modo;""")
# textos
rep("""      <p class="nota">Las piezas se colocan por su rectángulo envolvente, de mayor a menor, con la separación de la fresa entre ellas. Con el ratón, sobre el rectángulo de cada pieza:""",
    """      <p class="nota">Las piezas se colocan por su rectángulo envolvente o, con «Colocar las piezas: por su forma real», encajadas por su contorno (las pequeñas, también en los huecos de las grandes), siempre con la separación de la fresa entre ellas. Con el ratón, sobre cada pieza:""")
rep("""  <p class="nota">Las piezas se colocan por su rectángulo envolvente: las piezas curvas no se encajan unas dentro de otras. Pasa el ratón""",
    """  <p class="nota">Pasa el ratón""")
rep("""  <h4>Colocar a mano con el ratón</h4>""", """  <h4>Por su rectángulo o por su forma real</h4>
  <p>En <b>Colocar las piezas</b> (caja del tablero) eliges cómo se colocan. <b>Por su rectángulo</b>: cada pieza ocupa su rectángulo envolvente; es lo más rápido y lo mejor para piezas rectangulares. <b>Por su forma real</b>: las piezas se encajan por su contorno, unas junto a otras, y las pequeñas aprovechan los <b>huecos</b> de las grandes; aprovecha mucho mejor el tablero con piezas curvas del Calcador. Siempre queda la separación de la fresa entre dos piezas. Si con la forma real no sale mejor (por ejemplo, con todo rectángulos), se usa el anidado por rectángulos. Con la forma real también puedes <b>colocar a mano</b> una pieza dentro del hueco de otra.</p>
  <p>Una pieza dentro del hueco de otra se corta <b>antes</b> que ese hueco: en el Calcador, ⚙️ Mecanizar corta de dentro afuera (la pieza del hueco, después el hueco y al final el exterior).</p>
  <h4>Colocar a mano con el ratón</h4>""")

# el nombre: si el centro de la pieza cae en un hueco (un anillo), se pone sobre su material, más pequeño
rep("""    if (et) s += `<text x="${(a.x + r.w / 2).toFixed(1)}" y="${(a.y + r.h / 2 + et.fs / 3).toFixed(1)}" text-anchor="middle" font-size="${et.fs.toFixed(1)}">${esc(et.t)}</text>`;""",
    """    let lx = a.x + r.w / 2, ly = a.y + r.h / 2;
    if (et && resultado.forma) { const f = formaPieza(c.p, c.g);
      if (!dentroPar(f.w / 2, f.h / 2, f.polys)) for (let dd = 0; dd < f.h / 2; dd += Math.max(0.5, f.h / 200)) {
        if (dentroPar(f.w / 2, f.h / 2 - dd, f.polys)) { let fin = dd; while (fin < f.h / 2 && dentroPar(f.w / 2, f.h / 2 - fin, f.polys)) fin += Math.max(0.5, f.h / 200);
          ly = a.y + r.h / 2 + k * (dd + fin) / 2; et.fs = Math.max(8, Math.min(et.fs, k * (fin - dd) * 0.7)); break; } } }
    if (et) s += `<text x="${lx.toFixed(1)}" y="${(ly + et.fs / 3).toFixed(1)}" text-anchor="middle" font-size="${et.fs.toFixed(1)}">${esc(et.t)}</text>`;""")

# los grupos del Calcador: cada unidad colocada, un grupo propio (y al reabrir el tablero, el de la pieza)
rep("    if (k.deTexto && k.deTexto.id) k.deTexto.id += sufijo;", "    if (k.deTexto && k.deTexto.id) k.deTexto.id += sufijo;\n    if (k.grupo) k.grupo += sufijo;")
rep("    if (c.deTexto && c.deTexto.id) c.deTexto.id = sinSufijo(c.deTexto.id);", "    if (c.deTexto && c.deTexto.id) c.deTexto.id = sinSufijo(c.deTexto.id);\n    if (c.grupo) c.grupo = sinSufijo(c.grupo);")

# al llevar el tablero al Calcador, cada pieza de varios contornos va agrupada: se mueve entera con un clic
rep("""  t.col.forEach((c, n) => { deCada[n] = []; contornosColocados(c, `_t${i + 1}p${n + 1}`).forEach(k => {""",
    """  t.col.forEach((c, n) => { deCada[n] = []; const ks = contornosColocados(c, `_t${i + 1}p${n + 1}`); ks.forEach(k => {
    if (ks.length > 1) k.grupo = `pieza_t${i + 1}p${n + 1}`;""")
open(P, 'w', encoding='utf-8').write(s)
print('Anidador v8: anidado por la forma real:', P)
