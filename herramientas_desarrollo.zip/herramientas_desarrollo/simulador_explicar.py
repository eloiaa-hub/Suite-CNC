"""Simulador 3D V42: 💬 explicar en castellano la línea marcada y 📍 posición absoluta en las líneas en G91.
El código está en fuentes_mecanizar/explicar_linea.js (entre las marcas // <explicar-linea>).
Uso: python3 simulador_explicar.py <carpeta de la suite>      (si ya está aplicado, solo actualiza el código JS)
"""
import sys, os, re
AQUI = os.path.dirname(os.path.abspath(__file__))
SUITE = sys.argv[1] if len(sys.argv) > 1 else '.'
RUTA = os.path.join(SUITE, 'simulador3d.html')
JS = '// <explicar-linea>\n' + open(os.path.join(AQUI, 'fuentes_mecanizar', 'explicar_linea.js'), encoding='utf-8').read() + '// </explicar-linea>\n'
s = open(RUTA, encoding='utf-8').read()

def rep(a, b, cnt=1):
    global s
    assert s.count(a) == cnt, (a[:70], s.count(a))
    s = s.replace(a, b)

if '// <explicar-linea>' in s:
    s = re.sub(r'// <explicar-linea>\n.*?// </explicar-linea>\n', lambda m: JS, s, flags=re.S)
else:
    rep("""    .gl.activa .num { color:var(--warn); font-weight:700; }
""", """    .gl.activa .num { color:var(--warn); font-weight:700; }
    /* 💬 Explicar la línea · 📍 absolutas en G91 */
    .gl .abs-g91 { color:var(--accent); font-weight:600; font-style:italic; opacity:.8; padding-left:4px; }
    .gl.activa .abs-g91 { color:var(--warn); opacity:1; }
    #panelExplicar { border-top:1px solid var(--border-color); flex-shrink:0; display:flex; flex-direction:column; max-height:42%; background:var(--bg-panel); }
    #panelExplicar.oculto { display:none; }
    #cabExplicar { padding:7px 12px 5px 16px; font-size:12px; font-weight:700; color:var(--accent); }
    #cuerpoExplicar { overflow-y:auto; padding:0 12px 10px 16px; font-size:12px; line-height:1.45; }
    #cuerpoExplicar .ex-codigo { font-family: Consolas, "Cascadia Mono", Menlo, "Courier New", monospace; background:var(--linea-activa); border-radius:4px; padding:3px 7px; white-space:pre-wrap; word-break:break-all; }
    #cuerpoExplicar .ex-codigo .t-g0 { color:var(--codigo-g0); font-weight:700; } #cuerpoExplicar .ex-codigo .t-g { color:var(--accent); font-weight:700; }
    #cuerpoExplicar .ex-codigo .t-com { color:var(--codigo-com); font-style:italic; }
    #cuerpoExplicar ul { margin:6px 0 4px; padding-left:16px; }
    #cuerpoExplicar li { margin:2px 0; }
    #cuerpoExplicar li b { font-family: Consolas, "Cascadia Mono", Menlo, "Courier New", monospace; color:var(--accent); }
    #cuerpoExplicar .ex-sumas, #cuerpoExplicar .ex-res, #cuerpoExplicar .ex-nota, #cuerpoExplicar .ex-rev { margin-top:5px; padding:4px 8px; border-radius:5px; }
    #cuerpoExplicar .ex-sumas { background:var(--accent-light); font-variant-numeric:tabular-nums; }
    #cuerpoExplicar .ex-res { border-left:3px solid var(--accent); padding-left:7px; border-radius:0; }
    #cuerpoExplicar .ex-nota { color:var(--text-muted); padding-left:0; }
    #cuerpoExplicar .ex-rev.error { color:var(--danger); } #cuerpoExplicar .ex-rev.aviso { color:var(--warn); }
    #cuerpoExplicar .ex-vacio { color:var(--text-muted); margin:2px 0 4px; }
""")
    rep("""                    <button onclick="nuevoPrograma()" title="Empezar un programa nuevo en blanco">📄</button>
""", """                    <button onclick="nuevoPrograma()" title="Empezar un programa nuevo en blanco">📄</button>
                    <button id="btnExplicar" onclick="toggleExplicar()" title="💬 Explicar en castellano la línea marcada: qué hace cada código, de dónde a dónde va la fresa y el centro de los arcos">💬</button>
                    <button id="btnAbsolutas" onclick="toggleAbsolutas()" title="📍 En las líneas en G91 (incrementales), escribir al lado el punto absoluto en el que queda la fresa">📍</button>
""")
    rep("""Haz clic en cualquier línea para llevar la fresa hasta ella.</div></div>
""", """Haz clic en cualquier línea para llevar la fresa hasta ella.</div></div>
            <div id="panelExplicar" class="oculto"><div id="cabExplicar">💬 Qué hace cada línea</div><div id="cuerpoExplicar"></div></div>
""")
    rep("""        lineasCodigoEls[n] = div;
    });
    cont.appendChild(frag);
}
""", """        lineasCodigoEls[n] = div;
    });
    cont.appendChild(frag);
    explicaciones = explicarPrograma(texto, gcodeMoves);
    anotarAbsolutas();
}
""")
    rep("""function resaltarLineaCodigo(n) {
    if (n === lineaResaltada) return;""", JS + """
function resaltarLineaCodigo(n) {
    if (n === lineaResaltada) return;
    actualizarExplicacion(n);""")
    rep("""function mostrarRevision(res) {
""", """function mostrarRevision(res) {
    ultimaRevision = res;
""")
    rep("""    document.getElementById('listaCodigo').classList.toggle('oculto', v);
""", """    document.getElementById('listaCodigo').classList.toggle('oculto', v);
    actualizarExplicacion(lineaResaltada);
""")
    # Estado inicial de los dos botones (se recuerda en el navegador)
    rep("""function toggleEdicionCodigo() {""", """(function () {
    const ini = () => { const a = document.getElementById('btnExplicar'), b = document.getElementById('btnAbsolutas');
        if (a) a.classList.toggle('activo', verExplicacion); if (b) b.classList.toggle('activo', verAbsolutas); actualizarExplicacion(lineaResaltada); };
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', ini); else ini();
})();
function toggleEdicionCodigo() {""")
    rep('vertical-align:middle">V41</span>', 'vertical-align:middle">V42</span>')

open(RUTA, 'w', encoding='utf-8').write(s)
print('simulador3d.html: explicar línea y absolutas en G91 (V42)')
