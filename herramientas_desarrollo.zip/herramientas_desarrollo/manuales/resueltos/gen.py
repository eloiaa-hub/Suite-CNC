"""Programas resueltos (G90, G91 y mixta) de las piezas de piezas/*.json, con su tabla de puntos y su plano con los puntos numerados.
Lo usa construir.py. Todo se calcula desde los contornos del Calcador (puntos y curvatura de cada tramo)."""
import json, math, os, re
AQUI = os.path.dirname(os.path.abspath(__file__))
ZSEG, ZPROF, FZ, F = 20, -3, 150, 1000

def fmt(v):
    v = round(v, 3) + 0.0
    return str(int(round(v))) if abs(v - round(v)) < 5e-4 else ('%.3f' % v).rstrip('0').rstrip('.')

def area(pts):
    return sum(pts[i][0] * pts[(i + 1) % len(pts)][1] - pts[(i + 1) % len(pts)][0] * pts[i][1] for i in range(len(pts))) / 2

def centro(p1, p2, b):
    s = (1 / b - b) / 2
    return ((p1[0] + p2[0]) / 2 - s * (p2[1] - p1[1]) / 2, (p1[1] + p2[1]) / 2 + s * (p2[0] - p1[0]) / 2)

class Contorno:
    def __init__(s, c):
        s.pts = [(p['x'], p['y']) for p in c['pts']]; s.b = list(c['b'])
        n = len(s.pts)
        # muestra para el área (los arcos cuentan)
        m = []
        for i in range(n):
            p1, p2, b = s.pts[i], s.pts[(i + 1) % n], s.b[i]
            m.append(p1)
            if b:
                C = centro(p1, p2, b); r = math.dist(C, p1); a0 = math.atan2(p1[1] - C[1], p1[0] - C[0]); th = 4 * math.atan(b)
                m += [(C[0] + r * math.cos(a0 + th * k / 16), C[1] + r * math.sin(a0 + th * k / 16)) for k in range(1, 16)]
        s.muestra = m; s.area = area(m)
    def tramos(s):
        n = len(s.pts)
        for i in range(n):
            p1, p2, b = s.pts[i], s.pts[(i + 1) % n], s.b[i]
            if not b: yield dict(i=i, p1=p1, p2=p2, g='G1')
            else:
                C = centro(p1, p2, b); r = math.dist(C, p1); th = 4 * math.atan(b)
                yield dict(i=i, p1=p1, p2=p2, g='G3' if b > 0 else 'G2', c=C, r=r, ang=abs(math.degrees(th)), I=C[0] - p1[0], J=C[1] - p1[1])

def pieza(nombre):
    d = json.load(open(os.path.join(AQUI, 'piezas', nombre + '.json'), encoding='utf-8'))
    cs = [Contorno(c) for c in d['calcador']['contornos'] if len(c['pts']) >= 2]
    ext = max(cs, key=lambda c: abs(c.area))
    ints = [c for c in cs if c is not ext]
    ints.sort(key=lambda c: (min(p[1] for p in c.pts), min(p[0] for p in c.pts)))
    letras = 'ABCDEF'
    orden = [(letras[k], c, 'interior') for k, c in enumerate(ints)] + [('P', ext, 'exterior')]
    return orden

def quitar_tildes(t):
    import unicodedata
    return ''.join(ch for ch in unicodedata.normalize('NFD', t) if unicodedata.category(ch) != 'Mn')

def nombre_pt(l, i, n): return f'{l}{i % n + 1}'

def sentido(tr): return 'horario' if tr['g'] == 'G2' else 'antihorario'

# ── la tabla de puntos ──
def tabla(orden, modo):
    filas = []
    inc = modo == 'g91'
    cab = '<tr><th>Punto</th><th>X</th><th>Y</th>' + ('<th>ΔX</th><th>ΔY</th>' if inc else '') + '<th>Llega con</th><th>Centro</th><th>I</th><th>J</th></tr>'
    for l, c, tipo in orden:
        n = len(c.pts)
        filas.append(f'<tr class="grupo"><td colspan="{9 if inc else 7}">{"Interior" if tipo == "interior" else "Exterior"} · empieza y acaba en {l}1</td></tr>')
        trs = list(c.tramos())
        for k in range(n):
            p = c.pts[k]
            llega = trs[k - 1]          # el tramo que llega a este punto (al 1 llega el último, que cierra)
            prev = c.pts[k - 1]
            arc = llega['g'] != 'G1'
            d = f'<td>{fmt(p[0] - prev[0])}</td><td>{fmt(p[1] - prev[1])}</td>' if inc else ''
            if k == 0: llegatxt = '— (inicio)'; d = '<td>—</td><td>—</td>' if inc else ''; arc = False
            else: llegatxt = f'{llega["g"]} ({"recta" if not arc else sentido(llega)})'
            ctr = f'<td>X{fmt(llega["c"][0])} Y{fmt(llega["c"][1])}</td><td>{fmt(llega["I"])}</td><td>{fmt(llega["J"])}</td>' if arc else '<td></td><td></td><td></td>'
            filas.append(f'<tr><td><b>{nombre_pt(l, k, n)}</b></td><td>{fmt(p[0])}</td><td>{fmt(p[1])}</td>{d}<td>{llegatxt}</td>{ctr}</tr>')
        # el tramo que cierra
        ult = trs[-1]
        if ult['g'] != 'G1' or True:
            arc = ult['g'] != 'G1'; p = c.pts[0]; prev = c.pts[-1]
            d = f'<td>{fmt(p[0] - prev[0])}</td><td>{fmt(p[1] - prev[1])}</td>' if inc else ''
            ctr = f'<td>X{fmt(ult["c"][0])} Y{fmt(ult["c"][1])}</td><td>{fmt(ult["I"])}</td><td>{fmt(ult["J"])}</td>' if arc else '<td></td><td></td><td></td>'
            filas.append(f'<tr class="cierre"><td><b>{l}1</b></td><td>{fmt(p[0])}</td><td>{fmt(p[1])}</td>{d}<td>{ult["g"]} ({"recta" if not arc else sentido(ult)}): cierra</td>{ctr}</tr>')
    return f'<table class="tabla puntos">{cab}{"".join(filas)}</table>'

# ── el programa, con un comentario en cada línea ──
def programa(orden, modo, pasadas=None, titulo=''):
    L = []   # (código, comentario)
    pas = pasadas or [ZPROF]
    L.append((f'({quitar_tildes(titulo).upper()})', ''))
    if modo == 'g90': L.append(('G71 G90', 'milímetros y coordenadas absolutas'))
    else: L.append(('G71 G90', 'milímetros; empezamos en absolutas'))
    L.append(('T101 M06', 'fresa de Ø6'))
    L.append(('S12000 M03', 'arranca el husillo a 12000 rpm'))
    L.append(('G0 Z20', 'sube a la altura de seguridad'))
    actual = (0, 0); modal = 'G90'
    for idx, (l, c, tipo) in enumerate(orden):
        n = len(c.pts); trs = list(c.tramos()); p1 = c.pts[0]
        if idx > 0:
            L.append(('G90 G0 Z20' if modal == 'G91' else 'G0 Z20', 'sube antes de ir al siguiente trazado' + (' (la Z, siempre en G90)' if modal == 'G91' else '')))
            modal = 'G90'
        L.append(('', f'── {"Interior" if tipo == "interior" else "Exterior"}: {l}1 … {l}{n} ──'))
        if modo == 'g91' and idx > 0:
            L.append((f'G91 G0 X{fmt(p1[0] - actual[0])} Y{fmt(p1[1] - actual[1])}', f'en rápido hasta encima de {l}1, desde donde está la fresa'))
            modal = 'G91'
        else:
            L.append((f'G0 X{fmt(p1[0])} Y{fmt(p1[1])}', f'en rápido hasta encima de {l}1' + (', desde el cero pieza' if modo != 'g90' else '')))
        for kp, z in enumerate(pas):
            zl = f'G1 Z{fmt(z)} F{FZ}'
            if modal == 'G91': zl = 'G90 ' + zl; modal = 'G90'
            L.append((zl, ('baja despacio a la profundidad' if len(pas) == 1 else f'pasada {kp + 1}: baja a Z{fmt(z)}') + (' (en G90)' if modo != 'g90' else '')))
            pf = f' F{F}'
            for k, tr in enumerate(trs):
                a = nombre_pt(l, k, n); bpt = nombre_pt(l, k + 1, n); ultimo = k == n - 1
                arc = tr['g'] != 'G1'
                if modo == 'g90' or (modo == 'mix' and ultimo):
                    pre = ''
                    if modal == 'G91': pre = 'G90 '; modal = 'G90'
                    xy = f'X{fmt(tr["p2"][0])} Y{fmt(tr["p2"][1])}'
                else:
                    pre = ''
                    if modal == 'G90': pre = 'G91 '; modal = 'G91'
                    xy = f'X{fmt(tr["p2"][0] - tr["p1"][0])} Y{fmt(tr["p2"][1] - tr["p1"][1])}'
                ij = f' I{fmt(tr["I"])} J{fmt(tr["J"])}' if arc else ''
                cod = f'{pre}{tr["g"]} {xy}{ij}{pf}'; pf = ''
                if not arc: com = f'{a} → {bpt}: recta'
                else: com = f'{a} → {bpt}: arco {sentido(tr)} R{fmt(tr["r"])}, centro X{fmt(tr["c"][0])} Y{fmt(tr["c"][1])}'
                cambio = modo != 'g90' and pre
                if ultimo: com += ' (cierra, en G90)' if cambio and pre.startswith('G90') else ' (cierra)'
                elif cambio: com += ' (pasa a G91)' if pre.startswith('G91') else ' (vuelve a G90)'
                L.append((cod, com))
        actual = p1
    L.append(('G90 G0 Z20' if modal == 'G91' else 'G0 Z20', 'sube a la altura de seguridad' + (' (vuelve a absolutas)' if modal == 'G91' else '')))
    L.append(('G0 X0 Y0', 'vuelve encima del cero pieza'))
    L.append(('M05', 'para el husillo')); L.append(('M30', 'fin del programa'))
    return L

def nc(L):
    out = []
    for cod, com in L:
        if not cod: out.append(f'; {com}')
        elif com: out.append(f'{cod:<30}; {com}')
        else: out.append(cod)
    return '\n'.join(out) + '\n'

def html_prog(L):
    def col(cod):
        if cod.startswith('('): return cod
        cod = re.sub(r'\b(G7[01])\b', r'<span class="g">\1</span>', cod)
        cod = re.sub(r'\b(G9[01])\b', r'<span class="o">\1</span>', cod)
        cod = re.sub(r'\b(G[0-3])\b', r'<span class="g">\1</span>', cod)
        cod = re.sub(r'\b(M0?[0-9]+|T[0-9]+)\b', r'<span class="m">\1</span>', cod)
        cod = re.sub(r'\b(F[0-9]+)\b', r'<span class="k">\1</span>', cod)
        return cod
    out = []
    for cod, com in L:
        if not cod: out.append(f'<span class="c sep">; {com}</span>'); continue
        pad = ' ' * max(1, 30 - len(cod))
        out.append(col(cod) + (f'{pad}<span class="c">; {com}</span>' if com else ''))
    return '<pre class="prog resuelto">' + '\n'.join(out) + '</pre>'

# ── el plano del Calcador con los puntos numerados ──
def plano(nombre, orden, ancho='78%'):
    s = open(os.path.join(AQUI, 'piezas', nombre + '.svg'), encoding='utf-8').read()
    vb = [float(v) for v in re.search(r'viewBox="([^"]+)"', s).group(1).split()]
    tam = max(vb[2], vb[3]); fs = tam / 30
    etiquetas = []
    for l, c, tipo in orden:
        n = len(c.pts); cx = sum(p[0] for p in c.muestra) / len(c.muestra); cy = sum(p[1] for p in c.muestra) / len(c.muestra)
        for k, p in enumerate(c.pts):
            # hacia dentro de la pieza: en el exterior, hacia su centro; en un interior, hacia fuera del agujero
            # en un interior grande, las etiquetas dentro del agujero (no chocan con las del exterior); en uno pequeño, fuera
            xs = [q[0] for q in c.muestra]; ys = [q[1] for q in c.muestra]; grande = min(max(xs) - min(xs), max(ys) - min(ys)) > 4.5 * fs
            dx, dy = (cx - p[0], cy - p[1]) if tipo == 'exterior' or grande else (p[0] - cx, p[1] - cy)
            m = math.hypot(dx, dy) or 1; dx, dy = dx / m, dy / m
            x, y = p[0] + dx * fs * 1.25, p[1] + dy * fs * 1.25
            etiquetas.append(f'<circle cx="{p[0]:.2f}" cy="{-p[1]:.2f}" r="{fs * 0.22:.2f}" fill="#C4580C"/>'
                             f'<text x="{x:.2f}" y="{-y + fs * 0.35:.2f}" font-size="{fs:.2f}" font-weight="700" fill="#C4580C" text-anchor="middle" font-family="Arial, sans-serif" stroke="#fff" stroke-width="{fs * 0.18:.2f}" paint-order="stroke">{l}{k + 1}</text>')
    s = s.replace('</svg>', '<g id="PUNTOS">' + ''.join(etiquetas) + '</g></svg>')
    s = re.sub(r'<\?xml[^>]*>\s*', '', s)
    s = re.sub(r'width="[^"]*mm" height="[^"]*mm"', f'class="dib" style="width:{ancho}; max-height:88mm"', s, count=1)
    return s

def comprobar(orden, L):
    """Sigue el programa y comprueba que pasa por todos los puntos (en G90 y G91)."""
    x = y = 0; modal = 'G90'; vis = []
    for cod, _ in L:
        if not cod or cod.startswith('('): continue
        if 'G91' in cod: modal = 'G91'
        if 'G90' in cod: modal = 'G90'
        mx = re.search(r'X(-?[\d.]+)', cod); my = re.search(r'Y(-?[\d.]+)', cod)
        if mx or my:
            if modal == 'G90': x = float(mx.group(1)) if mx else x; y = float(my.group(1)) if my else y
            else: x += float(mx.group(1)) if mx else 0; y += float(my.group(1)) if my else 0
            vis.append((round(x, 2), round(y, 2)))
    for l, c, t in orden:
        for p in c.pts: assert (round(p[0], 2), round(p[1], 2)) in vis, (l, p)
    assert vis[-1] == (0, 0)
    return True
