"""Calcador v117 / Corrector v62: los programas muy parecidos, en el informe del profesor (no en la devolución del alumno):
en el resumen de la clase, las parejas con su porcentaje y lo que comparten solo ellos; en la hoja de cada alumno,
«👥 Muy parecido a: …».
Uso: python3 parecidos_informe.py <carpeta de la suite>   (construir_calcador.sh lo pone tras profesor.py)"""
import sys, os
P = os.path.join(sys.argv[1] if len(sys.argv) > 1 else '.', 'calcador.html')
s = open(P, encoding='utf-8').read()
def rep(a, b, cnt=1):
    global s
    n = s.count(a); assert n == cnt, f'{n} apariciones (se esperaban {cnt}) de: {a[:100]}'
    s = s.replace(a, b)
JS = r"""// ── 👥 Los parecidos en el informe del profesor (en la devolución del alumno, no) ──
function tablaParecidosInforme() {
    if (modoDevol) return '';
    try { calcularParecidos(); } catch (e) { return ''; }
    const P = masiva.parejas || []; if (!P.length) return '';
    const esc = t => String(t).replace(/&/g, '&amp;').replace(/</g, '&lt;');
    return `<h2>Programas muy parecidos</h2><table class="tr"><tr><th>Alumnos</th><th>Parecido</th><th>Qué comparten solo ellos</th></tr>${P.map(p => `<tr><td><b>${esc(masiva.lista[p.a].alumno)}</b> ↔ <b>${esc(masiva.lista[p.b].alumno)}</b></td><td style="color:${p.p >= PARECIDO.alto ? '#b0301f' : '#a86b00'};font-weight:700">${pctPar(p.p)}</td><td>${esc(razonesPareja(p))}</td></tr>`).join('')}</table>
        <p class="crit">Lo que comparten esos dos programas y no tiene nadie más en la clase: las mismas líneas raras, los mismos comentarios, los mismos errores. Es un indicio, no una prueba.</p>`;
}
const _imprimirInformesPar = imprimirInformes;
imprimirInformes = function () { if (!modoDevol) { try { calcularParecidos(); } catch (e) {} } return _imprimirInformesPar.apply(this, arguments); };
"""
rep("// Arrastrar archivos a la ventana de corrección masiva; ordenar por columna", JS + "// Arrastrar archivos a la ventana de corrección masiva; ordenar por columna")
rep("""            ${it.comProf ? `<div class="com-prof">💬 <b>Comentario del profesor:</b> ${esc(it.comProf)}</div>` : ''}""",
    """            ${it.comProf ? `<div class="com-prof">💬 <b>Comentario del profesor:</b> ${esc(it.comProf)}</div>` : ''}
            ${!modoDevol && (it.parecidos || []).length ? `<div class="ar" style="margin:-4px 0 8px;color:#b0301f;font-weight:600">👥 Muy parecido a: ${esc(textoParecidos(it))}</div>` : ''}""")
rep("""        ${tablaErroresClase(sel)}""", """        ${tablaErroresClase(sel)}
        ${tablaParecidosInforme()}""")
rep("""la columna «Parecido con» del CSV. Es un indicio, no una prueba.""", """la columna «Parecido con» del CSV; y en los informes (no en las devoluciones): las parejas en el resumen de la clase y «👥 Muy parecido a…» en la hoja de cada uno. Es un indicio, no una prueba.""")
open(P, 'w', encoding='utf-8').write(s)
print('Calcador: los parecidos en el informe del profesor')
