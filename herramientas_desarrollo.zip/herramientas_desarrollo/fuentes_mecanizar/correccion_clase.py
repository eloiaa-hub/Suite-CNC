"""Calcador v109 / Corrector v54: tres mejoras de la corrección.
- Avisos de los códigos no dados en clase (codigos_clase.js): G y M fuera de la lista de clase (configurable), O/%, D,
  la herramienta que no es T101 M06 y el husillo M03 S…; son avisos: no bajan la nota.
- Rúbrica (rubrica.js): un modo de nota por apartados, opcional (por defecto, la nota de siempre): geometría, compensación,
  lo pedido, seguridad, final del programa, formato y comentarios, con sus pesos; en el informe y en el CSV.
- 📊 Los errores más repetidos de la clase (errores_clase.js): ventana, impresión y tabla en el resumen de los informes.
Uso: python3 correccion_clase.py <carpeta de la suite>   (construir_calcador.sh lo pone tras huecos_programa.py)"""
import sys, os
AQUI = os.path.dirname(os.path.abspath(__file__))
P = os.path.join(sys.argv[1] if len(sys.argv) > 1 else '.', 'calcador.html')
s = open(P, encoding='utf-8').read()
def rep(a, b, cnt=1):
    global s
    n = s.count(a); assert n == cnt, f'{n} apariciones (se esperaban {cnt}) de: {a[:100]}'
    s = s.replace(a, b)
JS = ''.join(open(os.path.join(AQUI, f), encoding='utf-8').read() for f in ('codigos_clase.js', 'rubrica.js', 'errores_clase.js'))
rep("// Arrastrar archivos a la ventana de corrección masiva; ordenar por columna", JS + "// Arrastrar archivos a la ventana de corrección masiva; ordenar por columna")
# lo que se pide: los códigos de clase
rep("""                    <label><input type="checkbox" id="mvSentido" onchange="cambiarRequisitosMasiva()"> Exigir sentido</label>""",
    """                    <label><input type="checkbox" id="mvSentido" onchange="cambiarRequisitosMasiva()"> Exigir sentido</label>
                    <label title="Avisa (sin bajar la nota) de las G y M que no se han dado en clase, de la D, de la herramienta que no es T101 M06 y del husillo escrito M03 S…"><input type="checkbox" id="mvClase" onchange="cambiarAvisoClase(this)"> Avisar de códigos no dados en clase <button type="button" class="mv-mini-b" onclick="event.preventDefault(); editarCodigosClase()" title="La lista de códigos dados en clase">✎</button></label>""")
# los criterios: la de siempre o por apartados
rep("""                    <span class="cr-req-t">Criterios de la nota orientativa</span>
                    <label title="En proporción al contorno bien mecanizado">Geometría""",
    """                    <span class="cr-req-t">Criterios de la nota orientativa</span>
                    <label title="La de siempre: geometría, lo pedido y seguridad. Por apartados: la rúbrica, con compensación, final del programa, formato y comentarios">Nota <select id="mvModoNota" onchange="cambiarModoNota(this)"><option value="siempre">Geometría, lo pedido y seguridad</option><option value="apartados">Por apartados (rúbrica)</option></select></label>
                    <button type="button" class="btn-action sec mv-rub-b" id="mvBtnRub" onclick="editarRubrica()" style="display:none" title="Los puntos de cada apartado">⚙ Rúbrica…</button>
                    <label class="mv-crit-siempre" title="En proporción al contorno bien mecanizado">Geometría""")
rep("""                    <label title="Completos si cumple lo pedido">Lo pedido""", """                    <label class="mv-crit-siempre" title="Completos si cumple lo pedido">Lo pedido""")
rep("""                    <label title="Completos si no hay rápidos peligrosos">Seguridad""", """                    <label class="mv-crit-siempre" title="Completos si no hay rápidos peligrosos">Seguridad""")
# la barra: los errores de la clase
rep("""title="Programas muy parecidos entre alumnos: las mismas líneas, comentarios o errores que no tiene nadie más en la clase (un indicio de copia, no una prueba)">👥 Parecidos</button>""",
    """title="Programas muy parecidos entre alumnos: las mismas líneas, comentarios o errores que no tiene nadie más en la clase (un indicio de copia, no una prueba)">👥 Parecidos</button>
                <button class="btn-action sec" onclick="verErroresClase()" title="Los errores y avisos que más se repiten en la clase, con quién los tiene: qué repasar">📊 Errores de la clase</button>""")
rep("    .mv-inf { font-size:12px; cursor:help; }",
    """    .mv-mini-b { padding:0 5px; font-size:11px; line-height:16px; border:1px solid var(--border-color); border-radius:4px; background:var(--bg-panel, #fff); cursor:pointer; }
    .mv-rub-b { width:auto !important; padding:2px 10px !important; }
    .err-tabla td { vertical-align:top; } .err-tabla td.n { white-space:nowrap; font-weight:700; } .err-barra { width:70px; height:5px; background:#eee; border-radius:3px; margin-top:4px; } .err-barra i { display:block; height:100%; border-radius:3px; }
    .err-tipo { font-size:11px; font-weight:700; padding:0 5px; border-radius:4px; } .err-tipo.error { background:#fde3df; color:#b0301f; } .err-tipo.aviso { background:#fff1d6; color:#a86b00; }
    .err-tabla details summary { cursor:pointer; font-size:12px; color:var(--text-muted); }
    .mv-inf { font-size:12px; cursor:help; }""")
# los informes
rep("""            <table class="des"><tr><th>Geometría</th><th>Lo pedido</th><th>Seguridad</th><th>Contorno bien mecanizado</th></tr>
                <tr><td>${nf(v.desglose.geo, 2)} / ${nf(N.geo, 1)}</td><td>${nf(v.desglose.pedido, 1)} / ${nf(N.pedido, 1)}</td><td>${nf(v.desglose.seg, 1)} / ${nf(N.seg, 1)}</td><td>${pct(v.cob)}</td></tr></table>""",
    """            ${tablaDesglose(v, N)}""")
i = s.index('        <p class="crit">Nota orientativa sobre 10: geometría'); j = s.index('</p></section>` : \'\';', i)
s = s[:i] + '        ${tablaErroresClase(sel)}\n        <p class="crit">${textoCriterios(N)}' + s[j:]
# el CSV: los apartados de la rúbrica
rep("""...((masiva.parejas || []).length ? ['Parecido con'] : []), 'Observaciones']];""",
    """...((masiva.parejas || []).length ? ['Parecido con'] : []), ...(rubricaActiva() ? RUBRICA.map(x => x[1] + ' (rúbrica)') : []), 'Observaciones']];""")
rep("""...((masiva.parejas || []).length ? [(it.parecidos || []).length ? textoParecidos(it) : ''] : []), obs]); });""",
    """...((masiva.parejas || []).length ? [(it.parecidos || []).length ? textoParecidos(it) : ''] : []), ...(rubricaActiva() ? RUBRICA.map(x => { const a = (v.rub || []).find(y => y.k === x[0]); return d(a ? a.puntos : 0); }) : []), obs]); });""")
# la ayuda
rep("""Cada alumno se reconoce por su número de participante del zip de Aules o por su nombre.""",
    """Cada alumno se reconoce por su número de participante del zip de Aules o por su nombre. <strong>📊 Errores de la clase</strong>: los errores y avisos que más se repiten (juntando los del mismo tipo aunque sean en otra línea), con quién los tiene; también salen en el resumen de los informes. En los criterios, la <strong>nota por apartados (rúbrica)</strong> es opcional: geometría, compensación, lo pedido, seguridad, final del programa, formato y comentarios, con los puntos que elijas (⚙ Rúbrica…); sale en el informe y en el CSV. <strong>Avisar de códigos no dados en clase</strong> (✎ para cambiar la lista): avisos, sin bajar la nota, de las G y M que no se han dado, de la D, de la herramienta que no es T101 M06 y del husillo escrito M03 S….""")
open(P, 'w', encoding='utf-8').write(s)
print('Calcador: códigos de clase, rúbrica y errores más repetidos de la clase')
