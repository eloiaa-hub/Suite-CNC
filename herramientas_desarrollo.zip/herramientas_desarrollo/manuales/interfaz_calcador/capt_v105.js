// Capturas del manual del Calcador v105: los paneles ocultos (con 🏷 Nombres y 📏 Cotas), «Seleccionar puntos» y «◠ Hacer arco».
// Uso: node capt_v105.js   (desde esta carpeta; deja las imágenes en capturas/)
const path = require('path'), fs = require('fs');
const { lanzar, SUITE } = require(path.join(__dirname, '../../pruebas/comun'));
const CAP = path.join(__dirname, 'capturas'), TMP = path.join(CAP, '_placa.json'), b15 = Math.tan(Math.PI / 8);
const PLACA = { version: 7, nombre: 'ejercicio_7_placa', calcador: { version: 4, escala: 10, origen: { x: 0, y: 0 }, contornos: [
  { pts: [{ x: 0, y: 0 }, { x: 80, y: 0 }, { x: 80, y: 35 }, { x: 65, y: 50 }, { x: 10, y: 50 }, { x: 0, y: 40 }], b: [0, 0, b15, 0, 0, 0], cerrado: true, tipo: 'auto' },
  { pts: [{ x: 31, y: 22 }, { x: 19, y: 22 }], b: [1, 1], cerrado: true, tipo: 'auto' }] } };
(async () => {
  fs.writeFileSync(TMP, JSON.stringify(PLACA));
  const b = await lanzar(); const p = await b.newPage({ viewport: { width: 1440, height: 900 } }); p.on('pageerror', e => console.log('ERR', e.message));
  await p.goto('file://' + path.join(SUITE, 'calcador.html')); await p.evaluate(() => localStorage.clear()); await p.reload(); await p.waitForTimeout(1200);
  const sinSnack = () => p.evaluate(() => document.querySelectorAll('.snackbar, #snackbar, .snack').forEach(s => { s.classList.remove('show', 'visible'); s.style.display = 'none'; }));
  const foto = async (n, clip) => { await sinSnack(); await p.waitForTimeout(300); await p.screenshot({ path: path.join(CAP, n), clip }); console.log('✓', n); };
  await p.setInputFiles('#fileJSON', TMP); await p.waitForTimeout(700);
  await p.evaluate(() => { document.getElementById('projectName').value = 'ejercicio_7_placa'; const c = document.getElementById('chkCotas'); if (!c.checked) c.click(); setHerramienta('editar'); });
  await p.click('#btnPanelIzq'); await p.click('#btnPanelDer'); await p.waitForTimeout(500);
  await foto('sin_paneles.png');
  await p.click('#btnPanelIzq'); await p.click('#btnPanelDer'); await p.waitForTimeout(400);
  // una esquina R15 vectorizada: muchos tramos rectos
  await p.evaluate(() => { const c = document.getElementById('chkCotas'); if (c.checked) c.click(); const pts = [{ x:0, y:0 }, { x:60, y:0 }, { x:60, y:40 }];
    for (let k = 1; k < 8; k++) { const a = k / 8 * Math.PI / 2, r = 15 + (k % 2 ? 0.06 : -0.05); pts.push({ x: 45 + r * Math.cos(a), y: 40 + r * Math.sin(a) }); }
    pts.push({ x:45, y:55 }, { x:0, y:55 });
    contornos.length = 0; contornos.push({ pts, b: pts.map(() => 0), cerrado: true }); if (typeof memoTipos !== 'undefined') memoTipos = null; refrescar(); setHerramienta('puntos');
    encuadrar(); view.cx = 46; view.cy = 40; view.z *= 1.9; render(); });
  await p.waitForTimeout(300);
  const scr = (x, y) => p.evaluate(([x, y]) => { const r = cv.getBoundingClientRect(), q = aPantalla({ x, y }); return { x: r.left + q.x, y: r.top + q.y }; }, [x, y]);
  const a = await scr(43, 58), c = await scr(63, 38);
  await p.mouse.move(a.x, a.y); await p.mouse.down(); await p.mouse.move(c.x, c.y, { steps: 6 }); await p.waitForTimeout(200);
  const cv = await p.evaluate(() => { const r = document.getElementById('canvasWrap').getBoundingClientRect(); return { x: r.left, y: r.top, width: r.width, height: r.height }; });
  await foto('puntos_ventana.png', cv);
  await p.mouse.up(); await p.waitForTimeout(300);
  await foto('puntos_elegidos.png', cv);
  await p.click('#btnHacerArco'); await p.waitForTimeout(400);
  await foto('hacer_arco.png', cv);
  // (manual_v105.py usa la parte de arriba: 470 px de alto)
  await b.close(); fs.unlinkSync(TMP);
})();
