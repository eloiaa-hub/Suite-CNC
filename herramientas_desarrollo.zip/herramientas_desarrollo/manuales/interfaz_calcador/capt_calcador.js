// Capturas del manual del Calcador con la interfaz nueva (v95).
// Uso: node capt_calcador.js   (desde esta carpeta; deja las imágenes en capturas/)
const path = require('path'), fs = require('fs');
const { lanzar, SUITE } = require(path.join(__dirname, '../../pruebas/comun'));
const CAP = path.join(__dirname, 'capturas'), LAMINA = path.join(CAP, 'lamina_ejercicio7.png');
const TMP = path.join(CAP, '_placa.json');
const b15 = Math.tan(Math.PI / 8);
const PLACA = { version: 7, nombre: 'ejercicio_7_placa', calcador: { version: 4, escala: 10, origen: { x: 0, y: 0 }, contornos: [
  { pts: [{ x: 0, y: 0 }, { x: 80, y: 0 }, { x: 80, y: 35 }, { x: 65, y: 50 }, { x: 10, y: 50 }, { x: 0, y: 40 }], b: [0, 0, b15, 0, 0, 0], cerrado: true, tipo: 'auto' },
  { pts: [{ x: 31, y: 22 }, { x: 19, y: 22 }], b: [1, 1], cerrado: true, tipo: 'auto' }] } };

(async () => {
  fs.writeFileSync(TMP, JSON.stringify(PLACA));
  const b = await lanzar();
  const nueva = async () => {
    const p = await b.newPage({ viewport: { width: 1440, height: 900 } }); p.on('pageerror', e => console.log('ERR', e.message)); p.on('dialog', d => d.accept());
    await p.goto('file://' + path.join(SUITE, 'calcador.html')); await p.evaluate(() => localStorage.clear()); await p.reload(); await p.waitForTimeout(1000);
    return p;
  };
  const sinSnack = p => p.evaluate(() => document.querySelectorAll('.snackbar, #snackbar, .snack').forEach(s => { s.classList.remove('show', 'visible'); s.style.display = 'none'; }));
  const foto = async (p, n, clip) => { await sinSnack(p); await p.waitForTimeout(250); await p.screenshot({ path: path.join(CAP, n), clip }); console.log('✓', n); };
  const caja = (p, sels, m = 0) => p.evaluate(([sels, m]) => { let r = null; sels.forEach(s => { const e = document.querySelector(s); if (!e) return; const q = e.getBoundingClientRect(); r = r ? { x1: Math.min(r.x1, q.left), y1: Math.min(r.y1, q.top), x2: Math.max(r.x2, q.right), y2: Math.max(r.y2, q.bottom) } : { x1: q.left, y1: q.top, x2: q.right, y2: q.bottom }; });
    return { x: Math.floor(r.x1 - m), y: Math.floor(r.y1 - m), width: Math.ceil(r.x2 - r.x1 + 2 * m), height: Math.ceil(r.y2 - r.y1 + 2 * m) }; }, [sels, m]);
  const pestana = (p, bar, i) => p.evaluate(([bar, i]) => c2Pestana(document.querySelectorAll(bar + ' button')[i]), [bar, i]);
  const fondoCalibrado = p => p.evaluate(() => { fondo.s = 0.1; fondo.tx = -26; fondo.ty = -20; fondo.rot = 0; actualizarPanelFondo(); encuadrar(); render(); });
  const alFinal = p => p.evaluate(() => { const a = document.querySelector('.action-panel'); a.scrollTop = a.scrollHeight; });

  // 1) La lámina recién cargada, sin calibrar (Fondo a la vista)
  let p = await nueva();
  await p.evaluate(() => { document.getElementById('projectName').value = 'ejercicio_7_placa'; tuRefrescar(true); });
  await p.setInputFiles('#fileFondo', LAMINA); await p.waitForTimeout(800);
  await pestana(p, '#c2Tabs3', 0); await alFinal(p);
  await foto(p, 'recien.png');
  await foto(p, 'fondo.png', await caja(p, ['#c2Tabs3', '#c2PaneFondo'], 4));
  // 2) Calibrar con la cota de 80
  await p.evaluate(() => { const m = (px, py) => ({ x: fondo.tx + px * fondo.s, y: fondo.ty + (fondo.natH - py) * fondo.s }); setHerramienta('calibrar'); cal = { p1: m(260, 820), p2: m(1060, 820) }; abrirCalibracion(); render(); });
  await p.fill('#calReal', '80'); await p.waitForTimeout(200);
  await foto(p, 'calibrar.png');
  await p.close();

  // 3) Dibujando: arco tangente tras tres rectas
  p = await nueva();
  await p.setInputFiles('#fileFondo', LAMINA); await p.waitForTimeout(800); await fondoCalibrado(p);
  await p.evaluate(() => { document.getElementById('projectName').value = 'ejercicio_7_placa'; view.z *= 1; });
  const cv = await p.evaluate(() => { const r = cv.getBoundingClientRect(); return { x: r.left, y: r.top }; });
  const pant = q => p.evaluate(q => aPantalla(q), q);
  await p.evaluate(() => setHerramienta('linea'));
  for (const q of [{ x: 0, y: 0 }, { x: 80, y: 0 }, { x: 80, y: 35 }]) { const s = await pant(q); await p.mouse.click(cv.x + s.x, cv.y + s.y); await p.waitForTimeout(150); }
  await p.keyboard.press('t'); await p.waitForTimeout(150);
  { const s = await pant({ x: 66, y: 49 }); await p.mouse.move(cv.x + s.x, cv.y + s.y); await p.waitForTimeout(150); }
  await p.keyboard.type('65,50'); await p.waitForTimeout(250);
  await foto(p, 'arco.png');
  await p.close();

  // 4) La pantalla: la placa calcada y acotada, con el programa
  p = await nueva();
  await p.setInputFiles('#fileJSON', TMP); await p.waitForTimeout(700);
  await p.setInputFiles('#fileFondo', LAMINA); await p.waitForTimeout(800); await fondoCalibrado(p);
  await p.evaluate(() => { document.getElementById('projectName').value = 'ejercicio_7_placa'; const c = document.getElementById('chkCotas'); c.checked = true; c.dispatchEvent(new Event('change')); setHerramienta('editar'); sel = -1; refrescar(); encuadrar(); });
  await p.waitForTimeout(500);
  await foto(p, 'pantalla.png');
  // Dibujo, Imanes, Ejercicios, Exportar
  await foto(p, 'dibujo.png', await caja(p, ['#c2Tabs2', '#c2PaneDib'], 4));
  await p.evaluate(() => { const d = document.querySelector('#c2PaneDib details'); d.open = true; });
  await foto(p, 'imanes.png', await caja(p, ['#c2PaneDib details'], 6));
  await p.evaluate(() => { document.querySelector('#c2PaneDib details').open = false; const d = document.querySelector('.c2-comprobar'); d.open = true; tuFijarD(14); const c = document.getElementById('chkFresa'); c.checked = true; c.dispatchEvent(new Event('change')); });
  await p.waitForTimeout(400);
  await foto(p, 'comprobar.png', await caja(p, ['.c2-comprobar'], 6));
  await p.evaluate(() => { const c = document.getElementById('chkFresa'); c.checked = false; c.dispatchEvent(new Event('change')); tuFijarD(6); document.querySelector('.c2-comprobar').open = false; });
  await p.evaluate(() => { document.querySelector('#c2PaneDib details').open = false; document.querySelector('.action-panel').scrollTop = 0; });
  await foto(p, 'ejercicios.png', await caja(p, ['#c2Tabs', '#c2PaneEj'], 4));
  await pestana(p, '#c2Tabs', 1);
  await foto(p, 'corregir.png', await caja(p, ['#c2Tabs', '#c2PaneCorr'], 4));
  await pestana(p, '#c2Tabs', 0);
  await pestana(p, '#c2Tabs3', 1); await alFinal(p);
  await foto(p, 'exportar.png', await caja(p, ['#c2Tabs3', '#c2PaneExp'], 4));
  await pestana(p, '#c2Tabs3', 0);
  await foto(p, 'archivo.png', await caja(p, ['#projectName', '.c2-archivo'], 6));
  // El panel derecho: mecanizado y Contornos
  await foto(p, 'mecanizado.png', await caja(p, ['#tutorPanel .tu-cab', '#tuMec'], 4));
  await p.evaluate(() => { contornos[0].mec = { op: 'corte', prof: 10, puentes: { n: 4, ancho: 6, alto: 3 } }; sel = 0; refrescar(); tuPestana('contornos'); });
  await p.waitForTimeout(300);
  await p.evaluate(() => { document.getElementById('tuMec').open = false; });
  await p.waitForTimeout(200);
  await foto(p, 'contornos.png', await caja(p, ['#tutorPanel'], 0));
  // El reproductor del panel
  await p.evaluate(() => { document.querySelector('.action-panel').scrollTop = 0; sel = -1; refrescar(); tuPestana('programa'); cfgMec.comp = 'auto'; tuPintarMec(); tuRefrescar(true); tuInicio(); for (let i = 0; i < 16; i++) tuPaso(1); });
  await p.waitForTimeout(400);
  await foto(p, 'reproductor.png');
  // La ventana de Mecanizar
  await p.evaluate(() => { Object.assign(cfgMec, { prof: 10, paso: 5, acab: 0, comp: 'auto', coord: 'G90' }); document.getElementById('tuMec').open = true; tuPintarMec(); });
  await p.click('button.c2-ventana-mec'); await p.waitForTimeout(700);
  await foto(p, 'mecanizar.png');
  await p.close();
  // 5) Cajeras: concéntrica con isla y en zigzag
  const k = b15, CAJ = { version: 7, nombre: 'cajeras', calcador: { version: 4, escala: 10, origen: { x: 0, y: 0 }, contornos: [
    { pts: [{ x: 0, y: 0 }, { x: 160, y: 0 }, { x: 160, y: 80 }, { x: 0, y: 80 }], b: [0, 0, 0, 0], cerrado: true, tipo: 'auto' },
    { pts: [{ x: 21, y: 15 }, { x: 69, y: 15 }, { x: 75, y: 21 }, { x: 75, y: 59 }, { x: 69, y: 65 }, { x: 21, y: 65 }, { x: 15, y: 59 }, { x: 15, y: 21 }], b: [0, k, 0, k, 0, k, 0, k], cerrado: true, tipo: 'auto', mec: { op: 'cajera', prof: 4, caj: { estr: 'concentrica', paso: 50, entrada: 'rampa' } } },
    { pts: [{ x: 53, y: 40 }, { x: 37, y: 40 }], b: [1, 1], cerrado: true, tipo: 'auto', mec: { op: 'isla' } },
    { pts: [{ x: 140, y: 40 }, { x: 100, y: 40 }], b: [1, 1], cerrado: true, tipo: 'auto', mec: { op: 'cajera', prof: 4, caj: { estr: 'zigzag', paso: 50, entrada: 'vertical' } } }] } };
  fs.writeFileSync(TMP, JSON.stringify(CAJ));
  p = await nueva();
  await p.setInputFiles('#fileJSON', TMP); await p.waitForTimeout(700);
  await p.evaluate(() => { setHerramienta('editar'); sel = 1; refrescar(); tuPestana('contornos'); document.getElementById('tuMec').open = false; encuadrar(); });
  await p.waitForTimeout(500);
  await foto(p, 'cajeras.png', { x: 0, y: 0, width: 1440, height: 700 });
  await p.close();
  // 6) Texto de grabado seleccionado
  fs.writeFileSync(TMP, JSON.stringify({ version: 7, nombre: 'placa_grabada', calcador: { version: 4, escala: 10, origen: { x: 0, y: 0 }, contornos: [
    { pts: [{ x: 0, y: 0 }, { x: 140, y: 0 }, { x: 140, y: 60 }, { x: 0, y: 60 }], b: [0, 0, 0, 0], cerrado: true, tipo: 'auto' }] } }));
  p = await nueva();
  await p.setInputFiles('#fileJSON', TMP); await p.waitForTimeout(700);
  await p.evaluate(() => { Object.assign(cfgTexto, { texto: 'Pieza nº 7\nMadera 2026', altura: 12, alin: 'centro', prof: 1 }); setHerramienta('texto'); clicTexto({ x: 70, y: 36 }); setHerramienta('editar'); refrescar(); tuPestana('contornos'); document.getElementById('tuMec').open = false; encuadrar(); });
  await p.waitForTimeout(600);
  await foto(p, 'texto.png');
  await p.close();
  // 7) Operaciones con formas: tres formas superpuestas, seleccionadas
  fs.writeFileSync(TMP, JSON.stringify({ version: 7, nombre: 'formas', calcador: { version: 4, escala: 10, origen: { x: 0, y: 0 }, contornos: [
    { pts: [{ x: 0, y: 0 }, { x: 70, y: 0 }, { x: 70, y: 36 }, { x: 0, y: 36 }], b: [0, 0, 0, 0], cerrado: true, tipo: 'auto' },
    { pts: [{ x: 88, y: 18 }, { x: 52, y: 18 }], b: [1, 1], cerrado: true, tipo: 'auto' },
    { pts: [{ x: 12, y: 30 }, { x: 40, y: 30 }, { x: 40, y: 44 }, { x: 12, y: 44 }], b: [0, 1, 0, 1], cerrado: true, tipo: 'auto' }] } }));
  p = await nueva();
  await p.setInputFiles('#fileJSON', TMP); await p.waitForTimeout(700);
  await p.evaluate(() => { setHerramienta('editar'); seleccionarVarios([0, 1, 2], false); refrescar(); tuPestana('contornos'); document.getElementById('tuMec').open = false; encuadrar(); });
  await p.waitForTimeout(500);
  await p.evaluate(() => { const v = document.getElementById('tuVista_contornos'); const h = [...v.querySelectorAll('*')].find(e => /Operaciones con formas/.test(e.textContent) && e.children.length < 3); if (h) h.scrollIntoView({ block: 'start' }); });
  await p.waitForTimeout(300);
  await foto(p, 'operaciones.png');
  await p.close();
  await b.close(); fs.unlinkSync(TMP);
})();
