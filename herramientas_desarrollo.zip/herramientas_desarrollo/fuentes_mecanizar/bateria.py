"""Calcador v110-v111 / Corrector v55-v56: 🗃 Batería de corrección (v111: los ejercicios también de un archivo de biblioteca o de la biblioteca del navegador, casando por el número o el título de la ficha). Una carpeta con los ejercicios (.json), las entregas de Aules
(«<curso>-<tarea>-<número>.zip») y, si están, sus hojas de calificaciones: cada zip se casa con su ejercicio (o con sus
variantes) por el nombre de la tarea, se corrige todo de una vez y se descarga en un zip (resumen, CSV de cada tarea y las
hojas de calificaciones rellenadas).
Uso: python3 bateria.py <carpeta de la suite>   (construir_calcador.sh lo pone tras correccion_clase.py)"""
import sys, os
AQUI = os.path.dirname(os.path.abspath(__file__))
P = os.path.join(sys.argv[1] if len(sys.argv) > 1 else '.', 'calcador.html')
s = open(P, encoding='utf-8').read()
def rep(a, b, cnt=1):
    global s
    n = s.count(a); assert n == cnt, f'{n} apariciones (se esperaban {cnt}) de: {a[:100]}'
    s = s.replace(a, b)
JS = open(os.path.join(AQUI, 'bateria.js'), encoding='utf-8').read()
rep("// Arrastrar archivos a la ventana de corrección masiva; ordenar por columna", JS + "// Arrastrar archivos a la ventana de corrección masiva; ordenar por columna")
rep("""title="Corregir con las variantes del examen (12A, 12B…): cada programa se corrige con todas y se queda la que mejor encaja; avisa si no es la que le tocaba">🎲 Variantes…</button>""",
    """title="Corregir con las variantes del examen (12A, 12B…): cada programa se corrige con todas y se queda la que mejor encaja; avisa si no es la que le tocaba">🎲 Variantes…</button>
                <button class="btn-action sec" onclick="abrirBateria()" title="Varias tareas de una vez: una carpeta con los ejercicios (.json) y los zip de las entregas de Aules; cada zip se corrige con su ejercicio">🗃 Batería…</button>""")
rep("    .mv-inf { font-size:12px; cursor:help; }",
    """    .bat-tabla td { vertical-align:top; } .bat-tabla select { max-width:220px; } .bat-acc { white-space:nowrap; } .bat-acc .btn-action { width:auto; padding:3px 8px; margin:0 2px 2px 0; }
    #batCuerpo.bat-sobre { outline:3px dashed var(--accent); outline-offset:-6px; }
    .mv-inf { font-size:12px; cursor:help; }""")
rep("""<strong>📊 Errores de la clase</strong>:""", """<strong>🗃 Batería…</strong>: varias tareas de una vez. Eliges (o arrastras) una carpeta con los ejercicios (.json) y los zip de «Descargar todas las entregas» de cada tarea de Aules («curso-ISO GEO 01A-número.zip»); cada zip se casa con su ejercicio por el nombre de la tarea (o con sus variantes: «ISO GEO 01» con «ISO GEO 01A», «01B»…), y se puede cambiar a mano. ▶ Corregir todo, y ⬇ Descargar todo: el resumen, el CSV de cada tarea y, si la hoja de calificaciones de la tarea está en la carpeta, rellenada con las notas. 🔍 Ver abre cada tarea en la corrección masiva. <strong>📊 Errores de la clase</strong>:""")
open(P, 'w', encoding='utf-8').write(s)
print('Calcador: batería de corrección')
