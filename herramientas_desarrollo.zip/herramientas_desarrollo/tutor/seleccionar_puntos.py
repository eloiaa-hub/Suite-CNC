"""Herramienta «Seleccionar puntos» (doble flecha, tecla I): ventana para elegir varios vértices y borrarlos de una vez.
Calcador v105. Se aplica al texto de calcador.html desde interfaz_ordenada.py (rep_puntos(s) devuelve el texto cambiado);
incluye «◠ Hacer arco» (hacer_arco.js)."""
def rep_puntos(s):
    def rep(a, b, cnt=1):
        nonlocal s
        n = s.count(a); assert n == cnt, f'{n} apariciones (se esperaban {cnt}) de: {a[:100]}'
        s = s.replace(a, b)
    ED = '<div class="tool-btn" data-h="editar" data-tip="Editar / seleccionar (V)"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"><path d="M5 3l13 8-6 1.5L9 19z"/></svg></div>'
    rep(ED, ED + '\n                <div class="tool-btn" data-h="puntos" data-tip="Seleccionar puntos (I): arrastra una ventana para elegir varios y bórralos con Supr"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"><path d="M3 2.5l10 6.2-4.6 1.2L6.2 15z"/><path d="M10 9.5l10 6.2-4.6 1.2-2.2 5.1z"/></svg></div>')
    rep("const PISTAS = {\n", "const PISTAS = {\n    puntos:  ['PUNTOS', 'Arrastra una ventana para elegir puntos · Mayús: añadir o quitar · clic en un punto: solo ese · Supr: borrar los elegidos · Esc: ninguno'],\n")
    rep("const ATAJOS = { y:'recortar',", "const ATAJOS = { i:'puntos', y:'recortar',")
    # al cambiar de herramienta, la selección de puntos se pierde
    rep("    herramienta = h; circ = null; ran = null;", "    if (selPuntos) selPuntos.clear();\n    herramienta = h; circ = null; ran = null;")
    # ratón
    rep("        case 'editar': {\n            if (trf)", """        case 'puntos': {
            const vp = verticeEnPantalla(sx, sy), anadir = e.shiftKey || e.ctrlKey || e.metaKey;
            if (vp) { const k = vp.ci + ':' + vp.vi; if (anadir) { selPuntos.has(k) ? selPuntos.delete(k) : selPuntos.add(k); } else { selPuntos.clear(); selPuntos.add(k); } actualizarEstado(); render(); break; }
            arrastre = { tipo:'cajaPts', sx, sy, sx2:sx, sy2:sy, anadir }; break;
        }
        case 'editar': {
            if (trf)""")
    rep("    if (arrastre && arrastre.tipo === 'caja') { arrastre.sx2 = sx; arrastre.sy2 = sy; snapAct = null; render(); return; }",
        "    if (arrastre && (arrastre.tipo === 'caja' || arrastre.tipo === 'cajaPts')) { arrastre.sx2 = sx; arrastre.sy2 = sy; snapAct = null; render(); return; }")
    rep("    if (a.tipo === 'caja') {\n", """    if (a.tipo === 'cajaPts') {
        if (Math.hypot(a.sx2 - a.sx, a.sy2 - a.sy) < 4) { if (!a.anadir) selPuntos.clear(); }
        else { if (!a.anadir) selPuntos.clear(); puntosEnCaja(a.sx, a.sy, a.sx2, a.sy2).forEach(k => selPuntos.add(k)); }
        actualizarEstado(); render(); return;
    }
    if (a.tipo === 'caja') {
""")
    rep("    if (!arrastre || arrastre.tipo !== 'caja') return;\n    const { sx, sy, sx2, sy2 } = arrastre, cruce = sx2 < sx;",
        "    if (!arrastre || (arrastre.tipo !== 'caja' && arrastre.tipo !== 'cajaPts')) return;\n    const { sx, sy, sx2, sy2 } = arrastre, cruce = arrastre.tipo === 'caja' && sx2 < sx;")
    # teclado: Supr / Retroceso borran los puntos elegidos; Esc, ninguno
    rep("    if (e.key === 'Backspace') { e.preventDefault(); if (!quitarUltimoPunto()",
        "    if (k === 'a' && herramienta === 'puntos' && selPuntos.size) { e.preventDefault(); abrirHacerArco(); return; }\n    if ((e.key === 'Delete' || e.key === 'Backspace') && herramienta === 'puntos') { e.preventDefault(); borrarPuntosSel(); return; }\n    if (e.key === 'Backspace') { e.preventDefault(); if (!quitarUltimoPunto()")
    rep("    if (e.key === 'Escape' && pick) {", "    if (e.key === 'Escape' && herramienta === 'puntos' && selPuntos.size) { selPuntos.clear(); actualizarEstado(); render(); return; }\n    if (e.key === 'Escape' && pick) {")
    # la pista dice cuántos hay elegidos
    rep("    if (herramienta === 'cotaman') h = pistaCotaMan();\n", "    if (herramienta === 'cotaman') h = pistaCotaMan();\n    if (herramienta === 'puntos' && selPuntos.size) h = `${selPuntos.size} punto${selPuntos.size === 1 ? '' : 's'} elegido${selPuntos.size === 1 ? '' : 's'}${selPuntos.size >= 3 ? ' · A: hacer un arco' : ''} · Supr: borrar${selPuntos.size === 1 ? 'lo' : 'los'} · Mayús + ventana: añadir · Esc: ninguno`;\n")
    # dibujo de los puntos elegidos
    rep("    dibujarCaja();\n    if (typeof tutorDibujar", "    dibujarCaja();\n    dibujarPuntosSel();\n    dibujarPreviaArco();\n    colocarBotonArco();\n    if (typeof tutorDibujar")
    JS = r"""
// ── Seleccionar puntos (herramienta «puntos»): ventana para elegir vértices y borrarlos de una vez ──
var selPuntos = new Set();          // «ci:vi»
const puntoEditable = c => c && c.pts.length && !c.texto && !c.deTexto && !c.bloqueado;
function verticeEnPantalla(sx, sy) {
    let mejor = null;
    contornos.forEach((c, ci) => { if (!puntoEditable(c)) return; c.pts.forEach((q, vi) => { const s = aPantalla(q), d = Math.hypot(s.x - sx, s.y - sy); if (d <= 8 && (!mejor || d < mejor.d)) mejor = { d, ci, vi }; }); });
    return mejor;
}
function puntosEnCaja(x1, y1, x2, y2) {
    const a = Math.min(x1, x2), b = Math.max(x1, x2), c0 = Math.min(y1, y2), d0 = Math.max(y1, y2), out = [];
    contornos.forEach((c, ci) => { if (!puntoEditable(c)) return; c.pts.forEach((q, vi) => { const s = aPantalla(q); if (s.x >= a && s.x <= b && s.y >= c0 && s.y <= d0) out.push(ci + ':' + vi); }); });
    return out;
}
function dibujarPuntosSel() {
    if (herramienta !== 'puntos' || !selPuntos.size) return;
    ctx.save(); ctx.fillStyle = '#e67e22'; ctx.strokeStyle = '#fff'; ctx.lineWidth = 1.5;
    selPuntos.forEach(k => { const [ci, vi] = k.split(':').map(Number), c = contornos[ci], q = c && c.pts[vi]; if (!q) return; const s = aPantalla(q); ctx.beginPath(); ctx.rect(s.x - 5.5, s.y - 5.5, 11, 11); ctx.fill(); ctx.stroke(); ctx.strokeStyle = '#e67e22'; ctx.lineWidth = 1; ctx.strokeRect(s.x - 8, s.y - 8, 16, 16); ctx.strokeStyle = '#fff'; ctx.lineWidth = 1.5; });
    ctx.restore();
}
// Quita los puntos elegidos de cada contorno de una vez (un solo «deshacer»). Un tramo que pierde un extremo queda recto;
// un contorno con menos de 2 puntos desaparece; uno cerrado que se queda sin superficie pasa a abierto.
function borrarPuntosSel() {
    if (!selPuntos.size) { snack('No hay puntos elegidos: arrastra una ventana sobre ellos'); return; }
    const porC = new Map(); selPuntos.forEach(k => { const [ci, vi] = k.split(':').map(Number); if (!contornos[ci] || !contornos[ci].pts[vi]) return; if (!porC.has(ci)) porC.set(ci, new Set()); porC.get(ci).add(vi); });
    if (!porC.size) { selPuntos.clear(); render(); return; }
    guardarUndo();
    let nPts = 0, nBorrados = 0, nAbiertos = 0;
    [...porC.keys()].sort((a, b) => b - a).forEach(ci => {
        const c = contornos[ci], quitar = porC.get(ci), n = c.pts.length, quedan = [];
        for (let i = 0; i < n; i++) if (!quitar.has(i)) quedan.push(i);
        nPts += quitar.size;
        if (quedan.length < 2) { contornos.splice(ci, 1); nBorrados++; return; }
        const pts = quedan.map(i => c.pts[i]), b = quedan.map((i, k) => {
            const j = quedan[(k + 1) % quedan.length], seguido = j === (i + 1) % n && (c.cerrado || k < quedan.length - 1);
            return seguido ? (c.b[i] || 0) : 0; });
        c.pts = pts; c.b = b;
        if (!c.cerrado) c.b[c.pts.length - 1] = 0;
        if (c.cerrado && (c.pts.length < 3 && !c.b.some(x => x) || !contornoValido(c))) { c.cerrado = false; c.b[c.pts.length - 1] = 0; nAbiertos++; }
    });
    selPuntos.clear(); sel = -1; if (typeof selSet !== 'undefined' && selSet.clear) selSet.clear();
    refrescar(); actualizarEstado();
    snack(`${nPts} punto${nPts === 1 ? '' : 's'} borrado${nPts === 1 ? '' : 's'}` + (nBorrados ? ` · ${nBorrados} contorno${nBorrados === 1 ? '' : 's'} sin puntos, quitado${nBorrados === 1 ? '' : 's'}` : '') + (nAbiertos ? ` · ${nAbiertos} quedan abiertos` : '') + ' (Ctrl+Z para deshacer)');
}
"""
    import os
    JS += open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'hacer_arco.js'), encoding='utf-8').read()
    rep("function dibujarCaja() {", JS.lstrip('\n') + "function dibujarCaja() {")
    # deshacer y rehacer: los números de los puntos cambian
    rep("function deshacer() { if (!undoStack.length)", "function deshacer() { if (selPuntos) selPuntos.clear(); if (!undoStack.length)")
    rep("function rehacer() { if (!redoStack.length)", "function rehacer() { if (selPuntos) selPuntos.clear(); if (!redoStack.length)")
    # ayuda
    rep("            <h3>Imán a la rejilla</h3>", """            <h3>Seleccionar puntos</h3>
            <p>La herramienta de la doble flecha (tecla <span class="kbd">I</span>), junto a la flecha de Editar: arrastra una ventana sobre el dibujo y se eligen todos los puntos que quedan dentro (en naranja). Con <span class="kbd">Mayús</span> se añaden más; un clic sobre un punto elige solo ese. <span class="kbd">Supr</span> los borra todos de una vez (Ctrl+Z lo deshace): el tramo que pierde un extremo queda recto. Muy útil para limpiar los puntos de más de una silueta vectorizada.</p>
            <h3>Imán a la rejilla</h3>""")
    rep("if (typeof centroEd !== 'undefined' && centroEd) { centroEd = null; render(); } }", "if (typeof centroEd !== 'undefined' && centroEd) { centroEd = null; render(); } if (typeof arcoEd !== 'undefined' && arcoEd) { arcoEd = null; ctxPanel.style.minWidth = ''; render(); } }")
    rep("Muy útil para limpiar los puntos de más de una silueta vectorizada.</p>", "Muy útil para limpiar los puntos de más de una silueta vectorizada.</p>\n            <p><strong>◠ Hacer arco</strong> (o la tecla <span class=\"kbd\">A</span>), con 3 o más puntos seguidos elegidos: los cambia por un solo arco. <em>Tangente a los tramos de al lado</em> empalma con las rectas anterior y siguiente (que se recortan o alargan); <em>por los puntos</em> deja el primer y el último punto y pasa lo más cerca posible de los demás. El radio puede ser el calculado, redondeado a 0,5 mm o el que escribas. La vista previa, en discontinua naranja, dice el radio, el centro y cuánto se aparta de los puntos; si no forman un arco, no deja aplicarlo.</p>")
    return s
