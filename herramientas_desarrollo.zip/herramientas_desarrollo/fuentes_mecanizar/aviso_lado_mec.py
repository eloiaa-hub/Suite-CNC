"""Calcador v96 / Corrector v43: la ventana ⚙️ Mecanizar avisa cuando, con «G41 en todos» o «G42 en todos», algún
contorno queda del lado equivocado (la fresa se come la pieza). El panel derecho ya lo avisaba; la ventana, no.
El lado lo comprueba la propia corrección del Calcador (corregirPrograma), la misma que se usa con los alumnos.
Uso: python3 aviso_lado_mec.py <carpeta de la suite>   (después de tutor_ejercicio.py)"""
import sys, os
P = os.path.join(sys.argv[1] if len(sys.argv) > 1 else '.', 'calcador.html')
s = open(P, encoding='utf-8').read()
def rep(a, b, cnt=1):
    global s
    n = s.count(a); assert n == cnt, f'{n} apariciones (se esperaban {cnt}) de: {a[:100]}'
    s = s.replace(a, b)
rep("""        + out.avisos.map(a => `<div class="mec-aviso">⚠ ${escMec(a)}</div>`).join('');
    dibujarMec();""", """        + out.avisos.map(a => `<div class="mec-aviso">⚠ ${escMec(a)}</div>`).join('')
        + '<div id="mecAvisoLado"></div>';
    avisoLadoMec(P);
    dibujarMec();""")
rep("""function dibujarMec() {""", """// Con G41 o G42 en todos los contornos, los que quedan del lado equivocado (según la corrección del Calcador).
// El lado no depende de las pasadas: se comprueba con el programa de una sola pasada y sin acabado, después de pintar la ventana.
let tLadoMec = null;
function avisoLadoMec(P) {
    clearTimeout(tLadoMec);
    if (P.comp !== 'G41' && P.comp !== 'G42') return;
    tLadoMec = setTimeout(() => { const caja = document.getElementById('mecAvisoLado'); if (!caja) return;
        try { const r = MEC.generar(trazadosParaMecanizar(), Object.assign({}, P, { zStep: Math.abs(P.zTotal), sobre: 0 })); caja.innerHTML = r.error ? '' : textoLadoMec(r.nc, P.comp); } catch (e) { caja.innerHTML = ''; } }, 0);
}
function textoLadoMec(nc, comp) {
    let mal = [];
    try { mal = corregirPrograma(nc).hallazgos.filter(h => h.cat === 'compensacion').map(h => (h.msg.match(/trazado (C\\d+) es (EXTERIOR|INTERIOR)/) || []).slice(1)).filter(x => x.length); } catch (e) { return ''; }
    const vistos = new Set(); mal = mal.filter(([c]) => !vistos.has(c) && vistos.add(c));
    if (!mal.length) return '';
    return `<div class="mec-aviso">⚠ Con ${comp} en todos, ${mal.map(([c, t]) => `el contorno ${c} (${t === 'EXTERIOR' ? 'exterior' : 'interior'})`).join(' y ')} ${mal.length > 1 ? 'quedan' : 'queda'} del lado equivocado: la fresa se come la pieza. Para que cada contorno lleve su lado, elige «G41/G42 según el trazado» (o invierte el sentido de ${mal.length > 1 ? 'esos contornos' : 'ese contorno'}).</div>`;
}
function dibujarMec() {""")
open(P, 'w', encoding='utf-8').write(s)
print('Calcador: aviso del lado equivocado en la ventana ⚙️ Mecanizar')
