// ── Trazado desplazado: la forma de la pieza, pero con otro cero pieza ──
// Si el programa no encaja con la pieza, se busca un desplazamiento X Y con el que sus vértices caigan sobre los del plano
// (votando entre las diferencias de vértices) y se corrige otra vez con la pieza movida. Si así sale bien, el primer error es
// «Trazado desplazado: … el cero pieza que ha usado no es el del plano…». Los demás errores y la nota no cambian.
function verticesCorte(r) {
    const V = [], ya = new Set(), mete = p => { const k = p.x.toFixed(3) + ',' + p.y.toFixed(3); if (!ya.has(k)) { ya.add(k); V.push(p); } };
    ((r.prog && r.prog.segs) || []).filter(s => s.corte || (r._sinZ && !s.rapido)).forEach(s => { mete(s.p1); mete(s.p2); });
    return V;
}
// ¿Está el punto sobre el contorno de alguna pieza? (sobre la línea, no solo en un vértice: las entradas van a mitad de lado)
function tramosPlano() { const S = []; contornos.filter(c => c.pts.length >= 2 && !c.texto && !c.deTexto && !soloFabricar(c)).forEach(c => { const m = muestrearContorno(c); for (let i = 0; i + 1 < m.length; i++) S.push([m[i], m[i + 1]]); if (c.cerrado && m.length > 2) S.push([m[m.length - 1], m[0]]); }); return S; }
function sobreContorno(p, S, tol) {
    return S.some(([a, b]) => { const dx = b.x - a.x, dy = b.y - a.y, L = dx * dx + dy * dy; let t = L ? ((p.x - a.x) * dx + (p.y - a.y) * dy) / L : 0; t = Math.max(0, Math.min(1, t));
        return Math.hypot(a.x + t * dx - p.x, a.y + t * dy - p.y) <= tol; });
}
function buscarDesplazamiento(r) {
    const piezas = contornos.filter(c => c.pts.length >= 2 && !c.texto && !c.deTexto && !soloFabricar(c)), Q = [].concat(...piezas.map(c => c.pts));
    const V = verticesCorte(r); if (V.length < 3 || !Q.length) return null;
    const tol = Math.max(0.05, +cfgCorr.tol || 0.02), votos = new Map();
    V.forEach(p => Q.forEach(q => { const k = (Math.round((q.x - p.x) * 100) / 100) + ',' + (Math.round((q.y - p.y) * 100) / 100); votos.set(k, (votos.get(k) || 0) + 1); }));
    const cand = [...votos.entries()].sort((a, b) => b[1] - a[1]).slice(0, 12).map(([k]) => { const [x, y] = k.split(',').map(Number); return { x, y }; });
    let mejor = null;
    const S = tramosPlano(), tolS = Math.max(0.1, tol * 2);
    cand.forEach(d => { if (Math.hypot(d.x, d.y) < 0.05) return;
        const n = V.filter(p => sobreContorno({ x: p.x + d.x, y: p.y + d.y }, S, tolS)).length;
        if (!mejor || n > mejor.n) mejor = { ...d, n }; });
    // casi todos los vértices del programa caen sobre vértices del plano, y casi todos los del plano tienen el suyo
    if (!mejor || mejor.n < Math.max(3, 0.6 * V.length)) return null;
    const usados = Q.filter(q => V.some(p => Math.abs(p.x + mejor.x - q.x) <= tol && Math.abs(p.y + mejor.y - q.y) <= tol)).length;
    if (usados < 0.7 * Q.length) return null;
    return mejor;
}
// Corregir con la pieza movida (el programa no se toca): ¿sale bien?
function corregirDesplazado(texto, d) {
    const antes = contornos, c0 = corr, base = typeof _corregirProgramaClase === 'function' ? _corregirProgramaClase : corregirPrograma;
    try { contornos = contornos.map(c => ({ ...c, pts: c.pts.map(p => ({ x: p.x - d.x, y: p.y - d.y })) })); memoTipos = null; return base(texto); }
    catch (e) { return null; } finally { contornos = antes; memoTipos = null; corr = c0; }
}
function dondeCero(d) {
    const P = [].concat(...contornos.filter(c => c.pts.length >= 2 && !c.texto && !c.deTexto).map(c => muestrearContorno(c))), b = bboxPts(P), t = 0.05;
    const h = Math.abs(d.x - b.x0) < t ? 'izquierda' : Math.abs(d.x - b.x1) < t ? 'derecha' : null, v = Math.abs(d.y - b.y0) < t ? 'abajo' : Math.abs(d.y - b.y1) < t ? 'arriba' : null;
    const enPlano = `X${fmt(d.x, 3)} Y${fmt(d.y, 3)} en el plano`;
    if (h && v) return `en la esquina de ${v} a la ${h} de la pieza (${enPlano})`;
    const esVertice = contornos.some(c => c.pts.some(p => Math.abs(p.x - d.x) < t && Math.abs(p.y - d.y) < t));
    return esVertice ? `en un vértice de la pieza (${enPlano})` : `en ${enPlano}`;
}
const _corregirProgramaDespl = corregirPrograma;
corregirPrograma = function (texto) {
    const r = _corregirProgramaDespl.apply(this, arguments);
    try {
        if (!r || r.error || r.piezaOk) return r;
        const altura = r.trazado && !r.trazado.ok, conCortes = r.resumen && r.resumen.cortes;
        if (!altura && !conCortes) return r;
        const txt = altura ? r._textoSinZ : texto; if (!txt) return r;
        const rv = altura ? Object.assign({}, r, { prog: interpretarISO(txt), _sinZ: true }) : r;
        const d = buscarDesplazamiento(rv); if (!d) return r;
        const r2 = corregirDesplazado(txt, d);
        if (!r2 || r2.error || (r2.cobertura || 0) < 0.95) return r;
        // el trazado (solo la geometría: los errores de seguridad o de lo pedido, aparte)
        const geoMal = r2.hallazgos.filter(h => h.tipo === 'error' && (h.cat === 'geometria' || h.cat === 'compensacion')).length, entero = (r2.cobertura || 0) >= 0.995 && !geoMal;
        const sg = v => (v > 0 ? '+' : '') + fmt(v, 3), mov = { x: -d.x, y: -d.y };
        const p0 = verticesCorte(rv)[0], ej = p0 ? ` Por ejemplo, el punto que ha programado como X${fmt(p0.x, 3)} Y${fmt(p0.y, 3)} es, con el cero del plano, X${fmt(p0.x + d.x, 3)} Y${fmt(p0.y + d.y, 3)}.` : '';
        r.desplazado = { x: mov.x, y: mov.y, ok: entero, cob: Math.max(0, Math.min(1, r2.cobertura || 0)) };
        r.hallazgos.unshift({ tipo: 'error', cat: 'desplazado', linea: null,
            msg: `Trazado desplazado: el recorrido tiene la forma de la pieza${entero ? '' : ' (casi entera)'}, pero movido X${sg(mov.x)} Y${sg(mov.y)}: el cero pieza que ha usado no es el del plano, lo ha puesto ${dondeCero(d)}.${ej} Los errores de debajo son, sobre todo, consecuencia de esto.`,
            pista: 'toma las coordenadas desde el cero pieza X0 Y0 que marca el plano' });
        if (altura) r.trazado.desplazado = r.desplazado;
        r.errores = r.hallazgos.filter(h => h.tipo === 'error').length;
    } catch (e) { console.warn(e); }
    return r;
};
function extraVeredicto(it) { const dz = it && it.r && it.r.desplazado; return dz ? ` <span class="mv-despl" title="El recorrido tiene la forma de la pieza, movido X${dz.x > 0 ? '+' : ''}${fmt(dz.x, 3)} Y${dz.y > 0 ? '+' : ''}${fmt(dz.y, 3)}: otro cero pieza">· trazado desplazado</span>` : ''; }
