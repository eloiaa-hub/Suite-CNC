// ── 🖨 Imprimir desde la batería: los informes o las devoluciones de todas las tareas, en un solo documento ──
// (el PDF se guarda desde la ventana de impresión del navegador: «Guardar como PDF»)
function htmlInformesTarea(t, devol) {
    let h = ''; const o = window.open;
    window.open = () => ({ document: { open() {}, write(x) { h += x; }, close() {} }, focus() {}, print() {}, addEventListener() {} });
    try { conTareaBat(t, () => devol ? imprimirDevoluciones() : imprimirInformes()); } catch (e) { console.warn(e); } finally { window.open = o; }
    return h;
}
function imprimirBateria(devol, soloK) {
    const T = (soloK === undefined ? bat.tareas : [bat.tareas[soloK]]).filter(t => t && t.res && t.res.lista && t.res.lista.length);
    if (!T.length) { snack('Corrige antes las tareas (▶ Corregir todo)'); return; }
    let estilo = '', cuerpos = '';
    T.forEach(t => { const h = htmlInformesTarea(t, devol); if (!h) return;
        if (!estilo) estilo = (h.match(/<style>([\s\S]*?)<\/style>/) || [])[1] || '';
        cuerpos += ((h.match(/<body>([\s\S]*)<\/body>/) || [])[1] || '').replace(/<script[\s\S]*?<\/script>/g, '') + '\n'; });
    if (!cuerpos) { snack('No se ha podido preparar ningún informe'); return; }
    const esc = x => String(x).replace(/&/g, '&amp;').replace(/</g, '&lt;');
    const tit = `${devol ? 'Devoluciones' : 'Informes'} — ${T.length === 1 ? esc(T[0].tarea) : `batería de ${T.length} tareas`}`;
    const w = window.open('', '_blank'); if (!w) { snack('El navegador ha bloqueado la ventana de impresión: permite las ventanas emergentes para este archivo'); return; }
    w.document.open(); w.document.write(`<!DOCTYPE html><html lang="es"><head><meta charset="utf-8"><title>${tit}</title><style>${estilo}</style></head><body>${cuerpos}<script>window.onload = () => setTimeout(() => window.print(), 400);<\/script></body></html>`); w.document.close();
    snack(`${tit}: en la ventana de impresión, «Guardar como PDF» para tenerlo en un archivo`);
}
