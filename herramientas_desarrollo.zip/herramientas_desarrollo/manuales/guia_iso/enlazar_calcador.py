"""Manual del Calcador: la estrategia Concordancia / Oposición explicada (con M03, G41 = concordancia) y el enlace a los apuntes de códigos ISO.
Uso: python3 enlazar_calcador.py <suite>   (una sola vez)"""
import sys, os
P = os.path.join(sys.argv[1] if len(sys.argv) > 1 else '../../..', 'manual_calcador.html'); s = open(P, encoding='utf-8').read()
assert 'apuntes_iso' not in s, 'ya aplicado'
def rep(a, b):
    global s
    assert s.count(a) == 1, (s.count(a), a[:80]); s = s.replace(a, b)
rep('<strong>Concordancia</strong> y <strong>Oposición</strong> eligen el sentido de cada contorno para cortar así.',
    '<strong>Concordancia</strong> y <strong>Oposición</strong> eligen el sentido de cada contorno para cortar así. Con el husillo a derechas (M03), concordancia es cortar con la fresa a la izquierda (G41): los exteriores en sentido horario y los interiores en antihorario; oposición, al revés (G42).')
i = s.index('<strong>Concordancia</strong> y <strong>Oposición</strong> eligen'); j = s.index('</table>', i) + len('</table>')
s = s[:j] + '\n<div class="nota consejo"><strong>📘 Los códigos, explicados.</strong> Los apuntes <a href="apuntes_iso.html">Códigos ISO de la Suite CNC</a> (también en PDF, <code>apuntes_iso.pdf</code>) explican para el alumnado todos los códigos que escribe ⚙️ Mecanizar, con la compensación G41 y G42 paso a paso.</div>' + s[j:]
open(P, 'w', encoding='utf-8').write(s); print('manual_calcador.html: estrategia explicada y enlace a los apuntes')
