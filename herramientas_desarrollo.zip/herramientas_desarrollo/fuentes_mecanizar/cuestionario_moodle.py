"""Calcador / Corrector: 📝 Cuestionario para Aules (Moodle XML) a partir del ejercicio abierto, con variantes.
Uso: python3 cuestionario_moodle.py <carpeta de la suite>
"""
import sys, os
AQUI = os.path.dirname(os.path.abspath(__file__))
P = os.path.join(sys.argv[1] if len(sys.argv) > 1 else '.', 'calcador.html')
s = open(P, encoding='utf-8').read()
def rep(a, b, cnt=1):
    global s
    n = s.count(a)
    assert n == cnt, f'{n} apariciones (se esperaban {cnt}) de: {a[:100]}'
    s = s.replace(a, b)
JS = open(os.path.join(AQUI, 'cuestionario_moodle.js'), encoding='utf-8').read()

rep("function abrirVariantes() {", JS + "function abrirVariantes() {")
rep("""    html[data-visor="1"] .params-box.visor-si > button[onclick*="abrirVariantes"] { order: -2; }""",
    """    html[data-visor="1"] .params-box.visor-si > button[onclick*="abrirVariantes"] { order: -2; }
    html[data-visor="1"] .params-box.visor-si > button[onclick*="abrirCuestionario"] { order: -2; }
    .cu-lista { flex: 1; overflow-y: auto; display: flex; flex-direction: column; gap: 10px; }
    .cu-cab span { display: inline-block; min-width: 18px; padding: 0 4px; margin-left: 2px; border-radius: 5px; background: var(--accent-soft, rgba(0,90,156,.12)); text-align: center; font-weight: 600; cursor: help; }
    .cu-plano { text-align: center; } .cu-plano img { max-width: 100%; max-height: 330px; border: 1px solid var(--border-color, #d7dee7); border-radius: 8px; background: #fff; }
    .cu-preg { border: 1px solid var(--border-color, #d7dee7); border-radius: 8px; padding: 8px 12px; font-size: 13px; line-height: 1.5; }
    .cu-preg p { margin: 4px 0; } .cu-tit { font-weight: 700; margin-bottom: 2px; }
    .cu-sol { color: #1e7a46; background: rgba(30,158,90,.12); padding: 0 5px; border-radius: 4px; } .cu-no { color: #8a97a8; }""")
rep("""                    <button class="btn-action sec" onclick="abrirVariantes()" """,
    """                    <button class="btn-action sec" onclick="abrirCuestionario()" title="Preguntas para un cuestionario de Aules (Moodle XML) sobre este ejercicio: coordenadas G90, G91 y polares, I J, R, G2/G3 y G41/G42, con el plano y varias variantes para que cada alumno reciba la suya">📝 Cuestionario para Aules…</button>
                    <button class="btn-action sec" onclick="abrirVariantes()" """)
rep("""<div class="modal-overlay" id="modalCreditos" onclick="if(event.target===this)cerrarCreditos()">""",
"""<div class="modal-overlay" id="modalCuest" onclick="if(event.target===this)cerrarCuestionario()">
    <div class="help-modal var-modal">
        <div class="help-header"><h2>📝 Cuestionario para Aules (Moodle XML)</h2><button class="help-close" onclick="cerrarCuestionario()">✕</button></div>
        <div class="var-cuerpo">
            <div class="var-opciones">
                <p class="ctx-nota">Preguntas sobre este ejercicio, con su plano: el alumno escribe los valores y Aules los corrige solo. Cada pregunta sale en varias <b>variantes</b> de la pieza (las de 🎲 Variantes: simetrías, giro, otro cero pieza, escala), cada una con su plano y su solución.</p>
                <div class="param-line" title="Cuántas versiones de cada pregunta (1: solo el ejercicio original). Las transformaciones son las marcadas en 🎲 Variantes para examen">Variantes <input type="number" id="cuN" min="1" max="8" step="1" value="4" onchange="cambiarCuestionario()"></div>
                <div class="param-line" title="Margen que se acepta en cada valor numérico (mm). En los ángulos de las polares, cinco veces más (en grados)">Tolerancia (mm) <input type="text" id="cuTol" value="0.01" style="width:60px" onchange="cambiarCuestionario()"></div>
                <div class="cr-req-t" style="margin-top:6px">Preguntas de cada tipo</div>
                <div id="cuTipos"></div>
                <p class="ctx-nota">En Aules: <b>Banco de preguntas → Importar → Formato Moodle XML</b>. Cada pregunta queda en su propia categoría con sus variantes; en el cuestionario, <b>Añadir → una pregunta aleatoria</b> de cada categoría: así cada alumno recibe una variante distinta.</p>
                <button class="btn-action" id="cuDescargar" onclick="descargarCuestionario()" title="Descarga el archivo .xml para importarlo en el banco de preguntas de Aules">⬇ Descargar el XML de Moodle</button>
            </div>
            <div class="cu-lista" id="cuLista"></div>
        </div>
    </div>
</div>
<div class="modal-overlay" id="modalCreditos" onclick="if(event.target===this)cerrarCreditos()">""")
rep("""    if (document.getElementById('modalVariantes').classList.contains('visible')) { if (e.key === 'Escape') cerrarVariantes(); return; }""",
    """    if (document.getElementById('modalVariantes').classList.contains('visible')) { if (e.key === 'Escape') cerrarVariantes(); return; }
    if (document.getElementById('modalCuest').classList.contains('visible')) { if (e.key === 'Escape') cerrarCuestionario(); return; }""")
# ayuda
rep("""            <p><strong>📚 Corrección masiva</strong>""", """            <p><strong>📝 Cuestionario para Aules</strong> (Exportar): prepara preguntas sobre el ejercicio abierto para un cuestionario de Aules (Moodle XML): coordenadas absolutas, incrementales y polares de un punto, I y J o R de un arco, ¿G2 o G3? y ¿G41 o G42? Cada pregunta lleva el plano con los puntos (P1, P2…), los arcos (A1, A2…), el cero pieza y el sentido de recorrido, y sale en varias variantes de la pieza (las de 🎲 Variantes). Impórtalo en el banco de preguntas y, en el cuestionario, añade una pregunta aleatoria de cada categoría: cada alumno recibe una variante distinta y Aules la corrige solo.</p>
            <p><strong>📚 Corrección masiva</strong>""")
open(P, 'w', encoding='utf-8').write(s)
print('Calcador: cuestionario para Aules (Moodle XML):', P)
