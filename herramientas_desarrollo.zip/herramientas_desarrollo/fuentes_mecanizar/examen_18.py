#!/usr/bin/env python3
"""Calcador v121: 🎲 Variantes hasta 26 (antes, 8), para que cada alumno de la clase tenga la suya, y ◠ Examen de I J…, que abre
Arcos I J con su ventana de examen para Aules. Uso: python3 examen_18.py CARPETA_DE_LA_SUITE (después de hoja_ij.py)."""
import os, re, sys
d = sys.argv[1] if len(sys.argv) > 1 else '.'
p = os.path.join(d, 'calcador.html'); s = open(p, encoding='utf-8').read()
def rep(a, b):
    global s
    assert s.count(a) == 1, (s.count(a), a[:80]); s = s.replace(a, b)
rep('id="varN" min="2" max="8"', 'id="varN" min="2" max="26"')
rep("Object.assign(varCfg, { n: Math.max(2, Math.min(8, +g('varN').value || 4))", "Object.assign(varCfg, { n: Math.max(2, Math.min(26, +g('varN').value || 4))")
b = '<button class="btn-action sec" onclick="abrirHojaIJ()"'
i = s.index(b); j = s.index('</button>', i) + len('</button>')
s = s[:j] + '''\n                    <button class="btn-action sec" onclick="window.open('arcos_ij.html#profesor', '_blank')" title="Abre Arcos I J con la ventana para preparar un examen que Aules corrige solo">◠ Examen de I J…</button>''' + s[j:]
m = re.search(r'vertical-align:middle">v(\d+)</span></span>', s); assert m
s = s.replace(m.group(0), m.group(0).replace('v' + m.group(1), 'v121'), 1)
open(p, 'w', encoding='utf-8').write(s); print('calcador.html: hasta 26 variantes y ◠ Examen de I J, v121')
