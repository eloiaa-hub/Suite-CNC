"""Simulador 3D V44: la fresa del panel manda sobre la de la base de herramientas.
Antes, si el programa traía una T de la base (T101 M06), el corte y la fresa dibujada usaban el tipo, el ángulo y el Ø
de la base (T101: plana), aunque en el panel se eligiera bola o V, o el programa dijera «fresa de bola» en un comentario.
Ahora lo que se cambia en el panel (tipo, ángulo de la V, Ø o una fresa de la base) se aplica a la T que está usando
el programa en ese punto, solo en esta simulación: la base no cambia. Los comentarios del programa también cuentan.
Al avanzar por un programa con varias herramientas, el panel muestra la de cada tramo.
Uso: python3 simulador_fresa_panel.py <carpeta de la suite>      (ya aplicado: no se vuelve a ejecutar)"""
import sys, os
RUTA = os.path.join(sys.argv[1] if len(sys.argv) > 1 else '.', 'simulador3d.html')
s = open(RUTA, encoding='utf-8').read()
assert 'herrPanel' not in s, 'ya aplicado'
def rep(a, b, cnt=1):
    global s
    assert s.count(a) == cnt, (a[:70], s.count(a)); s = s.replace(a, b)

# 1) la base, con los cambios del panel para esta simulación
rep("""    moves.forEach(m => { const h = m.T ? base.get(m.T) : null; m.herr = h ? { T:h.T, d:h.d, tipo:h.tipo, angulo:h.angulo, nombre:h.nombre } : null; if (m.T && !h) faltan.add(m.T); });""",
"""    moves.forEach(m => { const h = m.T ? base.get(m.T) : null, o = h ? herrPanel[h.T] || {} : {};
        m.herr = h ? { T:h.T, d:o.d || h.d, tipo:o.tipo || h.tipo, angulo:o.angulo || h.angulo, nombre:h.nombre, cambiada:!!(o.d || o.tipo) } : null; if (m.T && !h) faltan.add(m.T); });""")
rep("// Ejecuta f con la herramienta h como si fuera la del panel", """// Cambios del panel para la T del programa, solo en esta simulación (la base de herramientas no cambia): { T: { tipo, angulo, d } }
let herrPanel = {};
// La T de la base que usa el programa donde está la fresa (o la primera del programa)
function tDelPanel() {
    const p = puntosPlanos && puntosPlanos[Math.round(indicePlano)] , mv = p ? gcodeMoves[p.movIdx] : null;
    if (mv && mv.herr) return mv.herr.T;
    const m = gcodeMoves.find(x => x.herr); return m ? m.herr.T : null;
}
// El panel ha cambiado (campos: tipo y ángulo, o Ø): se aplica a esa T y se rehace la simulación
function panelAHerramienta(campos) {
    if (!gcodeMoves.length) return false;
    const T = tDelPanel(); if (!T) return false;
    herrPanel[T] = Object.assign(herrPanel[T] || {}, campos);
    herrVista = null; recalcularTrayectoria(); if (typeof evaluarPlano === 'function') evaluarPlano();
    const h = HB.porT(T), o = herrPanel[T], tipo = o.tipo || h.tipo, d = o.d || h.d;
    const nota = document.getElementById('notaHerrPrograma');
    nota.textContent = `✏️ T${T} en esta simulación: ${tipo === 'bola' ? 'fresa de bola' : tipo === 'v' ? 'fresa en V ' + (o.angulo || h.angulo) + '°' : 'fresa plana'} Ø${+(+d).toFixed(3)} mm. La base de herramientas no cambia.`;
    nota.style.display = 'block';
    return true;
}
// Ejecuta f con la herramienta h como si fuera la del panel""")

# 2) el panel: tipo, ángulo y Ø
rep("""    document.getElementById('filaAnguloV').style.display = tipoFresa === 'v' ? 'block' : 'none';
    reconstruirFresaSolida();
    if (material) { reiniciarMaterial(); actualizarMaterial(indicePlano); }
}""", """    document.getElementById('filaAnguloV').style.display = tipoFresa === 'v' ? 'block' : 'none';
    if (!sincronizandoPanel && panelAHerramienta({ tipo: tipoFresa, angulo: anguloV })) return;
    reconstruirFresaSolida();
    if (material) { reiniciarMaterial(); actualizarMaterial(indicePlano); }
}
let sincronizandoPanel = false;""")
rep("""    if (!desdePrograma) document.getElementById('notaHerrPrograma').style.display = 'none';
    reconstruirFresaSolida();""", """    if (!desdePrograma) document.getElementById('notaHerrPrograma').style.display = 'none';
    if (!desdePrograma && !sincronizandoPanel && panelAHerramienta({ d: diametroFresa })) return;
    reconstruirFresaSolida();""")
# una fresa elegida en el desplegable de la base: tipo, ángulo y Ø a la vez (una sola simulación)
rep("""    document.getElementById('diamHerramienta').value = h.d;
    actualizarTipoFresa(); actualizarDiametroHerramienta();""", """    document.getElementById('diamHerramienta').value = h.d;
    sincronizandoPanel = true; try { actualizarTipoFresa(); actualizarDiametroHerramienta(); } finally { sincronizandoPanel = false; }
    panelAHerramienta({ tipo: tipoFresa, angulo: anguloV, d: diametroFresa });""")

# 3) los comentarios del programa («fresa de bola», «Ø6», «V 60°») valen para su herramienta si solo usa una
rep("""    const nota = document.getElementById('notaHerrPrograma');
    nota.style.display = 'none';
    const lineas = texto.split(/\\r?\\n/);""", """    const nota = document.getElementById('notaHerrPrograma');
    nota.style.display = 'none';
    herrPanel = {};
    const lineas = texto.split(/\\r?\\n/);""")
rep("""    if (partes.length) {
        nota.textContent = '📄 Leído del programa: ' + partes.join(', ') + '.';""", """    {   const Ts = [...new Set(gcodeMoves.filter(m => m.T).map(m => m.T))], T1 = Ts.length === 1 && HB.porT(Ts[0]) ? Ts[0] : null;
        if (T1) { const o = {}; if (diam > 0 && !hT) o.d = diam; if (tipo) { o.tipo = tipo; if (ang) o.angulo = ang; } if (Object.keys(o).length) herrPanel[T1] = o; } }
    if (partes.length) {
        nota.textContent = '📄 Leído del programa: ' + partes.join(', ') + '.';""")

# 4) al pasar a otra herramienta (M06), el panel muestra la de ese tramo
rep("""    if (claveH !== herrVista) { herrVista = claveH; conHerramienta(hM, reconstruirFresaSolida); diamVista = hM ? hM.d : diametroFresa; }""",
"""    if (claveH !== herrVista) { herrVista = claveH; conHerramienta(hM, reconstruirFresaSolida); diamVista = hM ? hM.d : diametroFresa;
        if (hM) { const g = id => document.getElementById(id); g('tipoFresa').value = hM.tipo || 'plana'; if (hM.angulo) g('anguloV').value = hM.angulo; g('diamHerramienta').value = +(+hM.d).toFixed(3);
            g('filaAnguloV').style.display = hM.tipo === 'v' ? 'block' : 'none'; } }""")
rep('vertical-align:middle">V43</span>', 'vertical-align:middle">V44</span>')
open(RUTA, 'w', encoding='utf-8').write(s)
print('Simulador V44: la fresa del panel manda sobre la de la base')
