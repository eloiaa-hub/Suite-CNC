// ── 👥 Programas parecidos entre alumnos (corrección masiva) ──
// Dos programas bien hechos de la misma pieza se parecen mucho sin haberse copiado: lo que cuenta es lo que SOLO tienen
// esos dos (o muy pocos) en la clase: las mismas líneas escritas igual (sin contar los números de bloque, que se cambian
// fácilmente), los mismos comentarios (por trozos de 3 palabras, aunque cambien alguna) y los mismos errores.
// Cada coincidencia pesa más cuanto más rara es en la clase. Es un indicio, no una prueba.
const PARECIDO = { umbral: 0.5, alto: 0.75, minComun: 2 };
const normComPar = c => c.toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9ñ]+/g, ' ').trim();
const lineaPar = l => l.toUpperCase().replace(/^\s*N\s*\d+\s*/, '').replace(/\s+/g, ' ').trim();
// lo que dice la línea, escrito como sea (G01 = G1, X80.000 = X80, Z+20 = Z20, sin espacios ni avance)
const contenidoPar = k => k.replace(/\s+/g, '').replace(/F[-+]?[\d.]+/g, '').replace(/([A-Z])([-+]?(?:\d+\.?\d*|\.\d+))/g, (m, c, v) => c + String(+v));
function rasgosPrograma(texto) {
    const lin = [], com = [], sec = [], lineas = String(texto || '').replace(/\r/g, '').split('\n');
    lineas.forEach((l, i) => {
        const cs = []; let cod = l.replace(/\(([^)]*)\)/g, (m, c) => { cs.push(c); return ' '; });
        const pc = cod.indexOf(';'); if (pc >= 0) { cs.push(cod.slice(pc + 1)); cod = cod.slice(0, pc); }
        const k = lineaPar(cod); if (k && !/^%$/.test(k)) lin.push({ k, c: contenidoPar(k), i });
        { const t = normComPar(cs.join(' ')); if (t.length >= 3) sec.push({ t: contenidoPar(k || '') + '|' + t, i }); }
        cs.forEach(c => { const p = normComPar(c).split(' ').filter(Boolean); if (p.join('').length < 4) return;
            if (p.length < 3) com.push({ k: p.join(' '), i }); else for (let j = 0; j + 3 <= p.length; j++) com.push({ k: p.slice(j, j + 3).join(' '), i }); });
    });
    // la secuencia de los comentarios: cada uno con su línea y los dos siguientes (dos alumnos pueden poner «arriba» en la
    // misma línea; que coincidan tres seguidos, en las mismas líneas, ya es raro)
    const cs = []; for (let j = 0; j + 2 < sec.length; j++) cs.push({ k: sec[j].t + '>' + sec[j + 1].t + '>' + sec[j + 2].t, i: sec[j + 2].i });
    return { lin, com, cs, n: lin.length };
}
const errPar = it => it.r && it.r.hallazgos ? [...new Set(it.r.hallazgos.filter(h => h.tipo === 'error' || h.tipo === 'aviso').map(h => String(h.msg).replace(/\bN\d+\b|l[ií]nea \d+/gi, '#')))] : [];
function rasgosDe(it) { if (!it._par || it._par.t !== it.texto) it._par = { t: it.texto, f: rasgosPrograma(it.texto) }; return it._par.f; }
// Cuántos alumnos tienen cada cosa (para ver lo raro que es)
function cuentasClase(items) {
    const df = { lit: new Map(), con: new Map(), com: new Map(), cs: new Map(), err: new Map() }, sube = (m, s) => s.forEach(x => m.set(x, (m.get(x) || 0) + 1));
    items.forEach(it => { const f = rasgosDe(it); sube(df.lit, new Set(f.lin.map(x => x.k))); sube(df.con, new Set(f.lin.map(x => x.c))); sube(df.com, new Set(f.com.map(x => x.k))); sube(df.cs, new Set(f.cs.map(x => x.k))); sube(df.err, new Set(errPar(it))); });
    return df;
}
// Una línea igual cuenta por lo rara que es lo que dice (una línea bien hecha la tienen casi todos, escrita de una forma u otra)
// y por lo pocos que la escriben exactamente así
function compararDos(A, B, df, N) {
    const fa = rasgosDe(A), fb = rasgosDe(B), idf = (m, x) => Math.log((N + 1) / (m.get(x) || 1)), pocos = d => d <= 2 ? 1 : 2 / d;
    const solo = { lin: 0, com: 0, err: 0 }, parte = { lin: 0, com: 0, cs: 0, err: 0 }; let nSec = 0;
    const litB = new Set(fb.lin.map(x => x.k)), vistos = new Set();
    fa.lin.forEach(x => { if (!litB.has(x.k) || vistos.has(x.k)) return; vistos.add(x.k);
        const dl = df.lit.get(x.k), dc = df.con.get(x.c); parte.lin += idf(df.con, x.c) * pocos(dl); if (dl <= 2 && dc <= 3) solo.lin++; });
    const comB = new Set(fb.com.map(x => x.k)); new Set(fa.com.map(x => x.k)).forEach(x => { if (!comB.has(x)) return; const d = df.com.get(x); parte.com += 0.5 * idf(df.com, x) * pocos(d); if (d <= 2) solo.com++; });
    const csB = new Set(fb.cs.map(x => x.k)); new Set(fa.cs.map(x => x.k)).forEach(x => { if (!csB.has(x)) return; const d = df.cs.get(x); parte.cs += 0.5 * idf(df.cs, x) * pocos(d); nSec++; if (d <= 2) solo.com++; });
    const errB = new Set(errPar(B)); errPar(A).forEach(x => { if (!errB.has(x)) return; const d = df.err.get(x); parte.err += 0.5 * idf(df.err, x) * pocos(d); if (d <= 2) solo.err++; });
    // los comentarios: alguno igual puede ser casualidad (todos escriben «cambio de herramienta»); cinco o más seguidos, en las mismas líneas, no
    const fCom = nSec >= 5 ? 1 : nSec >= 3 ? 0.4 : 0.2;
    const E = parte.lin + fCom * (Math.min(parte.com, 3) + parte.cs) + parte.err;
    const p = 1 - Math.exp(-E / (2 * Math.log(N + 1)));
    return { p, E, solo, parte };
}
function calcularParecidos() {
    const L = masiva.lista; L.forEach(it => { it.parecidos = []; }); masiva.parejas = [];
    const cand = L.map((it, k) => ({ it, k })).filter(({ it }) => it.texto && it.v && it.v.veredicto !== 'vacio' && rasgosDe(it).n >= 4);
    const N = cand.length; if (N < 3) return;
    const df = cuentasClase(cand.map(c => c.it));
    for (let a = 0; a < N; a++) for (let b = a + 1; b < N; b++) {
        const A = cand[a], B = cand[b], r = compararDos(A.it, B.it, df, N);
        if (r.p >= PARECIDO.umbral && r.solo.lin + r.solo.com + r.solo.err >= PARECIDO.minComun) {
            const par = { a: A.k, b: B.k, p: r.p, solo: r.solo };
            masiva.parejas.push(par); A.it.parecidos.push({ k: B.k, p: r.p }); B.it.parecidos.push({ k: A.k, p: r.p });
        }
    }
    masiva.parejas.sort((x, y) => y.p - x.p); L.forEach(it => it.parecidos.sort((x, y) => y.p - x.p));
}
const pctPar = p => Math.round(p * 100) + ' %';
function textoParecidos(it) { return it.parecidos.map(x => `${masiva.lista[x.k].alumno} (${pctPar(x.p)})`).join(', '); }
function razonesPareja(par) {
    const r = [], n = (x, s, p) => `${x} ${x === 1 ? s : p}`;
    if (par.solo.lin) r.push(n(par.solo.lin, 'línea rara igual (no la tiene nadie más)', 'líneas raras iguales (no las tiene nadie más)'));
    if (par.solo.com) r.push(n(par.solo.com, 'trozo de comentario igual', 'trozos de comentario iguales'));
    if (par.solo.err) r.push(n(par.solo.err, 'error o aviso igual', 'errores o avisos iguales'));
    return r.join(' · ');
}
// la marca 👥 junto al nombre y el resumen de la clase
const _pintarMasivaPar = pintarMasiva;
pintarMasiva = function () {
    try { calcularParecidos(); } catch (e) { console.warn(e); masiva.parejas = []; }
    _pintarMasivaPar.apply(this, arguments);
    const cuerpo = document.getElementById('mvTabla'), res = document.getElementById('mvResumen'), b = document.getElementById('mvBtnPar');
    if (b) { b.textContent = masiva.parejas && masiva.parejas.length ? `👥 Parecidos (${masiva.parejas.length})` : '👥 Parecidos'; b.classList.toggle('activo', !!(masiva.parejas && masiva.parejas.length)); }
    if (!cuerpo || !masiva.parejas || !masiva.parejas.length) return;
    cuerpo.querySelectorAll('tr[data-k]').forEach(tr => { const it = masiva.lista[+tr.dataset.k]; if (!it || !it.parecidos.length) return;
        const td = tr.querySelector('td.mv-al'), s = document.createElement('span'), max = it.parecidos[0].p;
        s.className = 'mv-par' + (max >= PARECIDO.alto ? ' alto' : ''); s.textContent = '👥'; s.title = 'Muy parecido a: ' + textoParecidos(it) + ' · pulsa para compararlos';
        s.onclick = ev => { ev.stopPropagation(); verParecidos(+tr.dataset.k); }; td.appendChild(document.createTextNode(' ')); td.appendChild(s); });
    if (res) res.insertAdjacentHTML('beforeend', ` · <span style="color:#b0301f;cursor:pointer" onclick="verParecidos()" title="Programas con líneas, comentarios o errores iguales que no tiene nadie más">👥 ${masiva.parejas.length} pareja${masiva.parejas.length === 1 ? '' : 's'} muy parecida${masiva.parejas.length === 1 ? '' : 's'}</span>`);
};
// La ventana: las parejas y la comparación lado a lado
function verParecidos(k) {
    calcularParecidos();
    const esc = t => String(t).replace(/&/g, '&amp;').replace(/</g, '&lt;');
    let ov = document.getElementById('modalParMasiva');
    if (!ov) { ov = document.createElement('div'); ov.className = 'modal-overlay'; ov.id = 'modalParMasiva'; ov.onclick = e => { if (e.target === ov) ov.classList.remove('visible'); }; document.body.appendChild(ov); }
    const P = (masiva.parejas || []).filter(p => k === undefined || p.a === k || p.b === k);
    ov.innerHTML = `<div class="help-modal" style="width:min(760px,100%)"><div class="help-header"><h2>👥 Programas muy parecidos${k !== undefined ? ' · ' + esc(masiva.lista[k].alumno) : ''}</h2><button class="help-close" onclick="document.getElementById('modalParMasiva').classList.remove('visible')">✕</button></div>
        <div class="help-content"><p class="ctx-nota" style="margin-top:0">Dos programas bien hechos de la misma pieza se parecen mucho sin haberse copiado. Aquí cuenta lo que <b>solo tienen esos dos</b> en la clase: las mismas líneas escritas igual (aunque cambien los números de bloque), los mismos comentarios y los mismos errores. Es un <b>indicio, no una prueba</b>: compáralos y pregúntales.</p>
        ${P.length ? `<table class="par-tabla"><tr><th>Alumnos</th><th>Parecido</th><th>Qué comparten solo ellos</th><th></th></tr>${P.map(p => `<tr><td><b>${esc(masiva.lista[p.a].alumno)}</b> ↔ <b>${esc(masiva.lista[p.b].alumno)}</b></td><td class="n ${p.p >= PARECIDO.alto ? 'alto' : ''}">${pctPar(p.p)}</td><td>${esc(razonesPareja(p))}</td><td><button class="btn-action sec" data-a="${p.a}" data-b="${p.b}">⇆ Comparar</button></td></tr>`).join('')}</table>`
          : `<p>${masiva.lista.length < 3 ? 'Hacen falta al menos tres programas para comparar.' : 'No hay programas muy parecidos: ninguna pareja comparte líneas, comentarios o errores que no tenga el resto.'}</p>`}
        <div id="parCompara"></div></div></div>`;
    ov.querySelectorAll('button[data-a]').forEach(bt => bt.onclick = () => compararPareja(+bt.dataset.a, +bt.dataset.b));
    ov.classList.add('visible');
    if (P.length === 1 || (k !== undefined && P.length)) compararPareja(P[0].a, P[0].b);
}
function compararPareja(a, b) {
    const A = masiva.lista[a], B = masiva.lista[b], esc = t => String(t).replace(/&/g, '&amp;').replace(/</g, '&lt;');
    const fa = rasgosDe(A), fb = rasgosDe(B), df = cuentasClase(masiva.lista.filter(it => it.texto));
    const comA = new Set(fa.com.map(x => x.k)), comB = new Set(fb.com.map(x => x.k));
    const col = (it, f, otro, comOtro) => { const marca = new Map(); f.lin.forEach(x => { if (otro.has(x.k)) marca.set(x.i, df.lit.get(x.k) <= 2 && df.con.get(x.c) <= 3 ? 'ex' : 'co'); });
        f.com.forEach(x => { if (comOtro.has(x.k) && (!marca.has(x.i) || marca.get(x.i) === 'co')) marca.set(x.i, 'cm'); });
        return `<div class="par-col"><div class="par-nom">${esc(it.alumno)} <small>${esc(it.archivo)}</small></div><div class="par-prog">${String(it.texto).replace(/\r/g, '').split('\n').map((l, i) => `<div class="${marca.get(i) || ''}">${esc(l) || '&nbsp;'}</div>`).join('')}</div></div>`; };
    const sa = new Set(fa.lin.map(x => x.k)), sb = new Set(fb.lin.map(x => x.k));
    const d = document.getElementById('parCompara'); if (!d) return;
    d.innerHTML = `<div class="par-ley"><i class="ex"></i>línea rara igual (nadie más la tiene) <i class="cm"></i>comentario igual <i class="co"></i>igual, pero es normal (bien hecha, o la tienen más)</div><div class="par-lado">${col(A, fa, sb, comB)}${col(B, fb, sa, comA)}</div>`;
    d.scrollIntoView({ block: 'nearest' });
}
