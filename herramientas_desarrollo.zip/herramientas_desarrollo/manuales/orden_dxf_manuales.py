"""Manual del Calcador: orden de corte elegible (interiores primero) y DXF R12. Uso: python3 orden_dxf_manuales.py <suite>"""
import sys, os
P = os.path.join(sys.argv[1] if len(sys.argv) > 1 else '../..', 'manual_calcador.html')
s = open(P, encoding='utf-8').read()
def rep(a, b):
    global s
    assert s.count(a) == 1, (s.count(a), a[:80]); s = s.replace(a, b)
rep("«Polilínea con arcos» genera LWPOLYLINE con arcos; «Líneas y arcos (R12)» genera entidades sueltas, la opción más compatible con AutoCAD.",
    "Es un DXF R12 completo (con cabecera, capas y extensión), que se abre en AutoCAD, LibreCAD y los demás programas de CAD: «Polilíneas con arcos (R12)» guarda cada contorno como una polilínea con sus arcos; «Líneas y arcos (R12)», como líneas y arcos sueltos. Cada tipo va en su capa: PERFIL, INTERIOR, ABIERTO, CAJERA, ISLA y TEXTO.")
rep("⚙️ Mecanizar hace primero los grabados (con la pieza aún bien sujeta), luego las cajeras, los contornos exteriores y por último los interiores. Las entradas E1, E2… del plano siguen ese mismo orden.",
    "⚙️ Mecanizar hace primero los grabados (con la pieza aún bien sujeta), luego las cajeras y después los cortes: por defecto, los <strong>interiores antes que los exteriores</strong>, como se hace en madera (la pieza sigue sujeta al tablero mientras se cortan sus agujeros, y el contorno exterior la suelta al final). En ⚙️ Mecanizar, <strong>Orden de corte</strong> permite elegir lo contrario. Las entradas E1, E2… del plano y la tabla de soluciones siguen ese mismo orden.")
rep("<tr><td>Unidades</td><td>G71 (mm) o G70 (pulgadas).</td></tr></tbody></table>",
    "<tr><td>Orden de corte</td><td><strong>Interiores primero, después exteriores</strong> (por defecto: la pieza sigue sujeta mientras se cortan sus agujeros) o <strong>exteriores primero</strong>. Los grabados y las cajeras van siempre antes. Se guarda en el JSON, y las entradas E1, E2… lo siguen.</td></tr><tr><td>Unidades</td><td>G71 (mm) o G70 (pulgadas).</td></tr></tbody></table>")
s = s.replace('Calcador de contornos v81 · Por Eloi A.A.', 'Calcador de contornos v82 · Por Eloi A.A.')
open(P, 'w', encoding='utf-8').write(s); print('manual_calcador.html: orden de corte y DXF')
