// ── 📝 Completar el programa (huecos): una pregunta más del cuestionario para Aules ──
// El programa de la solución (el de «📋 Solución», sin los comentarios) con algunas palabras en blanco: G2/G3 de los arcos,
// su I y J, la compensación G41/G42 de la entrada y coordenadas X Y. En Aules es una pregunta «Respuestas incrustadas
// (Cloze)» que se corrige sola (cada hueco por separado); en cada variante, los mismos huecos con sus valores. También
// se imprime: la hoja con los huecos numerados y la de soluciones.
cuestCfg.huecos = cuestCfg.huecos || 0;
CUEST_TIPOS.push(['huecos', 'Completar el programa: nº de huecos']);
const PALABRA_HUECO = /^([A-Z])(-?\d+(?:\.\d+)?)$/;
function programaHuecos() {
    if (typeof tuGenerar !== 'function') return null;
    try { const p = tuGenerar(); return p && !p.vacio && p.lineas ? p.lineas.filter(l => l.cod && !l.sep).map(l => ({ cod: String(l.cod).trim(), titulo: !!l.titulo })) : null; } catch (e) { console.warn(e); return null; }
}
const _modeloCuestHuecos = modeloCuest;
modeloCuest = function () { const M = _modeloCuestHuecos.apply(this, arguments); if (cuestCfg.huecos > 0) M.prog = programaHuecos(); return M; };
// Los huecos posibles: G2/G3 y la compensación, I J de los arcos, las X Y de las rectas, las de los arcos y las de los rápidos
function candidatosHuecos(prog) {
    const C = [];
    prog.forEach((l, li) => {
        if (l.titulo) return;
        const w = l.cod.split(/\s+/), arco = w.some(x => /^G0?[23]$/.test(x)), g1 = w.some(x => /^G0?1$/.test(x)), g0 = w.some(x => /^G0?0$/.test(x));
        w.forEach((x, wi) => {
            if (/^G0?[23]$/.test(x) || /^G4[12]$/.test(x)) C.push({ li, wi, pri: 0 });
            else if (arco && /^[IJ]-?[\d.]+$/.test(x)) C.push({ li, wi, pri: 1 });
            else if (g1 && !arco && /^[XY]-?[\d.]+$/.test(x)) C.push({ li, wi, pri: 2 });
            else if (arco && /^[XY]-?[\d.]+$/.test(x)) C.push({ li, wi, pri: 3 });
            else if (g0 && /^[XY]-?[\d.]+$/.test(x)) C.push({ li, wi, pri: 4 });
        });
    });
    return C;
}
function elegirHuecos(prog, n) {
    if (!prog || n <= 0) return [];
    const C = candidatosHuecos(prog), porLinea = new Map(), out = [];
    const tomar = (g, k) => { g = g.filter(c => !out.includes(c) && (porLinea.get(c.li) || 0) < 2); k = Math.min(k, g.length);
        for (let i = 0; i < k; i++) { const c = g[Math.floor((i + 0.5) * g.length / k)]; if (out.includes(c) || (porLinea.get(c.li) || 0) >= 2) continue; out.push(c); porLinea.set(c.li, (porLinea.get(c.li) || 0) + 1); } };
    // un reparto equilibrado: un tercio de funciones (G2/G3, G41/G42), un tercio de I J y el resto, coordenadas
    tomar(C.filter(c => c.pri === 0), Math.ceil(n / 3));
    tomar(C.filter(c => c.pri === 1), Math.ceil(n / 3));
    tomar(C.filter(c => c.pri === 2), n - out.length); tomar(C.filter(c => c.pri === 3), n - out.length); tomar(C.filter(c => c.pri === 4), n - out.length);
    for (let pri = 0; pri <= 4 && out.length < n; pri++) tomar(C.filter(c => c.pri === pri), n - out.length);      // si no hay de algún tipo, se completa con los demás
    return out.sort((a, b) => a.li - b.li || a.wi - b.wi).map(c => ({ li: c.li, wi: c.wi }));
}
const mismaForma = (prog, H) => H.every(h => prog[h.li] && prog[h.li].cod.split(/\s+/)[h.wi] !== undefined);
const _elegirCuestHuecos = elegirCuest;
elegirCuest = function (M) { const s = _elegirCuestHuecos.apply(this, arguments); s.huecos = cuestCfg.huecos > 0 && M.prog ? elegirHuecos(M.prog, cuestCfg.huecos) : []; return s; };
// La pregunta: el programa con los huecos (Cloze) y, para imprimir, con los huecos numerados
function preguntaHuecos(M, H, tol) {
    if (!M.prog || !H.length) return null;
    if (!mismaForma(M.prog, H) || H.some(h => { const x = M.prog[h.li].cod.split(/\s+/)[h.wi]; return !(/^G/.test(x) || PALABRA_HUECO.test(x)); })) H = elegirHuecos(M.prog, H.length);   // esta variante tiene otro programa: sus propios huecos
    const esc = t => String(t).replace(/&/g, '&amp;').replace(/</g, '&lt;'), fn = v => { const t = (+(+v).toFixed(3)).toString(); return t === '-0' ? '0' : t; };
    const enH = new Map(H.map((h, k) => [h.li + ':' + h.wi, k + 1])), sol = [];
    const linea = (l, li, modo) => l.cod.split(/\s+/).map((x, wi) => {
        const k = enH.get(li + ':' + wi); if (!k) return esc(x);
        if (/^G/.test(x)) { const alt = /^G0?([0-3])$/.test(x) ? [`G${x.replace(/^G0?/, '')}`, `G0${x.replace(/^G0?/, '')}`] : [x];
            sol.push({ k, txt: x }); return modo === 'cloze' ? `{1:SHORTANSWER:${[...new Set(alt)].map(a => '=' + a).join('~')}}` : `<span class="hu">(${k}) ________</span>`; }
        const m = PALABRA_HUECO.exec(x); sol.push({ k, txt: x });
        return esc(m[1]) + (modo === 'cloze' ? `{1:NUMERICAL:=${fn(m[2])}:${tol}}` : `<span class="hu">(${k}) ______</span>`);
    }).join(' ');
    const cuerpo = modo => `<div style="font-family:Consolas,'Courier New',monospace;font-size:14px;line-height:2;background:#f7f7f7;border:1px solid #ddd;border-radius:6px;padding:8px 12px">${M.prog.map((l, li) => `<div>${linea(l, li, modo)}</div>`).join('')}</div>`;
    const cloze = cuerpo('cloze'); sol.length = 0; const papel = cuerpo('papel');
    const solTxt = sol.sort((a, b) => a.k - b.k).map(s => `(${s.k}) ${s.txt}`).join(' · ');
    return { clave: `Completar el programa (${H.length} huecos)`, txt: `<p>Completa el programa de la pieza del plano: escribe en cada hueco la función (G2, G3, G41…) o el valor que falta.</p>${cloze}<p style="font-size:90%;color:#555">Los valores, con punto decimal (por ejemplo, 12.5). Tolerancia: ±${String(tol).replace('.', ',')} mm.</p>`,
             sol: 'Solución: ' + solTxt, papel, solTxt };
}
const _preguntasCuestHuecos = preguntasCuest;
preguntasCuest = function (M, sel, tol) {
    const out = _preguntasCuestHuecos.apply(this, arguments);
    if (sel.huecos && sel.huecos.length) { const q = preguntaHuecos(M, sel.huecos, tol); if (q) out.push(q); }
    return out;
};
// Imprimir: cada variante en su hoja (el plano y el programa con los huecos numerados) y, al final, las soluciones
async function imprimirHuecos() {
    if (!cuestGen || !cuestGen.vars.some(v => v.preguntas.some(q => q.papel))) { snack('Pon algún hueco en «Completar el programa»'); return; }
    const esc = t => String(t).replace(/&/g, '&amp;').replace(/</g, '&lt;'), tit = cfgHoja.titulo || nombreProyecto(), num = (cfgHoja.num || '').trim();
    const pags = cuestGen.vars.map(v => { const q = v.preguntas.find(x => x.papel); if (!q) return '';
        return `<section class="pag"><header><h1>${esc(tit)}${num ? ' · nº ' + esc(num) : ''}${cuestGen.vars.length > 1 ? ` · variante ${v.letra}` : ''}</h1><div class="al">Alumno/a: ______________________________ &nbsp; Fecha: ____________</div></header>
            <p class="enun">Completa el programa: escribe en cada hueco la función (G2, G3, G41…) o el valor que falta.</p>
            <div class="plano"><img src="data:image/png;base64,${v.png.b64}"></div>${q.papel}</section>`; }).join('');
    const sols = `<section class="pag"><header><h1>Soluciones · ${esc(tit)}</h1></header>${cuestGen.vars.map(v => { const q = v.preguntas.find(x => x.papel); return q ? `<p><b>Variante ${v.letra}</b> (${esc(v.desc)}): ${esc(q.solTxt)}</p>` : ''; }).join('')}</section>`;
    const html = `<!DOCTYPE html><html lang="es"><head><meta charset="UTF-8"><title>Completar el programa · ${esc(tit)}</title><style>
        @page { size: A4; margin: 12mm; } body { font-family: Arial, sans-serif; color: #222; margin: 0; } .pag { page-break-after: always; }
        h1 { font-size: 17px; margin: 0 0 4px; } .al { font-size: 13px; margin-bottom: 6px; } .enun { font-size: 13px; margin: 4px 0 8px; }
        .plano { text-align: center; } .plano img { max-width: 100%; max-height: 120mm; } .hu { color: #1a56b0; font-weight: bold; }
    </style></head><body>${pags}${sols}<script>window.onload = () => setTimeout(() => window.print(), 300);<\/script></body></html>`;
    const w = window.open('', '_blank'); if (!w) { snack('El navegador ha bloqueado la ventana de impresión: permite las ventanas emergentes para este archivo'); return; }
    w.document.open(); w.document.write(html); w.document.close();
}
