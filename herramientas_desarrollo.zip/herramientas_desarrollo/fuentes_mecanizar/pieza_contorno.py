#!/usr/bin/env python3
"""Calcador v125: 📐 Contornos sencillos, dentro de 🧩 Aleatorio: como el nivel Contorno de Arcos I J. La pieza se construye
con una intención (ancho × alto, redondeos, entallas y salientes centrados en un lado) y sus cotas salen de esa construcción.
Con taladros, colisos, huecos y cajeras. Uso: python3 pieza_contorno.py CARPETA_DE_LA_SUITE (después de examen_18.py)."""
import os, re, sys
d = sys.argv[1] if len(sys.argv) > 1 else '.'
p = os.path.join(d, 'calcador.html'); s = open(p, encoding='utf-8').read()
def rep(a, b):
    global s
    assert s.count(a) == 1, (s.count(a), a[:80]); s = s.replace(a, b)
rep('<p class="ctx-nota">Elige el nivel (o los parámetros) y haz clic en la propuesta que quieras: pasa al dibujo, con sus formas editables.</p>',
    '<button class="btn-action sec" onclick="abrirPiezaContorno()" title="Piezas construidas como el nivel Contorno de Arcos I J, con sus cotas" style="margin-bottom:8px">📐 Contornos sencillos…</button>\n                <p class="ctx-nota">Elige el nivel (o los parámetros) y haz clic en la propuesta que quieras: pasa al dibujo, con sus formas editables.</p>')
rep('<div class="modal-overlay" id="modalGenerador"', '''<div class="modal-overlay" id="modalPiezaC" onclick="if(event.target===this)cerrarPiezaContorno()">
    <div class="help-modal var-modal gen-modal">
        <div class="help-header"><h2>📐 Contornos sencillos</h2><button class="help-close" onclick="cerrarPiezaContorno()">✕</button></div>
        <div class="var-cuerpo">
            <div class="var-opciones">
                <p class="ctx-nota">La pieza se construye como en el nivel Contorno de Arcos I J: un rectángulo con redondeos, chaflanes y entallas o salientes centrados, y las cotas salen de esa construcción. Haz clic en una propuesta.</p>
                <div class="cr-req-t">Nivel</div>
                <select id="pcNivel" onchange="pcElegirNivel(this.value)" title="Pone las opciones de cada nivel; si cambias alguna a mano, pasa a «Libre»"><option value="libre">Libre</option><option value="1">1 · Rectas y chaflanes</option><option value="2">2 · Redondeos y taladros</option><option value="3">3 · Semicírculos y colisos</option><option value="4">4 · Pitágoras y huecos</option></select>
                <div class="cr-req-t">Tamaño</div>
                <div class="param-line" title="La pieza sale entre el 60 % y el 100 % de esta medida, de 10 en 10 mm">Ancho máximo (mm) <input type="number" id="pcAncho" min="80" max="2000" step="10" value="200" onchange="pintarPiezasC()"></div>
                <div class="param-line">Alto máximo (mm) <input type="number" id="pcAlto" min="80" max="2000" step="10" value="140" onchange="pintarPiezasC()"></div>
                <div class="cr-req-t">Esquinas</div>
                <div class="gen-chips">
                    <label class="gen-chip" title="Si se quita, las cuatro esquinas llevan forma"><input type="checkbox" id="pcRec" checked onchange="pintarPiezasC()"> Rectas</label>
                    <label class="gen-chip"><input type="checkbox" id="pcRed" checked onchange="pintarPiezasC()"> Redondeadas</label>
                    <label class="gen-chip" title="Los dos catetos iguales"><input type="checkbox" id="pcC45" checked onchange="pintarPiezasC()"> Chaflán a 45°</label>
                    <label class="gen-chip" title="Catetos distintos: hay que calcular los dos puntos"><input type="checkbox" id="pcCDes" onchange="pintarPiezasC()"> Chaflán desigual</label>
                </div>
                <div class="param-line" title="Cuántas esquinas llevan redondeo o chaflán">Esquinas con forma <span class="gen-rango"><input type="number" id="pcEMin" min="0" max="4" step="1" value="2" onchange="pintarPiezasC()"> a <input type="number" id="pcEMax" min="0" max="4" step="1" value="4" onchange="pintarPiezasC()"></span></div>
                <div class="cr-req-t">Lados</div>
                <div class="gen-chips">
                    <label class="gen-chip"><input type="checkbox" id="pcSemi" checked onchange="pintarPiezasC()"> Semicírculos</label>
                    <label class="gen-chip"><input type="checkbox" id="pcPit" checked onchange="pintarPiezasC()"> Arcos con Pitágoras</label>
                </div>
                <div class="cr-req-t">Interiores</div>
                <div class="gen-chips">
                    <label class="gen-chip"><input type="checkbox" id="pcTal" checked onchange="pintarPiezasC()"> Taladros</label>
                    <label class="gen-chip"><input type="checkbox" id="pcCol" checked onchange="pintarPiezasC()"> Colisos</label>
                    <label class="gen-chip"><input type="checkbox" id="pcHue" checked onchange="pintarPiezasC()"> Huecos rectangulares</label>
                    <label class="gen-chip" title="Las cajeras no entran en la tabla de soluciones ni en la corrección"><input type="checkbox" id="pcCaj" onchange="pintarPiezasC()"> Cajeras</label>
                </div>
                <div class="param-line">Número de interiores <span class="gen-rango"><input type="number" id="pcIMin" min="0" max="4" step="1" value="1" onchange="pintarPiezasC()"> a <input type="number" id="pcIMax" min="0" max="4" step="1" value="2" onchange="pintarPiezasC()"></span></div>
                <div class="param-line" title="Separación mínima entre un interior y cualquier otro borde">Pared mínima (mm) <input type="number" id="pcPared" min="4" max="40" step="1" value="12" onchange="pintarPiezasC()"></div>
                <div class="btn-row" style="margin-top:12px"><button class="btn-action" onclick="pcBase = 0; pintarPiezasC()">🎲 Otras propuestas</button></div>
                <p class="ctx-nota" style="margin-top:12px">Las cajeras no entran en la tabla de soluciones ni en la corrección. Las variantes de examen recalculan estas cotas.</p>
            </div>
            <div class="var-lista" id="pcLista"></div>
        </div>
    </div>
</div>
<div class="modal-overlay" id="modalGenerador"''')
rep("            const str = (m.tipo === 'radio' ? 'R' : 'Ø') + fmt(ref.valor);\n", "            const str = (m.tipo === 'radio' ? 'R' : 'Ø') + fmt(ref.valor);\n            if (m.cruz) ejes(C, 2.5);\n            if (m.cruz2) ejes(add(m.cruz2, O), 2.5);\n")
rep("    if (fondo) unir(bboxFondoMundo());\n    if (cfgCotas.ver && cfgCotas.cero", "    if (fondo) unir(bboxFondoMundo());\n    if (cotasManuales.some(m => m.sencillo)) cotasManuales.forEach(m => { const q = m.pos; if (q) unir({ x0:q.x - 12, y0:q.y - 10, x1:q.x + 12, y1:q.y + 10 }); });   // 📐 Contornos sencillos: que se vean sus cotas\n    if (cfgCotas.ver && cfgCotas.cero")
# las variantes de un contorno sencillo: el cero, en una esquina de la pieza, y sus cotas recalculadas
_a = "contornos = est.contornos; aux = est.aux; cotasManuales = []; cotasAjuste = {};"; assert s.count(_a) >= 1; s = s.replace(_a, _a + " if (est.sencillo) pcAcotar();")
rep("(cotasManuales.length ? 'Las cotas manuales no pasan a las variantes (las automáticas sí). ' : '')", "(cotasManuales.length && !cotasManuales.some(m => m.sencillo) ? 'Las cotas manuales no pasan a las variantes (las automáticas sí). ' : '')")
rep("transformarEstado = function (est, sp) { return _transformarEstadoBase(estirarEstado(est, sp.med), sp); };", """transformarEstado = function (est, sp) { const r = _transformarEstadoBase(estirarEstado(est, sp.med), sp);
    if (cotasManuales.some(m => m.sencillo)) { r.sencillo = true; const ext = r.contornos.reduce((a, c) => { const A = bboxPts(a.pts), B = bboxPts(c.pts); return (B.x1 - B.x0) * (B.y1 - B.y0) > (A.x1 - A.x0) * (A.y1 - A.y0) ? c : a; }), b = bboxPts(ext.pts), d = { x:Math.abs(b.x0) <= Math.abs(b.x1) ? b.x0 : b.x1, y:Math.abs(b.y0) <= Math.abs(b.y1) ? b.y0 : b.y1 }; r.contornos.forEach(c => { c.pts = c.pts.map(p => ({ x:+(p.x - d.x).toFixed(6), y:+(p.y - d.y).toFixed(6) })); }); }
    return r; };""")
JS = r"""// ── 📐 Contornos sencillos: la pieza sale de una intención, y sus cotas, de esa construcción ──
let pcBase = 0;
function pcConstruir(sem, op) {
    const R = genAleatorio(sem), DIR = [{ x:1, y:0 }, { x:0, y:1 }, { x:-1, y:0 }, { x:0, y:-1 }];
    const lista = modo => { const o = []; for (let r = 12; r <= 60; r++) { if (modo === 'cuerda') { for (let c = 10; c <= 2 * r - 6; c += 2) { const h = c / 2, dd = Math.sqrt(r * r - h * h); if (dd >= 4 && h >= 5 && Math.abs(dd - Math.round(dd)) < 1e-9) o.push({ R:r, h, d:Math.round(dd) }); } } else { for (let dd = 4; dd <= r - 4; dd++) { const h = Math.sqrt(r * r - dd * dd); if (h >= 5 && Math.abs(h - Math.round(h)) < 1e-9) o.push({ R:r, h:Math.round(h), d:dd }); } } } return o; };
    for (let n = 0; n < 400; n++) {
        const paso = (M) => R.entero(Math.max(8, Math.ceil(M * .06)), Math.max(8, Math.floor(M / 10))) * 10, W = paso(op.W), H = paso(op.H), C = [{ x:0, y:0 }, { x:W, y:0 }, { x:W, y:H }, { x:0, y:H }], lados = [null, null, null, null], esq = [null, null, null, null];
        const formas = [op.red && 'r', op.c45 && 'c', op.cd && 'd'].filter(Boolean), lim = Math.min(W, H) / 4, nEsq = !formas.length ? 0 : !op.rec ? 4 : R.entero(Math.min(op.eMin, op.eMax), op.eMax), orden = [0, 1, 2, 3];
        for (let i = 3; i > 0; i--) { const j = R.entero(0, i); [orden[i], orden[j]] = [orden[j], orden[i]]; }
        orden.slice(0, nEsq).forEach(i => { const f = R.uno(formas), v = l => R.uno(l.filter(x => x <= lim)); esq[i] = f === 'r' ? { t:'r', a:v([10, 15, 20, 25, 30]) } : f === 'c' ? { t:'c', a:v([10, 15, 20]) } : { t:'c', a:v([10, 15, 20]), b:v([20, 25, 30]) }; const e = esq[i]; e.b = e.b || e.a; if (e.t === 'c' && R() < .5 && e.a !== e.b) [e.a, e.b] = [e.b, e.a]; });
        const ent = esq.map(e => e ? e.a : 0), sal = esq.map(e => e ? e.b : 0);   // lo que la esquina quita del lado que llega y del que sale
        const tipos = [op.semi && 'semi', op.pit && 'pit'].filter(Boolean);
        if (tipos.length) { const i0 = R.entero(0, 3), ls = R() < .35 || !op.red ? [i0, (i0 + 2) % 4] : [i0];
            for (const i of ls) { const len = i % 2 === 0 ? W : H, perp = i % 2 === 0 ? H : W, libre = len - sal[i] - ent[(i + 1) % 4], t = R.uno(tipos);
                if (t === 'semi') { const o = [10, 15, 20, 25, 30].filter(v => 2 * v <= libre - 20 && v <= perp * .4); if (o.length) { const v = R.uno(o); lados[i] = { t, R:v, h:v, d:0 }; } }
                else { const sub2 = R.uno(['entalla', 'saliente']), modo = R.uno(['cuerda', 'dist']), o = lista(modo).filter(D => 2 * D.h <= libre - 20 && (sub2 === 'entalla' ? D.R - D.d <= perp * .4 : D.R - D.d <= 35)); if (o.length) { const D = R.uno(o); lados[i] = { t, sub:sub2, modo, R:D.R, h:D.h, d:D.d }; } } } }
        // en sentido antihorario, empezando en el lado de abajo
        const pts = [], b = [], arcos = [], add2 = (p, q) => ({ x:p.x + q.x, y:p.y + q.y }), kp = (p, q, k) => ({ x:p.x + q.x * k, y:p.y + q.y * k });
        const tramo = (p, bu) => { const u = pts[pts.length - 1]; if (u && Math.hypot(u.x - p.x, u.y - p.y) < 1e-9) { b[b.length - 1] = bu; return; } pts.push(p); b.push(bu); };
        const ini = kp(C[0], DIR[0], sal[0]), chaf = []; pts.push(ini); b.push(0);
        for (let i = 0; i < 4; i++) { const tg = DIR[i], nL = { x:-tg.y, y:tg.x }, j = (i + 1) % 4, f = lados[i];
            if (f) { const len = i % 2 === 0 ? W : H, m = kp(C[i], tg, len / 2), pA = kp(m, tg, -f.h), pB = kp(m, tg, f.h); tramo(pA, 0);
                let Cc, ccw; if (f.t === 'semi') { Cc = m; ccw = false; } else if (f.sub === 'entalla') { Cc = kp(m, nL, -f.d); ccw = false; } else { Cc = kp(m, nL, f.d); ccw = true; }
                b[b.length - 1] = bulgeAlrededor(pA, pB, Cc, ccw); arcos.push({ c:Cc, r:f.R, f, lado:i, m, pA, pB, nL }); pts.push(pB); b.push(0); }
            const fin = kp(C[j], tg, -ent[j]); tramo(fin, 0); const E = esq[j];
            if (E) { const e = kp(C[j], DIR[j], sal[j]); if (E.t === 'r') { const Cc = kp(fin, nL, E.a); b[b.length - 1] = bulgeAlrededor(fin, e, Cc, true); arcos.push({ c:Cc, r:E.a, esquina:j }); } else chaf.push({ C:C[j], fin, e });
                if (j === 0) break; pts.push(e); b.push(0); } }
        // el último punto coincide con el primero: se cierra
        const u = pts[pts.length - 1]; if (Math.hypot(u.x - ini.x, u.y - ini.y) < 1e-9) { pts.pop(); const bu = b.pop(); b[b.length - 1] = b[b.length - 1] || bu; }
        const cont = { pts, b, cerrado:true, tipo:'auto' };
        if (R() < .5) invertirContorno(cont);
        return { cont, W, H, arcos, chaf };
    }
    return null;
}
// Los interiores: en sitios con pared suficiente, a múltiplos de 5 mm, con otra secuencia del azar (el exterior no cambia)
function pcInteriores(P, sem, op) {
    const R = genAleatorio((sem * 2654435761) ^ 0x51ed27), tipos = [op.tal && 'tal', op.col && 'col', op.hue && 'hue', op.caj && 'caj'].filter(Boolean), out = [], pared = op.pared;
    if (!tipos.length || op.iMax <= 0) return out;
    const n = R.entero(Math.min(op.iMin, op.iMax), op.iMax), borde = muestrearContorno(P.cont);
    const dentro = q => { let d = false; for (let i = 0, j = borde.length - 1; i < borde.length; j = i++) { const a = borde[i], b = borde[j]; if ((a.y > q.y) !== (b.y > q.y) && q.x < (b.x - a.x) * (q.y - a.y) / (b.y - a.y) + a.x) d = !d; } return d; };
    const cabe = c => { if (c.x0 < pared || c.y0 < pared || c.x1 > P.W - pared || c.y1 > P.H - pared) return false;
        if (!dentro({ x:(c.x0 + c.x1) / 2, y:(c.y0 + c.y1) / 2 })) return false;
        if (borde.some(q => q.x > c.x0 - pared && q.x < c.x1 + pared && q.y > c.y0 - pared && q.y < c.y1 + pared)) return false;
        return !out.some(o => c.x0 < o.caja.x1 + pared && c.x1 > o.caja.x0 - pared && c.y0 < o.caja.y1 + pared && c.y1 > o.caja.y0 - pared); };
    for (let k = 0; k < n; k++) for (let t = 0; t < 80; t++) {
        const tipo = R.uno(tipos), x = R.entero(2, Math.floor(P.W / 5) - 2) * 5, y = R.entero(2, Math.floor(P.H / 5) - 2) * 5; let I = null;
        if (tipo === 'tal') { const r = R.uno([6, 8, 10, 12, 15, 20]); I = { tipo, c:{ x, y }, r, caja:{ x0:x - r, y0:y - r, x1:x + r, y1:y + r }, cont:{ pts:[{ x:x + r, y }, { x:x - r, y }], b:[1, 1], cerrado:true, tipo:'auto' } }; }
        else if (tipo === 'col') { const r = R.uno([6, 8, 10]), L = R.uno([20, 30, 40, 50, 60]), hor = R() < .6, c2 = hor ? { x:x + L, y } : { x, y:y + L };
            const pts = hor ? [{ x, y:y - r }, { x:c2.x, y:y - r }, { x:c2.x, y:y + r }, { x, y:y + r }] : [{ x:x + r, y }, { x:x + r, y:c2.y }, { x:x - r, y:c2.y }, { x:x - r, y }];
            I = { tipo, c:{ x, y }, c2, r, L, hor, caja:{ x0:x - r, y0:y - r, x1:c2.x + r, y1:c2.y + r }, cont:{ pts, b:[0, 1, 0, 1], cerrado:true, tipo:'auto' } }; }
        else { const w = R.entero(4, 10) * 5, h = R.entero(4, 8) * 5, r = R.uno(tipo === 'caj' ? [5, 6, 8] : [0, 4, 5, 6, 8]), k2 = Math.tan(Math.PI / 8), X = x + w, Y = y + h;
            const pts = r ? [{ x:x + r, y }, { x:X - r, y }, { x:X, y:y + r }, { x:X, y:Y - r }, { x:X - r, y:Y }, { x:x + r, y:Y }, { x, y:Y - r }, { x, y:y + r }] : [{ x, y }, { x:X, y }, { x:X, y:Y }, { x, y:Y }];
            I = { tipo, x, y, w, h, r, caja:{ x0:x, y0:y, x1:X, y1:Y }, cont:{ pts, b:r ? [0, k2, 0, k2, 0, k2, 0, k2] : [0, 0, 0, 0], cerrado:true, tipo:'auto' } };
            if (tipo === 'caj') I.cont.mec = { op:'cajera', prof:5, puentes:{ n:0, ancho:5, alto:2 }, caj:{ estr:'concentrica', paso:50, entrada:'rampa' } }; }
        if (I && cabe(I.caja)) { out.push(I); break; }
    }
    return out;
}
function pcOpciones() { const g = id => document.getElementById(id), v = id => g(id).checked, n = (id, d, lo, hi) => { const x = parseInt(g(id).value, 10); return Math.max(lo, Math.min(hi, isFinite(x) ? x : d)); };
    return { W:n('pcAncho', 200, 80, 2000), H:n('pcAlto', 140, 80, 2000), rec:v('pcRec'), red:v('pcRed'), c45:v('pcC45'), cd:v('pcCDes'), eMin:n('pcEMin', 2, 0, 4), eMax:n('pcEMax', 4, 0, 4), semi:v('pcSemi'), pit:v('pcPit'), tal:v('pcTal'), col:v('pcCol'), hue:v('pcHue'), caj:v('pcCaj'), iMin:n('pcIMin', 1, 0, 4), iMax:n('pcIMax', 2, 0, 4), pared:n('pcPared', 12, 4, 40) }; }
const PC_NIVELES = { 1:{ rec:1, red:0, c45:1, cd:0, eMin:1, eMax:3, semi:0, pit:0, tal:0, col:0, hue:0, caj:0, iMin:0, iMax:0 }, 2:{ rec:1, red:1, c45:1, cd:0, eMin:2, eMax:4, semi:0, pit:0, tal:1, col:0, hue:0, caj:0, iMin:1, iMax:1 },
    3:{ rec:1, red:1, c45:1, cd:1, eMin:2, eMax:4, semi:1, pit:0, tal:1, col:1, hue:0, caj:0, iMin:1, iMax:2 }, 4:{ rec:1, red:1, c45:1, cd:1, eMin:2, eMax:4, semi:1, pit:1, tal:1, col:1, hue:1, caj:0, iMin:2, iMax:3 } };
const PC_CAMPOS = { rec:'pcRec', red:'pcRed', c45:'pcC45', cd:'pcCDes', semi:'pcSemi', pit:'pcPit', tal:'pcTal', col:'pcCol', hue:'pcHue', caj:'pcCaj', eMin:'pcEMin', eMax:'pcEMax', iMin:'pcIMin', iMax:'pcIMax' };
function pcElegirNivel(k) { const N = PC_NIVELES[k]; if (!N) return; Object.entries(PC_CAMPOS).forEach(([c, id]) => { const e = document.getElementById(id); if (e.type === 'checkbox') e.checked = !!N[c]; else e.value = N[c]; }); pintarPiezasC(); }
function pcNivelActual() { const op = pcOpciones(); return Object.keys(PC_NIVELES).find(k => Object.entries(PC_NIVELES[k]).every(([c, v]) => +op[c] === +v)) || 'libre'; }
function pcPieza(s, op) { let P = null; const pide = Math.min(op.iMin, op.iMax);   // si en una pieza no caben los interiores pedidos, se busca otra (siempre la misma para cada número)
    for (let t = 0; t < 40; t++) { const Q = pcConstruir(s + t * 100003, op); if (!Q) continue; Q.ints = pcInteriores(Q, s + t * 100003, op); if (!P || Q.ints.length > P.ints.length) P = Q; if (P.ints.length >= pide) break; } return P; }
function abrirPiezaContorno() { try { const o = JSON.parse(localStorage.getItem('calcador_contornos') || 'null'); if (o && typeof o === 'object') { Object.entries(PC_CAMPOS).forEach(([c, id]) => { const e = document.getElementById(id); if (o[c] === undefined) return; if (e.type === 'checkbox') e.checked = !!o[c]; else e.value = o[c]; }); if (o.W) document.getElementById('pcAncho').value = o.W; if (o.H) document.getElementById('pcAlto').value = o.H; if (o.pared) document.getElementById('pcPared').value = o.pared; } } catch (e) {} cerrarGenerador(); document.getElementById('modalPiezaC').classList.add('visible'); pintarPiezasC(); }
function cerrarPiezaContorno() { document.getElementById('modalPiezaC').classList.remove('visible'); }
function pintarPiezasC() {
    if (!pcBase) pcBase = 10000 + Math.floor(Math.random() * 89990);
    const op = pcOpciones(), caja = document.getElementById('pcLista'); document.getElementById('pcNivel').value = pcNivelActual();
    try { localStorage.setItem('calcador_contornos', JSON.stringify(op)); } catch (e) {}
    caja.innerHTML = Array.from({ length:6 }, (_, k) => { const s = pcBase + k, P = pcPieza(s, op); return P ? `<div class="var-ficha gen-ficha" data-s="${s}" title="Usar esta pieza"><div class="var-mini">${svgMini({ calcador:{ contornos:[P.cont].concat(P.ints.map(i => i.cont)) } })}</div><div><strong>Nº ${s}</strong><br><span>${P.W} × ${P.H} mm · ${P.arcos.length} arco${P.arcos.length === 1 ? '' : 's'} · ${P.chaf.length} ${P.chaf.length === 1 ? 'chaflán' : 'chaflanes'} · ${P.ints.length} interior${P.ints.length === 1 ? '' : 'es'}</span></div></div>` : ''; }).join('');
    caja.querySelectorAll('.gen-ficha').forEach(el => el.onclick = () => usarPiezaC(+el.dataset.s));
}
// Las cotas salen de la geometría que haya, con el cero en una esquina de la pieza: así valen igual en la pieza y en sus variantes
function pcAcotar() {
    asegurarUids(); cotasManuales = [];
    const vivos = contornos.filter(c => c.pts.length >= 2); if (!vivos.length) return;
    const cajaV = c => bboxPts(c.pts), ext = vivos.reduce((a, c) => { const A = cajaV(a), B = cajaV(c); return (B.x1 - B.x0) * (B.y1 - B.y0) > (A.x1 - A.x0) * (A.y1 - A.y0) ? c : a; }), bb = cajaV(ext), mu = bboxPts(muestrearContorno(ext)), EPS = 1e-3;
    const zx = Math.abs(bb.x0) <= Math.abs(bb.x1) ? bb.x0 : bb.x1, zy = Math.abs(bb.y0) <= Math.abs(bb.y1) ? bb.y0 : bb.y1, ox = zx === bb.x0 ? bb.x1 : bb.x0, oy = zy === bb.y0 ? bb.y1 : bb.y0;
    const sx = zx === bb.x0 ? -1 : 1, sy = zy === bb.y0 ? -1 : 1, Z = { x:zx, y:zy }, cx = (bb.x0 + bb.x1) / 2, cy = (bb.y0 + bb.y1) / 2;      // sx, sy: hacia fuera de la pieza, por el lado del cero
    const sobre = { x0:bb.x0 - mu.x0, x1:mu.x1 - bb.x1, y0:bb.y0 - mu.y0, y1:mu.y1 - bb.y1 }, sobreZX = zx === bb.x0 ? sobre.x0 : sobre.x1, sobreZY = zy === bb.y0 ? sobre.y0 : sobre.y1;
    const id = () => 'm' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6), mete = m => { m.id = id(); m.sencillo = true; fijarPosRel(m); cotasManuales.push(m); };
    const lin = (tipo, p1, p2, pos) => mete({ tipo, p1, r1:null, p2, r2:null, pos });
    const filaX = new Set(), filaY = new Set(), sitX = x => { if (Math.abs(x - zx) > EPS && Math.abs(x - ox) > EPS) filaX.add(+x.toFixed(4)); }, sitY = y => { if (Math.abs(y - zy) > EPS && Math.abs(y - oy) > EPS) filaY.add(+y.toFixed(4)); };
    const enH = q => Math.abs(q.y - bb.y0) < EPS || Math.abs(q.y - bb.y1) < EPS, enV = q => Math.abs(q.x - bb.x0) < EPS || Math.abs(q.x - bb.x1) < EPS;
    tramos(ext).forEach(t => {
        if (!t.b) { // chaflán: un tramo inclinado, de un lado a otro: sus dos catetos, por fuera de la esquina
            if (Math.abs(t.p1.x - t.p2.x) > EPS && Math.abs(t.p1.y - t.p2.y) > EPS) { const [ph, pv] = enH(t.p1) ? [t.p1, t.p2] : [t.p2, t.p1], C = { x:pv.x, y:ph.y }, ax = C.x > cx ? 1 : -1, ay = C.y > cy ? 1 : -1;
                lin('h', C, { x:ph.x, y:ph.y }, { x:(C.x + ph.x) / 2, y:C.y + ay * 7 }); lin('v', C, { x:pv.x, y:pv.y }, { x:C.x + ax * 7, y:(C.y + pv.y) / 2 }); }
            return; }
        const a = arcoDeBulge(t.p1, t.p2, t.b); if (!a) return;
        const am = a.a1 + a.theta / 2, hor = Math.abs(t.p1.y - t.p2.y) < EPS && enH(t.p1), ver = Math.abs(t.p1.x - t.p2.x) < EPS && enV(t.p1), lado = hor || ver, off = lado && Math.hypot(hor ? a.c.y - t.p1.y : a.c.x - t.p1.x, 0) > EPS ? .2 : 0;
        mete({ tipo:'radio', cruz:true, c:a.c, r:a.r, rc:{ uid:ext.uid, si:t.i }, pos:{ x:a.c.x + (a.r + 8) * Math.cos(am + off), y:a.c.y + (a.r + 8) * Math.sin(am + off) } });
        if (!lado) return;   // redondeo de esquina: basta su radio
        const m = { x:(t.p1.x + t.p2.x) / 2, y:(t.p1.y + t.p2.y) / 2 };
        if (hor) { if (Math.abs(m.y - zy) < EPS) sitX(m.x); else { const s = m.y > cy ? 1 : -1, sal = s > 0 ? sobre.y1 : sobre.y0; lin('h', { x:zx, y:m.y }, m, { x:(zx + m.x) / 2, y:m.y + s * (sal + 16) }); } }
        else { if (Math.abs(m.x - zx) < EPS) sitY(m.y); else { const s = m.x > cx ? 1 : -1, sal = s > 0 ? sobre.x1 : sobre.x0; lin('v', { x:m.x, y:zy }, m, { x:m.x + s * (sal + 16), y:(zy + m.y) / 2 }); } }
        const d = hor ? Math.abs(a.c.y - m.y) : Math.abs(a.c.x - m.x), cuerda = dist(t.p1, t.p2);
        if (d > EPS) { // Pitágoras: la cuerda o la distancia al centro (siempre la misma para la misma pieza)
            const haciaC = hor ? Math.sign(a.c.y - m.y) : Math.sign(a.c.x - m.x), ent = haciaC * (hor ? (m.y > cy ? -1 : 1) : (m.x > cx ? -1 : 1)) > 0;
            if (Math.round(cuerda) % 4 === 0) { const e = (ent ? -1 : 1) * 14, np = hor ? (m.y > cy ? 1 : -1) : (m.x > cx ? 1 : -1); mete({ tipo:hor ? 'h' : 'v', p1:{ ...t.p1 }, r1:null, p2:{ ...t.p2 }, r2:null, pos:hor ? { x:m.x, y:m.y + np * Math.abs(e) } : { x:m.x + np * Math.abs(e), y:m.y } }); }
            else { const lat = cuerda / 2 + 14; mete({ tipo:hor ? 'v' : 'h', p1:m, r1:null, p2:{ x:a.c.x, y:a.c.y }, r2:null, pos:{ x:hor ? a.c.x + lat : (m.x + a.c.x) / 2, y:hor ? (m.y + a.c.y) / 2 : a.c.y + lat } }); } }
    });
    vivos.filter(c => c !== ext).forEach(c => { const uid = c.uid, circ = esCirculoContorno(c), ran = !circ && esRanuraContorno(c);
        if (circ) { sitX(circ.c.x); sitY(circ.c.y); mete({ tipo:'diametro', cruz:true, c:circ.c, r:circ.r, rc:{ uid, si:-1 }, pos:{ x:circ.c.x + (circ.r + 8) * .71, y:circ.c.y + (circ.r + 8) * .71 } }); return; }
        if (ran) { const [c1, c2] = dist(ran.c1, Z) <= dist(ran.c2, Z) ? [ran.c1, ran.c2] : [ran.c2, ran.c1], h = Math.abs(c1.y - c2.y) < EPS, si = tramos(c).findIndex(t => t.b && dist(arcoDeBulge(t.p1, t.p2, t.b).c, c2) < EPS);
            sitX(c1.x); sitY(c1.y); mete({ tipo:'radio', cruz:true, cruz2:c1, c:c2, r:ran.r, rc:{ uid, si:si < 0 ? 1 : si }, pos:{ x:c2.x + (h ? Math.sign(c2.x - c1.x) * (ran.r + 8) : (ran.r + 8) * .7), y:c2.y + (h ? 0 : Math.sign(c2.y - c1.y) * (ran.r + 8) * .7) } });
            lin(h ? 'h' : 'v', c1, c2, h ? { x:(c1.x + c2.x) / 2, y:c1.y + ran.r + 7 } : { x:c1.x + ran.r + 7, y:(c1.y + c2.y) / 2 }); return; }
        const q = bboxPts(muestrearContorno(c)), nx = Math.abs(q.x0 - zx) <= Math.abs(q.x1 - zx) ? q.x0 : q.x1, ny = Math.abs(q.y0 - zy) <= Math.abs(q.y1 - zy) ? q.y0 : q.y1; sitX(nx); sitY(ny);
        lin('h', { x:q.x0, y:q.y1 }, { x:q.x1, y:q.y1 }, { x:(q.x0 + q.x1) / 2, y:q.y1 + 7 }); lin('v', { x:q.x1, y:q.y0 }, { x:q.x1, y:q.y1 }, { x:q.x1 + 7, y:(q.y0 + q.y1) / 2 });
        const tA = tramos(c).find(t => t.b); if (tA) { const a = arcoDeBulge(tA.p1, tA.p2, tA.b); mete({ tipo:'radio', c:a.c, r:a.r, rc:{ uid, si:tA.i }, pos:{ x:q.x1 + 4, y:q.y0 - 4 } }); } });
    let dy = sobreZY + 14, dx = sobreZX + 14;
    [...filaX].sort((a, b) => Math.abs(a - zx) - Math.abs(b - zx)).forEach(x => { lin('h', { ...Z }, { x, y:zy }, { x:(zx + x) / 2, y:zy + sy * dy }); dy += 10; });
    [...filaY].sort((a, b) => Math.abs(a - zy) - Math.abs(b - zy)).forEach(y => { lin('v', { ...Z }, { x:zx, y }, { x:zx + sx * dx, y:(zy + y) / 2 }); dx += 10; });
    lin('h', { ...Z }, { x:ox, y:zy }, { x:(zx + ox) / 2, y:zy + sy * (dy + 4) });
    lin('v', { ...Z }, { x:zx, y:oy }, { x:zx + sx * (dx + 4), y:(zy + oy) / 2 });
}
function usarPiezaC(s) {
    const P = pcPieza(s, pcOpciones()); if (!P) return;
    if (contornos.length && !confirm('Se sustituye el dibujo actual por la pieza Nº ' + s + ' (puedes deshacer).')) return;
    guardarUndo();
    contornos = [P.cont].concat(P.ints.map(i => i.cont)); aux = []; auxPend = null; fondo = null; sel = -1; selSet = new Set(); cotasAjuste = {}; cotasManuales = []; dib = null; circ = null; ran = null; genUltimo = null;
    if (typeof requisitosPorDefecto === 'function') requisitosPorDefecto();
    document.getElementById('projectName').value = 'Contorno sencillo ' + s;
    cfgCotas.ver = false; cfgCotas.centros = true; sincronizarControlesCotas();
    pcAcotar(); actualizarBotonBorrarCotas(); actualizarPanelFondo(); cerrarPiezaContorno(); refrescar(); encuadrar();
    snack(`Nº ${s}: ${P.W} × ${P.H} mm, con ${P.arcos.length} arcos y ${P.ints.length} interior${P.ints.length === 1 ? '' : 'es'}`);
}
// ◠ Hoja de I J: los arcos de la pieza en papel."""
rep("// ◠ Hoja de I J: los arcos de la pieza en papel.", JS)
m = re.search(r'vertical-align:middle">v(\d+)</span></span>', s); assert m
s = s.replace(m.group(0), m.group(0).replace('v' + m.group(1), 'v125'), 1)
open(p, 'w', encoding='utf-8').write(s); print('calcador.html: 📐 Contornos sencillos, v125')
