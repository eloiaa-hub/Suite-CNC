"""Manual del Calcador: alinear y repartir, bloquear, recortar y alargar.
Uso (tras node capt_herramientas_cad.js): python3 manual_herramientas_cad.py <suite>"""
import sys, os, io, base64
from PIL import Image
D = sys.argv[1] if len(sys.argv) > 1 else '../../..'
P = os.path.join(D, 'manual_calcador.html'); s = open(P, encoding='utf-8').read()
assert 'Recortar y alargar' not in s, 'ya aplicado'
C = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'capturas')
rec = Image.open(os.path.join(C, 'recortar.png')).convert('RGB').crop((0, 100, 1190, 1040))
pan = Image.open(os.path.join(C, 'panel.png')).convert('RGB').crop((0, 0, 261, 600))
pan = pan.resize((round(pan.width * rec.height / pan.height), rec.height), Image.LANCZOS)
im = Image.new('RGB', (rec.width + 30 + pan.width, rec.height), 'white'); im.paste(rec, (0, 0)); im.paste(pan, (rec.width + 30, 0))
im = im.resize((1500, round(im.height * 1500 / im.width)), Image.LANCZOS); b = io.BytesIO(); im.save(b, 'WEBP', quality=82, method=6)
src = 'data:image/webp;base64,' + base64.b64encode(b.getvalue()).decode()
def rep(a, c):
    global s
    assert s.count(a) == 1, (s.count(a), a[:80]); s = s.replace(a, c)
cap = 'A la izquierda, Recortar: el marco está bloqueado (🔒) y el cursor sobre el trozo de travesaño que sobresale; en rosa, lo que se quitará con el clic, hasta el cruce marcado. A la derecha, el panel con tres piezas seleccionadas: Alinear, Repartir y Bloquear.'
rep('<h3>Copiar, cortar y pegar</h3>', f'''<h3>Recortar y alargar</h3>
<p>Para dibujar como en un programa de CAD: traza líneas de más largas, que se crucen, y después quita lo que sobra.</p>
<ul>
<li><span class="boton">Recortar</span> (tecla <kbd>Y</kbd>): clic en el <strong>trozo que sobra</strong> de un contorno. Se quita lo que hay entre los dos cruces más cercanos con otros contornos o con las líneas y círculos auxiliares, o hasta el extremo del trazo si no hay cruce por ese lado. Antes de hacer clic se ve en rosa lo que se quitará. En un contorno cerrado se quita el trozo entre los dos cruces y queda abierto.</li>
<li><span class="boton">Alargar</span> (tecla <kbd>H</kbd>): clic junto al <strong>extremo de un trazo abierto</strong>; la recta (en su misma dirección) o el arco (sobre su misma circunferencia) se prolonga hasta el primer contorno o auxiliar que encuentra. Se ve antes, en verde, con lo que crece.</li>
<li>Las dos siguen activas para hacer varios clics seguidos; cada clic se deshace con <kbd>Ctrl</kbd>+<kbd>Z</kbd>, y <kbd>Esc</kbd> vuelve a Editar. Los trazos de un texto de grabado no se recortan.</li>
</ul>
<h3>Bloquear un contorno</h3>
<p>Con <span class="boton">🔒 Bloquear</span>, en el panel del contorno o de la selección, el contorno ya <strong>no se coge en el dibujo</strong>: ni con un clic, ni con el recuadro, ni con <kbd>Ctrl</kbd>+<kbd>A</kbd>, ni se mueve con las flechas, y Recortar y Alargar no lo cambian (pero sí lo usan como borde). Es útil para calcar, acotar o recortar encima de un contorno ya terminado sin moverlo por error. Los imanes sí lo ven. Se reconoce por el 🔒 en el dibujo y en la lista de contornos; para desbloquearlo, selecciónalo en la lista y pulsa <span class="boton">🔓 Desbloquear</span>. El bloqueo se guarda en el JSON.</p>
<figure class="ancha"><img src="{src}" alt="{cap}"><figcaption>{cap}</figcaption></figure>
<h3>Copiar, cortar y pegar</h3>''')
rep('<h3>Transformar con asas</h3>', '''<h3>Alinear y repartir</h3>
<p>Con dos o más piezas seleccionadas, el panel ofrece seis botones para <strong>alinearlas</strong> respecto al conjunto: a la izquierda, centradas (mismo centro en X), a la derecha, abajo, centradas (mismo centro en Y) y arriba. <span class="boton">Repartir ↔</span> y <span class="boton">Repartir ↕</span>, con tres o más, dejan <strong>la misma separación</strong> entre una pieza y la siguiente; la primera y la última no se mueven, y la barra de estado dice la separación que ha quedado. Cada grupo o texto cuenta como una sola pieza, así que una pieza agrupada con sus agujeros se alinea entera.</p>
<h3>Transformar con asas</h3>''')
rep('<tr><td><kbd>J</kbd></td><td>Cortar en un punto</td><td><kbd>U</kbd></td><td>Tangencias</td></tr>',
    '<tr><td><kbd>J</kbd></td><td>Cortar en un punto</td><td><kbd>U</kbd></td><td>Tangencias</td></tr><tr><td><kbd>Y</kbd></td><td>Recortar</td><td><kbd>H</kbd></td><td>Alargar</td></tr>')
s = s.replace('Calcador de contornos v83 · Por Eloi A.A.', 'Calcador de contornos v84 · Por Eloi A.A.')
open(P, 'w', encoding='utf-8').write(s); print('manual_calcador.html: alinear, repartir, bloquear, recortar y alargar')
