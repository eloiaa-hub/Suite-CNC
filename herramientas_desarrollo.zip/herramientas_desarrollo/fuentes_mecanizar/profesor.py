"""Calcador v115 / Corrector v60: el profesor en la corrección masiva. Su nota y su comentario (✎ en la lista y en la
corrección detallada), ◀ ▶ para ir de un alumno a otro (Alt+← Alt+→), 💾 guardar y 📂 abrir la corrección, y 🖨 la hoja
de devolución para el alumno. Pasan a la tabla, al CSV, a los informes y a las notas para Aules.
Uso: python3 profesor.py <carpeta de la suite>   (construir_calcador.sh lo pone tras diagnostico.py)"""
import sys, os
AQUI = os.path.dirname(os.path.abspath(__file__))
P = os.path.join(sys.argv[1] if len(sys.argv) > 1 else '.', 'calcador.html')
s = open(P, encoding='utf-8').read()
def rep(a, b, cnt=1):
    global s
    n = s.count(a); assert n == cnt, f'{n} apariciones (se esperaban {cnt}) de: {a[:100]}'
    s = s.replace(a, b)
JS = open(os.path.join(AQUI, 'profesor.js'), encoding='utf-8').read()
rep("// Arrastrar archivos a la ventana de corrección masiva; ordenar por columna", JS + "// Arrastrar archivos a la ventana de corrección masiva; ordenar por columna")
# la lista: la marca y el botón ✎
rep("""<td class="n nota ${v.nota >= 5 ? 'ap' : 'su'}">${nf(v.nota, 1)}</td>""", """<td class="n nota ${v.nota >= 5 ? 'ap' : 'su'}">${nf(v.nota, 1)}${marcaProf(it)}</td>""")
rep("""<button class="mv-b" data-a="ver\"""", """<button class="mv-b" data-a="prof" title="Tu nota y tu comentario para este alumno">✎</button><button class="mv-b" data-a="ver\"""")
rep("""        else if (a === 'inf') { ev.stopPropagation(); imprimirInformes([k]); }""", """        else if (a === 'inf') { ev.stopPropagation(); imprimirInformes([k]); }
        else if (a === 'prof') { ev.stopPropagation(); editarProf(k); }""")
# la barra de la corrección masiva
rep("""title="Los errores y avisos que más se repiten en la clase, con quién los tiene: qué repasar">📊 Errores de la clase</button>""",
    """title="Los errores y avisos que más se repiten en la clase, con quién los tiene: qué repasar">📊 Errores de la clase</button>
                <button class="btn-action sec" onclick="imprimirDevoluciones()" title="La hoja de devolución de cada alumno: su recorrido, lo que tiene que revisar, tu comentario y la nota">🖨 Devoluciones</button>
                <button class="btn-action sec" onclick="guardarCorreccion()" title="Guarda en un archivo la corrección de esta tarea (el ejercicio, las variantes, los programas, tus notas y comentarios) para seguir otro día">💾 Guardar corrección</button>
                <input type="file" id="mvCorrJSON" accept=".json" style="display:none" onchange="abrirCorreccionArchivo(this)">
                <button class="btn-action sec" onclick="document.getElementById('mvCorrJSON').click()" title="Abre una corrección guardada con 💾 Guardar corrección">📂 Abrir corrección</button>""")
# la barra del alumno en la corrección detallada
rep("""        <div class="cr-cuerpo">""", """        <div class="cr-alumno" id="crAlumno" style="display:none"></div>
        <div class="cr-cuerpo">""")
rep("    .mv-inf { font-size:12px; cursor:help; }", """    .mv-prof { font-size:11px; margin-left:3px; cursor:help; }
    .cr-alumno { display:flex; align-items:center; gap:8px; padding:6px 14px; background:var(--accent-light); border-bottom:1px solid var(--border-color); flex-wrap:wrap; }
    .cr-alumno .btn-action { width:auto; padding:3px 10px; flex:0 0 auto; } .cr-al-nom { min-width:160px; } .cr-al-nom small { color:var(--text-muted); margin-left:4px; }
    .cr-alumno label { display:flex; align-items:center; gap:4px; font-size:13px; } #crNotaProf { width:56px; } #crComProf { flex:1; min-width:200px; padding:4px 6px; }
    .prof-l { display:block; margin:8px 0; font-size:13px; } .prof-l textarea { margin-top:4px; padding:6px; border:1px solid var(--border-color); border-radius:6px; font:13px/1.4 inherit; }
    .mv-inf { font-size:12px; cursor:help; }""")
# el CSV
rep("""...(rubricaActiva() ? RUBRICA.map(x => x[1] + ' (rúbrica)') : []), 'Observaciones']];""",
    """...(rubricaActiva() ? RUBRICA.map(x => x[1] + ' (rúbrica)') : []), ...(hayProf() ? ['Nota orientativa', 'Comentario del profesor'] : []), 'Observaciones']];""")
rep("""...(rubricaActiva() ? RUBRICA.map(x => { const a = (v.rub || []).find(y => y.k === x[0]); return d(a ? a.puntos : 0); }) : []), obs]); });""",
    """...(rubricaActiva() ? RUBRICA.map(x => { const a = (v.rub || []).find(y => y.k === x[0]); return d(a ? a.puntos : 0); }) : []), ...(hayProf() ? [d(v.notaAuto !== undefined ? v.notaAuto : v.nota), it.comProf || ''] : []), obs]); });""")
# el informe y la devolución
rep("""<div class="nota ${v.nota >= 5 ? 'ap' : 'su'}"><span>Nota orientativa</span>""", """<div class="nota ${v.nota >= 5 ? 'ap' : 'su'}"><span>${it.notaProf !== null && it.notaProf !== undefined ? 'Nota del profesor' : modoDevol ? 'Nota' : 'Nota orientativa'}</span>""")
rep("""<div class="al"><span>Alumno/a:</span> <b>${esc(it.alumno)}</b> <span class="ar">(${esc(it.archivo)})</span></div>""",
    """<div class="al"><span>Alumno/a:</span> <b>${esc(it.alumno)}</b> <span class="ar">(${esc(it.archivo)})</span></div>
            ${it.comProf ? `<div class="com-prof">💬 <b>Comentario del profesor:</b> ${esc(it.comProf)}</div>` : ''}""")
rep("""            ${(e => e ? `<div class="ar" style="margin:-4px 0 8px;color:${e.ok ? '#1e7a46' : '#b0301f'}">🧾 ${esc(e.txt)}</div>` : '')(estadoInforme(it))}""",
    """            ${modoDevol ? '' : (e => e ? `<div class="ar" style="margin:-4px 0 8px;color:${e.ok ? '#1e7a46' : '#b0301f'}">🧾 ${esc(e.txt)}</div>` : '')(estadoInforme(it))}""")
rep("""            ${it.variante ? `<div class="ar" style="margin:-4px 0 8px;${it.varAviso""", """            ${it.variante && modoDevol ? `<div class="ar" style="margin:-4px 0 8px">🎲 Tu variante: <b>${esc(it.variante)}</b>${it.varAviso ? ' · ⚠️ ' + esc(it.varAviso) : ''}</div>` : it.variante ? `<div class="ar" style="margin:-4px 0 8px;${it.varAviso""")
rep("<h2>Observaciones</h2>", "<h2>${modoDevol ? 'Lo que tienes que revisar' : 'Observaciones'}</h2>")
rep("Corrección del programa · ${hoy}", "${modoDevol ? 'Devolución de la corrección' : 'Corrección del programa'} · ${hoy}")
rep("<title>Corrección — ${esc(titulo)}</title>", "<title>${modoDevol ? 'Devolución' : 'Corrección'} — ${esc(titulo)}</title>")
rep("        body { font: 10pt/1.35 'Segoe UI', Arial, sans-serif; color: #222; margin: 0; }", "        body { font: 10pt/1.35 'Segoe UI', Arial, sans-serif; color: #222; margin: 0; }\n        .com-prof { margin: 2px 0 10px; padding: 6px 10px; border-left: 4px solid #2a6db0; background: #eef4fb; }")
# en la devolución con la nota del profesor, sin el desglose de la orientativa (confunde); el programa, sin salirse de su columna
rep("            ${tablaDesglose(v, N)}", "            ${modoDevol && it.notaProf !== null && it.notaProf !== undefined ? '' : tablaDesglose(v, N)}")
rep("        .prog div { white-space: pre; break-inside: avoid; }", "        .prog div { white-space: pre-wrap; overflow-wrap: anywhere; break-inside: avoid; }")
rep("    .cr-volver { margin-left: auto; margin-right: 10px; white-space: nowrap; }", "    .cr-volver { margin-left: auto; margin-right: 10px; white-space: nowrap; width: auto !important; flex: 0 0 auto; }")
# la ayuda
rep("""<strong>🗃 Batería…</strong>:""", """<strong>✎</strong> en cada alumno (o en su corrección detallada, que tiene ◀ ▶ y Alt+← Alt+→ para ir al anterior y al siguiente): tu nota, que manda sobre la orientativa, y tu comentario; pasan a la tabla, el CSV, los informes, la devolución y las notas para Aules. <strong>🖨 Devoluciones</strong>: la hoja para cada alumno, con su recorrido, lo que tiene que revisar, tu comentario y la nota. <strong>💾 Guardar corrección</strong> y <strong>📂 Abrir corrección</strong>: la corrección de la tarea (el ejercicio, las variantes, los programas, tus notas y comentarios) en un archivo, para seguir otro día. <strong>🗃 Batería…</strong>:""")
open(P, 'w', encoding='utf-8').write(s)
print('Calcador: nota y comentario del profesor, anterior/siguiente, guardar la corrección y devolución')
