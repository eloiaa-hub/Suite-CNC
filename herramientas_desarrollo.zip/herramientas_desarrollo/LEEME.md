# Herramientas de desarrollo de la Suite CNC

Esta carpeta no se usa en clase y no hace falta subirla a Aules. Sirve para mantener la suite sin perder trabajo.

## Construir el Corrector

El Corrector es el Calcador en modo visor. Después de cualquier cambio en `calcador.html`:

```
python3 construir_corrector.py ..
```

(el argumento es la carpeta de la suite). Para subir la versión del Corrector, cambia `VERSION_CORRECTOR` dentro del script.

## Fuentes de ⚙️ Mecanizar (`fuentes_mecanizar/`)

Copia de referencia de lo que se integró en el Calcador (v74 y v75). **El Calcador ya lo lleva dentro**: los cambios nuevos se hacen directamente en `calcador.html`.

- `motor_mecanizado.js`: motor de G-code (adaptación fiel del Generador v81 a mm reales).
- `adaptador_calcador.js`: convierte los contornos del Calcador en trazados para el motor.
- `mecanizar_ui.js`: ventana ⚙️ Mecanizar (campos, vista previa, descargar, simulador).
- `caj_bloque.js`, `offset_bloque.js`, `clipper_bloque.js`: cajeras, desbaste/acabado y Clipper 6.4.2 (licencia Boost), sacados del Generador.
- `integrar_mecanizar.py` + `quitar_generador.py` + `multiherramienta.py` + `dxf_texto.py` + `recibir_proyecto.py` + `entregas_aules.py` + `cuestionario_moodle.py` + `dxf_exportar.py` + `orden_corte.py` + `agrupar.py` + `herramientas_cad.py` + `ejercicio_aleatorio.py` + `centros_arcos.py` + `simulador_unico_calc.py` + `cierre_arcos.py` + `cotas_interiores.py` + `tutor_ejercicio.py` + `calcador_v73_original.html`: rehacen el Calcador actual desde el v73 (la versión resultante está en `VERSION_CALCADOR`) y, al final, el Corrector y el Tutor. Todo seguido, con:

  ```
  sh construir_calcador.sh
  ```

  `quitar_generador.py` quita del Calcador las referencias visibles al Generador (botón, escala y textos). `multiherramienta.py` añade la herramienta por contorno: el campo del panel, el cambio con M06 en el intérprete, la compensación con el radio de cada tramo, la corrección de la herramienta y el cambio en el programa de la tabla de soluciones. `recibir_proyecto.py` recibe el proyecto del Anidador también sin almacén compartido (por mensaje). `dxf_texto.py` lee los textos de los DXF de fondo con sus acentos (UTF-8, página de códigos, `\U+XXXX` y `%%nnn`). `entregas_aules.py` mete `zip_lector.js` (lector de .zip con descompresión propia) y `entregas_comun.js` (SHA-256, código y lectura del informe de entrega) para la corrección masiva desde el zip de Aules. `cuestionario_moodle.py` mete `cuestionario_moodle.js` (📝 Cuestionario para Aules, Moodle XML). `dxf_exportar.py` escribe el DXF como R12 completo (AutoCAD abría vacío el anterior). `orden_corte.py` añade el orden de corte de ⚙️ Mecanizar (interiores primero por defecto, de dentro afuera). `agrupar.py`, los grupos (Ctrl+G) y mover la selección con las flechas. `herramientas_cad.py` (con `herramientas_cad.js`), alinear y repartir, bloquear contornos, recortar (Y) y alargar (H). `ejercicio_aleatorio.py` (con `ejercicio_aleatorio.js`), la ventana 🧩 Ejercicio aleatorio: piezas al azar con las formas del Calcador, con semilla. `centros_arcos.py`, la cruz de cada centro (5 mm) en su propia capa de cotas (E), rojo oscuro y más gruesa, y el contorno de la pieza más grueso que las cotas en el SVG y las hojas. El Generador está retirado: `generador.html` se conserva sin actualizar y solo lo usan las pruebas de referencia.

## Manuales

Las fuentes originales de los manuales no están: se editan directamente `manual_calcador.html` y `manual_corrector.html`, y los PDF se rehacen con

```
node generar_pdf_manuales.js ..
```

(Chromium y Playwright; con Python, pikepdf y Pillow, `aligerar_pdf.py` pasa después las capturas a JPEG y el PDF pesa menos de la mitad; en el del Calcador recalcula las páginas del índice impreso; `SOLO=manual_anidador` imprime solo ese). En `manuales/` están los scripts que quitaron el Generador de los dos manuales (ya aplicados: no se vuelven a ejecutar), y `manuales_m06.py`, que añadió la herramienta por contorno y el M06, `orden_dxf_manuales.py`, el orden de corte y el DXF R12, `agrupar/manual_agrupar.py` (con su captura, `capt_agrupar.js`), los grupos y las flechas, `herramientas_cad/manual_herramientas_cad.py` (con `capt_herramientas_cad.js`), alinear, repartir, bloquear, recortar y alargar, y `ejercicio_aleatorio/manual_generador.py`, `manual_generador_fase2.py` y `manual_generador_fase3.py` (con `capt_generador.js`), el ejercicio aleatorio.

En `manuales/entregas/`, `capt_entregas.js` hace las capturas del zip de Aules y del cuestionario, y `manuales_entregas.py` (ya aplicado) las añadió a los manuales del Calcador y del Corrector.

La **guía del Simulador 3D** se hace desde su fuente, `manuales/guia_simulador/fuente_guia.html`, como los manuales de la Calculadora y el Anidador: primero las capturas (en esa carpeta, `LANG=C.UTF-8 node capt_guia.js`, `node capt_editor.js`, `node capt_informe.js` y `node capt_explicar.js`, que dejan las imágenes en `img/`, que no va en el zip; los programas de ejemplo de las capturas están en `progs/`) y después `sh construir_guia.sh`, que hace `guia_simulador.html` y `guia_simulador.pdf`.

La **biblioteca de inicio** (`biblioteca_inicio/` en la suite) sale de `biblioteca_inicio/construir_biblioteca.js` con el plan de `plan.js`: cada ejercicio es una semilla y una etapa (los parámetros del generador) de su nivel, con la programación pedida. Las semillas se eligieron mirando las hojas de contactos de `candidatos.js` (`LANG=C.UTF-8 node candidatos.js [nivel]`). El script escribe los JSON por niveles, el paquete `Biblioteca_de_inicio.json`, la página `index.html` (`pagina.js`), el `LEEME.md` (copia de `LEEME_biblioteca.md`) y, importándolo en la biblioteca del Calcador, las hojas y las soluciones en PDF; `resumen.csv` lista lo que ha salido. Si cambia el generador, vuelve a mirar los candidatos: un mismo número puede dar otra pieza.

Los **apuntes de códigos ISO** (`apuntes_iso.html` y `.pdf`) tienen sus fuentes en `manuales/guia_iso/`: el texto en `fuente_apuntes_iso.html` (con `{{svg:…}}` para los dibujos y `{{img:…}}` para las capturas), los dibujos en `diagramas.py` (los deja en `diagramas/`), las capturas del Simulador con la pieza ISO 13 en `capt_iso.js` y `construir_apuntes.py`, que lo junta con el estilo de los manuales. Orden: `python3 diagramas.py`, `LANG=C.UTF-8 node capt_iso.js`, `python3 construir_apuntes.py ../../..` y después el PDF con `SOLO=apuntes_iso node generar_pdf_manuales.js ..`. Los programas de ejemplo de los apuntes están comprobados en el Simulador (sin avisos; el del capítulo 9, al 100 % del plano). `enlazar_calcador.py` (ya aplicado) añadió al manual del Calcador la explicación de la estrategia y el enlace a los apuntes.

Los manuales de la **Calculadora** y del **Anidador** sí tienen fuentes, en `manuales/anidador_calculadora/`: el texto en `fuentes/` (con `{{img:captura.png}}` donde va cada imagen), los guiones que hacen las capturas con ejemplos (`capt_calc.js`, `capt_anid.js`; el del Anidador usa ejercicios de la carpeta `EJERCICIOS`) y `construir_manual.py`, que incrusta las capturas en WebP con el estilo del manual del Corrector. Después, el PDF con `generar_pdf_manuales.js`.

## Tutor G-Code

`tutor.html` se genera a partir del Calcador (como el Corrector), al final de `construir_calcador.sh`, con `tutor/construir_tutor.py`: quita lo que es del profesor, pone el panel del Tutor (`tutor/tutor_panel.html`, `tutor/tutor.css`, `tutor/tutor.js`), la explicación de cada línea y el intérprete del Simulador 3D (sacados de `simulador3d.html` y de `fuentes_mecanizar/explicar_linea.js`) y los ejemplos (los programas resueltos de `manuales/resueltos/piezas/` y la biblioteca de inicio). Su versión está en `VERSION_TUTOR`. Solo: `python3 tutor/construir_tutor.py ..`. El botón del Calcador 🎓 Ejercicio para el Tutor es el parche `fuentes_mecanizar/tutor_ejercicio.py`.

La **interfaz del Calcador** (v95) es la del Tutor: `tutor/interfaz_calcador.py`, el último paso de `construir_calcador.sh`, la aplica a `calcador.html` (después de generar el Corrector y el Tutor, que salen de la interfaz anterior). Pone Nuevo/Abrir/Guardar/Biblioteca en la barra superior, el panel izquierdo en pestañas (Ejercicios/Corregir, Dibujo/Construcción/Formas, Fondo/Exportar), el panel del Tutor a la derecha (con `const TU_C2 = true`: Solución/Máquina, ⚙️ Mecanizado con los campos de ⚙️ Mecanizar, sin Practicar ni niveles) y quita los botones viejos. Comprueba que no se aplica dos veces: para rehacerlo, se ejecuta `construir_calcador.sh` entero.

La **guía del Tutor** está en `manuales/guia_tutor/`: el texto en `fuente_guia_tutor.html`, las capturas con `capt_tutor.js` (en `img/`) y `construir_guia.sh`, que hace `guia_tutor.html` y el PDF. El **manual del Calcador** se edita directamente; el paso a la interfaz nueva es `manuales/interfaz_calcador/interfaz_manual.py` (ya aplicado), con las capturas de `capt_calcador.js` (`node capt_calcador.js && python3 numerar.py`, en `capturas/`; la lámina del tutorial es `capturas/lamina_ejercicio7.png`). Después, el PDF: `SOLO=manual_calcador node generar_pdf_manuales.js .` desde la carpeta de la suite. Para que el zip quede por debajo de 30 MB, las capturas de los PDF de los manuales y las guías se reducen con `python3 reducir_pdf.py entrada.pdf salida.pdf` (a 1300 px de ancho y JPEG de calidad 80).

## Simuladores

`simulador3d.html` se edita directamente (no se genera): es el único Simulador 3D, con editor, para alumnado y profesorado. `simulador_unico.py` (ya aplicado) lo hizo a partir del antiguo `simulador3d_profesor.html`, que ahora solo lleva a `simulador3d.html`. `simulador_m06.py` (ya aplicado) es el cambio de herramienta con T… M06. `simulador_m04.py` (V43, ya aplicado) avisa de M04 en la revisión. `simulador_fresa_panel.py` y `simulador_angulo_v.py` (V44, ya aplicados): lo que se cambia en el panel Herramienta (tipo, ángulo, Ø) se aplica a la T de la base del programa, solo en la simulación. `simulador_explicar.py` (V42) le añade 💬 explicar la línea y 📍 la posición absoluta en G91, con el código de `fuentes_mecanizar/explicar_linea.js` (entre las marcas `// <explicar-linea>`; si ya está, solo actualiza ese código: `python3 simulador_explicar.py ..`). `simulador_informe.py` le añade el 🧾 informe de entrega (`fuentes_mecanizar/entregas_comun.js` + `informe_entrega.js`, entre las marcas `// <informe-entrega>`); si ya está, solo actualiza ese código: `python3 simulador_informe.py ..`.

## Anidador

`anidador.html` se edita directamente. `anidador/cantos_coste.py` es el paso de la v6 (`anidador/anidador_v6.html`) a la v7: cantos y coste; `anidador/forma_real.py` (con `forma_real.js`), el de la v7 a la v8: anidado por la forma real. Para rehacerlo: `cp anidador/anidador_v6.html ../anidador.html && python3 anidador/cantos_coste.py .. && python3 anidador/forma_real.py ..`.

## Pruebas automáticas (`pruebas/`)

Requieren Node.js y Playwright con Chromium. Variables opcionales: `SUITE` (carpeta de la suite, por defecto `../..`), `EJERCICIOS` (carpeta con JSON de ejercicios) y `CHROME` (ruta del navegador).

| Prueba | Qué comprueba |
|---|---|
| `arranque.js` | Todos los programas abren sin errores y muestran su versión |
| `robustez_tutor.js`, `robustez_calcador.js`, `robustez_simulador.js` | Entradas malas y extremas: almacenamiento corrupto, JSON malformados, campos vacíos, con letras o enormes, geometrías raras, cambios rápidos; sin errores de JavaScript ni NaN en el G-code |
| `sim_fresa_panel.js` | Simulador: con `T101 M06`, la fresa de bola o en V elegida en el panel (o en un comentario) corta con su forma; la base no cambia; con dos herramientas, solo la del tramo |
| `regresion_basica.js` | Todos los ejercicios abren y se corrigen en Calcador y Corrector |
| `motor_vs_generador.js` | El motor de Mecanizar da el mismo G-code que el Generador (`referencia_generador.json`, 390 casos). Desde el Calcador v75 los 65 casos con G41/G42 (`comp_oposic`) salen distintos a propósito: entrada y salida de la compensación | Desde el Calcador v85, las configuraciones con estrategia «concordancia» (`pasadas_g91`, `mixto_g91`) salen distintas a propósito: el Generador tenía la concordancia al revés (con M03, concordancia = G41).
| `referencia_generador.js` | Regenera esa referencia con el Generador |
| `comp_simulador.js` | Programas con G41/G42 en el Simulador: la trayectoria compensada corta todo el contorno sin meterse en la pieza (con `Prueba01.json`) |
| `corpus_comp.js` | `comp_simulador.js` sobre todos los ejercicios (quedan avisos esperables: detalles más pequeños que la fresa y huecos que se solapan) |
| `calculadora.js` | Calculadora de taller: resultados con valores conocidos, conversión G90 ↔ G91 (ida y vuelta), guardado, móvil (las cinco pestañas sin salirse) y capturas |
| `anidador.js` | Anidador: sin solapes y dentro del margen, veta, varios tableros, CSV con coma decimal, piezas reales; el tablero se abre en el Calcador y ⚙️ Mecanizar genera el programa; colocar a mano con el ratón (arrastrar, doble clic para girar, asas para la escala, chincheta, pasar a otro tablero por su pestaña o a uno nuevo; los tableros vacíos se quitan), giro y color en la lista; reabrir un tablero guardado (también de versiones anteriores, `anidado_v3_usuario.json`) con las piezas por separado; exportar PNG, SVG y DXF (en el SVG y el DXF se comprueba que cada arco va hacia su lado, y en el DXF el color de cada pieza; el DXF se valida con `validar_dxf.py`, que necesita `pip install ezdxf`) |
| `dxf_texto.js` | Calcador: textos de DXF de fondo con acentos (R12 en Windows-1252 y en UTF-8, DXF 2010, `\U+XXXX`, `%%nnn`); crea los DXF con ezdxf |
| `multiherr.js` | Herramienta por contorno: panel, plano, ⚙️ Mecanizar con M06, corrección de los errores típicos del cambio y nota |
| `sim_m06.js` | Simuladores con T… M06: compensación y corte con el radio de cada herramienta, fresa dibujada y revisión |
| `entregas.js` | 🧾 Informe de entrega de los dos Simuladores (PDF válido, código, plano y revisión) y corrección masiva desde el zip de Aules (en carpetas, sin carpetas, texto en línea, zip dentro, informe que coincide, que no y modificado), también con la descompresión propia. Con `LANG=C.UTF-8` |
| `cuestionario.js` | 📝 Cuestionario: en cada variante de 30 ejercicios, las respuestas (G90, G91, polares, I J, R, G2/G3, G41/G42) coinciden con la geometría, el Cloze está bien escrito y el XML se lee |
| `agrupar.js` | Grupos (Ctrl+G, clic, Alt + clic, arrastrar, pegar y matrices como grupos nuevos, JSON, desagrupar, tablero del Anidador agrupado por piezas) y flechas (1 / 10 / 0,1 mm, deshacer de una vez, sin selección no mueven) |
| `herramientas_cad.js` | Alinear (seis modos, el grupo como una pieza) y repartir; bloquear (ni clic, ni arrastre, ni Ctrl+A, ni flechas; sí desde la lista; JSON); recortar (extremo, trozo central, contorno cerrado, círculo, hasta una auxiliar, con un bloqueado de borde) y alargar (recta, por el principio hasta un círculo auxiliar, arco), teclas Y / H y Esc |
| `simulador_unico.js` | Un solo Simulador 3D: sin «Profesor» y V40, con el editor (editar y aplicar), el enlace antiguo `simulador3d_profesor.html` lleva al nuevo, «➜ Abrir en el Simulador» del Calcador lo abre con el plano y la solución, y la portada tiene una sola ficha |
| `cierre_arcos.js` | Un arco de 3 puntos se cierra con una recta hasta su inicio (sin terminar o ya terminado, desde cualquier extremo); dos puntos en recta no; «Unir o cerrar con el extremo más cercano» cierra el propio trazo si su otro extremo es el más cercano y, si no, une con el otro trazo (Calcador v92) |
| `sim_tpacad.js` | Simulador V41: `G71 X Y Z` antes del primer movimiento (TpaCAD) son las medidas del tablero (material en manual) y no un movimiento; el programa de prueba de los apuntes de TpaCAD sin errores; morder el martiriño hasta 2 mm es un aviso y más, un error |
| `explicar_linea.js` | Simulador V42: 💬 la explicación de cada línea (G91, arcos con I J y R, círculo completo, modales, comentarios, después de M30, TpaCAD, G41/G42, ciclos) y 📍 la posición absoluta de las líneas en G91, que coincide con donde acaba la fresa en todos los programas resueltos en G91 y mixtos; los botones y el editor |
| `tutor.js` | Tutor G-Code: sin lo del profesor; los 20 programas resueltos de los apuntes salen iguales (G90, G91, mixta, dos pasadas); Practicar acepta el propio programa y las formas equivalentes y explica los errores; los ejercicios (sin programa ni coordenadas, solo medir; el JSON del Calcador con `tutor.ejercicio`); el programa crece al dibujar; las 50 piezas de ejemplo en G90/G91/mixta con y sin G41/G42 pasan por todos sus puntos; con `tutor_compensacion.json`, el aviso de G41/G42 del lado equivocado, el centro de la fresa a su radio con fresas de Ø10 y Ø40 (el Ø del Tutor, no el de la T en la base). Con `TUTOR_SALIDA=carpeta` guarda los programas. Los de G41/G42 se comprueban en el Simulador con `comp_simulador.js plano.json prog.nc…` (`SOLO_EXTRA=1`) |
| `ejercicio_aleatorio.js` | 🧩 Ejercicio aleatorio: 1650 semillas con once configuraciones, también los cuatro niveles (nivel 1 solo rectas horizontales y verticales en la rejilla, nivel 2 sin arcos, nivel 3 con los centros de los arcos enteros) y una comprobación de solapes independiente; la serie en la biblioteca (carpeta, número de orden, semilla, sin tocar el dibujo abierto); el nivel pasa a «Libre» al cambiar algo; y (también con esquinas y lados en arco: salen los cinco tipos, sin cruces y con los arcos cóncavos para la fresa de al menos su diámetro; sin estos parámetros, las piezas de la v86) (tamaño, cotas en múltiplos del paso, interiores dentro con la pared mínima y en el grupo de su pieza, piezas separadas, huecos de más de dos diámetros de fresa), la misma semilla da lo mismo, la ventana, usar, deshacer, Nuevo y el JSON, y ⚙️ Mecanizar de cinco propuestas en el Simulador (todo cortado, sin meterse en la pieza) |
| `orden_dxf.js` | Orden de corte (interiores primero por defecto, elegible, en el programa, el plano, la tabla y el JSON) y DXF del Calcador (un ejercicio y un anidado, en los dos modos) leído por ezdxf sin recuperar: R12, sin errores y con la misma longitud que los contornos |
| `forma_real.js` | Anidador por la forma real: anillos y discos y ejercicios del Calcador sin solapes ni separaciones menores que la de la fresa (geometría exacta), dentro del margen, los discos en los huecos, mejor que por rectángulos, veta, colocar a mano dentro de un hueco, arrastrar (en rojo si choca), guardar y reabrir, y en el Calcador el corte de dentro afuera |
| `cantos_coste.js` | Anidador: cantos desde el CSV (por título, números y letras), clic en la lista, dibujo con la pieza girada, metros de canto, superficie, tiempo y coste, guardar y reabrir, CSV y móvil |
| `mecanizar_ui.js` | La ventana ⚙️ Mecanizar: herramienta, opciones, guardado, descarga y simulador |
| `interp_corpus.js`, `interp_cmp.js` | Intérprete ISO de los simuladores frente al corpus de programas |
| `estres_mecanizar.js`, `perfil_*.js`, `mec_vista.js` | Casos extremos y medidas de tiempo |

Ejemplo: `cd pruebas && node arranque.js`

Los apuntes **Arcos con el centro fuera de la línea** (`arcos_pitagoras.html` / `.pdf`, de momento aparte de los apuntes ISO) salen de `manuales/arcos_pitagoras/`: `python3 diagramas.py`, `python3 construir.py ../../..` y el PDF con `SOLO=arcos_pitagoras node herramientas_desarrollo/generar_pdf_manuales.js .` desde la carpeta de la suite.

Los **programas resueltos** (`programas_resueltos.html` / `.pdf`) salen de `manuales/resueltos/`: `LANG=C.UTF-8 node exportar_planos.js` (planos con cotas desde el Calcador, de `piezas/*.json`) y `python3 construir.py` (necesita los dibujos de `../guia_iso/diagramas/`). `gen.py` calcula las tablas y los programas G90, G91 y mixta desde los contornos, y comprueba que pasan por todos los puntos; los deja también en `programas/*.nc`.
