#!/bin/sh
# Reconstruye calcador.html (y corrector.html) desde el Calcador v73 original con todos los parches, en orden.
# Uso: sh construir_calcador.sh            (desde herramientas_desarrollo; escribe en la carpeta de la suite)
set -e
cd "$(dirname "$0")/fuentes_mecanizar"
cp calcador_v73_original.html ../../calcador.html
python3 integrar_mecanizar.py ../..
python3 quitar_generador.py ../..
python3 multiherramienta.py ../..
python3 dxf_texto.py ../..
python3 recibir_proyecto.py ../..
python3 entregas_aules.py ../..
python3 cuestionario_moodle.py ../..
python3 dxf_exportar.py ../..
python3 orden_corte.py ../..
python3 agrupar.py ../..
python3 herramientas_cad.py ../..
python3 ejercicio_aleatorio.py ../..
python3 centros_arcos.py ../..
python3 simulador_unico_calc.py ../..
python3 cierre_arcos.py ../..
python3 cotas_interiores.py ../..
python3 tutor_ejercicio.py ../..
python3 aviso_lado_mec.py ../..
python3 informe_tutor.py ../..
python3 hoja_ejercicio.py ../..
python3 entregas_documentos.py ../..
python3 fin_programa.py ../..
python3 editar_centro.py ../..
python3 variantes_masiva.py ../..
python3 parecidos_masiva.py ../..
python3 aules_notas.py ../..
python3 variantes_medidas.py ../..
python3 examen_reparto.py ../..
python3 huecos_programa.py ../..
python3 correccion_clase.py ../..
python3 bateria.py ../..
python3 altura_corte.py ../..
python3 desplazado.py ../..
python3 trazado_nota.py ../..
python3 diagnostico.py ../..
python3 profesor.py ../..
python3 parecidos_informe.py ../..
python3 ../tutor/construir_tutor.py ../..
python3 ../tutor/interfaz_tutor.py ../..
python3 ../tutor/interfaz_calcador.py ../..
python3 ../tutor/interfaz_paneles.py ../..
python3 ../tutor/interfaz_ordenada.py ../..
python3 arcos_calcador.py ../..
python3 hoja_ij.py ../..
python3 examen_18.py ../..
python3 pieza_contorno.py ../..
python3 hoja_datos.py ../..
python3 cotas_cero.py ../..
python3 ../tutor/pantallas_pequenas.py ../..
python3 ../construir_corrector.py ../..          # el Corrector, con la interfaz nueva (después de interfaz_calcador.py)
