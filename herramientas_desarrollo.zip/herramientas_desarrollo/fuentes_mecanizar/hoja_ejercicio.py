"""Calcador v99: la 🖨 Hoja de ejercicio sin la tabla de coordenadas en blanco (al imprimir varios ejercicios desde la
Biblioteca, una tabla larga no cabía en su página y se montaba sobre el enunciado del ejercicio siguiente), y con la
opción de imprimir el plano en color, con los colores del Calcador (los de 💾 SVG en color). Si el plano no cabe a 1:1,
se ajusta al hueco y el cajetín dice «Escala: ajustada (las cotas mandan)» (antes saltaba a 1:2 y quedaba a la mitad).
Uso: python3 hoja_ejercicio.py <carpeta de la suite>   (después de informe_tutor.py)"""
import sys, os
P = os.path.join(sys.argv[1] if len(sys.argv) > 1 else '.', 'calcador.html')
s = open(P, encoding='utf-8').read()
def rep(a, b, cnt=1):
    global s
    n = s.count(a); assert n == cnt, f'{n} apariciones (se esperaban {cnt}) de: {a[:100]}'
    s = s.replace(a, b)
# la configuración: sin «tabla» (los ejercicios guardados que la tengan la ignoran), con «color»
rep("enunciado:'Programa en código ISO el contorno de la pieza tomando como origen el cero pieza indicado en el plano.', tabla:true, rayado:false };",
    "enunciado:'Programa en código ISO el contorno de la pieza tomando como origen el cero pieza indicado en el plano.', rayado:false, color:false };")
rep("const CAMPOS_HOJA = ['titulo', 'num', 'grupo', 'fecha', 'material', 'espesor', 'herramienta', 'centro', 'orient', 'prog', 'enunciado', 'tabla', 'rayado'];",
    "const CAMPOS_HOJA = ['titulo', 'num', 'grupo', 'fecha', 'material', 'espesor', 'herramienta', 'centro', 'orient', 'prog', 'enunciado', 'rayado', 'color'];")
# la ventana: fuera la casilla de la tabla; la del color
rep('                <label><input type="checkbox" id="hj_tabla"> Añadir tabla de coordenadas en blanco para rellenar</label>\n',
    '                <label title="Los contornos exteriores, los interiores, las cotas y las entradas con los colores de la pantalla del Calcador. Sin marcar, todo en negro."><input type="checkbox" id="hj_color"> Imprimir el plano en color (los colores del Calcador)</label>\n')
i = s.index('function imprimirHoja() {'); j = s.index("    try { svg = exportarSVG(true, false) || ''; } finally { chk.checked = antes; }", i)
assert j - i < 400, 'imprimirHoja inesperada'
s = s[:j] + "    try { svg = exportarSVG(true, !!H.color) || ''; } finally { chk.checked = antes; }" + s[j + len("    try { svg = exportarSVG(true, false) || ''; } finally { chk.checked = antes; }"):]
# fuera la tabla: sus filas, sus estilos y su página
i = s.index("    // Filas en blanco de la tabla (orden de mecanizado: exteriores y luego interiores)")
j = s.index("    const rayas = Array.from(", i)
assert j - i < 1500, 'bloque de la tabla inesperado'
s = s[:i] + s[j:]
for a in ["  table.tc { width: 100%; border-collapse: collapse; font-size: 9pt; }\n",
          "  table.tc th { border: 0.3mm solid #111; background: #eee; padding: 1mm; font-size: 8pt; }\n",
          "  table.tc td { border: 0.25mm solid #777; height: 6.5mm; }\n",
          "  table.tc tr.g td { background: #f3f3f3; font-weight: 600; font-size: 8pt; height: auto; padding: 0.8mm 2mm; }\n",
          "  table.tc th:nth-child(1), table.tc th:nth-child(2) { width: 12%; }\n",
          "  table.tc th:last-child { width: 26%; }\n"]:
    rep(a, '')
i = s.index("${H.tabla ? `<div class=\"pag\"><div class=\"cab2\"><h2>Tabla de coordenadas")
j = s.index("` : ''}\n", i) + len("` : ''}\n")
s = s[:i] + s[j:]
assert 'H.tabla' not in s and 'hj_tabla' not in s
# en color, que el navegador no lo pase a gris ni quite los rellenos
rep("  body { margin: 0; font-family: 'Segoe UI', Arial, sans-serif; color: #111; }",
    "  body { margin: 0; font-family: 'Segoe UI', Arial, sans-serif; color: #111; -webkit-print-color-adjust: exact; print-color-adjust: exact; }")
rep("La línea del alumno queda en blanco. Estos datos se recuerdan para el siguiente ejercicio.</p>",
    "La línea del alumno queda en blanco. En color, el plano sale con los colores de la pantalla; si no, en negro. Estos datos se recuerdan para el siguiente ejercicio.</p>")
# imprimir varias (Biblioteca, generador, variantes): todas las hojas con la misma elección de color, la de cfgHoja.color;
# en la barra de la selección de la Biblioteca, una casilla «En color» junto a «Imprimir sus hojas de ejercicio»
rep("""                <button class="btn-action" onclick="imprimirLoteBib([...bib.sel], 'hoja')">🖨 Imprimir sus hojas de ejercicio</button>""",
    """                <button class="btn-action" onclick="imprimirLoteBib([...bib.sel], 'hoja')">🖨 Imprimir sus hojas de ejercicio</button>
                <label class="bib-color" title="El plano de las hojas de ejercicio con los colores del Calcador (sin marcar, en negro)"><input type="checkbox" id="bibColor" onchange="cfgHoja.color = this.checked; guardarAutoPronto()"> En color</label>""")
rep("""    b.style.display = n ? '' : 'none';
    document.getElementById('bibSelN').textContent""", """    b.style.display = n ? '' : 'none';
    const bc = document.getElementById('bibColor'); if (bc) bc.checked = !!cfgHoja.color;
    document.getElementById('bibSelN').textContent""")
rep("""            if (tipo === 'hoja') { abrirHoja(); imprimirHoja(); cerrarHoja(); }""",
    """            if (tipo === 'hoja') { cfgHoja.color = !!antes.cfgHoja.color; abrirHoja(); imprimirHoja(); cerrarHoja(); }""")
rep("    .hoja-checks input { accent-color: var(--accent); }", "    .hoja-checks input, .bib-color input { accent-color: var(--accent); }\n    .bib-color { display: inline-flex; align-items: center; gap: 5px; font-size: 12.5px; color: var(--text-main); cursor: pointer; }")
# si no cabe a 1:1, el plano se ajusta al hueco (antes saltaba a la escala normalizada siguiente, 1:2, y quedaba a la mitad)
rep("""    const k = [1, 2, 2.5, 5, 10, 20, 50].find(k => W / k <= dispW && Hh / k <= dispH) || 50;
    const escala = k === 1 ? '1:1' : '1:' + fmt(k, 1);""",
    """    // a 1:1 si cabe; si no, ajustado al hueco (con un pequeño margen): la escala no es exacta y en el cajetín pone «ajustada»
    const k = W <= dispW && Hh <= dispH ? 1 : Math.max(W / (dispW - 4), Hh / (dispH - 4));
    const ajustada = k > 1, escala = ajustada ? 'ajustada (las cotas mandan)' : '1:1';""")
rep("""Escala</span><span class="v">${escala}</span>""", """Escala</span><span class="v"${ajustada ? ' style="font-size:8.5pt"' : ''}>${escala}</span>""")
rep("""    snack(`Hoja de ejercicio a escala ${escala}` + (k > 1 ? ' (la pieza no cabía a 1:1)' : ''));""",
    """    snack(ajustada ? 'Hoja de ejercicio: la pieza no cabía a 1:1 y el plano se ajusta al papel (escala ajustada: las cotas mandan)' : 'Hoja de ejercicio a escala 1:1');""")
rep("(1:1 si cabe; si no, a escala normalizada)", "(1:1 si cabe; si no, ajustado al papel)")
rep("a 1:1 si cabe en A4; si no, a la escala normalizada que quepa, indicada en el cajetín.",
    "a 1:1 si cabe en A4; si no, ajustado al papel, y en el cajetín pone «Escala: ajustada (las cotas mandan)».")
# ajustada: el SVG ocupa todo el hueco del dibujo (el navegador lo encaja sin deformarlo, gracias a su viewBox)
rep("""    svg = svg.replace(/width="[\\d.]+mm"/, `width="${(W / k).toFixed(3)}mm"`).replace(/height="[\\d.]+mm"/, `height="${(Hh / k).toFixed(3)}mm"`);""",
    """    svg = ajustada ? svg.replace(/width="[\\d.]+mm"/, 'width="100%"').replace(/height="[\\d.]+mm"/, 'height="100%"')
                   : svg.replace(/width="[\\d.]+mm"/, `width="${(W / k).toFixed(3)}mm"`).replace(/height="[\\d.]+mm"/, `height="${(Hh / k).toFixed(3)}mm"`);""")
rep("  .dib { flex: 1; display: flex; align-items: center; justify-content: center; overflow: hidden; }",
    "  .dib { flex: 1; min-height: 0; display: flex; align-items: center; justify-content: center; overflow: hidden; }\n  .dib svg[width=\"100%\"] { display: block; padding: 1mm; }")
open(P, 'w', encoding='utf-8').write(s)
print('Calcador: hoja de ejercicio sin tabla de coordenadas, con el plano en color y ajustado al papel si no cabe a 1:1')
