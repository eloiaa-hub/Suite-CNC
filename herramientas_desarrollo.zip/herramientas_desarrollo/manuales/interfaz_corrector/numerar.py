"""Pone los números de las zonas sobre capturas/pantalla.png → pantalla_num.png (captura a 1,5 ×)."""
import os
from PIL import Image, ImageDraw, ImageFont
C = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'capturas') + '/'
im = Image.open(C + 'pantalla.png').convert('RGB'); d = ImageDraw.Draw(im); k = 1.5
f = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf', int(20 * k))
for n, x, y in [(1, 600, 34), (2, 945, 70), (3, 290, 175), (4, 660, 140), (5, 940, 815), (6, 1410, 163), (7, 1370, 515)]:
    x, y, r = x * k, y * k, 16 * k; d.ellipse((x - r, y - r, x + r, y + r), fill=(214, 104, 30), outline='white', width=int(3 * k))
    w = d.textlength(str(n), font=f); d.text((x - w / 2, y - 12 * k), str(n), font=f, fill='white')
im.save(C + 'pantalla_num.png')
