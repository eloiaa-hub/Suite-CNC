// ── Corrección masiva con las variantes de un examen (🎲 Variantes…) ──
// Cada programa se corrige contra todas las variantes elegidas y se queda la que mejor encaja. Si se sabe la variante que
// le tocaba (por el nombre del archivo, la carpeta del alumno o un comentario del programa: «12B», «variante B»), se corrige
// con esa y se avisa si el programa encaja mejor con otra; si dos encajan casi igual, se avisa de que no está claro.
masiva.variantes = [];
const copiaJ = v => JSON.parse(JSON.stringify(v));
const CFG_VAR = () => ({ cfgCotas, cfgHoja, cfgMec, cfgCorr, cfgCotaMan, cfgAjuste, cfgExport, cfgTexto });
function estadoGuardado() {
    const cfg = {}; Object.entries(CFG_VAR()).forEach(([k, o]) => { cfg[k] = copiaJ(o); });
    return { contornos, cotasManuales: copiaJ(cotasManuales), cotasAjuste: copiaJ(cotasAjuste), aux: copiaJ(aux), fondo, cfg, nombre: document.getElementById('projectName').value,
             undo: undoStack.slice(), redo: redoStack.slice(), sel, selSet: new Set(selSet), view: { ...view } };
}
function restaurarEstado(a) {
    contornos = a.contornos; cotasManuales = a.cotasManuales; cotasAjuste = a.cotasAjuste; aux = a.aux; fondo = a.fondo;
    Object.entries(CFG_VAR()).forEach(([k, o]) => { Object.keys(o).forEach(x => delete o[x]); Object.assign(o, copiaJ(a.cfg[k])); });
    try { sincronizarControlesCotas(); } catch (e) {}
    document.getElementById('projectName').value = a.nombre; undoStack = a.undo; redoStack = a.redo;
    sel = a.sel; selSet = a.selSet; Object.assign(view, a.view); memoTipos = null;
}
// Abre la variante (sin el aviso del panel del Tutor), con lo que se pide en la corrección masiva (la del ejercicio abierto)
function cargarVariante(v, base) {
    const abrir = typeof _tuAbrirJSONDatos === 'function' ? _tuAbrirJSONDatos : abrirJSONDatos;
    abrir(copiaJ(v.datos));
    const h = base.cfg.cfgHoja, c = base.cfg.cfgCorr;
    Object.assign(cfgHoja, { prog: h.prog, reqEntrada: h.reqEntrada, reqSentido: h.reqSentido });
    cfgCorr.tol = c.tol; if (c.nota) cfgCorr.nota = copiaJ(c.nota); else delete cfgCorr.nota;
    memoTipos = null;
}
function conVariante(v, fn) {
    const a = estadoGuardado(), sn = window.snack; window.snack = () => {};
    try { cargarVariante(v, a); return fn(); }
    finally { window.snack = sn; restaurarEstado(a); }
}
// La variante que le tocaba, si lo dice el nombre del archivo, la carpeta o el principio del programa
function varianteAsignada(it) {
    const esc = t => String(t).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const buscar = txt => masiva.variantes.filter(v => new RegExp(`(^|[^0-9A-Za-z])${esc(v.etq)}([^0-9A-Za-z]|$)`, 'i').test(txt) || (v.letra && new RegExp(`[Vv]ariante\\s*${v.letra.toUpperCase()}([^A-Za-z]|$)`).test(txt)));
    // primero el nombre del archivo y la carpeta; si no lo dicen, el principio del programa
    for (const txt of [`${it.archivo || ''} ${it.alumno || ''}`, String(it.texto || '').slice(0, 400)]) { const h = buscar(txt); if (h.length === 1) return h[0]; if (h.length > 1) return null; }
    return null;
}
const puntuacion = val => (val.veredicto === 'error' ? -100 : 0) + val.nota * 10 + val.cob * 5 - (val.errGeo || 0) * 0.5 - (val.faltas || 0) * 0.5;
function corregirConVariantes(items) {
    if (!items.length || !masiva.variantes.length) return;
    const res = new Map(items.map(it => [it, []]));
    masiva.variantes.forEach(v => conVariante(v, () => items.forEach(it => {
        let r; try { r = corregirPrograma(it.texto); } catch (e) { r = { error: 'No se ha podido interpretar: ' + e.message }; }
        res.get(it).push({ v, r, val: valorarCorreccion(r) });
    })));
    items.forEach(it => {
        const c = res.get(it).sort((a, b) => puntuacion(b.val) - puntuacion(a.val)), mejor = c[0], seg = c[1];
        const asig = varianteAsignada(it), usada = asig ? c.find(x => x.v === asig) : mejor;
        it.r = usada.r; it.v = usada.val; it.variante = usada.v.etq; it.varAsignada = asig ? asig.etq : '';
        const nota = x => String(Math.round(x.val.nota * 10) / 10).replace('.', ',');
        it.varTxt = `Corregido con la variante ${usada.v.etq}${asig ? ' (la que le tocaba)' : ' (la que mejor encaja)'} · ` + c.map(x => `${x.v.etq}: ${nota(x)}`).join(' · ');
        it.varAviso = '';
        const parecidas = seg && puntuacion(seg.val) >= puntuacion(mejor.val) - 3 && mejor.val.veredicto !== 'vacio' && mejor.val.veredicto !== 'error';
        if (asig && mejor.v !== asig && puntuacion(mejor.val) > puntuacion(usada.val) + 3) it.varAviso = `Su programa encaja con la variante ${mejor.v.etq} (nota ${nota(mejor)}), pero le tocaba la ${asig.etq}`;
        else if (!asig && parecidas) it.varAviso = `No está claro qué variante ha hecho: ${mejor.v.etq} y ${seg.v.etq} encajan casi igual`;
    });
}
// corregirAlumno, con variantes: se juntan y se corrigen todos de una vez (una carga de cada variante)
const colaVariantes = new Set(); let tempVariantes = null;
const _corregirAlumnoBase = corregirAlumno;
corregirAlumno = function (it) {
    if (!masiva.variantes.length) { delete it.variante; delete it.varAviso; delete it.varTxt; delete it.varAsignada; return _corregirAlumnoBase(it); }
    it.r = null; it.v = { veredicto: 'pendiente', nota: 0, cob: 0, errGeo: 0, faltas: 0, incumple: 0, seguridad: 0, avisos: 0, desglose: { geo: 0, pedido: 0, seg: 0 } };
    colaVariantes.add(it);
    if (!tempVariantes) tempVariantes = setTimeout(() => { tempVariantes = null; const l = [...colaVariantes]; colaVariantes.clear(); corregirConVariantes(l); corr = null; pintarMasiva(); }, 0);
};
// ver la corrección de un alumno: se abre su variante; al volver, el ejercicio de antes
const _verAlumnoBase = verAlumno, _volverAMasivaBase = volverAMasiva;
verAlumno = function (k) {
    const it = masiva.lista[k], v = it && it.variante && masiva.variantes.find(x => x.etq === it.variante);
    if (v) { if (!masiva.baseVariantes) masiva.baseVariantes = estadoGuardado(); cargarVariante(v, masiva.baseVariantes); refrescar(); }
    _verAlumnoBase(k);
    if (v) setTimeout(() => snack(`Variante ${v.etq} abierta para ver su corrección${it.varAviso ? ' · ⚠️ ' + it.varAviso : ''}`), 450);
};
volverAMasiva = function () {
    // primero el ejercicio de antes; después, si ha cambiado el texto, se recorrige (con todas las variantes)
    if (masiva.baseVariantes) { const base = masiva.baseVariantes; masiva.baseVariantes = null; restaurarEstado(base); refrescar(); }
    return _volverAMasivaBase();
};
const _abrirMasivaBase = abrirMasiva;
abrirMasiva = function () {
    if (masiva.baseVariantes) { const base = masiva.baseVariantes; masiva.baseVariantes = null; restaurarEstado(base); refrescar(); masiva.viendo = null; const b = document.getElementById('crVolver'); if (b) b.style.display = 'none'; }
    return _abrirMasivaBase.apply(this, arguments);
};
const _pintarEjercicioMasivaBase = pintarEjercicioMasiva;
pintarEjercicioMasiva = function () {
    _pintarEjercicioMasivaBase();
    const d = document.getElementById('mvEjDat'), b = document.getElementById('mvBtnVar');
    if (b) { b.classList.toggle('activo', masiva.variantes.length > 0); b.textContent = masiva.variantes.length ? `🎲 Variantes (${masiva.variantes.length})…` : '🎲 Variantes…'; }
    if (d && masiva.variantes.length) d.textContent += ` · 🎲 con las variantes ${masiva.variantes.map(v => v.etq).join(', ')}`;
};
// los informes impresos: el dibujo de cada alumno, con su variante
const _imprimirInformesBase = imprimirInformes;
imprimirInformes = function (ks) {
    if (!masiva.variantes.length) return _imprimirInformesBase(ks);
    const mapa = new Map(), sel = ks || masiva.lista.map((_, k) => k);
    masiva.variantes.forEach(v => { const de = sel.map(k => masiva.lista[k]).filter(it => it && it.variante === v.etq && it.r && it.r.segs); if (de.length) conVariante(v, () => de.forEach(it => mapa.set(it.r, svgCorreccion(it.r)))); });
    const orig = svgCorreccion; svgCorreccion = r => mapa.has(r) ? mapa.get(r) : orig(r);
    try { return _imprimirInformesBase(ks); } finally { svgCorreccion = orig; }
};
// ── La ventana para elegir las variantes ──
async function elegirVariantesMasiva() {
    try { await bibCargar(); } catch (e) {}
    const lista = (bib.lista || []).filter(e => /^Variantes\//i.test(e.ruta || ''));
    const carpetas = new Map(); lista.forEach(e => { const f = e.ruta.split('/').slice(0, -1).join('/') || 'Variantes'; if (!carpetas.has(f)) carpetas.set(f, []); carpetas.get(f).push(e); });
    const etiqueta = e => { const l = (/ - ([A-Z])\.json$/i.exec(e.archivo || '') || [])[1] || ''; const n = e.ficha && e.ficha.num ? String(e.ficha.num) : '';
        return { etq: n ? (/[A-Z]$/i.test(n) ? n : n + l) : (l || (e.ficha && e.ficha.titulo) || e.archivo), letra: l || (/([A-Z])$/i.exec(n) || [])[1] || '' }; };
    const ya = new Set(masiva.variantes.map(v => v.id)), nom = (cfgHoja.titulo || nombreProyecto() || '').toLowerCase(), num = String(cfgHoja.num || '').toLowerCase();
    const pre = f => ya.size ? null : (f.toLowerCase().includes(nom) && nom) || (num && carpetas.get(f).some(e => String(e.ficha.num || '').toLowerCase().startsWith(num)));
    const esc = t => String(t).replace(/&/g, '&amp;').replace(/</g, '&lt;');
    let ov = document.getElementById('modalVarMasiva');
    if (!ov) { ov = document.createElement('div'); ov.className = 'modal-overlay'; ov.id = 'modalVarMasiva'; ov.onclick = e => { if (e.target === ov) ov.classList.remove('visible'); }; document.body.appendChild(ov); }
    ov.innerHTML = `<div class="help-modal" style="width:min(620px,100%)"><div class="help-header"><h2>🎲 Corregir con las variantes del examen</h2><button class="help-close" onclick="document.getElementById('modalVarMasiva').classList.remove('visible')">✕</button></div>
        <div class="help-content"><p class="ctx-nota" style="margin-top:0">Cada programa se corrige con todas las variantes marcadas y se queda la que mejor encaja. Si el nombre del archivo, la carpeta del alumno o el principio del programa dicen qué variante le tocaba («12B», «variante B»), se corrige con esa y se avisa si encaja mejor con otra.</p>
        ${carpetas.size ? [...carpetas].map(([f, es]) => `<div class="var-carpeta"><label class="var-tit"><input type="checkbox" data-carpeta="${esc(f)}"> <b>${esc(f.replace(/^Variantes\/?/i, '') || 'Variantes')}</b></label>
            ${es.sort((a, b) => etiqueta(a).etq.localeCompare(etiqueta(b).etq, 'es', { numeric: true })).map(e => `<label class="var-item"><input type="checkbox" data-id="${esc(e.id)}" ${ya.has(e.id) || pre(f) ? 'checked' : ''}> ${esc(etiqueta(e).etq)} · ${esc(e.ficha.titulo || e.archivo)}</label>`).join('')}</div>`).join('')
          : '<p>No hay variantes en la biblioteca. Hazlas con <b>🎲 Variantes…</b> (pestaña 🧩 Ejercicios) y guárdalas en la biblioteca, o añade aquí sus archivos JSON.</p>'}
        <input type="file" id="varMasivaJSON" accept=".json" multiple style="display:none">
        <div class="btn-row" style="margin-top:12px"><button class="btn-action sec" id="varMasivaArch">📂 Añadir JSON de variantes…</button><button class="btn-action sec" id="varMasivaNo">Sin variantes</button><button class="btn-action" id="varMasivaSi">Corregir con las marcadas</button></div></div></div>`;
    ov.querySelectorAll('input[data-carpeta]').forEach(c => { const its = [...c.closest('.var-carpeta').querySelectorAll('input[data-id]')]; c.checked = its.length && its.every(x => x.checked); c.onchange = () => its.forEach(x => { x.checked = c.checked; }); });
    const aplicar = vs => { masiva.variantes = vs; ov.classList.remove('visible');
        if (vs.length && !hayPieza()) { try { abrirJSONDatos(copiaJ(vs[0].datos)); sincronizarRequisitosMasiva(); } catch (e) {} }   // sin ejercicio abierto: se abre la primera
        pintarEjercicioMasiva(); recorregirMasiva();
        snack(vs.length ? `Corrección con ${vs.length} variantes: ${vs.map(v => v.etq).join(', ')}` : 'Corrección sin variantes: con el ejercicio abierto'); };
    ov.querySelector('#varMasivaNo').onclick = () => aplicar([]);
    ov.querySelector('#varMasivaSi').onclick = () => { const ids = [...ov.querySelectorAll('input[data-id]:checked')].map(x => x.dataset.id);
        const vs = lista.filter(e => ids.includes(e.id)).map(e => ({ id: e.id, ...etiqueta(e), datos: e.datos })).concat(masiva.variantes.filter(v => v.deArchivo));
        if (vs.length === 1) { snack('Marca al menos dos variantes (con una sola, abre ese ejercicio)'); return; }
        aplicar(vs); };
    ov.querySelector('#varMasivaArch').onclick = () => ov.querySelector('#varMasivaJSON').click();
    ov.querySelector('#varMasivaJSON').onchange = async ev => { const fs = [...ev.target.files]; const nuevas = [];
        for (const f of fs) { try { const d = JSON.parse(await f.text()); if (!d || !d.calcador) continue; const fi = fichaDe(d), l = (/[ _-]([A-Z])\.json$/i.exec(f.name) || [])[1] || '';
            const n = fi.num ? String(fi.num) : ''; nuevas.push({ id: 'archivo:' + f.name, etq: n ? (/[A-Z]$/i.test(n) ? n : n + l) : (l || f.name.replace(/\.json$/i, '')), letra: l || (/([A-Z])$/i.exec(n) || [])[1] || '', datos: d, deArchivo: true }); } catch (e) {} }
        if (!nuevas.length) { snack('Esos archivos no son ejercicios del Calcador'); return; }
        masiva.variantes = masiva.variantes.filter(v => !v.deArchivo).concat(nuevas); snack(`${nuevas.length} variante(s) añadida(s) desde archivos: ${nuevas.map(v => v.etq).join(', ')}`); };
    ov.classList.add('visible');
}
