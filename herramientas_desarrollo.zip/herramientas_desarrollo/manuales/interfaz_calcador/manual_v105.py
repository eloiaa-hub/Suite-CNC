"""Manual del Calcador v105: la interfaz ordenada (botones de vista, deshacer en la barra de herramientas, Dibujo en
desplegables, 🖼 Fondo y ⬇ Exportar en la barra superior), «Seleccionar puntos» y «◠ Hacer arco». Cambia textos y capturas.
Uso: python3 manual_v105.py <manual_calcador.html>   (antes: node capt_calcador.js; python3 numerar.py; node capt_v105.js)"""
import sys, re, os, base64, io
from PIL import Image
P = sys.argv[1]; IMG = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'capturas')
s = open(P, encoding='utf-8').read()
assert 'Seleccionar puntos' not in s, 'El manual ya tiene los cambios de la v105'
def rep(a, b, cnt=1):
    global s
    n = s.count(a); assert n == cnt, f'{n} apariciones (se esperaban {cnt}) de: {a[:100]}'
    s = s.replace(a, b)
def webp(im, q=84):
    if isinstance(im, str): im = Image.open(os.path.join(IMG, im))
    if getattr(im, 'filename', '').endswith(('puntos_ventana.png', 'puntos_elegidos.png', 'hacer_arco.png')): im = im.crop((0, 0, im.width, min(im.height, 470)))
    b = io.BytesIO(); im.convert('RGB').save(b, 'WEBP', quality=q, method=6)
    return 'data:image/webp;base64,' + base64.b64encode(b.getvalue()).decode()
def cambiar_img(alt_inicio, im, alt_nuevo=None):
    global s
    m = re.search(r'<img src="data:image/[^"]+" alt="' + re.escape(alt_inicio), s); assert m, alt_inicio
    i = m.start(); j = s.index('"', i + 10); s = s[:i] + '<img src="' + webp(im) + s[j:]
    if alt_nuevo:
        k = s.index('alt="', i) + 5; e = s.index('"', k); s = s[:k] + alt_nuevo + s[e:]
# ── las capturas, de nuevo (la barra superior y la de herramientas han cambiado) ──
for alt, f in [('Las zonas de la pantalla del programa.', 'pantalla_num.png'), ('La lámina recién cargada, aún sin calibrar.', 'recien.png'),
               ('Calibración con la cota de 80 mm.', 'calibrar.png'), ('Dibujando el arco tangente;', 'arco.png'),
               ('La pestaña Fondo con una imagen cargada.', 'fondo.png'), ('El desplegable Imanes de la pestaña Dibujo.', 'imanes.png'),
               ('La pestaña ◯ Contornos:', 'contornos.png'), ('Una placa con dos cajeras', 'cajeras.png'), ('Texto seleccionado:', 'texto.png'),
               ('Antes: un rectángulo,', 'operaciones.png'), ('El resumen, en el desplegable Comprobar con la fresa.', 'comprobar.png'),
               ('El reproductor del panel derecho', 'reproductor.png'), ('La placa del tutorial en ⚙️ Mecanizar:', 'mecanizar.png')]:
    cambiar_img(alt, f)
cambiar_img('La pestaña Dibujo.', 'dibujo.png', 'La pestaña Dibujo: Imanes, Comprobar con la fresa, Cotas y marcas y Ajustar medidas, en desplegables.')
cambiar_img('El Calcador con los dos paneles ocultos', 'sin_paneles.png', 'El Calcador con los dos paneles ocultos: arriba a la derecha, ◧ ◨ y 👁 Rejilla, 🏷 Nombres y 📏 Cotas; al pie de la barra de herramientas, ↶ ↷ ⭘ ✓.')
an = Image.open(os.path.join(IMG, 'archivo.png')); ex = Image.open(os.path.join(IMG, 'exportar.png'))
comp = Image.new('RGB', (max(an.width, ex.width), an.height + 14 + ex.height), 'white'); comp.paste(an, (0, 0)); comp.paste(ex, (0, an.height + 14))
cambiar_img('Arriba, los botones de archivo de la barra superior;', comp, 'Arriba, los botones de la barra superior: Nuevo, Abrir, 🖼 Fondo, Guardar, ⬇ Exportar ▾ y Biblioteca; debajo, el menú ⬇ Exportar abierto, con DXF, SVG y sus opciones.')
# ── la pantalla ──
rep('los botones de archivo <span class="boton">🗋 Nuevo</span>, <span class="boton">📂 Abrir</span>, <span class="boton">💾 Guardar</span> y <span class="boton">🗂 Biblioteca</span>,',
    'los botones de archivo <span class="boton">🗋 Nuevo</span>, <span class="boton">📂 Abrir</span>, <span class="boton">🖼 Fondo</span> (el plano a calcar), <span class="boton">💾 Guardar</span>, <span class="boton">⬇ Exportar ▾</span> (DXF y SVG) y <span class="boton">🗂 Biblioteca</span>,')
rep('Editar, dibujo (línea, arcos, círculo, ranura),', 'Editar y Seleccionar puntos (la doble flecha), dibujo (línea, arcos, círculo, ranura),')
rep('y, abajo, las herramientas del fondo: calibrar, mover fondo, origen y medir.', 'las herramientas del fondo: calibrar, mover fondo, origen y medir; y, al pie, <span class="boton">↶</span> <span class="boton">↷</span> deshacer y rehacer, y <span class="boton">⭘</span> cerrar y <span class="boton">✓</span> terminar el contorno en curso, que se ven aunque ocultes el panel izquierdo.')
rep('en medio, <strong>Dibujo</strong> (con los desplegables Imanes y Comprobar con la fresa), <strong>Construcción</strong> y <strong>Formas</strong>; abajo, <strong>Fondo</strong> y <strong>Exportar</strong> (DXF y SVG).',
    'en medio, <strong>Dibujo</strong> (con los desplegables Imanes, Comprobar con la fresa, Cotas y marcas y Ajustar medidas), <strong>Construcción</strong> y <strong>Formas</strong>; abajo, <strong>Fondo</strong>, con los ajustes del plano a calcar.')
rep('<td><strong>Lienzo.</strong> El dibujo, sobre una rejilla milimetrada. El eje X crece hacia la derecha y el eje Y hacia arriba, como en la máquina.</td>',
    '<td><strong>Lienzo.</strong> El dibujo, sobre una rejilla milimetrada. El eje X crece hacia la derecha y el eje Y hacia arriba, como en la máquina. Arriba a la derecha, los botones de vista: ◧ ◨ ocultan los paneles y 👁 Rejilla, 🏷 Nombres y 📏 Cotas enseñan u ocultan la rejilla, los nombres de los puntos y las cotas automáticas.</td>')
# más sitio para dibujar
rep('<li><span class="boton">👁 Rejilla</span> oculta (o vuelve a mostrar) la <strong>rejilla</strong> del fondo. Solo cambia lo que se ve: el imán a la rejilla sigue con su propio botón, <span class="boton">▦ Rejilla</span>.</li>',
    '<li><span class="boton">👁 Rejilla</span> oculta (o vuelve a mostrar) la <strong>rejilla</strong> del fondo. Solo cambia lo que se ve: el imán a la rejilla sigue con su propio botón, <span class="boton">▦ Rejilla</span>.</li>\n<li><span class="boton">🏷 Nombres</span> enseña u oculta los <strong>nombres de los puntos</strong> (P1, P2… A1…), y <span class="boton">📏 Cotas</span>, las <strong>cotas automáticas</strong> (lo mismo que «Acotar automáticamente»). Se iluminan cuando lo suyo se ve.</li>')
rep('<p>La <strong>barra de herramientas</strong> de la izquierda se ve siempre.', '<p>La <strong>barra de herramientas</strong> de la izquierda se ve siempre, con <span class="boton">↶</span> <span class="boton">↷</span> <span class="boton">⭘</span> <span class="boton">✓</span> al pie.')
rep('Arriba a la derecha de la zona de dibujo hay tres botones para ver el dibujo más grande:', 'Arriba a la derecha de la zona de dibujo están los botones de vista:')
# fondo, exportar, deshacer
rep('<li>En la pestaña Fondo (abajo, en el panel izquierdo) pulsa <span class="boton">🖼 Cargar imagen, SVG o DXF</span> y elige la imagen de la lámina.</li>',
    '<li>Pulsa <span class="boton">🖼 Fondo</span>, en la barra superior (o <span class="boton">🖼 Cargar imagen, SVG o DXF</span>, en la pestaña Fondo, abajo en el panel izquierdo), y elige la imagen de la lámina. Al cargarla se abre la pestaña Fondo, con sus ajustes.</li>')
rep('<p>Están en la pestaña <strong>Exportar</strong>, abajo en el panel izquierdo; sus opciones, en su desplegable <strong>▸ Opciones de DXF y SVG</strong>.</p>',
    '<p>Están en el botón <span class="boton">⬇ Exportar ▾</span> de la barra superior: <span class="boton">⬇ DXF</span>, <span class="boton">⬇ SVG</span> y, debajo, el desplegable <strong>▸ Opciones de DXF y SVG</strong>.</p>')
rep('<td>Deshacer y rehacer. También con los botones de la pestaña Dibujo.</td>', '<td>Deshacer y rehacer. También con los botones ↶ ↷ del pie de la barra de herramientas.</td>')
rep('<p>La pestaña Dibujo tiene los botones <span class="boton">⭘ Cerrar</span> y <span class="boton">✓ Terminar</span> para el contorno en curso, y <span class="boton">↶ Deshacer</span> / <span class="boton">↷ Rehacer</span>.</p>',
    '<p>Al pie de la barra de herramientas están <span class="boton">⭘</span> Cerrar y <span class="boton">✓</span> Terminar, para el contorno en curso, y <span class="boton">↶</span> Deshacer / <span class="boton">↷</span> Rehacer.</p>')
rep('<p>En la pestaña Dibujo activa <strong>Acotar automáticamente</strong>.', '<p>En la pestaña Dibujo, desplegable <strong>Cotas y marcas</strong>, activa <strong>Acotar automáticamente</strong> (o pulsa <span class="boton">📏 Cotas</span>, arriba a la derecha del dibujo).')
rep('<p>En la pestaña Dibujo, <strong>Acotar automáticamente</strong> acota la pieza', '<p>En la pestaña Dibujo, desplegable <strong>Cotas y marcas</strong> (o con el botón <span class="boton">📏 Cotas</span>), <strong>Acotar automáticamente</strong> acota la pieza')
rep('En la pestaña Dibujo, <strong>Ajuste automático de medidas</strong> lo corrige solo', 'En la pestaña Dibujo, desplegable <strong>Ajustar medidas</strong>, <strong>Ajuste automático de medidas</strong> lo corrige solo')
# atajos
rep('<td><kbd>F7</kbd></td><td>Ocultar o mostrar el panel izquierdo</td><td><kbd>F8</kbd></td><td>Ocultar o mostrar el panel derecho</td>',
    '<td><kbd>F7</kbd></td><td>Ocultar o mostrar el panel izquierdo</td><td><kbd>F8</kbd></td><td>Ocultar o mostrar el panel derecho</td></tr><tr><td><kbd>I</kbd></td><td>Seleccionar puntos</td><td><kbd>A</kbd></td><td>Hacer un arco (con puntos elegidos)</td>')
# ── seleccionar puntos y hacer arco (capítulo Editar contornos) ──
SEC = f'''<h3>Seleccionar puntos</h3>
<p>La herramienta <strong>Seleccionar puntos</strong> es la doble flecha, junto a la de Editar (tecla <kbd>I</kbd>). Sirve para trabajar con muchos puntos a la vez; por ejemplo, para limpiar una silueta vectorizada.</p>
<ul>
<li><strong>Arrastra una ventana</strong>: se eligen todos los puntos que quedan dentro, que se marcan en naranja. Con <kbd>Mayús</kbd> se añaden más; un clic sobre un punto elige solo ese (con <kbd>Mayús</kbd>, lo añade o lo quita).</li>
<li><kbd>Supr</kbd> (o <kbd>Retroceso</kbd>) <strong>borra todos los puntos elegidos de una vez</strong>; un solo Ctrl+Z los recupera. El tramo que pierde un extremo queda recto; un contorno que se queda con menos de 2 puntos desaparece, y uno cerrado que se queda sin superficie pasa a abierto.</li>
<li><kbd>Esc</kbd> deja de elegirlos. Los textos de grabado y los contornos bloqueados 🔒 no se tocan.</li>
</ul>
<figure class="ancha"><img src="{webp('puntos_ventana.png')}" alt="La ventana de Seleccionar puntos sobre una esquina vectorizada"><figcaption>Al vectorizar, una esquina redondeada sale como muchos tramos rectos cortos. Con la doble flecha, una ventana elige todos sus puntos.</figcaption></figure>
<h3>Hacer un arco con los puntos elegidos</h3>
<p>Con 3 o más puntos seguidos de un mismo contorno elegidos, aparece junto a ellos el botón <span class="boton">◠ Hacer arco (A)</span> (o pulsa la tecla <kbd>A</kbd>). Cambia todos esos puntos y tramos rectos por <strong>un solo arco</strong>. Elige también el punto donde empieza la curva y el punto donde acaba.</p>
<ul>
<li><strong>Forma</strong>: <em>tangente a los tramos de al lado</em> empalma con la recta anterior y con la siguiente, que se recortan o alargan hasta el arco; es lo que suele pedir el plano (un radio que une dos rectas), y la que sale si se puede. <em>Por los puntos</em> deja el primer y el último punto donde están y pasa lo más cerca posible de los demás.</li>
<li><strong>Radio</strong>: el calculado, redondeado a 0,5 mm o el que escribas (el del plano, por ejemplo R15).</li>
</ul>
<p>La vista previa, en discontinua naranja, muestra el arco con su centro, y la ventana dice el radio, el centro y la <strong>desviación máxima</strong>: cuánto se aparta el arco de los puntos que tenías. Si los puntos no forman un arco (una esquina viva, una S), lo dice y no deja aplicarlo. <kbd>Intro</kbd> aplica, <kbd>Esc</kbd> cancela, y se puede deshacer.</p>
<div class="dos"><figure class="media"><img src="{webp('puntos_elegidos.png')}" alt="Los puntos elegidos, con el botón Hacer arco"><figcaption>Los puntos elegidos, en naranja, y el botón ◠ Hacer arco.</figcaption></figure>
<figure class="media"><img src="{webp('hacer_arco.png')}" alt="Vista previa del arco tangente"><figcaption>El arco tangente a las dos rectas: R15,09 con una desviación de 0,09 mm. Al aplicarlo, los 9 puntos quedan en un solo arco.</figcaption></figure></div>
'''
rep('<h3>El centro de un arco, por teclado</h3>', SEC + '<h3>El centro de un arco, por teclado</h3>')
s = s.replace('Calcador de contornos v104 · Por Eloi', 'Calcador de contornos v105 · Por Eloi')
open(P, 'w', encoding='utf-8').write(s)
print('manual del Calcador: v105')
