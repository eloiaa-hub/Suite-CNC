"""Construye «Programas resueltos» (programas_resueltos.html) con el estilo de los apuntes ISO.
Uso (desde esta carpeta): LANG=C.UTF-8 node exportar_planos.js && python3 construir.py
y el PDF, desde la carpeta de la suite: SOLO=programas_resueltos node herramientas_desarrollo/generar_pdf_manuales.js .
Los programas se calculan con gen.py desde las piezas del Calcador (piezas/*.json); también se guardan en programas/*.nc."""
import os, sys, subprocess
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from gen import pieza, tabla, programa, html_prog, plano, nc, comprobar
AQUI = os.path.dirname(os.path.abspath(__file__)); SUITE = os.path.abspath(os.path.join(AQUI, '..', '..', '..'))
os.makedirs(os.path.join(AQUI, 'programas'), exist_ok=True)

EJ = [  # (n.º, pieza, título, qué tiene de nuevo)
    (1, 'e104', 'Pieza en L', 'Solo rectas horizontales y verticales. Seis puntos.'),
    (2, 'e102', 'Pieza escalonada', 'Más puntos, y algunos tramos van hacia la izquierda o hacia abajo.'),
    (3, 'e108', 'Placa con un agujero rectangular', 'Dos trazados: el agujero (interior) y la placa (exterior).'),
    (4, 'e109', 'Pieza en cruz con un agujero', 'Un exterior con diez puntos y un agujero en medio.'),
    (5, 'e303', 'Placa con esquinas hacia dentro', 'Tres esquinas son arcos cóncavos: G2.'),
    (6, 'muesca_a', 'Pieza con muesca', 'Dos esquinas redondeadas (G3) y una muesca en medio del lado de arriba (G2).'),
    (7, 'e301', 'Ranura (colisa)', 'Dos rectas y dos semicírculos. El contorno va en sentido horario.'),
    (8, 'aro', 'Aro', 'Solo curvas: dos círculos completos, cada uno en dos semicírculos.'),
]
NOTAS = {
    1: 'Mira la tabla: cada punto cambia <strong>solo X o solo Y</strong>, porque todos los tramos son horizontales o verticales. Y el último tramo vuelve a P1: el contorno se cierra.',
    2: 'De P6 a P7 la fresa va hacia arriba y de P7 a P8 hacia la izquierda, pero en G90 da igual el sentido: siempre se escribe <strong>dónde está el punto</strong>, medido desde el cero pieza.',
    3: 'Primero el <strong>interior</strong>, después el exterior: si cortáramos antes el exterior, la pieza quedaría suelta mientras hacemos el agujero. Y entre un trazado y otro, la fresa <strong>sube a Z20</strong> (<code>G0 Z20</code>) antes de moverse: si no, iría arrastrándose por dentro de la madera.',
    4: 'El agujero no toca el exterior. Para pasar de A1 a P1, la fresa sube, va en rápido por encima de la pieza y vuelve a bajar.',
    5: 'Las tres esquinas curvas son <strong>cóncavas</strong> (hacia dentro de la pieza). Recorriendo el contorno en sentido antihorario, en ellas la fresa gira <strong>en sentido horario</strong>: G2. El centro de cada arco está en la esquina del rectángulo, por eso I o J valen el radio.',
    6: 'Las esquinas redondeadas giran como el contorno (antihorario): <strong>G3</strong>. La muesca gira al revés (horario): <strong>G2</strong>. El centro de la muesca está en la línea de arriba: I = −15 y J = 0.',
    7: 'El contorno va en sentido <strong>horario</strong> (empieza arriba a la izquierda y va hacia la derecha), así que los dos semicírculos son <strong>G2</strong>. Cada semicírculo tiene su centro: I = 0 y J = ±35 (la mitad del ancho).',
    8: 'Cada círculo se hace en <strong>dos semicírculos</strong>: de P1 a P2 y de P2 a P1, con I J desde el inicio de cada uno. Los dos círculos tienen el mismo centro (X50 Y50).',
}

def bloque(n, nom, tit, nuevo, modo, ancho='62%', pasadas=None, titulo_extra=''):
    o = pieza(nom)
    L = programa(o, modo, pasadas=pasadas, titulo=f'Ejercicio {n} {tit} {"G90" if modo == "g90" else "G91" if modo == "g91" else "mixta"}')
    comprobar(o, L)
    suf = {'g90': 'G90', 'g91': 'G91', 'mix': 'mixta'}[modo] + ('_pasadas' if pasadas else '')
    open(os.path.join(AQUI, 'programas', f'ejercicio{n}_{suf}.nc'), 'w', encoding='utf-8').write(nc(L))
    nota = NOTAS.get(n, '') if modo == 'g90' else ''
    return (f'<h3>Ejercicio {n}{titulo_extra} · {tit}</h3>\n<p class="nuevo">{nuevo}</p>\n'
            f'<figure class="dib">{plano(nom, o, ancho)}<figcaption>El plano, con los puntos que usa el programa. E: el punto de entrada y el sentido del recorrido.</figcaption></figure>\n'
            f'{tabla(o, "g91" if modo == "g91" else "g90")}\n'
            + (f'<div class="nota"><strong>💡 Fíjate.</strong> {nota}</div>\n' if nota else '')
            + html_prog(L))

def ej(n, modo, **kw):
    e = [x for x in EJ if x[0] == n][0]
    return bloque(e[0], e[1], e[2], e[3], modo, **kw)

CSS = '''<style>
table.puntos { font-size: 9pt; margin: 2mm 0 3mm; page-break-inside: avoid; }
table.puntos td, table.puntos th { padding: 0.9mm 2mm !important; text-align: center; }
table.puntos tr.grupo td { background: #eef3f8; color: #005A9C; font-weight: 700; text-align: left; }
table.puntos tr.cierre td { color: #5b6878; }
pre.prog.resuelto { font-size: 8.3pt; line-height: 1.42; }
pre.prog .c.sep { color: #005A9C; font-weight: 700; }
pre.prog .o { color: #c0392b; font-weight: 700; }
p.nuevo { color: #5b6878; font-style: italic; margin-top: 0; }
h3 { margin-top: 7mm; }
.cuenta { font-family: Consolas, 'DejaVu Sans Mono', monospace; background: #fdf3ec; border: 1px solid #f3d6c2; border-radius: 5px; padding: 1.8mm 3mm; margin: 1.5mm 0; display: block; }
table.letras td:first-child { font-family: Consolas, 'DejaVu Sans Mono', monospace; font-weight: 700; color: #005A9C; width: 14mm; text-align: center; }
</style>'''

P = []
P.append(CSS)
P.append('''<div class="portada"><div class="sup">Suite CNC · Apuntes para el alumnado</div><h1>Programas resueltos</h1><h2>Paso a paso: las letras de una línea, las coordenadas absolutas (G90), las rectas, los trazados exteriores e interiores, los arcos G2 y G3, los círculos, las incrementales (G91), la programación mixta y las pasadas de profundidad</h2>
<figure class="dib">''' + plano('muesca_a', pieza('muesca_a'), '86%') + '''</figure><div class="pie">Programas resueltos · Suite CNC 2026.10 · © 2026 Eloi A.A.<br>Apuntes publicados con licencia CC BY-SA 4.0. Las piezas son de la biblioteca de inicio del Calcador.</div></div>
<div class="indice"><h2>Contenido</h2><ol><li>Las letras de una línea</li><li>Cómo es un programa</li><li>Coordenadas absolutas: G90</li><li>Rectas</li><li>Varios trazados: exterior e interior</li><li>Arcos: G2 y G3</li><li>Círculos y piezas de curvas</li><li>Coordenadas incrementales: G91</li><li>Los mismos ejercicios, en G91</li><li>Programación mixta: G90 y G91</li><li>Varias pasadas de profundidad</li></ol></div>''')

P.append('''<section><h2 class="cap"><span>1</span>Las letras de una línea</h2>
<p>Un programa es una lista de líneas. Cada línea es una orden para la máquina, y está hecha de <strong>palabras</strong>: una letra y un número. La letra dice qué es y el número, cuánto.</p>
<pre class="prog"><span class="g">G1</span> X120 Y40 <span class="k">F1000</span>        <span class="c">; recta hasta X120 Y40, a 1000 mm/min</span></pre>
<table class="tabla letras">
<tr><th>Letra</th><th>Qué es</th><th>Ejemplo</th></tr>
<tr><td>G</td><td>El tipo de movimiento o de forma de trabajar: G0 rápido, G1 recta, G2 y G3 arcos, G90 y G91 absolutas e incrementales, G71 milímetros…</td><td><code>G1</code></td></tr>
<tr><td>X Y</td><td>El punto en el plano de la pieza, en milímetros.</td><td><code>X120 Y40</code></td></tr>
<tr><td>Z</td><td>La altura: Z0 es la cara de arriba de la madera, Z negativa es dentro y Z positiva, en el aire.</td><td><code>Z-3</code>, <code>Z20</code></td></tr>
<tr><td>I J</td><td>El centro de un arco (capítulo 6).</td><td><code>I-15 J0</code></td></tr>
<tr><td>F</td><td>El avance: la velocidad cortando, en mm/min.</td><td><code>F1000</code></td></tr>
<tr><td>S</td><td>Las revoluciones del husillo (rpm).</td><td><code>S12000</code></td></tr>
<tr><td>T</td><td>La herramienta.</td><td><code>T101</code></td></tr>
<tr><td>M</td><td>Funciones auxiliares: arrancar el husillo (M03), pararlo (M05), cambiar de herramienta (M06), terminar (M30).</td><td><code>M03</code></td></tr>
</table>
<ul>
<li>Las letras van en un orden fijo: <strong>N G X Y Z I J F S T M</strong>.</li>
<li>Lo que va después de un <code>;</code> es un <strong>comentario</strong>: la máquina no lo lee. En estos apuntes, cada línea lleva su comentario explicando qué hace.</li>
<li>Casi todo se queda activo hasta que se cambia: si escribes <code>F1000</code> una vez, las líneas siguientes también van a 1000 mm/min.</li>
</ul>
</section>''')

P.append('''<section><h2 class="cap"><span>2</span>Cómo es un programa</h2>
<p>Todos los programas de estos apuntes tienen la misma forma:</p>
<pre class="prog"><span class="g">G71 G90</span>                  <span class="c">; 1. cabecera: milímetros y absolutas</span>
<span class="m">T101 M06</span>                 <span class="c">;    la fresa</span>
S12000 <span class="m">M03</span>               <span class="c">;    arranca el husillo</span>
<span class="g">G0</span> Z20                   <span class="c">;    sube a la altura de seguridad</span>
<span class="g">G0</span> X… Y…                 <span class="c">; 2. por cada trazado: en rápido hasta encima del primer punto</span>
<span class="g">G1</span> Z-3 <span class="k">F150</span>              <span class="c">;    baja despacio a la profundidad</span>
<span class="g">G1</span> X… Y… <span class="k">F1000</span>           <span class="c">;    recorre el trazado, punto a punto…</span>
<span class="g">G0</span> Z20                   <span class="c">;    y sube</span>
<span class="m">M05</span>                      <span class="c">; 3. final: para el husillo</span>
<span class="m">M30</span>                      <span class="c">;    y termina</span></pre>
<ul>
<li><strong>G0</strong> es el movimiento rápido: solo por el aire. <strong>G1</strong> es la recta cortando, al avance F.</li>
<li>Se baja despacio (<code>F150</code>) y se corta más deprisa (<code>F1000</code>).</li>
<li>Programamos el <strong>contorno de la pieza</strong>, sin compensación del radio de la fresa: es lo primero que hay que saber hacer. La compensación (G41 y G42) está en los apuntes de los códigos ISO.</li>
<li>Todos los ejercicios se cortan a <strong>3 mm</strong> de profundidad, en una pasada. Las pasadas de profundidad están en el capítulo 11.</li>
</ul>
</section>''')

P.append('''<section><h2 class="cap"><span>3</span>Coordenadas absolutas: G90</h2>
<p>Con <strong>G90</strong> (coordenadas absolutas), cada punto se escribe <strong>midiendo desde el cero pieza</strong>, el símbolo del círculo con dos cuartos negros del plano. No importa de dónde venga la fresa: <code>X120 Y40</code> es siempre el mismo sitio, 120 mm a la derecha del cero y 40 mm por encima.</p>
<ul>
<li>X crece hacia la <strong>derecha</strong> e Y hacia <strong>arriba</strong>.</li>
<li>Para sacar la coordenada de un punto del plano, <strong>suma las cotas</strong> desde el cero hasta el punto.</li>
<li>Antes de escribir el programa, haz la <strong>tabla de puntos</strong>: numera los puntos en el orden en que los va a recorrer la fresa y escribe al lado su X y su Y. El programa sale casi solo de la tabla.</li>
</ul>
<div class="nota"><strong>💡 Cómo se leen los ejercicios.</strong> Cada ejercicio tiene el plano (con los puntos numerados), la tabla de puntos y el programa, con un comentario en cada línea. Intenta hacer tú la tabla y el programa antes de mirar la solución, y compruébalo en el Simulador.</div>
</section>''')

P.append('<section><h2 class="cap"><span>4</span>Rectas</h2>\n<p>Los primeros ejercicios solo tienen rectas (<code>G1</code>). Cada línea del programa lleva la fresa del punto en el que está al siguiente de la tabla.</p>\n' + ej(1, 'g90') + ej(2, 'g90') + '</section>')

P.append('<section><h2 class="cap"><span>5</span>Varios trazados: exterior e interior</h2>\n<p>Muchas piezas tienen más de un trazado: el contorno de fuera (<strong>exterior</strong>) y uno o varios agujeros (<strong>interiores</strong>), o dos piezas una al lado de otra. Cada trazado se hace igual que antes, pero entre uno y otro hay que <strong>subir a la altura de seguridad</strong> (<code>G0 Z20</code>) antes de moverse en rápido, y volver a bajar en el siguiente.</p>\n<ul><li><strong>Primero los interiores, después el exterior</strong>: así la pieza sigue sujeta mientras se hacen los agujeros.</li><li>Los puntos de cada trazado tienen su propia letra: A1, A2… el agujero; P1, P2… el exterior.</li></ul>\n' + ej(3, 'g90') + ej(4, 'g90') + '</section>')

P.append('''<section><h2 class="cap"><span>6</span>Arcos: G2 y G3</h2>
<figure class="dib">{{svg:g2g3}}<figcaption>Mirando la pieza desde arriba: G2 gira como las agujas del reloj y G3 al revés.</figcaption></figure>
<ul>
<li><strong>G2</strong>: arco en sentido <strong>horario</strong>. <strong>G3</strong>: arco en sentido <strong>antihorario</strong>.</li>
<li>Como en G1, se escribe el <strong>punto final</strong> del arco (X Y). El punto de inicio es donde está la fresa.</li>
<li>Además, hay que decir dónde está el <strong>centro</strong> con <strong>I y J</strong>: lo que hay que avanzar <strong>desde el punto de inicio del arco hasta su centro</strong>, I en X y J en Y, con su signo.</li>
</ul>
<figure class="dib">{{svg:ij}}<figcaption>I y J: del inicio del arco a su centro.</figcaption></figure>
<span class="cuenta">I = X del centro − X del inicio          J = Y del centro − Y del inicio</span>
<div class="nota atencion"><strong>⚠️ I y J siempre desde el inicio del arco.</strong> También en G90. Es el error más frecuente con los arcos.</div>
<p>En la tabla de puntos, al lado de cada punto al que se llega con un arco, apunta el centro, I y J.</p>
''' + ej(5, 'g90') + ej(6, 'g90') + '</section>')

P.append('''<section><h2 class="cap"><span>7</span>Círculos y piezas de curvas</h2>
<p>Un <strong>círculo completo</strong> empieza y acaba en el mismo punto. Algunos controles lo admiten en una sola línea con I y J, pero en clase lo hacemos siempre en <strong>dos semicírculos</strong>: funciona en todas las máquinas y no depende de que el final coincida exactamente con el inicio.</p>
<ul>
<li>Elige dos puntos opuestos del círculo, por ejemplo el de la derecha y el de la izquierda del centro.</li>
<li>Primer semicírculo: del primero al segundo. Segundo semicírculo: del segundo al primero.</li>
<li>Cada semicírculo lleva su I J, medido desde <strong>su</strong> punto de inicio: si en el primero I = −20, en el segundo I = 20.</li>
</ul>
''' + ej(7, 'g90') + ej(8, 'g90') + '</section>')

P.append('''<section><h2 class="cap"><span>8</span>Coordenadas incrementales: G91</h2>
<p>Con <strong>G91</strong> (coordenadas incrementales), cada punto se escribe <strong>midiendo desde el punto anterior</strong>, es decir, desde donde está la fresa: cuánto se mueve en X y cuánto en Y.</p>
<span class="cuenta">X en G91 = X del punto − X del anterior   (ΔX)          Y en G91 = Y del punto − Y del anterior   (ΔY)</span>
<ul>
<li>El <strong>signo</strong> dice hacia dónde: X positivo a la derecha, X negativo a la izquierda, Y positivo hacia arriba, Y negativo hacia abajo.</li>
<li>Un tramo horizontal tiene ΔY = 0; uno vertical, ΔX = 0.</li>
<li><strong>Comprobación</strong>: en un trazado cerrado, los ΔX suman 0 y los ΔY también (vuelves al punto de partida).</li>
<li><strong>I y J no cambian</strong>: también en G90 se miden desde el inicio del arco.</li>
<li>El <strong>primer punto</strong> de la pieza lo damos en G90, desde el cero pieza: así sabemos seguro dónde empieza. Después, <code>G91</code> y el recorrido.</li>
<li>La <strong>Z la escribimos siempre en G90</strong> (<code>G90 G1 Z-3</code>, <code>G90 G0 Z20</code>). En el capítulo 11 se ve por qué.</li>
</ul>
<div class="nota"><strong>💡 G90 o G91 en el plano.</strong> Si el plano está acotado desde el cero (cotas que salen todas de la misma esquina), es más cómodo G90. Si está acotado en cadena (cada cota sigue a la anterior), G91: las cotas ya son los ΔX y ΔY.</div>
</section>''')

g91 = ''.join(ej(n, 'g91', ancho='50%', titulo_extra=' en G91') for n in range(1, 9))
P.append('<section><h2 class="cap"><span>9</span>Los mismos ejercicios, en G91</h2>\n<p>Los ocho ejercicios otra vez, ahora en incrementales. Compara cada programa con el de G90: los puntos son los mismos; lo que cambia es cómo se escriben. En la tabla, ΔX y ΔY son lo que va en el programa.</p>\n' + g91 + '</section>')

P.append('''<section><h2 class="cap"><span>10</span>Programación mixta: G90 y G91</h2>
<p>G90 y G91 se pueden mezclar en el mismo programa: se cambia con <code>G90</code> o <code>G91</code> en cualquier línea, y vale hasta el siguiente cambio. Cada uno tiene sus ventajas:</p>
<table class="tabla">
<tr><th></th><th>G90 (absolutas)</th><th>G91 (incrementales)</th></tr>
<tr><td><strong>Conviene cuando…</strong></td><td>el plano está acotado desde el cero pieza; para ir a un punto conocido (entrar en un trazado, volver al cero)</td><td>el plano está acotado en cadena; para formas que se repiten (la misma forma en otro sitio se escribe igual)</td></tr>
<tr><td><strong>Ventaja</strong></td><td>un error en una línea no se arrastra a las siguientes</td><td>los movimientos son las cotas del plano, sin sumar</td></tr>
<tr><td><strong>Cuidado con…</strong></td><td>sumar bien las cotas desde el cero</td><td>un error se arrastra hasta el final; la Z (capítulo 11)</td></tr>
</table>
<p>Una forma cómoda de mezclarlos, la que usa el Calcador: <strong>G90 para entrar y para cerrar</strong> cada trazado (puntos fáciles de comprobar en el plano) y <strong>G91 para el recorrido</strong>. Así, aunque te equivoques en un tramo, el último vuelve exactamente al punto de partida… y lo verás en el Simulador, porque ese tramo saldrá torcido.</p>
''' + bloque(9, 'e302', 'Placa con una esquina redondeada', 'Rectas y un arco, en mixta: G90 para entrar y cerrar, G91 para el recorrido.', 'mix', titulo_extra=' (mixta)')
  + bloque(10, 'e306', 'Placa con una esquina cóncava y un agujero redondo', 'Un exterior con un arco y un agujero redondo (dos semicírculos), en mixta.', 'mix', titulo_extra=' (mixta)') + '</section>')

P.append('''<section><h2 class="cap"><span>11</span>Varias pasadas de profundidad</h2>
<p>Una fresa no puede cortar de una vez toda la profundidad que quieras: en madera, como mucho más o menos su diámetro por pasada (y menos si es pequeña). Si la pieza pide 6 mm con una fresa que corta 3 mm por pasada, se hace el mismo trazado <strong>dos veces</strong>: la primera a Z-3 y la segunda a Z-6.</p>
<ul>
<li>Al acabar la primera vuelta, la fresa está otra vez en el punto de inicio: <strong>baja a la siguiente profundidad</strong> (<code>G1 Z-6 F150</code>) y repite el recorrido.</li>
<li>No hace falta subir entre pasada y pasada: la fresa está dentro de su propio corte.</li>
<li>Al acabar la última pasada, sube a Z20.</li>
</ul>
''' + bloque(3, 'e108', 'Placa con un agujero rectangular, a 6 mm en dos pasadas', 'El ejercicio 3, a Z-6 en dos pasadas de 3 mm.', 'g90', pasadas=[-3, -6], titulo_extra=' (dos pasadas)') + '''
<h3>Cuidado con la Z en incrementales</h3>
<p>En G91 <strong>todo</strong> es incremental, también la Z. Y la Z es donde un error es más peligroso: si te pasas de profundidad, cortas el martiriño, la mesa o rompes la fresa.</p>
<table class="tabla">
<tr><th>Línea</th><th>Desde</th><th>Si es G90</th><th>Si es G91</th></tr>
<tr><td><code>G1 Z-3</code></td><td>Z20 (altura de seguridad)</td><td>Z-3 ✔</td><td>Z17: ¡sigue en el aire!</td></tr>
<tr><td><code>G1 Z-3</code></td><td>Z0 (tocando la madera)</td><td>Z-3 ✔</td><td>Z-3 ✔</td></tr>
<tr><td><code>G1 Z-6</code> (2.ª pasada)</td><td>Z-3</td><td>Z-6 ✔</td><td>Z-9: ¡3 mm de más!</td></tr>
<tr><td><code>G1 Z-3</code> (2.ª pasada)</td><td>Z-3</td><td>Z-3: no baja</td><td>Z-6 ✔</td></tr>
<tr><td><code>G0 Z20</code></td><td>Z-6</td><td>Z20 ✔</td><td>Z14 ✔ (pero no a la altura que crees)</td></tr>
</table>
<div class="nota atencion"><strong>⚠️ La regla.</strong> Escribe la <strong>Z siempre en G90</strong>, aunque el recorrido vaya en G91: <code>G90 G1 Z-6</code>, <code>G90 G0 Z20</code>. Así cada Z es una profundidad real, medida desde la cara de la madera, y no depende de dónde estaba la fresa. Es lo que hacen todos los programas de estos apuntes, y el Calcador.</div>
''' + bloque(3, 'e108', 'Placa con un agujero rectangular, a 6 mm en dos pasadas', 'El mismo programa con el recorrido en G91: las Z, en G90.', 'g91', ancho='50%', pasadas=[-3, -6], titulo_extra=' (dos pasadas, G91)') + '</section>')

fuente = os.path.join(AQUI, 'fuente_resueltos.html')
open(fuente, 'w', encoding='utf-8').write('\n'.join(P))
subprocess.run([sys.executable, os.path.join(AQUI, '..', 'construir_doc.py'), fuente, os.path.join(SUITE, 'programas_resueltos.html'), 'Programas resueltos — Apuntes para el alumnado'], check=True)
