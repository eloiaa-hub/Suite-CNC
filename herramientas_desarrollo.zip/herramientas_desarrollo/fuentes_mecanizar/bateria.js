// ── 🗃 Batería de corrección: una carpeta con los ejercicios (.json) y las entregas de Aules (.zip) ──
// Cada zip («<curso>-<tarea>-<número>.zip», el de «Descargar todas las entregas») se casa con su ejercicio por el nombre de la
// tarea («ISO GEO 01A» ↔ «ISO GEO 01A.json», «Tarea_ISO_09.zip» ↔ «ISO_09.json»); si la tarea es de un examen con variantes
// (ISO GEO 01 ↔ ISO GEO 01A, 01B…), se corrige con las variantes. La hoja de calificaciones de cada tarea
// («Calificaciones-…-<número>.csv»), si está en la carpeta, se rellena. Todo se corrige de una vez y se descarga en un zip.
let bat = { ejercicios: [], tareas: [], hojas: [] };
const normBat = t => String(t || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9ñ]+/g, ' ')
    .replace(/\b0+(\d)/g, '$1').replace(/\b(\d+)([a-h])\b/g, '$1 $2').trim();
const tokBat = t => normBat(t).split(' ').filter(Boolean);
// ¿Están los tokens de la clave seguidos dentro del nombre? (el mejor, el que llega más al final)
function encajeBat(nombre, clave) {
    if (!clave.length) return -1;
    for (let i = nombre.length - clave.length; i >= 0; i--) if (clave.every((t, k) => nombre[i + k] === t)) return i + clave.length;
    return -1;
}
function partesZipBat(nombre) {
    const base = nombre.replace(/^.*[\\/]/, '').replace(/\.zip$/i, ''), m = /^(.*?)-(\d{3,})$/.exec(base);
    const resto = m ? m[1] : base, cmid = m ? m[2] : '';
    // la tarea: lo que va después del último guion del curso, si lo hay (el curso puede llevar guiones; la tarea se casa en todo el nombre)
    const tarea = resto.replace(/^.*-(?=[^-]*$)/, '').trim() || resto;
    return { base, resto, cmid, tarea };
}
function claveEjercicio(e) { return tokBat(e.archivo.replace(/\.json$/i, '')); }
// Los nombres con los que se puede casar un ejercicio: el de su archivo y, si son bastante concretos, el número y el título de su ficha
function clavesEjercicio(e) {
    const out = [claveEjercicio(e)], f = e.ficha || {};
    const num = tokBat(f.num || ''); if (num.join('').length >= 3) out.push(num);
    const tit = tokBat(String(f.titulo || '').replace(/\(variante ([A-H])\)/i, '$1')); if (tit.length >= 2) out.push(tit);
    return out.filter((k, i) => k.length && out.findIndex(x => x.join(' ') === k.join(' ')) === i);
}
// Casar: primero el ejercicio cuyo nombre está entero en el nombre de la tarea (el más largo); si no, un grupo de variantes
function casarTarea(t) {
    const nom = tokBat(t.resto);
    let mejor = null;
    bat.ejercicios.forEach((e, i) => clavesEjercicio(e).forEach(k => { const p = encajeBat(nom, k); if (p >= 0 && (!mejor || k.length > mejor.len || (k.length === mejor.len && p > mejor.p))) mejor = { i, len: k.length, p }; }));
    // variantes: «…01» en la tarea, y ejercicios «…01A», «…01B» (o «… - A»)
    const grupos = new Map();
    bat.ejercicios.forEach((e, i) => clavesEjercicio(e).forEach(k => { if (k.length >= 2 && /^[a-h]$/.test(k[k.length - 1])) { const b = k.slice(0, -1).join(' '); if (!grupos.has(b)) grupos.set(b, new Map()); grupos.get(b).set(i, k[k.length - 1].toUpperCase()); } }));
    let grupo = null;
    grupos.forEach((m, b) => { if (m.size < 2) return; const k = b.split(' '), p = encajeBat(nom, k); if (p >= 0 && (!grupo || k.length > grupo.len)) grupo = { is: [...m.keys()].sort((x, y) => m.get(x).localeCompare(m.get(y))), letras: [...m.keys()].sort((x, y) => m.get(x).localeCompare(m.get(y))).map(i => m.get(i)), len: k.length, p }; });
    if (grupo && (!mejor || grupo.len >= mejor.len)) return { tipo: 'variantes', is: grupo.is, letras: grupo.letras };   // «…01» con «…01A», «…01B»: las variantes (aunque esté también «…01.json»)
    return mejor ? { tipo: 'uno', is: [mejor.i] } : null;
}
// Los ejercicios de un archivo de biblioteca (⬇ Exportar biblioteca) o de la biblioteca de este navegador
function anadirEjerciciosBib(lista, origen) {
    let n = 0;
    lista.forEach(e => { if (!e || !esObj(e.datos) || !esObj(e.datos.calcador)) return; const ruta = origen + '/' + (e.ruta || e.archivo);
        if (bat.ejercicios.some(x => x.ruta === ruta)) return; bat.ejercicios.push({ archivo: e.archivo || (e.ruta || 'ejercicio.json').split('/').pop(), ruta, datos: e.datos, ficha: fichaDe(e.datos), origen }); n++; });
    return n;
}
async function usarBibliotecaBat() {
    try { await bibCargar(); } catch (e) {}
    if (!bib.lista || !bib.lista.length) { snack('La biblioteca de este navegador está vacía'); return; }
    const n = anadirEjerciciosBib(bib.lista, '🗂 Biblioteca');
    bat.tareas.forEach(t => { if (!t.manual) t.casa = casarTarea(t); });
    pintarBateria(); snack(`${n} ejercicio(s) de la biblioteca${n < bib.lista.length ? ` (${bib.lista.length - n} ya estaban)` : ''}`);
}
function casarHoja(t) {
    const nom = tokBat(t.resto);
    return bat.hojas.find(h => t.cmid && h.cmid === t.cmid) || bat.hojas.find(h => { const k = tokBat(h.resto); return encajeBat(k, tokBat(t.tarea)) >= 0; }) || null;
}
async function leerArchivosBat(files) {
    const nuevos = { ej: 0, zip: 0, csv: 0 }, raros = [];
    for (const f of [...files]) {
        const ruta = f.webkitRelativePath || f.name;
        if (/\.json$/i.test(f.name)) {
            try { const d = JSON.parse(await f.text());
                if (esObj(d) && d.tipo === 'biblioteca-calcador' && Array.isArray(d.ejercicios)) { nuevos.ej += anadirEjerciciosBib(d.ejercicios, '📚 ' + f.name); nuevos.bib = (nuevos.bib || 0) + 1; continue; }
                if (!esObj(d) || !esObj(d.calcador)) { raros.push(f.name); continue; }
                if (!bat.ejercicios.some(e => e.ruta === ruta)) { bat.ejercicios.push({ archivo: f.name, ruta, datos: d, ficha: fichaDe(d) }); nuevos.ej++; } } catch (e) { raros.push(f.name); }
        } else if (/\.zip$/i.test(f.name)) {
            if (!bat.tareas.some(t => t.ruta === ruta)) { bat.tareas.push({ archivo: f.name, ruta, file: f, ...partesZipBat(f.name), casa: null, hoja: null, res: null }); nuevos.zip++; }
        } else if (/\.csv$/i.test(f.name)) {
            const txt = await f.text();
            if (/identificador|identifier/i.test(txt.split(/\r?\n/)[0])) { const base = f.name.replace(/\.csv$/i, ''), m = /^(.*?)-(\d{3,})$/.exec(base);
                bat.hojas.push({ archivo: f.name, texto: txt, resto: m ? m[1] : base, cmid: m ? m[2] : '' }); nuevos.csv++; }
        }
    }
    bat.tareas.forEach(t => { if (!t.manual) t.casa = casarTarea(t); t.hoja = casarHoja(t); });
    bat.tareas.sort((a, b) => a.tarea.localeCompare(b.tarea, 'es', { numeric: true }));
    return { nuevos, raros };
}
const etqBat = e => (e.ficha && e.ficha.num) || e.archivo.replace(/\.json$/i, '');
// Corregir una tarea: se abre su ejercicio (o sus variantes), se leen las entregas del zip y se corrigen
async function corregirTareaBat(t) {
    if (!t.casa) { t.res = { error: 'Sin ejercicio' }; return; }
    const es = t.casa.is.map(i => bat.ejercicios[i]);
    const antes = { lista: masiva.lista, ids: masiva.ids, variantes: masiva.variantes, reparto: masiva.reparto }, est = estadoGuardado(), sn = window.snack, al = window.alert;
    window.snack = () => {}; window.alert = () => {};
    try {
        (typeof _tuAbrirJSONDatos === 'function' ? _tuAbrirJSONDatos : abrirJSONDatos)(JSON.parse(JSON.stringify(es[0].datos)));
        masiva.lista = []; masiva.ids = {};
        masiva.variantes = t.casa.tipo === 'variantes' ? es.map((e, j) => { const k = claveEjercicio(e); return { id: 'bat:' + e.ruta, etq: etqBat(e), letra: (t.casa.letras && t.casa.letras[j]) || k[k.length - 1].toUpperCase(), datos: e.datos }; }) : [];
        masiva.reparto = masiva.variantes.length ? repartoParaVariantes(masiva.variantes) : null;
        await anadirProgramas([t.file]);
        if (masiva.variantes.length) { clearTimeout(tempVariantes); tempVariantes = null; colaVariantes.clear(); corregirConVariantes(masiva.lista); }
        calcularParecidos();
        const L = masiva.lista, val = L.filter(it => it.v && it.v.veredicto !== 'pendiente');
        const E = erroresClase(L).filter(e => e.alumnos.length >= 2);
        t.res = { lista: L, ids: masiva.ids, variantes: masiva.variantes, reparto: masiva.reparto, ejercicio: es[0], n: L.length,
                  media: val.length ? val.reduce((a, it) => a + it.v.nota, 0) / val.length : 0, aprueban: val.filter(it => it.v.nota >= 5).length,
                  bien: val.filter(it => it.v.veredicto === 'bien').length, parejas: (masiva.parejas || []).length, error: E[0] ? `${E[0].alumnos.length}: ${E[0].titulo}` : '' };
    } catch (e) { console.warn(e); t.res = { error: e.message }; }
    finally { masiva.lista = antes.lista; masiva.ids = antes.ids; masiva.variantes = antes.variantes; masiva.reparto = antes.reparto; restaurarEstado(est); window.snack = sn; window.alert = al; try { refrescar(); pintarMasiva(); } catch (e) {} }
}
// Trabajar con una tarea ya corregida como si estuviera abierta en la corrección masiva (sin tocar la pantalla)
function conTareaBat(t, fn) {
    const antes = { lista: masiva.lista, ids: masiva.ids, variantes: masiva.variantes, reparto: masiva.reparto, parejas: masiva.parejas }, est = estadoGuardado(), sn = window.snack;
    window.snack = () => {};
    try { (typeof _tuAbrirJSONDatos === 'function' ? _tuAbrirJSONDatos : abrirJSONDatos)(JSON.parse(JSON.stringify(t.res.ejercicio.datos)));
        Object.assign(masiva, { lista: t.res.lista, ids: t.res.ids, variantes: t.res.variantes, reparto: t.res.reparto }); calcularParecidos(); return fn(); }
    finally { Object.assign(masiva, antes); restaurarEstado(est); window.snack = sn; }
}
function csvTareaBat(t) { let txt = ''; const d0 = window.descargar; window.descargar = x => { txt = x; }; try { conTareaBat(t, () => exportarCSVMasiva()); } finally { window.descargar = d0; } return txt; }
function hojaTareaBat(t) { return t.hoja ? conTareaBat(t, () => rellenarHojaAules(t.hoja.texto, { comentario: true })) : null; }
function verTareaBat(k) {
    const t = bat.tareas[k]; if (!t || !t.res || !t.res.lista) return;
    document.getElementById('modalBateria').classList.remove('visible');
    abrirJSONDatos(JSON.parse(JSON.stringify(t.res.ejercicio.datos)));
    Object.assign(masiva, { lista: t.res.lista, ids: t.res.ids, variantes: t.res.variantes, reparto: t.res.reparto });
    abrirMasiva(); sincronizarRequisitosMasiva(); pintarMasiva();
    snack(`Tarea «${t.tarea}»: ${t.res.n} programas, corregidos con «${etqBat(t.res.ejercicio)}»${t.res.variantes.length ? ' y sus variantes' : ''}`);
}
// Un zip sin comprimir (para descargar todo de una vez)
function zipBat(archivos) {
    const crcT = zipBat.t || (zipBat.t = Array.from({ length: 256 }, (_, n) => { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1; return c >>> 0; }));
    const crc = b => { let x = 0xffffffff; for (let i = 0; i < b.length; i++) x = crcT[(x ^ b[i]) & 255] ^ (x >>> 8); return (x ^ 0xffffffff) >>> 0; };
    const enc = new TextEncoder(), loc = [], cen = []; let off = 0;
    archivos.forEach(([nombre, txt]) => {
        const n = enc.encode(nombre), d = typeof txt === 'string' ? enc.encode(txt) : txt, c = crc(d);
        const h = new DataView(new ArrayBuffer(30)); h.setUint32(0, 0x04034b50, true); h.setUint16(4, 20, true); h.setUint16(6, 0x800, true); h.setUint32(14, c, true); h.setUint32(18, d.length, true); h.setUint32(22, d.length, true); h.setUint16(26, n.length, true);
        const e = new DataView(new ArrayBuffer(46)); e.setUint32(0, 0x02014b50, true); e.setUint16(4, 20, true); e.setUint16(6, 20, true); e.setUint16(8, 0x800, true); e.setUint32(16, c, true); e.setUint32(20, d.length, true); e.setUint32(24, d.length, true); e.setUint16(28, n.length, true); e.setUint32(42, off, true);
        loc.push(new Uint8Array(h.buffer), n, d); cen.push(new Uint8Array(e.buffer), n); off += 30 + n.length + d.length;
    });
    const tamC = cen.reduce((a, b) => a + b.length, 0), f = new DataView(new ArrayBuffer(22));
    f.setUint32(0, 0x06054b50, true); f.setUint16(8, archivos.length, true); f.setUint16(10, archivos.length, true); f.setUint32(12, tamC, true); f.setUint32(16, off, true);
    return new Blob([...loc, ...cen, new Uint8Array(f.buffer)], { type: 'application/zip' });
}
function archivosTodoBat() {
    const lim = t => String(t).replace(/[\\/:*?"<>|]/g, '_').trim(), out = [], c = t => '"' + String(t).replace(/"/g, '""') + '"', d = x => String(Math.round(x * 10) / 10).replace('.', ',');
    const res = [['Tarea', 'Archivo', 'Ejercicio', 'Variantes', 'Alumnos', 'Nota media', 'Aprueban', 'La pieza sale bien', 'Parejas muy parecidas', 'Error más repetido', 'Hoja de calificaciones']];
    bat.tareas.forEach(t => {
        if (!t.res || !t.res.lista) { res.push([t.tarea, t.archivo, t.casa ? '' : 'sin ejercicio', '', '', '', '', '', '', t.res && t.res.error || '', '']); return; }
        const dir = lim(t.tarea) + '/';
        out.push([dir + lim(t.tarea) + ' - corrección.csv', csvTareaBat(t)]);
        const h = hojaTareaBat(t); if (h && !h.error) out.push([dir + t.hoja.archivo.replace(/\.csv$/i, '') + ' - con notas.csv', h.texto]);
        res.push([t.tarea, t.archivo, etqBat(t.res.ejercicio), t.res.variantes.map(v => v.etq).join(' '), t.res.n, d(t.res.media), t.res.aprueban, t.res.bien, t.res.parejas, t.res.error, h ? (h.error ? h.error : `rellenada: ${h.casados.length} alumnos`) : 'no está en la carpeta']);
    });
    out.unshift(['Resumen de la batería.csv', '﻿' + res.map(f => f.map(c).join(';')).join('\r\n')]);
    return out;
}
// ── La ventana ──
function abrirBateria() {
    let ov = document.getElementById('modalBateria');
    if (!ov) { ov = document.createElement('div'); ov.className = 'modal-overlay'; ov.id = 'modalBateria'; ov.onclick = e => { if (e.target === ov) ov.classList.remove('visible'); }; document.body.appendChild(ov);
        ov.innerHTML = `<div class="help-modal" style="width:min(1100px,100%)"><div class="help-header"><h2>🗃 Batería de corrección</h2><button class="help-close" onclick="document.getElementById('modalBateria').classList.remove('visible')">✕</button></div>
        <div class="help-content" id="batCuerpo">
        <p class="ctx-nota" style="margin-top:0">Una carpeta con los <b>ejercicios</b> (.json) y las <b>entregas de Aules</b> (el .zip de «Descargar todas las entregas» de cada tarea, por ejemplo «Automatització en fusteria i moble-2CFS7 1788982647-ISO GEO 01A-11829876.zip»). Cada zip se casa con su ejercicio por el nombre de la tarea (ISO GEO 01A ↔ «ISO GEO 01A.json»; si la tarea es «ISO GEO 01» y hay «…01A», «…01B»…, se corrige con las variantes). Los ejercicios también pueden venir de un <b>archivo de biblioteca</b> (el de ⬇ Exportar biblioteca) o de <b>🗂 la biblioteca</b> de este navegador; se casan por el nombre del archivo, el número o el título. Si en la carpeta está la <b>hoja de calificaciones</b> de la tarea (Calificaciones-…-número.csv), se rellena con las notas. Arrastra aquí la carpeta o los archivos.</p>
        <input type="file" id="batCarpeta" webkitdirectory directory multiple style="display:none"><input type="file" id="batArchivos" multiple accept=".json,.zip,.csv" style="display:none">
        <div class="btn-row"><button class="btn-action" id="batBCarpeta">📂 Elegir la carpeta…</button><button class="btn-action sec" id="batBArch">📄 Añadir archivos…</button><button class="btn-action sec" id="batBib" title="Usar como ejercicios los de la biblioteca de este navegador (así, en la carpeta solo hacen falta los zip de las entregas)">🗂 Usar la biblioteca</button><button class="btn-action sec" id="batVaciar">🗑 Vaciar</button></div>
        <div class="btn-row bat-acciones"><button class="btn-action" id="batCorregir">▶ Corregir todo</button><button class="btn-action sec" id="batImpInf" title="Los informes de todas las tareas en un solo documento: de cada tarea, el resumen de la clase y una hoja por alumno. En la ventana de impresión, «Guardar como PDF»">🖨 Informes de todas</button><button class="btn-action sec" id="batImpDev" title="Las hojas de devolución de todos los alumnos de todas las tareas, en un solo documento">🖨 Devoluciones de todas</button><button class="btn-action sec" id="batTodo">⬇ Descargar todo (.zip)</button></div>
        <div id="batTabla"></div></div></div>`;
        const g = id => ov.querySelector('#' + id);
        g('batBCarpeta').onclick = () => g('batCarpeta').click(); g('batBArch').onclick = () => g('batArchivos').click();
        const leer = async files => { const r = await leerArchivosBat(files); pintarBateria(); snack(`${r.nuevos.ej} ejercicio(s)${r.nuevos.bib ? ` (con ${r.nuevos.bib} archivo(s) de biblioteca)` : ''}, ${r.nuevos.zip} zip de entregas y ${r.nuevos.csv} hoja(s) de calificaciones${r.raros.length ? ` · ${r.raros.length} .json que no son ejercicios del Calcador` : ''}`); };
        g('batCarpeta').onchange = ev => { const f = [...ev.target.files]; ev.target.value = ''; leer(f); };
        g('batArchivos').onchange = ev => { const f = [...ev.target.files]; ev.target.value = ''; leer(f); };
        g('batBib').onclick = () => usarBibliotecaBat();
        g('batVaciar').onclick = () => { bat = { ejercicios: [], tareas: [], hojas: [] }; pintarBateria(); };
        g('batCorregir').onclick = () => corregirTodoBat();
        g('batImpInf').onclick = () => imprimirBateria(false); g('batImpDev').onclick = () => imprimirBateria(true);
        g('batTodo').onclick = () => { if (!bat.tareas.some(t => t.res && t.res.lista)) { snack('Corrige antes las tareas (▶ Corregir todo)'); return; }
            const url = URL.createObjectURL(zipBat(archivosTodoBat())), a = document.createElement('a'); a.href = url; a.download = `Batería de corrección ${new Date().toLocaleDateString('es-ES').replace(/\//g, '-')}.zip`; document.body.appendChild(a); a.click(); setTimeout(() => { URL.revokeObjectURL(url); a.remove(); }, 500);
            snack('Descargado: el resumen, el CSV de cada tarea y sus hojas de calificaciones rellenadas'); };
        const caja = g('batCuerpo');
        caja.addEventListener('dragover', e => { e.preventDefault(); caja.classList.add('bat-sobre'); }); caja.addEventListener('dragleave', () => caja.classList.remove('bat-sobre'));
        caja.addEventListener('drop', async e => { e.preventDefault(); caja.classList.remove('bat-sobre'); leer(await archivosDeArrastre(e.dataTransfer)); });
    }
    pintarBateria(); ov.classList.add('visible');
}
// Lo arrastrado: archivos y carpetas (con sus subcarpetas)
async function archivosDeArrastre(dt) {
    const out = [], items = [...(dt.items || [])].map(i => i.webkitGetAsEntry && i.webkitGetAsEntry()).filter(Boolean);
    if (!items.length) return [...dt.files];
    const rec = ent => new Promise(res => {
        if (ent.isFile) ent.file(f => { try { Object.defineProperty(f, 'webkitRelativePath', { value: ent.fullPath.replace(/^\//, '') }); } catch (e) {} out.push(f); res(); }, () => res());
        else { const r = ent.createReader(), todos = []; const leer = () => r.readEntries(async es => { if (!es.length) { for (const x of todos) await rec(x); res(); } else { todos.push(...es); leer(); } }, () => res()); leer(); }
    });
    for (const e of items) await rec(e);
    return out;
}
function pintarBateria() {
    const d = document.getElementById('batTabla'); if (!d) return;
    const esc = t => String(t).replace(/&/g, '&amp;').replace(/</g, '&lt;'), nf1 = x => String(Math.round(x * 10) / 10).replace('.', ',');
    if (!bat.tareas.length) { d.innerHTML = `<p class="ctx-nota">${bat.ejercicios.length ? `${bat.ejercicios.length} ejercicio(s) leído(s); faltan los zip de las entregas.` : 'Todavía no hay nada: elige la carpeta o arrastra aquí los archivos.'}</p>`; return; }
    const opts = sel => `<option value="">— sin ejercicio —</option>` + bat.ejercicios.map((e, i) => `<option value="${i}" ${sel && sel.tipo === 'uno' && sel.is[0] === i ? 'selected' : ''}>${esc(e.archivo)}${e.ficha && e.ficha.num && !e.archivo.includes(e.ficha.num) ? ' · ' + esc(e.ficha.num) : ''}${e.origen ? ' 🗂' : ''}</option>`).join('')
        + (sel && sel.tipo === 'variantes' ? `<option value="var" selected>Variantes: ${esc(sel.is.map(i => etqBat(bat.ejercicios[i])).join(', '))}</option>` : '');
    d.innerHTML = `<table class="par-tabla bat-tabla"><tr><th>Tarea (zip de Aules)</th><th>Ejercicio</th><th>Hoja de calificaciones</th><th>Alumnos</th><th>Media</th><th>Aprueban</th><th>Lo más repetido</th><th></th></tr>
        ${bat.tareas.map((t, k) => { const r = t.res;
            return `<tr><td><b>${esc(t.tarea)}</b><div class="ctx-nota" style="margin:0" title="${esc(t.archivo)}">${esc(t.archivo.length > 60 ? t.archivo.slice(0, 57) + '…' : t.archivo)}</div></td>
            <td><select data-k="${k}" class="bat-ej">${opts(t.casa)}</select></td>
            <td>${t.hoja ? `<span title="${esc(t.hoja.archivo)}">✔ ${t.cmid && t.hoja.cmid === t.cmid ? 'nº ' + esc(t.cmid) : 'por el nombre'}</span>` : '<span class="ctx-nota">—</span>'}</td>
            ${r && r.lista ? `<td class="n">${r.n}</td><td class="n"><b>${nf1(r.media)}</b></td><td class="n">${r.aprueban} de ${r.n}</td><td style="font-size:12px">${esc(r.error.slice(0, 90))}${r.error.length > 90 ? '…' : ''}${r.parejas ? `<div style="color:#b0301f">👥 ${r.parejas} pareja(s) muy parecida(s)</div>` : ''}</td>
                <td class="bat-acc"><button class="btn-action sec" data-a="ver" data-k="${k}" title="Abrirla en la corrección masiva: la lista, cada alumno, los informes…">🔍 Ver</button><button class="btn-action sec" data-a="imp" data-k="${k}" title="Imprimir sus informes (el resumen de la clase y una hoja por alumno)">🖨</button><button class="btn-action sec" data-a="csv" data-k="${k}" title="La tabla para Excel o LibreOffice">⬇ CSV</button>${t.hoja ? `<button class="btn-action sec" data-a="hoja" data-k="${k}" title="La hoja de calificaciones con las notas, para subirla a Aules">⬆ Aules</button>` : ''}</td>`
              : `<td colspan="5" class="ctx-nota">${r && r.error ? '⚠️ ' + esc(r.error) : t.casa ? 'sin corregir' : '⚠️ elige su ejercicio'}</td>`}</tr>`; }).join('')}</table>
        ${bat.ejercicios.length ? `<p class="ctx-nota">${bat.ejercicios.length} ejercicio(s): ${esc(bat.ejercicios.slice(0, 40).map(e => e.archivo + (e.ficha && e.ficha.num && !e.archivo.includes(e.ficha.num) ? ` (${e.ficha.num})` : '')).join(', '))}${bat.ejercicios.length > 40 ? '…' : ''}${bat.ejercicios.some(e => e.origen) ? ` · de la biblioteca: ${bat.ejercicios.filter(e => e.origen).length}` : ''}</p>` : ''}`;
    d.querySelectorAll('select.bat-ej').forEach(s => s.onchange = () => { const t = bat.tareas[+s.dataset.k]; t.manual = true; t.res = null;
        t.casa = s.value === '' ? null : s.value === 'var' ? t.casa : { tipo: 'uno', is: [+s.value] }; pintarBateria(); });
    d.querySelectorAll('button[data-a]').forEach(b => b.onclick = () => { const k = +b.dataset.k, t = bat.tareas[k];
        if (b.dataset.a === 'ver') verTareaBat(k);
        else if (b.dataset.a === 'imp') imprimirBateria(false, k);
        else if (b.dataset.a === 'csv') descargar(csvTareaBat(t), `${t.tarea} - corrección.csv`, 'text/csv;charset=utf-8');
        else if (b.dataset.a === 'hoja') { const h = hojaTareaBat(t); if (h.error) snack(h.error); else { descargar(h.texto, t.hoja.archivo.replace(/\.csv$/i, '') + ' - con notas.csv', 'text/csv;charset=utf-8'); snack(`${h.casados.length} alumnos con nota${h.sinCasar.length ? ` · ⚠️ sin casar: ${h.sinCasar.join(', ')}` : ''}`); } } });
}
async function corregirTodoBat() {
    const T = bat.tareas.filter(t => t.casa); if (!T.length) { snack(bat.tareas.length ? 'Ninguna tarea tiene ejercicio: elígelo en su fila' : 'Elige antes la carpeta'); return; }
    const b = document.getElementById('batCorregir'); b.disabled = true;
    for (let i = 0; i < T.length; i++) { b.textContent = `⏳ ${i + 1} de ${T.length}…`; await new Promise(r => setTimeout(r, 20)); await corregirTareaBat(T[i]); pintarBateria(); }
    b.disabled = false; b.textContent = '▶ Corregir todo';
    const n = T.reduce((a, t) => a + (t.res && t.res.n || 0), 0);
    snack(`${T.length} tarea(s) corregida(s): ${n} programas`);
}
