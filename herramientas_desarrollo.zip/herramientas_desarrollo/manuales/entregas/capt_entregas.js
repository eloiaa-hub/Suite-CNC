// Capturas de los manuales del Calcador y del Corrector: corrección desde el zip de Aules (con informes de entrega)
// y 📝 Cuestionario para Aules. Uso: node capt_entregas.js   (aules_informes.zip: el de la prueba entregas.js)
const path = require('path'), fs = require('fs');
const { lanzar, SUITE } = require('../../pruebas/comun.js');
const OUT = path.join(__dirname, 'capturas'); fs.mkdirSync(OUT, { recursive: true });
const EJ = path.join(__dirname, '../../pruebas/ISO 13 - dos herramientas.json');
(async () => {
  const b = await lanzar();
  for (const prog of ['corrector', 'calcador']) {
    const ctx = await b.newContext({ viewport: { width: 1400, height: 900 }, deviceScaleFactor: 1.5, acceptDownloads: true }), pg = await ctx.newPage(); pg.on('dialog', d => d.accept());
    await pg.goto('file://' + path.join(SUITE, prog + '.html')); await pg.waitForTimeout(700);
    await pg.evaluate(d => { abrirJSONDatos(d); }, JSON.parse(fs.readFileSync(EJ, 'utf8'))); await pg.waitForTimeout(400);
    if (prog === 'corrector') {
      await pg.evaluate(() => abrirMasiva()); await pg.setInputFiles('#mvArchivos', path.join(__dirname, 'aules_informes.zip')); await pg.waitForTimeout(1500);
      await pg.waitForTimeout(3000);
      await pg.locator('#modalMasiva .help-modal').screenshot({ path: path.join(OUT, 'masiva_aules.png') });
      await pg.evaluate(() => cerrarMasiva());
    }
    await pg.evaluate(() => abrirCuestionario()); await pg.waitForTimeout(3000);
    await pg.locator('#modalCuest .help-modal').screenshot({ path: path.join(OUT, `cuestionario_${prog}.png`) });
    await ctx.close();
  }
  await b.close(); console.log('capturas en', OUT);
})();
