"""Calcador v112 / Corrector v57: altura de corte incorrecta. Si el programa no corta porque la fresa nunca baja de Z0,
se corrige el recorrido sin las Z: «Trazado geométrico correcto · Altura de corte incorrecta» (o lo que falla del trazado),
con el veredicto «⛔ Altura de corte incorrecta» en lugar de «Sin programa válido». La nota no cambia.
Uso: python3 altura_corte.py <carpeta de la suite>   (construir_calcador.sh lo pone tras bateria.py)"""
import sys, os
AQUI = os.path.dirname(os.path.abspath(__file__))
P = os.path.join(sys.argv[1] if len(sys.argv) > 1 else '.', 'calcador.html')
s = open(P, encoding='utf-8').read()
def rep(a, b, cnt=1):
    global s
    n = s.count(a); assert n == cnt, f'{n} apariciones (se esperaban {cnt}) de: {a[:100]}'
    s = s.replace(a, b)
JS = open(os.path.join(AQUI, 'altura_corte.js'), encoding='utf-8').read()
rep("// Arrastrar archivos a la ventana de corrección masiva; ordenar por columna", JS + "// Arrastrar archivos a la ventana de corrección masiva; ordenar por columna")
rep("""v.veredicto === 'vacio' ? '<td class="n" colspan="4" style="color:var(--text-muted)">ningún movimiento de corte</td>'""",
    """(v.veredicto === 'vacio' || v.veredicto === 'altura') ? `<td class="n" colspan="4" style="color:var(--text-muted)">${textoSinCorte(it)}</td>`""")
rep("""v.veredicto === 'vacio' ? '<td colspan="4">ningún movimiento de corte</td>'""",
    """(v.veredicto === 'vacio' || v.veredicto === 'altura') ? `<td colspan="4">${textoSinCorte(it)}</td>`""")
rep("rango = { bien:0, nocumple:1, mal:2, vacio:3, error:4, pendiente:5 };", "rango = { bien:0, nocumple:1, mal:2, altura:3, vacio:3, error:4, pendiente:5 };")
rep(".v-mal, .v-error, .v-vacio { background: #fbe4e4; color: #b52b2b; }", ".v-mal, .v-error, .v-vacio, .v-altura { background: #fbe4e4; color: #b52b2b; }")
rep("""Se corrigen con los mismos requisitos""", """Si un programa no corta porque la fresa nunca baja de Z0, sale «⛔ Altura de corte incorrecta» y se comprueba igual el recorrido en X Y: «trazado geométrico correcto» o lo que falla. Se corrigen con los mismos requisitos""")
open(P, 'w', encoding='utf-8').write(s)
print('Calcador: altura de corte incorrecta (y el trazado)')
