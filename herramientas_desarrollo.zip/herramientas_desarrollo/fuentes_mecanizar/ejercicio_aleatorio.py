"""Calcador: 🧩 Ejercicio aleatorio (fase 1): piezas con las formas del Calcador y sus interiores, dentro de un tamaño
máximo, con cotas en múltiplos de un paso, sitio para la fresa y una semilla para repetir cada ejercicio.
Uso: python3 ejercicio_aleatorio.py <carpeta de la suite>   (después de herramientas_cad.py)
"""
import sys, os
AQUI = os.path.dirname(os.path.abspath(__file__))
P = os.path.join(sys.argv[1] if len(sys.argv) > 1 else '.', 'calcador.html')
s = open(P, encoding='utf-8').read()
def rep(a, b, cnt=1):
    global s
    n = s.count(a); assert n == cnt, f'{n} apariciones (se esperaban {cnt}) de: {a[:100]}'
    s = s.replace(a, b)
JS = open(os.path.join(AQUI, 'ejercicio_aleatorio.js'), encoding='utf-8').read()
rep("// ── Cortar un contorno en un punto ──", JS + "\n// ── Cortar un contorno en un punto ──")

# botón, arriba del todo en el panel de la izquierda
rep("""            <div class="action-panel">
                <div class="section-label">Fondo</div>""", """            <div class="action-panel">
                <div class="section-label">Ejercicio</div>
                <div class="params-box">
                    <button class="btn-action" onclick="abrirGenerador()" title="Genera ejercicios al azar con las formas del Calcador (rectángulos, polígonos, estrellas, círculos y colisos) y sus interiores, dentro del tamaño que elijas, con cotas enteras y sitio para la fresa. Cada uno tiene su número: el mismo número da el mismo ejercicio">🧩 Ejercicio aleatorio…</button>
                </div>

                <div class="section-label">Fondo</div>""")

# la ventana
rep("""<div class="modal-overlay" id="modalCuest" onclick="if(event.target===this)cerrarCuestionario()">""", """<div class="modal-overlay" id="modalGenerador" onclick="if(event.target===this)cerrarGenerador()">
    <div class="help-modal var-modal gen-modal">
        <div class="help-header"><h2>🧩 Ejercicio aleatorio</h2><button class="help-close" onclick="cerrarGenerador()">✕</button></div>
        <div class="var-cuerpo">
            <div class="var-opciones">
                <p class="ctx-nota">Elige el nivel (o los parámetros) y haz clic en la propuesta que quieras: pasa al dibujo, con sus formas editables.</p>
                <div class="cr-req-t">Nivel</div>
                <select id="genNivel" onchange="elegirNivel(this.value)" title="Niveles de la progresión de clase: cada uno pone las formas, esquinas y lados que le tocan. Si cambias algo a mano, pasa a «Libre»"></select>
                <div class="cr-req-t">Tamaño</div>
                <div class="param-line" title="Lo que ocupa como máximo el conjunto de piezas">Ancho máximo (mm) <input type="number" id="genAncho" min="40" step="10" onchange="cambiarGenerador()"></div>
                <div class="param-line">Alto máximo (mm) <input type="number" id="genAlto" min="40" step="10" onchange="cambiarGenerador()"></div>
                <div class="param-line" title="Cada pieza ocupa entre este porcentaje y el 100 % de su sitio: más alto, piezas más grandes">Ocupar al menos (%) <input type="number" id="genOcupar" min="20" max="100" step="5" onchange="cambiarGenerador()"></div>
                <div class="cr-req-t">Piezas</div>
                <div class="param-line">Número de piezas <span class="gen-rango"><input type="number" id="genPMin" min="1" max="12" step="1" onchange="cambiarGenerador()"> a <input type="number" id="genPMax" min="1" max="12" step="1" onchange="cambiarGenerador()"></span></div>
                <div class="gen-chips" id="genFormasExt" title="Formas que pueden salir como contorno exterior de cada pieza"></div>
                <div class="cr-req-t">Interiores de cada pieza</div>
                <div class="param-line">Número de interiores <span class="gen-rango"><input type="number" id="genIMin" min="0" max="12" step="1" onchange="cambiarGenerador()"> a <input type="number" id="genIMax" min="0" max="12" step="1" onchange="cambiarGenerador()"></span></div>
                <div class="gen-chips" id="genFormasInt" title="Formas que pueden salir como agujeros"></div>
                <div class="cr-req-t">Esquinas y lados</div>
                <div class="param-line" title="Probabilidad de que cada esquina de un rectángulo, polígono o estrella se cambie">Esquinas cambiadas (%) <input type="number" id="genPEsq" min="0" max="100" step="5" onchange="cambiarGenerador()"></div>
                <div class="gen-chips" id="genEsqTipos" title="Redondeada: arco hacia fuera, tangente a los dos lados. Hacia dentro: cuarto de círculo con centro en la esquina. Chaflán: un corte recto"></div>
                <div class="param-line" title="Probabilidad de que un lado recto (entre dos esquinas vivas) se cambie por un arco">Lados en arco (%) <input type="number" id="genPLado" min="0" max="100" step="5" onchange="cambiarGenerador()"></div>
                <div class="gen-chips" id="genLadoTipos" title="Abombado: el arco sale hacia fuera de la forma. Hundido: entra hacia dentro"></div>
                <label class="param-line var-chk" title="Cambiar también las esquinas y los lados de los agujeros"><input type="checkbox" id="genModInt" onchange="cambiarGenerador()"> También en los interiores</label>
                <div class="cr-req-t">Cotas y fresa</div>
                <div class="param-line" title="Las cotas de los rectángulos y colisos, los centros y los radios salen en múltiplos de este valor. Los vértices de polígonos y estrellas, y las formas giradas, dan decimales (se calculan con polares)">Cotas múltiplos de <select id="genPaso" onchange="cambiarGenerador()"><option value="1">1 mm</option><option value="5">5 mm</option><option value="10">10 mm</option></select></div>
                <label class="param-line var-chk" title="Rectángulos, colisos, polígonos y estrellas girados en múltiplos de 15°. Dan cotas con decimales"><input type="checkbox" id="genGirar" onchange="cambiarGenerador()"> Formas giradas</label>
                <div class="param-line" title="Ningún agujero más pequeño que dos veces este diámetro, y las piezas separadas al menos el diámetro más 4 mm">Diámetro de la fresa (mm) <input type="number" id="genFresa" min="0.5" step="0.5" onchange="cambiarGenerador()"></div>
                <div class="param-line" title="Lo que queda como mínimo entre un agujero y el borde de la pieza, y entre dos agujeros">Pared mínima (mm) <input type="number" id="genPared" min="0" step="1" onchange="cambiarGenerador()"></div>
                <p class="ctx-nota var-aviso" id="genAviso"></p>
                <button class="btn-action" onclick="otrasPropuestas()">🎲 Otras seis</button>
                <div class="param-line" title="El número de un ejercicio (con los mismos parámetros, sale el mismo)">Número <span class="gen-rango"><input type="number" id="genSemilla" min="1" step="1" style="width:80px" onkeydown="if(event.key==='Enter')verSemilla()"> <button class="btn-action sec" style="padding:3px 8px" onclick="verSemilla()">Ver</button></span></div>
                <div class="cr-req-t">Serie para la clase</div>
                <div class="param-line" title="Un ejercicio distinto para cada alumno: los números seguidos desde el primero de las propuestas">Ejercicios <input type="number" id="genSerieN" min="1" max="60" step="1" onchange="cfgGen.serieN = Math.max(1, Math.min(60, Math.round(+this.value || 25))); genGuardarCfg(); pintarCfgGen()"></div>
                <p class="ctx-nota" id="genSerieDe"></p>
                <button class="btn-action sec" onclick="guardarSerieBib()" title="Los guarda en la biblioteca, en la carpeta Aleatorios/Serie (número del primero); cada uno con su número de orden en el cajetín">📚 Guardar en la biblioteca</button>
                <div class="btn-row"><button class="btn-action sec" onclick="guardarSerieBib('hoja')" title="Los guarda en la biblioteca e imprime todas sus hojas de una vez">🖨 Sus hojas</button><button class="btn-action sec" onclick="guardarSerieBib('sol')" title="Los guarda en la biblioteca e imprime todas sus soluciones de una vez">📋 Sus soluciones</button></div>
            </div>
            <div class="var-lista" id="genLista"></div>
        </div>
    </div>
</div>
<div class="modal-overlay" id="modalCuest" onclick="if(event.target===this)cerrarCuestionario()">""")
rep("""    .var-aviso { color: #a3560f; }""", """    .var-aviso { color: #a3560f; }
    .help-modal.gen-modal { width: min(1500px, 97vw); max-height: 95vh; height: 95vh; }
    .gen-modal .var-cuerpo { max-height: none; flex: 1; min-height: 0; }
    .gen-modal .var-opciones { width: 470px; padding: 0 20px 0 4px; }
    .gen-modal .var-lista { grid-template-columns: repeat(auto-fill, minmax(240px, 1fr)); }
    .gen-modal .var-mini { height: 190px; } .gen-modal .var-mini svg { max-height: 190px; }
    .gen-modal #genNivel { width: 100%; }
    .gen-chips { display: flex; flex-wrap: wrap; gap: 4px 10px; font-size: 12px; }
    .gen-chip { display: flex; align-items: center; gap: 4px; cursor: pointer; }
    .gen-rango { display: flex; align-items: center; gap: 4px; } .gen-rango input[type=number] { width: 48px; }
    .gen-ficha { cursor: pointer; transition: border-color .15s, box-shadow .15s; }
    .gen-ficha:hover { border-color: var(--accent); box-shadow: 0 0 0 2px var(--accent-light); }
    .gen-av { color: #a3560f !important; }""")

# el número y los parámetros del ejercicio generado viajan en el JSON
rep("cfgMec: JSON.parse(JSON.stringify(cfgMec)) }", "cfgMec: JSON.parse(JSON.stringify(cfgMec)), generado: genUltimo ? JSON.parse(JSON.stringify(genUltimo)) : undefined }")
rep("""            if (esObj(d.calcador.cfgMec)) asignarCfg(cfgMec, d.calcador.cfgMec);""", """            if (esObj(d.calcador.cfgMec)) asignarCfg(cfgMec, d.calcador.cfgMec);
            genUltimo = esObj(d.calcador.generado) && d.calcador.generado.semilla > 0 ? d.calcador.generado : null;""")
rep("""    contornos = []; aux = []; auxPend = null; fondo = null; sel = -1; selSet = new Set(); cotasAjuste = {}; cotasManuales = []; dib = null; circ = null; ran = null;
    requisitosPorDefecto();""", """    contornos = []; aux = []; auxPend = null; fondo = null; sel = -1; selSet = new Set(); cotasAjuste = {}; cotasManuales = []; dib = null; circ = null; ran = null;
    genUltimo = null;
    requisitosPorDefecto();""")
# ayuda (❓)
rep("""            <p><strong>Alinear y repartir</strong>""", """            <p><strong>🧩 Ejercicio aleatorio</strong> (panel Ejercicio, arriba a la izquierda): genera ejercicios al azar con las formas del Calcador. Eliges el tamaño máximo del conjunto (por ejemplo, 250 × 200), cuántas piezas y cuántos interiores, qué formas pueden salir para las piezas y para los agujeros, en qué múltiplos salen las cotas (1, 5 o 10 mm), si las formas pueden ir giradas, el diámetro de la fresa y la pared mínima. En <em>Esquinas y lados</em>, la probabilidad de que cada esquina de un rectángulo, polígono o estrella salga redondeada, hacia dentro o con chaflán, y de que un lado recto salga como arco abombado o hundido (también en los agujeros, si se marca); sus radios y chaflanes salen en múltiplos del paso de las cotas, y los arcos que la fresa recorre por dentro miden al menos su diámetro. Con <em>Nivel</em> se eligen de una vez las formas, esquinas y lados de cada paso de la progresión: 1, solo rectas horizontales y verticales (rectángulos y piezas escalonadas, en L, en T o en U); 2, con rectas inclinadas (chaflanes); 3, con arcos de centro en la rejilla (I J enteros: redondeos, esquinas hacia dentro, círculos y colisos); 4, con arcos que piden calcular I J (lados en arco) y polígonos. En <em>Serie para la clase</em>, un ejercicio distinto para cada alumno (los números seguidos desde el primero de las propuestas): se guardan en la biblioteca y se pueden imprimir todas sus hojas o sus soluciones de una vez. Salen seis propuestas, cada una con su número: clic en la que quieras y pasa al dibujo con sus cotas, con las formas editables y cada pieza agrupada con sus agujeros. <em>🎲 Otras seis</em> da otras; con el número (y los mismos parámetros) vuelve a salir el mismo ejercicio, que se guarda en el JSON. Ningún agujero es más pequeño que dos diámetros de fresa, entre un agujero y el borde (o entre dos agujeros) queda la pared mínima, y las piezas quedan separadas el diámetro de la fresa más 4 mm.</p>
            <p><strong>Alinear y repartir</strong>""")
open(P, 'w', encoding='utf-8').write(s)
print('Calcador: ejercicio aleatorio:', P)
