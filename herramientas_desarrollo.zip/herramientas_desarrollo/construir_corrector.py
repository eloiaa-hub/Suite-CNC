#!/usr/bin/env python3
"""Genera corrector.html a partir de calcador.html (el Corrector es el Calcador en modo visor), con la interfaz del
Calcador v95: Nuevo, Abrir, Guardar y Biblioteca arriba; a la izquierda, Corregir / Ejercicios en pestañas y Exportar;
a la derecha, el programa de la pieza con ⚙️ Mecanizado (sin la pestaña Contornos: el Corrector no cambia la pieza).
Se ejecuta después de tutor/interfaz_calcador.py (construir_calcador.sh lo hace así).
Uso: python3 construir_corrector.py CARPETA_DE_LA_SUITE"""
import re, sys, os
VERSION_CORRECTOR = 'v66'   # v66: hasta 26 variantes; sin ◠ Examen de I J · v65: Coordenadas y zoom no se pisan en pantallas pequeñas; sin ◠ Hoja de I J · v64: sin ◠ Practicar I J (es del Calcador) · v63: la batería, en el orden de la biblioteca · v62: los parecidos en el informe · v61: imprimir toda la batería · v60: diagnóstico, nota del profesor, guardar la corrección, devolución · v59: el trazado puntúa · v58: trazado desplazado · v57: altura de corte incorrecta · v56: la batería, con la biblioteca · v55: batería de corrección · v54: errores de la clase, rúbrica y códigos de clase · v53: notas para Aules, reparto de variantes y completar huecos · v52: programas muy parecidos entre alumnos · v51: corrección masiva con las variantes de un examen · v50: 🏷 Nombres y 📏 Cotas en los botones de vista · v49: ocultar los paneles y la rejilla · v48: la fresa abajo al terminar, bajar en diagonal · v47: el final del programa (M05 y M30, o M02) y los números de bloque · v46: programas entregados en documentos (.odt, .docx…): se corrigen y se avisa del formato · v45: los informes del Tutor en «Toda la clase» · v44: la interfaz del Calcador v95 · v43: aviso del lado equivocado en ⚙️ Mecanizar
d = sys.argv[1] if len(sys.argv) > 1 else '.'
s = open(os.path.join(d, 'calcador.html'), encoding='utf-8').read()
vcal = re.search(r'vertical-align:middle">(v\d+)</span></span>', s).group(1)
def rep(a, b, cnt=1):
    global s
    n = s.count(a)
    assert n == cnt, f'esperaba {cnt} y hay {n}: {a[:80]}'
    s = s.replace(a, b)
assert s.startswith('<!DOCTYPE html>\n<html lang="es" data-calc2="1">'), 'cabecera inesperada: el Corrector se hace después de la interfaz nueva del Calcador'
s = s.replace('<html lang="es" data-calc2="1">', '<html lang="es" data-calc2="1" data-visor="1">', 1)      # solo la del propio documento
rep('<title>Calcador de contornos — Por Eloi A.A.</title>', '<title>Corrector — Por Eloi A.A.</title>')
rep(f'⬡ Calcador de contornos — Por Eloi A.A.<span class="ver-suite" title="Versión del programa" style="font-size:11px;font-weight:600;padding:1px 7px;margin-left:8px;border-radius:9px;background:rgba(0,90,156,.12);color:#005A9C;vertical-align:middle">{vcal}</span>',
    f'✅ Corrector — Por Eloi A.A.<span class="ver-suite" title="Versión del programa (generado a partir del Calcador {vcal})" style="font-size:11px;font-weight:600;padding:1px 7px;margin-left:8px;border-radius:9px;background:rgba(0,90,156,.12);color:#005A9C;vertical-align:middle">{VERSION_CORRECTOR}</span>')
rep('<a class="btn-manual" href="manual_calcador.html"', '<a class="btn-manual" href="manual_corrector.html"')
rep('El <a href="manual_calcador.html" target="_blank" rel="noopener"><strong>📖 manual completo</strong></a> lo explica todo paso a paso, con imágenes (archivo <em>manual_calcador.html</em>',
    'El <a href="manual_corrector.html" target="_blank" rel="noopener"><strong>📖 manual del Corrector</strong></a> lo explica todo paso a paso, con imágenes (archivo <em>manual_corrector.html</em>')
# sesión propia: el Corrector no pisa lo que haya abierto en el Calcador
n = s.count("'calcador_estado")
s = s.replace("'calcador_estado", "'corrector_estado")
assert n == 6, f'claves de sesión: {n}'

# ── La interfaz nueva en modo visor ──
# a la izquierda, en lugar de «solo el panel Exportar», las pestañas Corregir / Ejercicios y Exportar
rep('    html[data-visor="1"] .action-panel > :not(.visor-si) { display: none !important; }',
    '    html[data-visor="1"] .action-panel > .section-label, html[data-visor="1"] .action-panel > .params-box:not(.c2-botones):not(.c2-pane) { display: none !important; }')
CSS = '''    /* ═══ Corrector: la interfaz del Calcador, sin dibujo ═══ */
    html[data-visor="1"] #c2Tabs2, html[data-visor="1"] #c2PaneDib, html[data-visor="1"] #c2PaneCons, html[data-visor="1"] #c2PaneFormas,
    html[data-visor="1"] #c2PaneFondo, html[data-visor="1"] #c2Tabs3 button[data-p="c2PaneFondo"],
    html[data-visor="1"] #c2PaneEj button[onclick="abrirGenerador()"], html[data-visor="1"] #c2PaneEj button[onclick="exportarEjercicioTutor()"],
    html[data-visor="1"] #c2PaneEj button[onclick="abrirEnArcosIJ()"], html[data-visor="1"] #c2PaneEj button[onclick="abrirHojaIJ()"], html[data-visor="1"] #c2PaneEj button[onclick*="arcos_ij.html#profesor"],
    html[data-visor="1"] #tutorPanel .tu-tabs button[data-t="contornos"] { display: none !important; }
    html[data-visor="1"] #c2Tabs3 button { flex: 0 0 50%; }
'''
rep('</style>\n</head>', CSS + '</style>\n</head>')
JS = '''// Modo visor: el Corrector es este mismo programa con data-visor="1" (sin edición)
// (Corrector) primero la pestaña Corregir y, abajo, Exportar (sin fondo)
window.addEventListener('load', () => setTimeout(() => {
    const t = document.getElementById('c2Tabs'), bc = t && t.querySelector('button[data-p="c2PaneCorr"]'); if (bc) { t.insertBefore(bc, t.firstChild); c2Pestana(bc); }
    const be = document.querySelector('#c2Tabs3 button[data-p="c2PaneExp"]'); if (be) c2Pestana(be);
}, 50));'''
rep('// Modo visor: el Corrector es este mismo programa con data-visor="1" (sin edición)', JS)
open(os.path.join(d, 'corrector.html'), 'w', encoding='utf-8').write(s)
print(f'corrector.html generado desde el Calcador {vcal} → Corrector {VERSION_CORRECTOR}')
