"""Calcador v100 / Corrector v46: en la corrección masiva, los programas entregados en un documento (LibreOffice .odt,
Word .docx o .doc, RTF) se corrigen igual, sacando su texto, pero se avisa: «Formato de archivo incorrecto: es un
documento de LibreOffice (.odt); debe ser un archivo de texto (.txt, .nc o .gcode)». También si el documento se ha
renombrado a .nc o .txt (se reconoce por lo que lleva dentro). El aviso sale junto al nombre (📄⚠️), en el resumen,
en el CSV, en el informe impreso y al ver su corrección.
Uso: python3 entregas_documentos.py <carpeta de la suite>   (después de entregas_aules.py; construir_calcador.sh lo pone tras hoja_ejercicio.py)"""
import sys, os
AQUI = os.path.dirname(os.path.abspath(__file__))
P = os.path.join(sys.argv[1] if len(sys.argv) > 1 else '.', 'calcador.html')
s = open(P, encoding='utf-8').read()
def rep(a, b, cnt=1):
    global s
    n = s.count(a); assert n == cnt, f'{n} apariciones (se esperaban {cnt}) de: {a[:100]}'
    s = s.replace(a, b)
JS = open(os.path.join(AQUI, 'entregas_documentos.js'), encoding='utf-8').read()
rep("async function entregasDeZip(ab, dest, ignorados, nivel) {", JS + "async function entregasDeZip(ab, dest, ignorados, nivel) {")
rep("            if (!(EXT_PROGRAMA.test(e.nombre) || /\\.(pdf|html?)$/i.test(e.nombre)) || e.tam > 2e7) { ignorados.push(e.nombre); continue; }\n            if (!anotarEntrega(dest, e.nombre, await e.leer(), alumno)) ignorados.push(e.nombre);",
    "            if (!(EXT_PROGRAMA.test(e.nombre) || EXT_DOCUMENTO.test(e.nombre) || /\\.(pdf|html?)$/i.test(e.nombre)) || e.tam > 2e7) { ignorados.push(e.nombre); continue; }\n            if (!(await anotarEntregaDoc(dest, e.nombre, await e.leer(), alumno))) ignorados.push(e.nombre);")
rep("            if (!anotarEntrega(ent, f.name, new Uint8Array(await f.arrayBuffer()), alumnoDeRuta(f.name))) ignorados.push(f.name);",
    "            if (!(await anotarEntregaDoc(ent, f.name, new Uint8Array(await f.arrayBuffer()), alumnoDeRuta(f.name)))) ignorados.push(f.name);")
rep("        let progs = xs.filter(x => x.tipo === 'programa'); if (!progs.length) progs = xs.filter(x => x.tipo === 'texto');",
    "        let progs = xs.filter(x => x.tipo === 'programa'); if (!progs.length) progs = xs.filter(x => x.tipo === 'texto'); if (!progs.length && !xs.some(x => x.tipo === 'informe')) progs = xs.filter(x => x.tipo === 'docsin');")
rep("        const items = progs.map(x => ({ alumno: progs.length > 1 ? `${alumno} · ${x.archivo}` : alumno, archivo:x.archivo, texto:x.texto }));",
    "        const items = progs.map(x => ({ alumno: progs.length > 1 ? `${alumno} · ${x.archivo}` : alumno, archivo:x.archivo, texto:x.texto, ...(x.formato ? { formato:x.formato } : {}) }));")
rep("        items.forEach(it => { corregirAlumno(it); masiva.lista.push(it); n++; if (it.informe) nInf++; });",
    "        items.forEach(it => { corregirAlumno(it); masiva.lista.push(it); n++; if (it.informe) nInf++; if (it.formato) nFmt++; });")
rep("    let n = 0, nInf = 0;\n    grupos.forEach", "    let n = 0, nInf = 0, nFmt = 0;\n    grupos.forEach")
rep("${nInf ? ` · ${nInf} con informe de entrega` : ''}", "${nInf ? ` · ${nInf} con informe de entrega` : ''}${nFmt ? ` · ⚠️ ${nFmt} en un formato de archivo incorrecto (documento en lugar de texto)` : ''}")
rep('accept=".nc,.txt,.iso,.cnc,.tap,.gcode,.ngc,.mpf,.h,.zip,.pdf"', 'accept=".nc,.txt,.iso,.cnc,.tap,.gcode,.ngc,.mpf,.h,.zip,.pdf,.odt,.docx,.doc,.rtf"')
# la marca junto al nombre
rep("""(estadoInforme(it))}</td>
            <td>${VER_TXT[v.veredicto]}</td>""", """(estadoInforme(it))}${it.formato ? ` <span class="mv-inf mal" title="${esc(it.formato)}">📄⚠️</span>` : ''}</td>
            <td>${VER_TXT[v.veredicto]}</td>""")
# el resumen
rep("· aprueban <strong>${aprob}</strong> de ${n}`;", "· aprueban <strong>${aprob}</strong> de ${n}${(f => f ? ` · <span style=\"color:#b0301f\" title=\"Han entregado un documento (Word, LibreOffice…) en lugar de un archivo de texto\">📄⚠️ formato de archivo incorrecto: <strong>${f}</strong></span>` : '')(L.filter(it => it.formato).length)}`;")
# el CSV
rep("'Seguridad', 'Informe de entrega', 'Observaciones']];", "'Seguridad', 'Informe de entrega', 'Formato del archivo', 'Observaciones']];")
rep("(e => e ? e.txt : '')(estadoInforme(it)), obs]); });", "(e => e ? e.txt : '')(estadoInforme(it)), it.formato || 'Correcto', obs]); });")
# el informe impreso
rep("""            ${(e => e ? `<div class="ar" style="margin:-4px 0 8px;color:${e.ok ? '#1e7a46' : '#b0301f'}">🧾 ${esc(e.txt)}</div>` : '')(estadoInforme(it))}""",
    """            ${(e => e ? `<div class="ar" style="margin:-4px 0 8px;color:${e.ok ? '#1e7a46' : '#b0301f'}">🧾 ${esc(e.txt)}</div>` : '')(estadoInforme(it))}
            ${it.formato ? `<div class="ar" style="margin:-4px 0 8px;color:#b0301f;font-weight:600">⚠️ ${esc(it.formato)}</div>` : ''}""")
# al ver su corrección
rep("    const b = document.getElementById('crVolver'); b.style.display = ''; b.textContent = `← Volver a la lista (${it.alumno})`;",
    "    const b = document.getElementById('crVolver'); b.style.display = ''; b.textContent = `← Volver a la lista (${it.alumno})`;\n    if (it.formato) setTimeout(() => snack('⚠️ ' + it.formato), 400);")
# la ayuda
rep("si solo entrega el informe, se corrige el programa que lleva dentro.",
    "si solo entrega el informe, se corrige el programa que lleva dentro. Si entrega el programa en un <strong>documento</strong> (LibreOffice .odt, Word .docx o .doc, RTF), aunque lo haya renombrado a .nc o .txt, se corrige igual, pero se avisa de que el formato de archivo es incorrecto (📄⚠️ junto al nombre, en el resumen, en el CSV y en su informe).")
open(P, 'w', encoding='utf-8').write(s)
print('Calcador: la corrección masiva lee los programas entregados en documentos y avisa del formato')
