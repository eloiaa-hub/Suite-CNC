"""Calcador v114 / Corrector v59: el trazado puntúa. Con «Altura de corte incorrecta» (trazado comprobado sin las Z) o con
«Trazado desplazado», la geometría se lleva un porcentaje de sus puntos (criterio nuevo, de partida el 50 %), en proporción
al contorno bien recorrido. En la rúbrica, el apartado de geometría igual.
Uso: python3 trazado_nota.py <carpeta de la suite>   (construir_calcador.sh lo pone tras desplazado.py)"""
import sys, os
AQUI = os.path.dirname(os.path.abspath(__file__))
P = os.path.join(sys.argv[1] if len(sys.argv) > 1 else '.', 'calcador.html')
s = open(P, encoding='utf-8').read()
def rep(a, b, cnt=1):
    global s
    n = s.count(a); assert n == cnt, f'{n} apariciones (se esperaban {cnt}) de: {a[:100]}'
    s = s.replace(a, b)
JS = open(os.path.join(AQUI, 'trazado_nota.js'), encoding='utf-8').read()
rep("// Arrastrar archivos a la ventana de corrección masiva; ordenar por columna", JS + "// Arrastrar archivos a la ventana de corrección masiva; ordenar por columna")
# el criterio, en la corrección masiva (vale también con la rúbrica)
i = s.index('<label class="mv-crit-siempre" title="Completos si no hay rápidos peligrosos">Seguridad'); j = s.index('</label>', i) + len('</label>')
s = s[:j] + '\n                    <label title="Si el recorrido es el de la pieza pero no corta (la fresa no baja de Z0) o está desplazado (otro cero pieza): qué parte de los puntos de geometría se lleva, en proporción al contorno bien recorrido. 0: nada">Trazado sin cortar o desplazado <input type="number" id="mvTraz" min="0" max="100" step="5" style="width:56px" onchange="cambiarRequisitosMasiva()"> % de la geometría</label>' + s[j:]
rep("    g('mvTol').value = String(cfgCorr.tol);", "    g('mvTol').value = String(cfgCorr.tol); if (g('mvTraz')) g('mvTraz').value = pctTrazado();")
rep("    cfgCorr.tol = +g('mvTol').value;", "    cfgCorr.tol = +g('mvTol').value; if (g('mvTraz')) cfgCorr.notaTrazado = Math.max(0, Math.min(100, num('mvTraz', TRAZADO_DEF)));")
# los criterios en el resumen de los informes
rep("""lo pedido ${nf(N.pedido, 1)} y seguridad ${nf(N.seg, 1)}.`;""", """lo pedido ${nf(N.pedido, 1)} y seguridad ${nf(N.seg, 1)}.${pctTrazado() ? ` Si el trazado es el de la pieza pero no corta o está desplazado, el ${pctTrazado()} % de la geometría.` : ''}`;""")
rep("""En la geometría, −${nf(N.pen, 2)} por cada corte que se mete en la pieza.`; }""", """En la geometría, −${nf(N.pen, 2)} por cada corte que se mete en la pieza${pctTrazado() ? `; con el trazado de la pieza sin cortar o desplazado, el ${pctTrazado()} %` : ''}.`; }""")
rep("""y en la lista sale «· trazado desplazado».""", """y en la lista sale «· trazado desplazado». En los dos casos, el trazado puntúa: la geometría se lleva el porcentaje de «Trazado sin cortar o desplazado» (de partida, el 50 %).""")
open(P, 'w', encoding='utf-8').write(s)
print('Calcador: el trazado sin cortar o desplazado puntúa')
