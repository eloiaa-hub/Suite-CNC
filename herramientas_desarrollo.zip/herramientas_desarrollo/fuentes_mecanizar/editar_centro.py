"""Calcador v104: editar el centro de un arco por teclado. Doble clic sobre la cruz del centro (o sobre la cota de su
posición): X Y desde el cero pieza o I J desde el inicio del arco, con vista previa en discontinua antes de aplicar.
«Se mantienen los extremos» (el centro va a la mediatriz) o «se mueve el final del arco» (por la recta siguiente).
Un círculo completo se mueve entero. Se puede deshacer.
Uso: python3 editar_centro.py <carpeta de la suite>   (construir_calcador.sh lo pone tras fin_programa.py)"""
import sys, os
AQUI = os.path.dirname(os.path.abspath(__file__))
P = os.path.join(sys.argv[1] if len(sys.argv) > 1 else '.', 'calcador.html')
s = open(P, encoding='utf-8').read()
def rep(a, b, cnt=1):
    global s
    n = s.count(a); assert n == cnt, f'{n} apariciones (se esperaban {cnt}) de: {a[:100]}'
    s = s.replace(a, b)
JS = open(os.path.join(AQUI, 'editar_centro.js'), encoding='utf-8').read()
rep("function abrirEditorCota(ref, sx, sy) {", JS + "function abrirEditorCota(ref, sx, sy) {")
rep("    if (ref.tipo === 'cen') { snack('Cota de referencia: el centro del arco depende de sus extremos y su radio (cámbialos para moverlo)'); return; }",
    "    if (ref.tipo === 'cen') { abrirEditorCentro(ref.ci, ref.si, sx, sy); return; }")
rep("""    const { sx, sy } = posEvento(e);
    const k = cotaEnPantalla(sx, sy);
    if (k) { e.preventDefault(); abrirEditorCota(k.ref, sx, sy); return; }""", """    const { sx, sy } = posEvento(e);
    const hc = arcoEnCentro(sx, sy);
    if (hc) { e.preventDefault(); abrirEditorCentro(hc.ci, hc.si, sx, sy); return; }
    const k = cotaEnPantalla(sx, sy);
    if (k) { e.preventDefault(); abrirEditorCota(k.ref, sx, sy); return; }""")
rep("function cerrarCtx() { ctxPanel.classList.remove('visible'); if (cotaEdit) { cotaEdit = null; render(); } }",
    "function cerrarCtx() { ctxPanel.classList.remove('visible'); if (cotaEdit) { cotaEdit = null; render(); } if (typeof centroEd !== 'undefined' && centroEd) { centroEd = null; render(); } }")
rep("    dibujarPrevia(V);\n    dibujarCaja();", "    dibujarPrevia(V);\n    dibujarPreviaCentro();\n    dibujarCaja();")
# la ayuda
rep("<p>Con «Acotar automáticamente» activo, haz <strong>doble clic sobre el número</strong>",
    "<p><strong>El centro de un arco, por teclado</strong>: doble clic sobre la cruz de su centro (o sobre la cota de su posición). Se escribe en <strong>X Y</strong> (desde el cero pieza) o en <strong>I J</strong> (desde el inicio del arco, el punto verde), y el arco nuevo se ve en discontinua naranja antes de aplicar. Con los extremos fijos, el centro solo puede estar en su mediatriz (se lleva a ella); con «se mueve el final del arco», el inicio y el centro quedan como los escribes y el final se desliza por la recta siguiente. Un círculo se mueve entero. Intro aplica, Esc cancela, y se puede deshacer.</p>\n            <p>Con «Acotar automáticamente» activo, haz <strong>doble clic sobre el número</strong>")
open(P, 'w', encoding='utf-8').write(s)
print('Calcador: editar el centro de un arco por teclado (doble clic sobre su cruz)')
