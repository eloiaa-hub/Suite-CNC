// Capturas del manual del Corrector con la interfaz nueva (v44): la pantalla y el programa de la pieza en el panel derecho.
// Uso: node capt_corrector.js && python3 numerar.py      (desde esta carpeta; deja las imágenes en capturas/)
const path = require('path');
const { lanzar, SUITE } = require(path.join(__dirname, '../../pruebas/comun'));
const CAP = path.join(__dirname, 'capturas'), PIEZA = path.join(__dirname, 'utn_ejercicio_3.json');
(async () => {
  const b = await lanzar(); const ctx = await b.newContext({ viewport: { width: 1440, height: 900 }, deviceScaleFactor: 1.5 });
  const p = await ctx.newPage(); p.on('pageerror', e => console.log('ERR', e.message));
  await p.goto('file://' + path.join(SUITE, 'corrector.html')); await p.evaluate(() => localStorage.clear()); await p.reload(); await p.waitForTimeout(1200);
  await p.setInputFiles('#fileJSON', PIEZA); await p.waitForTimeout(900);
  const limpio = () => p.evaluate(() => document.querySelectorAll('.snackbar, #snackbar').forEach(s => s.style.display = 'none'));
  await p.evaluate(() => { encuadrar(); }); await limpio(); await p.waitForTimeout(300);
  await p.screenshot({ path: path.join(CAP, 'pantalla.png') }); console.log('✓ pantalla.png');
  // el programa de la pieza con G41/G42 según el trazado, a mitad del recorrido
  await p.evaluate(() => { cfgMec.comp = 'auto'; tuPintarMec(); tuRefrescar(true); document.getElementById('tuMec').open = false; tuInicio(); for (let i = 0; i < 12; i++) tuPaso(1); });
  await limpio(); await p.waitForTimeout(500);
  await p.screenshot({ path: path.join(CAP, 'recorrido.png') }); console.log('✓ recorrido.png');
  await b.close();
})();
