"""Calcador v115 / Corrector v60: diagnóstico de la pieza en espejo (o girada 180°) y de G90/G91 confundidos: el primer
error dice qué pasa y la lista lo marca. Los demás errores y la nota no cambian.
Uso: python3 diagnostico.py <carpeta de la suite>   (construir_calcador.sh lo pone tras trazado_nota.py)"""
import sys, os
AQUI = os.path.dirname(os.path.abspath(__file__))
P = os.path.join(sys.argv[1] if len(sys.argv) > 1 else '.', 'calcador.html')
s = open(P, encoding='utf-8').read()
def rep(a, b, cnt=1):
    global s
    n = s.count(a); assert n == cnt, f'{n} apariciones (se esperaban {cnt}) de: {a[:100]}'
    s = s.replace(a, b)
JS = open(os.path.join(AQUI, 'diagnostico.js'), encoding='utf-8').read()
rep("// Arrastrar archivos a la ventana de corrección masiva; ordenar por columna", JS + "// Arrastrar archivos a la ventana de corrección masiva; ordenar por columna")
rep("""Si un programa no corta porque la fresa nunca baja de Z0""", """También se diagnostica la <strong>pieza en espejo</strong> (o girada 180°: los signos de las X o las Y cambiados) y las <strong>coordenadas incrementales con G90</strong> (o absolutas con G91). Si un programa no corta porque la fresa nunca baja de Z0""")
open(P, 'w', encoding='utf-8').write(s)
print('Calcador: diagnóstico de la pieza en espejo y de G90/G91 confundidos')
