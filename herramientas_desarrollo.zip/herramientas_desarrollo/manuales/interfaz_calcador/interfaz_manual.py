"""Manual del Calcador con la interfaz nueva (v95): la barra superior con Nuevo/Abrir/Guardar/Biblioteca,
el panel izquierdo en pestañas y el panel derecho con el programa de la pieza. Cambia los textos y las capturas.
Uso: python3 interfaz_manual.py <manual_calcador.html>     (las capturas, de capt_calcador.js, en capturas/)"""
import sys, re, os, base64, io
from PIL import Image
P = sys.argv[1]; IMG = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'capturas')
s = open(P, encoding='utf-8').read()
assert 'pestaña ◯ Contornos' not in s, 'El manual ya tiene la interfaz nueva'

def rep(a, b, cnt=1):
    global s
    n = s.count(a)
    assert n == cnt, f'{n} apariciones (se esperaban {cnt}) de: {a[:100]}'
    s = s.replace(a, b)

def webp(im, q=86):
    if isinstance(im, str): im = Image.open(os.path.join(IMG, im))
    b = io.BytesIO(); im.convert('RGB').save(b, 'WEBP', quality=q, method=6)
    return 'data:image/webp;base64,' + base64.b64encode(b.getvalue()).decode()

def cambiar_img(alt_inicio, im, alt_nuevo=None, clase=None, q=86):
    global s
    m = re.search(r'<img src="data:image/[^"]+" alt="' + re.escape(alt_inicio), s)
    assert m, alt_inicio
    i = m.start(); j = s.index('"', i + 10)
    s = s[:i] + '<img src="' + webp(im, q) + s[j:]
    if clase:
        f = s.rindex('<figure class="', 0, i); g = s.index('"', f + 15)
        s = s[:f + 15] + clase + s[g:]
    if alt_nuevo:
        i = s.index('<img src="data:', s.rindex('<figure', 0, i + 20))
        k = s.index('alt="', i); k2 = s.index('"', k + 5); viejo = s[k + 5:k2]
        s = s[:k + 5] + alt_nuevo + s[k2:]
        s = s.replace('<figcaption>' + viejo + '</figcaption>', '<figcaption>' + alt_nuevo + '</figcaption>', 1)

# ── Portada ──
s, n = re.subn(r'Calcador de contornos v\d+ · Por Eloi', 'Calcador de contornos v95 · Por Eloi', s); assert n == 1

# ── 1. Presentación ──
rep('guárdalo como archivo con <span class="boton">💾 Guardar (.json)</span> (capítulo 17).',
    'guárdalo como archivo con <span class="boton">💾 Guardar</span> de la barra superior (capítulo 17).')

# ── 2. La pantalla ──
cambiar_img('Las zonas de la pantalla del programa.', 'pantalla_num.png')
i = s.index('<table class="leyenda">', s.index('id="pantalla"')); j = s.index('</table>', i) + 8
fila = lambda n, t: f'<tr><td><span class="marca-num">{n}</span></td><td>{t}</td></tr>'
s = s[:i] + '<table class="leyenda"><thead><tr><th></th><th>Zona</th></tr></thead><tbody>' + ''.join([
    fila(1, '<strong>Barra superior.</strong> Nombre del proyecto (se usa al guardar los archivos; un punto naranja ● avisa de cambios sin guardar en archivo), los botones de archivo <span class="boton">🗋 Nuevo</span>, <span class="boton">📂 Abrir</span>, <span class="boton">💾 Guardar</span> y <span class="boton">🗂 Biblioteca</span>, <span class="boton">📖 Manual</span>, la ayuda rápida ❓ y ⚙️ para el modo oscuro y el color de la interfaz.'),
    fila(2, '<strong>Barra de estado.</strong> A la izquierda, la herramienta activa y lo que espera de ti en cada momento («Clic en el segundo punto…»). A la derecha, el imán que está actuando y las coordenadas X e Y del cursor.'),
    fila(3, '<strong>Barra de herramientas.</strong> Editar, dibujo (línea, arcos, círculo, ranura), formas (rectángulo, polígono, estrella, elipse), equidistante, cota manual, auxiliares y, abajo, las herramientas del fondo: calibrar, mover fondo, origen y medir. Pasa el ratón por encima de cada icono para ver su nombre y su tecla. Si la pantalla es baja (un portátil, una pantalla táctil o con el zoom del navegador), la barra se reparte sola en dos o más columnas para que se vean todas.'),
    fila(4, '<strong>Panel izquierdo.</strong> Las opciones, en tres grupos de pestañas: arriba, <strong>🧩 Ejercicios</strong> (aleatorio, hoja, soluciones, variantes, cuestionario de Aules y ejercicio para el Tutor) y <strong>✅ Corregir</strong> (un programa o toda la clase); en medio, <strong>Dibujo</strong> (con los desplegables Imanes y Comprobar con la fresa), <strong>Construcción</strong> y <strong>Formas</strong>; abajo, <strong>Fondo</strong> y <strong>Exportar</strong> (DXF y SVG). La pestaña del medio cambia sola: al elegir una forma se abre Formas; al elegir Auxiliares, Construcción, y con las demás herramientas, Dibujo. El panel se desplaza con la rueda del ratón.'),
    fila(5, '<strong>Lienzo.</strong> El dibujo, sobre una rejilla milimetrada. El eje X crece hacia la derecha y el eje Y hacia arriba, como en la máquina.'),
    fila(6, '<strong>Caja de coordenadas.</strong> Se activa en cuanto empiezas a escribir con una herramienta de dibujo: permite dar puntos exactos por teclado.'),
    fila(7, '<strong>Zoom y Encuadrar.</strong> Acercar, alejar y encuadrar todo el dibujo.'),
    fila(8, '<strong>Panel derecho: el mecanizado.</strong> Arriba se elige qué programa se ve: <span class="boton">📋 Solución</span> (el de la tabla de soluciones, comentado línea a línea) o <span class="boton">⚙️ Máquina</span> (el de ⚙️ Mecanizar, con pasadas, puentes y cajeras). Debajo, <strong>⚙️ Mecanizado</strong>: coordenadas, compensación, fresa (T y Ø, o una de la base de herramientas), profundidad, pasada, avances, giro, Z de seguridad y orden, y el botón de la <strong>Ventana de Mecanizar</strong> (capítulo 21).'),
    fila(9, '<strong>Panel derecho: las pestañas.</strong> <strong>📜 Programa</strong>: el programa de la pieza, que se escribe solo mientras dibujas, con el reproductor, <span class="boton">⬇ Guardar .nc</span> y <span class="boton">➜ Simulador 3D</span> (capítulo 20). <strong>📋 Puntos</strong>: las coordenadas de cada punto. <strong>◯ Contornos</strong>: la lista de contornos (EXT exterior, INT interior, ABIERTO, TEXTO) y las propiedades de lo que tengas seleccionado: tipo, mecanizado, invertir, borrar, transformaciones y operaciones con formas. Al seleccionar algo con la herramienta Editar, se abre sola.'),
]) + '</tbody></table>' + s[j:]

# ── 3. Tutorial ──
cambiar_img('La lámina recién cargada, aún sin calibrar.', 'recien.png')
cambiar_img('Calibración con la cota de 80 mm.', 'calibrar.png')
cambiar_img('Dibujando el arco tangente;', 'arco.png')
rep('<li>En el panel Fondo pulsa <span class="boton">🖼 Cargar imagen, SVG o DXF</span>', '<li>En la pestaña Fondo (abajo, en el panel izquierdo) pulsa <span class="boton">🖼 Cargar imagen, SVG o DXF</span>')
rep('<li>Pulsa <span class="boton">💾 Guardar (.json)</span> en el panel Exportar. El archivo toma el nombre del proyecto de la barra superior.</li><li>Pulsa <span class="boton">🖨 Hoja de ejercicio</span>, rellena el cajetín',
    '<li>Pulsa <span class="boton">💾 Guardar</span> en la barra superior. El archivo toma el nombre del proyecto, que está a su izquierda.</li><li>En la pestaña 🧩 Ejercicios pulsa <span class="boton">🖨 Hoja</span>, rellena el cajetín')
rep('<li>Pulsa <span class="boton">📋 Soluciones</span> para ver la tabla de coordenadas',
    '<li>Pulsa <span class="boton">📋 Soluciones</span>, en la misma pestaña, para ver la tabla de coordenadas')
rep('<li>Pulsa <span class="boton">⚙️ Mecanizar (G-code)…</span> para obtener el programa de la máquina, con su cero, sus entradas y su sentido, y míralo mecanizado con <span class="boton">➜ Abrir en el Simulador</span> (capítulo 21).</li>',
    '<li>En el panel derecho, el programa de la pieza ya está escrito. Pulsa <span class="boton">⚙️ Máquina</span> para ver el programa de la máquina, con su cero, sus entradas, su sentido y sus pasadas, guárdalo con <span class="boton">⬇ Guardar .nc</span> y míralo mecanizado con <span class="boton">➜ Simulador 3D</span> (capítulos 20 y 21).</li>')

# ── Paneles del lado izquierdo ──
cambiar_img('El panel Fondo con una imagen cargada.', 'fondo.png', 'La pestaña Fondo con una imagen cargada.')
rep('Pulsa <span class="boton">🪄 Vectorizar silueta</span> en el panel Fondo.', 'Pulsa <span class="boton">🪄 Vectorizar silueta</span> en la pestaña Fondo.')
rep('Se activan y desactivan con los botones del panel Imanes (azul = activo).', 'Se activan y desactivan con los botones del desplegable <strong>▸ Imanes</strong>, arriba en la pestaña Dibujo (azul = activo).')
cambiar_img('El panel Imanes.', 'imanes.png', 'El desplegable Imanes de la pestaña Dibujo.')
cambiar_img('Opciones del panel Dibujo.', 'dibujo.png', 'La pestaña Dibujo.')
s = s.replace('En el panel Dibujo', 'En la pestaña Dibujo').replace('El panel Dibujo', 'La pestaña Dibujo').replace('del panel Dibujo', 'de la pestaña Dibujo')
rep('Sus opciones aparecen en la sección Formas del panel izquierdo al elegir la herramienta.', 'Sus opciones aparecen en la pestaña Formas del panel izquierdo, que se abre sola al elegir la herramienta.')
s = s.replace('sección Formas', 'pestaña Formas').replace('sección Construcción', 'pestaña Construcción')

# ── Contornos en el panel derecho ──
rep('<li>Clic en un contorno lo selecciona; sus datos aparecen en el panel derecho.</li>', '<li>Clic en un contorno lo selecciona; sus datos aparecen en la pestaña ◯ Contornos del panel derecho, que se abre sola.</li>')
rep('<p>Con uno o varios contornos seleccionados, el panel derecho ofrece:</p>', '<p>Con uno o varios contornos seleccionados, la pestaña ◯ Contornos del panel derecho ofrece:</p>')
rep('<p>En el panel derecho, cada contorno tiene su sección <strong>Mecanizado</strong>, que usa ⚙️ Mecanizar y se guarda en el JSON:</p>',
    '<p>En la pestaña ◯ Contornos del panel derecho, cada contorno tiene su sección <strong>Mecanizado</strong>, que usan el programa ⚙️ Máquina y la Ventana de Mecanizar, y se guarda en el JSON:</p>')
cambiar_img('Mecanizado de un contorno:', 'contornos.png', 'La pestaña ◯ Contornos: el contorno C1 seleccionado, con su mecanizado: corte a 10 mm con 4 puentes de 6 × 3 mm, en posición automática.', clase='media')

cambiar_img('Una placa con dos cajeras', 'cajeras.png')
cambiar_img('Texto seleccionado:', 'texto.png', 'Texto seleccionado: se ve limpio, sin puntos de edición, y la pestaña ◯ Contornos muestra sus datos.')
cambiar_img('Antes: un rectángulo,', 'operaciones.png')
# ── 16. La fresa y la base de herramientas ──
rep('<p>En el panel Fresa, el desplegable <strong>Herramienta</strong> elige una fresa de la <strong>base de herramientas</strong>: pone su diámetro y escribe su número y su nombre («T101 · Fresa plana Ø6») en el campo Herramienta de la hoja del alumno.',
    '<p>En ⚙️ Mecanizado (panel derecho), el desplegable <strong>De la base</strong> elige una fresa de la <strong>base de herramientas</strong>: pone su número T, su diámetro, sus avances, su giro y su pasada, y escribe su número y su nombre («T101 · Fresa plana Ø6») en el campo Herramienta de la hoja del alumno. Si cambias el Ø a mano, se usa la herramienta de la base que tenga ese Ø o, si no hay ninguna, un número libre; debajo se lee cuál.')
rep('<p>En el panel Fresa escribe el diámetro de tu fresa y activa <strong>Comprobar mecanizado</strong>. El programa revisa la pieza y marca:</p>',
    '<p>Escribe el diámetro de tu fresa en ⚙️ Mecanizado (panel derecho) y, en la pestaña Dibujo, abre el desplegable <strong>▸ Comprobar con la fresa</strong> y activa <strong>Comprobar mecanizado</strong>. El programa revisa la pieza y marca:</p>')
cambiar_img('El resumen en el panel Fresa.', 'comprobar.png', 'El resumen, en el desplegable Comprobar con la fresa.')

# ── 17. Guardar y exportar ──
an = Image.open(os.path.join(IMG, 'archivo.png')); ej = Image.open(os.path.join(IMG, 'ejercicios.png')); ex = Image.open(os.path.join(IMG, 'exportar.png'))
comp = Image.new('RGB', (max(an.width, ej.width + ex.width + 16), an.height + 16 + max(ej.height, ex.height)), 'white')
comp.paste(an, (0, 0)); comp.paste(ej, (0, an.height + 16)); comp.paste(ex, (ej.width + 16, an.height + 16))
cambiar_img('El panel Exportar.', comp, 'Arriba, los botones de archivo de la barra superior; debajo, las pestañas 🧩 Ejercicios y Exportar del panel izquierdo.', clase='media')
rep('<p><span class="boton">💾 Guardar (.json)</span> es la vía completa.', '<p><span class="boton">💾 Guardar</span>, en la barra superior, guarda el JSON: es la vía completa.')
rep('las que tengas en <span class="boton">⚙️ Mecanizar</span> al guardarlo.</p>', 'las que tengas en ⚙️ Mecanizado al guardarlo. El botón está en la pestaña 🧩 Ejercicios: <span class="boton">🎓 Para el Tutor</span>.</p>')
rep('<span class="boton">🎓 Ejercicio para el Tutor</span> guarda el mismo JSON', '<span class="boton">🎓 Para el Tutor</span> guarda el mismo JSON')
rep('<p><span class="boton">📂 Abrir .json</span> vuelve a abrirlo en el programa (y en el Corrector). <span class="boton">🗋 Nuevo</span> empieza de cero (se puede deshacer). En el mismo panel están <span class="boton">⚙️ Mecanizar (G-code)…</span> y <span class="boton">➜ Abrir en el Simulador</span> (capítulo 21), <span class="boton">🎲 Variantes para examen…</span> y <span class="boton">📝 Cuestionario para Aules…</span> (capítulo 19) y las hojas, la corrección y la corrección masiva (capítulos 18 y 20).</p>',
    '<p><span class="boton">📂 Abrir</span> vuelve a abrirlo en el programa (y en el Corrector). <span class="boton">🗋 Nuevo</span> empieza de cero (se puede deshacer). En la pestaña 🧩 Ejercicios están las hojas y las soluciones (capítulo 18), <span class="boton">🧩 Aleatorio…</span>, <span class="boton">🎲 Variantes…</span> y <span class="boton">📝 Aules…</span> (capítulo 19); en ✅ Corregir, la corrección de un programa y la de toda la clase (capítulo 20). El programa de la máquina se guarda desde el panel derecho, con <span class="boton">⬇ Guardar .nc</span> (capítulos 20 y 21).</p>')
rep('<h3>DXF y SVG</h3>', '<h3>DXF y SVG</h3>\n<p>Están en la pestaña <strong>Exportar</strong>, abajo en el panel izquierdo; sus opciones, en su desplegable <strong>▸ Opciones de DXF y SVG</strong>.</p>')

# ── 8 y 18: botones de la pestaña Ejercicios ──
rep('<span class="boton">🧩 Ejercicio aleatorio…</span> (arriba del todo en el panel de la izquierda)', '<span class="boton">🧩 Aleatorio…</span> (pestaña 🧩 Ejercicios, arriba en el panel izquierdo)')
rep('<p><span class="boton">🖨 Hoja de ejercicio</span> abre un diálogo', '<p><span class="boton">🖨 Hoja</span>, en la pestaña 🧩 Ejercicios, abre un diálogo')
rep('<p><span class="boton">📋 Soluciones</span> abre la tabla de coordenadas', '<p><span class="boton">📋 Soluciones</span>, en la misma pestaña, abre la tabla de coordenadas')
# ── 19 y 20 ──
rep('<span class="boton">🎲 Variantes para examen…</span> (panel Exportar)', '<span class="boton">🎲 Variantes…</span> (pestaña 🧩 Ejercicios)')
rep('<span class="boton">📝 Cuestionario para Aules…</span> (panel Exportar)', '<span class="boton">📝 Aules…</span> (pestaña 🧩 Ejercicios)')
rep('<li>Pulsa <span class="boton">✅ Corregir programa</span> en el panel Exportar.', '<li>En la pestaña ✅ Corregir pulsa <span class="boton">✅ Un programa</span>.')
rep('<p>Con <span class="boton">📚 Corrección masiva</span> (en el panel Exportar, o', '<p>Con <span class="boton">📚 Toda la clase</span> (en la pestaña ✅ Corregir, o')
rep('El selector de compensación del reproductor de la barra superior hace lo mismo con el programa de la pieza:', 'La <strong>Compensación</strong> de ⚙️ Mecanizado hace lo mismo con el programa de la pieza del panel derecho:')
rep('<em>G41 en todos</em> o <em>G42 en todos</em> sirven para enseñar qué pasa con el lado equivocado, que la barra de estado avisa.</p>',
    '<em>G41 en todos</em> o <em>G42 en todos</em> sirven para enseñar qué pasa con el lado equivocado: el panel lo avisa en un recuadro rojo y el corte que se mete en la pieza se dibuja en rojo.</p>')
rep('<li>El <strong>recorrido de la pieza</strong> (los botones de la barra superior) dibuja la fresa y su huella con el diámetro de la herramienta de cada contorno.</li>',
    '<li>El <strong>recorrido de la pieza</strong> (el reproductor del panel derecho, con ⚙️ Máquina) dibuja la fresa y su huella con el diámetro de la herramienta de cada contorno.</li>')
i = s.index('<h3>Ver el recorrido de la pieza</h3>'); j = s.index('</figure>', i) + 9
s = s[:i] + '''<h3>El programa de la pieza, en el panel derecho</h3>
<p>El panel derecho escribe el programa de la pieza mientras dibujas: cada contorno nuevo añade sus líneas, con un comentario en cada una. Arriba eliges cuál ves:</p>
<ul>
<li><span class="boton">📋 Solución</span>: el de la tabla de soluciones, el que se pide al alumno, con las coordenadas (G90, G91 o mixta) y la compensación de ⚙️ Mecanizado. Con compensación, entra en cada contorno desde un punto de aproximación (F1, F2…) por el lado de la fresa.</li>
<li><span class="boton">⚙️ Máquina</span>: el de ⚙️ Mecanizar, con las pasadas, el acabado, los puentes, las cajeras y los cambios de herramienta de cada contorno.</li>
</ul>
<p>Los botones <span class="boton">⏮ ▏◀ ▶ ▶▏ ⏭</span> recorren el programa sobre el plano: la fresa avanza dejando su huella, la línea en curso se marca en el programa y debajo se explica qué hace. La barra con la tortuga y la liebre cambia la velocidad. También puedes hacer clic en cualquier línea. Con la casilla 📍, las líneas en incrementales (G91) muestran también el punto absoluto al que llega la fresa. Con el teclado: <kbd>←</kbd> <kbd>→</kbd> línea a línea. Si los contornos llevan herramientas distintas, con ⚙️ Máquina la fresa y su huella se dibujan con el diámetro de cada una. Sirve para enseñar en clase el orden de mecanizado, las entradas y el sentido.</p>
<p><span class="boton">⬇ Guardar .nc</span> guarda el programa que se ve, y <span class="boton">➜ Simulador 3D</span> lo abre en el Simulador 3D con el plano. La pestaña <strong>📋 Puntos</strong> da las coordenadas de cada punto del plano. El Corrector conserva el reproductor en su barra superior.</p>
<figure class="ancha"><img src="''' + webp('reproductor.png') + '''" alt="El reproductor del panel derecho, con G41/G42 según el trazado: la fresa recorre el contorno exterior con su huella; la línea en curso está marcada y debajo se explica."><figcaption>El reproductor del panel derecho, con G41/G42 según el trazado: la fresa recorre el contorno exterior con su huella; la línea en curso está marcada y debajo se explica.</figcaption></figure>''' + s[j:]

# ── 21. ⚙️ Mecanizar ──
rep('<p>El botón <span class="boton">⚙️ Mecanizar (G-code)…</span> del panel Exportar abre una ventana que convierte los contornos en el <strong>programa ISO de la máquina</strong>, en milímetros reales y desde el cero pieza del plano. Usa el mecanizado de cada contorno del panel derecho (capítulo 16): operación, profundidad, puentes y cajeras. El programa se rehace solo al cambiar cualquier dato. El Corrector tiene la misma ventana.</p>',
    '<p>El <strong>programa ISO de la máquina</strong>, en milímetros reales y desde el cero pieza del plano, se ve en el panel derecho con <span class="boton">⚙️ Máquina</span>, y se rehace solo al cambiar cualquier dato. Usa el mecanizado de cada contorno de la pestaña ◯ Contornos (capítulo 16): operación, profundidad, puentes y cajeras. Los datos comunes están en ⚙️ Mecanizado, y los que no caben ahí (estrategia, acabado y unidades), en la <strong>Ventana de Mecanizar</strong>: el botón <span class="boton">⚙️ Ventana de Mecanizar: vista previa, resumen y tiempo…</span> la abre con todos los datos, la vista previa con los colores de cada profundidad, el resumen (pasadas, recorrido, tiempo estimado y bloques) y los avisos. Los dos sitios usan los mismos datos: lo que cambies en uno se ve en el otro. El Corrector tiene la misma ventana.</p>')
cambiar_img('La placa del tutorial en ⚙️ Mecanizar:', 'mecanizar.png')
rep('<td>El mismo que el del panel Fresa: al cambiar uno cambia el otro.</td>', '<td>El mismo que el de ⚙️ Mecanizado: al cambiar uno cambia el otro.</td>')
rep('(la sección Fresa aquí; el panel Herramienta', '(el Ø de ⚙️ Mecanizado aquí; el panel Herramienta')

assert 'panel Exportar' not in s.replace('Solo muestra el panel Exportar', ''), re.findall('.{80}panel Exportar.{40}', s)
assert 'panel Fresa' not in s and 'barra superior, junto a la Biblioteca' not in s
open(P, 'w', encoding='utf-8').write(s)
print(f'manual_calcador.html: interfaz nueva ({len(s) // 1024} KB)')
