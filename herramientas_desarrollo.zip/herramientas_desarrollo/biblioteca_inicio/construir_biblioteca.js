// Biblioteca de inicio de la Suite CNC: 40 ejercicios del generador aleatorio del Calcador (4 niveles × 10),
// cada uno en su JSON, un paquete para importarlos de una vez y las hojas y soluciones en PDF.
// Uso: LANG=C.UTF-8 node construir_biblioteca.js      → ../../biblioteca_inicio/
const path = require('path'), fs = require('fs');
const { lanzar, SUITE } = require('../pruebas/comun.js');
const PLAN = require('./plan.js');
const OUT = path.join(SUITE, 'biblioteca_inicio');
const dd = n => String(n).padStart(2, '0');
(async () => {
  fs.rmSync(OUT, { recursive:true, force:true }); fs.mkdirSync(OUT, { recursive:true });
  const b = await lanzar(); const p = await b.newPage({ viewport:{ width:1600, height:1000 } });
  const errs = []; p.on('pageerror', e => errs.push(e.message)); p.on('dialog', d => d.accept());
  await p.goto('file://' + path.join(SUITE, 'calcador.html')); await p.evaluate(() => localStorage.clear()); await p.reload(); await p.waitForTimeout(900);
  const paquete = { tipo:'biblioteca-calcador', version:1, fecha:new Date().toISOString(), ejercicios:[] };
  const resumen = [], pagina = [];
  for (const nv of PLAN.niveles) {
    const dir = path.join(OUT, nv.nombre); fs.mkdirSync(dir, { recursive:true });
    const ejs = await p.evaluate(nv => nv.elegidas.map(([s, ie], k) => {
      const cfg = Object.assign(JSON.parse(JSON.stringify(GEN_CFG0)), JSON.parse(JSON.stringify(GEN_NIVELES[nv.clave].p)), { nivel:nv.clave }, nv.etapas[ie]);
      const r = generarEjercicio(s, cfg); if (!r.contornos.length) throw new Error('sin pieza ' + s);
      r.contornos.forEach(c => { c.uid = nuevoUid(); });
      const antes = { gen:genUltimo, ver:cfgCotas.ver };
      try {
        genUltimo = { semilla:s, cfg }; cfgCotas.ver = true;
        const num = String(nv.n * 100 + k + 1);
        const datos = datosDeEstado({ contornos:r.contornos, aux:[] }, { titulo:`Nivel ${nv.n} · ${nv.titulo} · Ejercicio ${k + 1}`, num, prog:nv.prog[k], herramienta:'Fresa Ø6' },
                                    `Inicio ${num} - ${nv.titulo}`);
        return { datos, svg:svgMini(datos), s, num, piezas:r.piezas, interiores:r.interiores, w:r.w, h:r.h, avisos:r.avisos };
      } finally { genUltimo = antes.gen; cfgCotas.ver = antes.ver; }
    }), nv);
    ejs.forEach((e, k) => {
      const archivo = `${dd(k + 1)} - Inicio ${e.num} (Nº ${e.s}).json`;
      fs.writeFileSync(path.join(dir, archivo), JSON.stringify(e.datos, null, 1));
      paquete.ejercicios.push({ ruta:`Biblioteca de inicio/${nv.nombre}/${archivo}`, archivo, datos:e.datos, meta:{ nivel:'', etiquetas:['Inicio', `Nivel ${nv.n}`] }, anadido:Date.now(), actualizado:Date.now() });
      pagina.push({ nv, k, e, archivo });
      resumen.push(`${nv.n};${k + 1};${e.num};${e.s};${nv.prog[k]};${e.interiores};${Math.round(e.w)}x${Math.round(e.h)};${(e.avisos || []).length}`);
    });
  }
  fs.writeFileSync(path.join(OUT, 'Biblioteca_de_inicio.json'), JSON.stringify(paquete));
  // Hojas y soluciones: se importa el paquete en la biblioteca del Calcador y se imprime cada nivel en lote
  await p.evaluate(async paq => { await bibCargar(); await importarPaqueteBib(paq); await bibCargar(); }, paquete);
  for (const nv of PLAN.niveles) {
    for (const tipo of ['hoja', 'sol']) {
      const html = await p.evaluate(async ([pref, tipo]) => {
        let cap = ''; const orig = window.open;
        window.open = () => ({ document:{ open(){}, write(h){ cap += h; }, close(){} } });
        try { const ids = bib.lista.filter(e => e.ruta.startsWith(pref)).sort((a, b) => a.ruta.localeCompare(b.ruta)).map(e => e.id); await imprimirLoteBib(ids, tipo); }
        finally { window.open = orig; }
        return cap;
      }, [`Biblioteca de inicio/${nv.nombre}/`, tipo]);
      const q = await b.newPage();
      await q.setContent(html.replace(/<script>window\.onload[\s\S]*?<\/script>/, ''), { waitUntil:'load' }); await q.waitForTimeout(300);
      const nombre = `${nv.nombre} - ${tipo === 'hoja' ? 'hojas' : 'soluciones'}.pdf`;
      await q.pdf({ path:path.join(OUT, nombre), preferCSSPageSize:true, printBackground:true }); await q.close();
      console.log(nombre, Math.round(fs.statSync(path.join(OUT, nombre)).size / 1024) + ' KB');
    }
  }
  fs.copyFileSync(path.join(__dirname, 'LEEME_biblioteca.md'), path.join(OUT, 'LEEME.md'));
  fs.writeFileSync(path.join(OUT, 'index.html'), require('./pagina.js')(PLAN, pagina));
  fs.writeFileSync(path.join(__dirname, 'resumen.csv'), 'nivel;n;num;semilla;prog;interiores;tamaño;avisos\n' + resumen.join('\n') + '\n');
  console.log('errores JS', errs); await b.close();
})();
