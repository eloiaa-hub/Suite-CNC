// ── Altura de corte incorrecta: el programa no baja de Z0, pero ¿el recorrido es el de la pieza? ──
// Si no hay ningún corte porque la fresa nunca baja de Z0, se vuelve a corregir el recorrido sin las Z (como si la fresa
// estuviera abajo): «Trazado geométrico correcto · Altura de corte incorrecta», o lo que falla del trazado. La nota no cambia
// (la pieza no se corta), y el veredicto pasa de «Sin programa válido» a «Altura de corte incorrecta».
VER_TXT.altura = '⛔ Altura de corte incorrecta';
const _corregirProgramaAltura = corregirPrograma, _corregirBaseAltura = typeof _corregirProgramaClase === 'function' ? _corregirProgramaClase : corregirPrograma;
corregirPrograma = function (texto) {
    const r = _corregirProgramaAltura.apply(this, arguments);
    if (!r || r.error || !r.prog || !r.prog.hayZ || !r.resumen || r.resumen.cortes || !r.prog.segs.some(s => !s.rapido)) return r;
    const sinZ = String(texto).replace(/\r/g, '').split('\n').map(l => { const i = l.search(/[(;]/); const c = i >= 0 ? l.slice(0, i) : l, com = i >= 0 ? l.slice(i) : '';
        return c.replace(/Z\s*[-+]?(\d+\.?\d*|\.\d+)/gi, '') + com; }).join('\n');
    r._textoSinZ = sinZ;   // (para buscar si el trazado está desplazado)
    let r2; try { r2 = _corregirBaseAltura(sinZ); } catch (e) { r2 = null; } finally { corr = r; }
    if (!r2 || r2.error || !r2.resumen || !r2.resumen.cortes) return r;
    const zs = r.prog.segs.filter(s => !s.rapido).map(s => Math.min(s.z0 === null || s.z0 === undefined ? Infinity : s.z0, s.z1 === null || s.z1 === undefined ? Infinity : s.z1)).filter(isFinite);
    const zMin = zs.length ? Math.min(...zs) : null, cob = Math.max(0, Math.min(1, r2.cobertura === undefined ? 1 : r2.cobertura));
    const geoErr = r2.hallazgos.filter(h => h.tipo === 'error' && (h.cat === 'geometria' || h.cat === 'compensacion') && !/^Falta mecanizar/.test(h.msg));
    // el trazado es correcto si recorre todo el contorno; los cortes que se meterían en la pieza (como llegar al inicio con G1), aparte
    const ok = cob >= 0.995, nE = geoErr.length, cortes = n => `${n} movimiento${n === 1 ? '' : 's'} se meter${n === 1 ? 'ía' : 'ían'} en la pieza`;
    r.trazado = { ok, cob, errores: nE, primero: nE ? (/^(N\d+|l[ií]nea \d+)/i.exec(geoErr[0].msg) || [''])[0] : '' };
    const dondeZ = zMin === null ? 'la fresa no baja nunca (no hay ninguna Z de corte)' : `la fresa corta a Z${fmt(zMin, 3)}, por encima de la pieza`;
    const h0 = r.hallazgos.find(h => /^El programa no tiene ningún movimiento de corte/.test(h.msg));
    const msg = `Altura de corte incorrecta: ${dondeZ}, así que no corta nada. `
        + (ok ? `Trazado geométrico correcto: el recorrido en X Y es el de la pieza.${nE ? ` Pero, con la fresa abajo, ${cortes(nE)} (abajo, «Si bajara la fresa…»): por ejemplo, llegar al punto de inicio con G1 en lugar de G0.` : ''}`
              : `El trazado geométrico tampoco está bien: con la fresa abajo, mecanizaría el ${Math.round(cob * 100)} % del contorno${nE ? ` y ${cortes(nE)}` : ''} (abajo, «Si bajara la fresa…»).`);
    const nuevo = { tipo: 'error', linea: null, cat: 'altura', msg, pista: 'antes de recorrer el contorno, baja a la profundidad de corte: G1 Z-3 F300 (y al terminar, G0 Z20)' };
    if (h0) Object.assign(h0, nuevo); else r.hallazgos.unshift(nuevo);
    geoErr.slice(0, 6).forEach(h => r.hallazgos.push({ tipo: 'aviso', cat: 'altura', linea: h.linea, msg: 'Si bajara la fresa: ' + h.msg }));
    // los «Falta mecanizar…» de todo el contorno sobran: ya lo dice la altura
    r.hallazgos = r.hallazgos.filter(h => !(h.tipo === 'error' && h.cat === 'geometria' && /^Falta mecanizar/.test(h.msg)));
    r.errores = r.hallazgos.filter(h => h.tipo === 'error').length; r.avisos = r.hallazgos.filter(h => h.tipo === 'aviso').length;
    return r;
};
const _valorarCorreccionAltura = valorarCorreccion;
valorarCorreccion = function (r) {
    const v = _valorarCorreccionAltura.apply(this, arguments);
    if (r && r.trazado && v.veredicto === 'vacio') { v.veredicto = 'altura'; v.trazado = r.trazado; }
    return v;
};
function textoSinCorte(it) {
    const t = it && it.r && it.r.trazado;
    if (!t) return 'ningún movimiento de corte';
    return t.ok ? `trazado geométrico correcto · altura de corte incorrecta (no baja de Z0)${t.errores ? ` · ojo: con la fresa abajo, ${t.primero || 'un movimiento'} se metería en la pieza` : ''}`
                : `altura de corte incorrecta · el trazado tampoco está bien (${Math.round(t.cob * 100)} % del contorno${t.errores ? `, ${t.errores} movimiento${t.errores === 1 ? '' : 's'} en la pieza` : ''})`;
}
