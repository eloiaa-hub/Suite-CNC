"""Calcador: «🎓 Ejercicio para el Tutor». Guarda el proyecto (.json) marcado como ejercicio para el Tutor G-Code:
el alumno ve el plano con sus cotas, pero no el programa; lo escribe él, línea a línea (✍ Practicar).
Las coordenadas (G90, G91 o mixta) y la compensación son las de ⚙️ Mecanizar.
Uso: python3 tutor_ejercicio.py <carpeta de la suite>   (después de cotas_interiores.py)"""
import sys, os
P = os.path.join(sys.argv[1] if len(sys.argv) > 1 else '.', 'calcador.html')
s = open(P, encoding='utf-8').read()
def rep(a, b, cnt=1):
    global s
    n = s.count(a); assert n == cnt, f'{n} apariciones (se esperaban {cnt}) de: {a[:100]}'
    s = s.replace(a, b)
rep("""💾 Guardar (.json)</button>
""", """💾 Guardar (.json)</button>
                    <button class="btn-action sec" onclick="exportarEjercicioTutor()" title="Guarda el ejercicio para el Tutor G-Code del alumno: verá el plano con sus cotas, pero no el programa, y lo escribirá él, línea a línea. Las coordenadas (G90, G91 o mixta) y la compensación son las de ⚙️ Mecanizar">🎓 Ejercicio para el Tutor</button>
""")
rep("""function abrirEnSimulador(programaMaquina, archivo) {""", """// 🎓 El proyecto marcado como ejercicio para el Tutor G-Code (el alumno no ve su programa)
function exportarEjercicioTutor() {
    const datos = exportarJSON(true); if (!datos) return;
    const coord = ['G90', 'G91', 'mixta'].includes(cfgMec.coord) ? cfgMec.coord : 'G90', comp = ['G40', 'G41', 'G42', 'auto'].includes(cfgMec.comp) ? cfgMec.comp : 'G40';
    datos.tutor = { ejercicio: true, coord, comp };
    descargar(JSON.stringify(datos, null, 2), nombreProyecto() + ' (Tutor).json', 'application/json');
    snack(`Ejercicio para el Tutor guardado: en ${coord === 'mixta' ? 'mixta' : coord}, ${comp === 'G40' ? 'sin compensación' : comp === 'auto' ? 'con G41/G42' : 'con ' + comp} (lo de ⚙️ Mecanizar). El alumno lo abre en el Tutor con «📂 Abrir»`);
}
function abrirEnSimulador(programaMaquina, archivo) {""")
# en el Corrector (visor) no se ve
rep("""    html[data-visor="1"] .params-box.visor-si > button[onclick*="abrirCuestionario"] { order: -2; }""", """    html[data-visor="1"] .params-box.visor-si > button[onclick*="abrirCuestionario"] { order: -2; }
    html[data-visor="1"] .params-box.visor-si > button[onclick*="exportarEjercicioTutor"] { display: none; }""")
open(P, 'w', encoding='utf-8').write(s)
print('Calcador: 🎓 Ejercicio para el Tutor:', P)
