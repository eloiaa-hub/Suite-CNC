// ── Variantes con otras medidas: alargar o acortar la pieza por un corte (como «estirar» en CAD) ──
// Un corte vertical (para el ancho) u horizontal (para el alto) que solo atraviesa rectas perpendiculares a él: todo lo que
// queda a un lado se desplaza los mm pedidos. Los arcos no se tocan (se mueven enteros) y las rectas cortadas se alargan
// o acortan sin cambiar de dirección, así que se conservan las tangencias, los radios y los agujeros; cambian las cotas.
Object.assign(varCfg, { medidas: varCfg.medidas || false, mm: varCfg.mm || '10, -10' });
const HUECO_MIN = 5;   // al acortar, lo que tiene que quedar como mínimo entre las dos partes (mm)
function corteEstirar(cs, eje) {
    const o = eje === 'x' ? 'y' : 'x', T = [].concat(...cs.map(c => tramos(c)));
    if (!T.length) return null;
    const vals = [...new Set([].concat(...cs.map(c => c.pts.map(p => +p[eje].toFixed(6)))))].sort((a, b) => a - b);
    const ext = t => { const m = muestrearTramo(t); return [Math.min(...m.map(p => p[eje])), Math.max(...m.map(p => p[eje]))]; };
    const E = T.map(t => ({ t, e: ext(t) }));
    const lo = Math.min(...E.map(({ e }) => e[0])), hi = Math.max(...E.map(({ e }) => e[1])), mitad = (lo + hi) / 2;
    let mejor = null;
    for (let k = 0; k + 1 < vals.length; k++) {
        const x = (vals[k] + vals[k + 1]) / 2;
        // lo que cruza el corte: solo rectas perpendiculares a él
        if (E.some(({ t, e }) => e[0] < x - 1e-9 && e[1] > x + 1e-9 && (t.b || Math.abs(t.p1[o] - t.p2[o]) > 1e-6))) continue;
        // el hueco libre entre las dos partes (para poder acortar): de lo último a un lado a lo primero al otro (los arcos, con su bombeo)
        const izq = Math.max(...E.filter(({ e }) => e[1] <= x + 1e-9).map(({ e }) => e[1])), der = Math.min(...E.filter(({ e }) => e[0] >= x - 1e-9).map(({ e }) => e[0]));
        const c = { x, hueco: der - izq, lo, hi };
        if (!mejor || Math.abs(x - mitad) < Math.abs(mejor.x - mitad)) mejor = c;
    }
    return mejor;
}
function estirarEstado(est, med) {
    if (!med || (!med.x && !med.y)) return est;
    const mueve = p => ({ x: p.x + (med.x && p.x > med.cx ? med.x : 0), y: p.y + (med.y && p.y > med.cy ? med.y : 0) });
    est.contornos.forEach(c => { c.pts = c.pts.map(mueve); delete c.forma; if (c.mec && c.mec.puentes && Array.isArray(c.mec.puentes.pts)) c.mec.puentes.pts = c.mec.puentes.pts.map(mueve); });
    est.aux = est.aux.map(e => e.t === 'P' ? { ...e, p: mueve(e.p) } : e.t === 'C' ? { ...e, c: mueve(e.c) } : e.t === 'L' ? { ...e, p: mueve(e.p) } : e);
    // el cero pieza sigue al punto en el que estaba (si estaba en un vértice, sigue en él)
    const O = mueve({ x: 0, y: 0 }), D = p => ({ x: +(p.x - O.x).toFixed(6), y: +(p.y - O.y).toFixed(6) });
    if (O.x || O.y) {
        est.contornos.forEach(c => { c.pts = c.pts.map(D); if (c.mec && c.mec.puentes && Array.isArray(c.mec.puentes.pts)) c.mec.puentes.pts = c.mec.puentes.pts.map(D); });
        est.aux = est.aux.map(e => e.t === 'P' ? { ...e, p: D(e.p) } : e.t === 'C' ? { ...e, c: D(e.c) } : e.t === 'L' ? { ...e, p: D(e.p) } : e);
    }
    return est;
}
const _transformarEstadoBase = transformarEstado;
transformarEstado = function (est, sp) { return _transformarEstadoBase(estirarEstado(est, sp.med), sp); };
// Las medidas que se pueden cambiar (y cuánto), con los cortes del ejercicio abierto
function medidasPosibles() {
    if (!varCfg.medidas || hayTextos()) return [];
    const cs = contornos.filter(c => c.pts.length >= 2), cx = corteEstirar(cs, 'x'), cy = corteEstirar(cs, 'y');
    const ds = String(varCfg.mm).split(/[;,\s]+/).map(x => parseFloat(x.replace(',', '.'))).filter(d => isFinite(d) && Math.abs(d) >= 0.5 && Math.abs(d) <= 200);
    const vale = (c, d) => c && (d > 0 || c.hueco - Math.abs(d) >= HUECO_MIN);
    const out = [];
    ds.forEach(d => { if (vale(cx, d)) out.push({ x: d, y: 0, cx: cx.x, cy: cy ? cy.x : 0, ancho: cx.hi - cx.lo }); });
    ds.forEach(d => { if (vale(cy, d)) out.push({ x: 0, y: d, cx: cx ? cx.x : 0, cy: cy.x, alto: cy.hi - cy.lo }); });
    if (ds.length && vale(cx, ds[0]) && vale(cy, ds[0])) out.push({ x: ds[0], y: ds[0], cx: cx.x, cy: cy.x, ancho: cx.hi - cx.lo, alto: cy.hi - cy.lo });
    return out;
}
especificacionesVariantes = function () {
    const textos = hayTextos();
    const geos = [{ ex:0, ey:0 }];
    if (!textos && varCfg.ex) geos.push({ ex:1, ey:0 }); if (!textos && varCfg.ey) geos.push({ ex:0, ey:1 }); if (!textos && varCfg.giro) geos.push({ ex:1, ey:1 });
    const b0 = bboxPts([].concat(...contornos.filter(c => c.pts.length >= 2).map(c => muestrearContorno(c))));
    const u = (0 - b0.x0) / ((b0.x1 - b0.x0) || 1), v = (0 - b0.y0) / ((b0.y1 - b0.y0) || 1), propia = (v < 0.5 ? 'B' : 'T') + (u < 0.5 ? 'L' : 'R');
    const ceros = ['mismo'].concat(varCfg.cero ? ['BL', 'BR', 'TL', 'TR'].filter(k => k !== propia) : []);
    const escalas = [1].concat(!textos && varCfg.escala ? String(varCfg.factores).split(/[;,\s]+/).map(x => parseFloat(x.replace(',', '.')) / 100).filter(f => f > 0.2 && f < 5 && Math.abs(f - 1) > 1e-9) : []);
    const meds = [null].concat(medidasPosibles());
    const todas = []; geos.forEach(g => ceros.forEach(c => escalas.forEach(e => meds.forEach(m => todas.push({ ...g, cero:c, escala:e, med:m })))));
    const id = todas[0], resto = todas.slice(1);
    const dif = (a, b) => (a.ex !== b.ex || a.ey !== b.ey ? 2 : 0) + (a.cero !== b.cero ? 1 : 0) + (a.escala !== b.escala ? 1 : 0) + (a.med !== b.med ? 2 : 0);
    const elegidas = varCfg.aOriginal ? [id] : [];
    while (elegidas.length < varCfg.n && resto.length) {
        let mejor = 0, md = -1; resto.forEach((c, i) => { const m = elegidas.length ? Math.min(...elegidas.map(e => dif(c, e))) : 9; if (m > md) { md = m; mejor = i; } });
        elegidas.push(resto.splice(mejor, 1)[0]);
    }
    return { elegidas, textos };
};
const _describirVarianteBase = describirVariante;
describirVariante = function (sp) {
    const t = _describirVarianteBase(sp), m = sp.med; if (!m) return t;
    const nf = x => String(Math.round(x * 100) / 100).replace('.', ','), sg = d => (d > 0 ? '+' : '−') + nf(Math.abs(d));
    const q = []; if (m.x) q.push(`ancho ${nf(m.ancho + m.x)} mm (${sg(m.x)})`); if (m.y) q.push(`alto ${nf(m.alto + m.y)} mm (${sg(m.y)})`);
    return (t === 'el ejercicio original' ? '' : t + ' · ') + q.join(' · ');
};
const _abrirVariantesMed = abrirVariantes, _cambiarVariantesMed = cambiarVariantes;
abrirVariantes = function () {
    const g = id => document.getElementById(id);
    if (g('varMed')) { g('varMed').checked = varCfg.medidas; g('varMm').value = varCfg.mm; g('varMed').disabled = hayTextos(); }
    return _abrirVariantesMed.apply(this, arguments);
};
cambiarVariantes = function () {
    const g = id => document.getElementById(id);
    if (g('varMed')) { varCfg.medidas = g('varMed').checked; varCfg.mm = g('varMm').value; }
    return _cambiarVariantesMed.apply(this, arguments);
};
