#!/usr/bin/env python3
"""Calcador v129: vaciar la biblioteca; al importar con ejercicios, elegir entre agregar o sustituir;
las opciones de la cota manual pasan a Dibujo, en un apartado plegable.
Uso: python3 biblioteca_cotaman.py CARPETA_DE_LA_SUITE (después de g91_total.py)."""
import os, re, sys
d = sys.argv[1] if len(sys.argv) > 1 else '.'
p = os.path.join(d, 'calcador.html'); s = open(p, encoding='utf-8').read()
def rep(a, b):
    global s
    assert s.count(a) == 1, (s.count(a), a[:80]); s = s.replace(a, b)
# ── Vaciar ──
rep('''Se recupera con «Importar archivos…»">⬇ Exportar biblioteca</button>''', '''Se recupera con «Importar archivos…»">⬇ Exportar biblioteca</button>
                <button class="btn-action sec" id="bibVaciar" onclick="vaciarBiblioteca()" title="Borra todos los ejercicios de la biblioteca de este navegador. Los archivos originales no se tocan">🗑 Vaciar biblioteca</button>''')
# ── Importar: se lee todo, se pregunta y después se escribe ──
i = s.index('async function importarArchivosBib(files) {'); j = s.index('// Copia de seguridad: un único archivo con los ejercicios')
s = s[:i] + r"""const bibVaciarAlmacen = async () => { await bibTx('readwrite', st => st.clear()); bib.lista = []; bib.sel.clear(); };
async function vaciarBiblioteca() {
    await bibCargar();
    const n = bib.lista.length;
    if (!n) { snack('La biblioteca ya está vacía'); return; }
    if (!confirm(`¿Borrar ${n === 1 ? 'el ejercicio' : `los ${n} ejercicios`} de la biblioteca?\n\nNo se puede deshacer. Los archivos originales no se tocan, pero lo que solo esté en la biblioteca se pierde: si quieres conservarlo, cancela y usa «Exportar biblioteca».`)) return;
    await bibVaciarAlmacen(); await bibCargar(); pintarBiblioteca();
    snack('Biblioteca vaciada');
}
// Pregunta qué hacer con lo que ya hay. Devuelve 'agregar', 'sustituir' o null
function preguntarImportarBib(hay, llegan) {
    return new Promise(res => {
        const o = document.createElement('div'); o.className = 'modal-overlay visible'; o.id = 'bibPregunta';
        const ej = n => n === 1 ? '1 ejercicio' : n + ' ejercicios';
        o.innerHTML = `<div class="help-modal" style="max-width:480px"><div class="help-header"><h2>Importar a la biblioteca</h2></div>
            <div style="padding:14px 18px;display:flex;flex-direction:column;gap:10px">
            <p style="margin:0">La biblioteca ya tiene <strong>${ej(hay)}</strong> y vas a importar <strong>${ej(llegan)}</strong>.</p>
            <button class="btn-action" data-r="agregar" title="Un ejercicio que ya esté en la biblioteca se actualiza; el resto se queda como está">➕ Agregar a la biblioteca</button>
            <button class="btn-action sec" data-r="sustituir">🔁 Sustituir toda la biblioteca</button>
            <div class="ctx-nota">Sustituir borra lo que hay ahora y no se puede deshacer. Si quieres conservarlo, cancela y usa «Exportar biblioteca».</div>
            <button class="btn-action sec" data-r="">Cancelar</button></div></div>`;
        const fin = r => { o.remove(); res(r || null); };
        o.addEventListener('click', e => { if (e.target === o) { fin(null); return; } const b = e.target.closest('button[data-r]'); if (b) fin(b.dataset.r); });
        document.body.appendChild(o);
        o.querySelector('button[data-r="agregar"]').focus();
    });
}
async function importarArchivosBib(files) {
    const lista = [...files].filter(f => /\.json$/i.test(f.name) && f.size < 5e6);
    if (!lista.length) { snack('No se ha encontrado ningún archivo .json'); return; }
    let nuevos = 0, act = 0, malos = 0, llegan = 0;
    await bibCargar();
    const leidos = [];
    for (const f of lista) {
        const t = await leerArchivoTexto(f); let d = null;
        try { d = JSON.parse(t); } catch (e) {}
        if (esObj(d) && d.tipo === 'biblioteca-calcador' && Array.isArray(d.ejercicios)) {
            const validos = d.ejercicios.filter(x => esObj(x) && esObj(x.datos) && esObj(x.datos.calcador) && Array.isArray(x.datos.calcador.contornos) && entradaDe(x.datos, String(x.ruta || x.archivo || 'importado.json'), String(x.archivo || 'importado.json')).ficha.valido).length;
            llegan += validos; leidos.push({ paquete: d }); continue;
        }
        if (!esObj(d) || !esObj(d.calcador) || !Array.isArray(d.calcador.contornos)) { malos++; continue; }
        const e = entradaDe(d, f.webkitRelativePath || f.name, f.name);
        if (!e.ficha.valido) { malos++; continue; }
        llegan++; leidos.push({ entrada: e });
    }
    if (!llegan) { snack(`No se ha importado nada: ${malos ? malos + ' archivo(s) no son ejercicios del Calcador' : 'no hay ejercicios válidos'}`); return; }
    let modo = 'agregar';
    if (bib.lista.length) {
        modo = await preguntarImportarBib(bib.lista.length, llegan);
        if (!modo) return;
        if (modo === 'sustituir') await bibVaciarAlmacen();
    }
    for (const x of leidos) {
        if (x.paquete) { const r = await importarPaqueteBib(x.paquete); nuevos += r.nuevos; act += r.act; continue; }
        const e = x.entrada;
        if (await bibGuardarEntrada(e)) act++; else nuevos++;
        bib.lista = bib.lista.filter(y => y.id !== e.id); bib.lista.push(e);
    }
    await bibCargar(); pintarBiblioteca();
    snack(`${modo === 'sustituir' ? 'Biblioteca sustituida' : 'Biblioteca'}: ${nuevos} ejercicio(s) nuevo(s)${act ? `, ${act} actualizado(s)` : ''}${malos ? ` · ${malos} archivo(s) no son ejercicios del Calcador` : ''}`);
}
""" + s[j:]
# ── Cotas manuales en Dibujo ──
rep("        cotas.open = true; ajuste.open = true;", "        const cman = det('c2-cotaman', 'Cotas manuales'), fmC = $('fmCota');\n        if (fmC) { cman.appendChild(fmC); fmC.style.display = 'flex'; fmC.style.marginTop = '5px'; }\n        cotas.open = true; ajuste.open = true;")
rep("        dibP.appendChild(cotas); dibP.appendChild(ajuste);", "        dibP.appendChild(cotas); dibP.appendChild(cman); dibP.appendChild(ajuste);\n        actualizarBotonBorrarCotas();")
rep("    document.getElementById('fmCota').style.display = h === 'cotaman' ? 'flex' : 'none';\n    if (h === 'cotaman') actualizarBotonBorrarCotas();",
    """    const fmC = document.getElementById('fmCota'), plegable = fmC.closest('.c2-cotaman');
    if (plegable) { fmC.style.display = 'flex'; actualizarBotonBorrarCotas(); if (h === 'cotaman') plegable.open = true; }   // en Dibujo, en su apartado
    else { fmC.style.display = h === 'cotaman' ? 'flex' : 'none'; if (h === 'cotaman') actualizarBotonBorrarCotas(); }""")
rep("    if (herramienta === 'cotaman') actualizarBotonBorrarCotas();", "    actualizarBotonBorrarCotas();")
m = re.search(r'vertical-align:middle">v(\d+)</span></span>', s); assert m
s = s.replace(m.group(0), m.group(0).replace('v' + m.group(1), 'v129'), 1)
open(p, 'w', encoding='utf-8').write(s); print('calcador.html: biblioteca y cotas manuales, v129')
