#!/usr/bin/env python3
"""Calcador v126: 💾 Guardar datos en 🖨 Hoja, sin imprimir; el título sigue al nombre del proyecto hasta que se escriba otro, y no se arrastra el de otra pieza o variante.
Uso: python3 hoja_datos.py CARPETA_DE_LA_SUITE (después de pieza_contorno.py)."""
import os, re, sys
d = sys.argv[1] if len(sys.argv) > 1 else '.'
p = os.path.join(d, 'calcador.html'); s = open(p, encoding='utf-8').read()
def rep(a, b):
    global s
    assert s.count(a) == 1, (s.count(a), a[:80]); s = s.replace(a, b)
rep('''<button class="btn-action" onclick="imprimirHoja()">🖨 Imprimir</button>''', '''<button class="btn-action sec" onclick="guardarDatosHoja()" title="Guarda estos datos en el ejercicio sin imprimir: los usan las variantes, las soluciones y el reparto">💾 Guardar datos</button>
                <button class="btn-action" onclick="imprimirHoja()">🖨 Imprimir</button>''')
rep("function cerrarHoja() { document.getElementById('modalHoja').classList.remove('visible'); }", r"""function cerrarHoja() { document.getElementById('modalHoja').classList.remove('visible'); }
function guardarDatosHoja() { leerHoja(); cerrarHoja(); snack('Datos de la hoja guardados'); }
// El título sigue al nombre del proyecto hasta que se escriba otro; el de una variante no pasa a otra pieza
const textoNombre = n => String(n || '').replace(/_/g, ' ').trim();
function hojaAlDia() {
    const nom = document.getElementById('projectName').value;
    if (/\(variante [A-Z]\)\s*$/.test(cfgHoja.titulo || '') && !/variante [A-Z]\s*$/i.test(nom)) { cfgHoja.titulo = ''; cfgHoja.num = String(cfgHoja.num || '').replace(/[A-Z]$/, ''); }
}
let nombreHojaPrevio = null;
function seguirNombreHoja() {
    const el = document.getElementById('projectName'); if (nombreHojaPrevio === null) nombreHojaPrevio = el.value;
    if (textoNombre(cfgHoja.titulo) === textoNombre(nombreHojaPrevio)) cfgHoja.titulo = '';
    nombreHojaPrevio = el.value; hojaAlDia();
}
window.addEventListener('DOMContentLoaded', () => { const el = document.getElementById('projectName'); nombreHojaPrevio = el.value; el.addEventListener('focus', () => { nombreHojaPrevio = el.value; }); el.addEventListener('input', seguirNombreHoja); });""")
rep("    const v = { ...cfgHoja };\n    if (!v.titulo) v.titulo = nombreProyecto().replace(/_/g, ' ');", "    hojaAlDia();\n    const v = { ...cfgHoja };\n    if (!v.titulo) v.titulo = nombreProyecto().replace(/_/g, ' ');")
rep("function abrirVariantes() {\n", "function abrirVariantes() {\n    hojaAlDia();\n")
rep("    contornos = [P.cont].concat(P.ints.map(i => i.cont)); aux = [];", "    cfgHoja.titulo = ''; cfgHoja.num = '';\n    contornos = [P.cont].concat(P.ints.map(i => i.cont)); aux = [];")
rep("    contornos = r.contornos; aux = []; auxPend = null; fondo = null; sel = -1; selSet = new Set(); cotasAjuste = {}; cotasManuales = []; dib = null; circ = null; ran = null;\n    if (typeof requisitosPorDefecto === 'function') requisitosPorDefecto();\n    genUltimo = { semilla:s,", "    cfgHoja.titulo = ''; cfgHoja.num = '';\n    contornos = r.contornos; aux = []; auxPend = null; fondo = null; sel = -1; selSet = new Set(); cotasAjuste = {}; cotasManuales = []; dib = null; circ = null; ran = null;\n    if (typeof requisitosPorDefecto === 'function') requisitosPorDefecto();\n    genUltimo = { semilla:s,")
m = re.search(r'vertical-align:middle">v(\d+)</span></span>', s); assert m
s = s.replace(m.group(0), m.group(0).replace('v' + m.group(1), 'v126'), 1)
open(p, 'w', encoding='utf-8').write(s); print('calcador.html: 💾 Guardar datos, v126')
