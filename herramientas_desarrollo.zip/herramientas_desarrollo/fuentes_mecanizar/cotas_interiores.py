"""Calcador: la posición de los agujeros que no son redondos ni ranuras (rectangulares, con chaflanes…).
Hasta ahora solo se acotaban sus medidas, no dónde están: no se podía sacar del plano la coordenada de sus puntos.
Ahora se acota su esquina inferior izquierda (su borde izquierdo y su borde de abajo) desde los bordes de la pieza,
como el centro de los taladros. Uso: python3 cotas_interiores.py <carpeta de la suite>   (después de cierre_arcos.py)"""
import sys, os
P = os.path.join(sys.argv[1] if len(sys.argv) > 1 else '.', 'calcador.html')
s = open(P, encoding='utf-8').read()
def rep(a, b, cnt=1):
    global s
    n = s.count(a); assert n == cnt, f'{n} apariciones (se esperaban {cnt}) de: {a[:100]}'
    s = s.replace(a, b)
rep("""            posicionCentro(ranura.c1, ranura.r + 1.4*h, ranura.r + 1.4*h, { tipo:'agu', ci:i, nombre:'de la ranura' }, { tipo:'agu', ci:i, nombre:'de la ranura' });
        }
""", """            posicionCentro(ranura.c1, ranura.r + 1.4*h, ranura.r + 1.4*h, { tipo:'agu', ci:i, nombre:'de la ranura' }, { tipo:'agu', ci:i, nombre:'de la ranura' });
        }
        // Agujero de otra forma (rectangular, con chaflanes…): dónde está, con su esquina inferior izquierda (su borde izquierdo y su borde de abajo)
        if (!ranura && c.cerrado && tipos[i] === 'interior') {
            const bI = bboxPts(muestrearContorno(c));
            posicionCentro({ x:bI.x0, y:bI.y0 }, 1.4*h, 1.4*h, { tipo:'agu', ci:i, nombre:'del agujero' }, { tipo:'agu', ci:i, nombre:'del agujero' });
        }
""")
rep("""        extra = `<div class="ctx-nota">Distancia del ${nom === 'de la ranura' ? 'primer centro' : 'centro'} al borde ${ref.borde} de la pieza. Mueve ${nom === 'de la ranura' ? 'la ranura' : 'el taladro'} sin cambiar su forma.</div>`;""",
    """        extra = `<div class="ctx-nota">Distancia ${nom === 'del agujero' ? 'del borde ' + (ref.eje === 'x' ? 'izquierdo' : 'de abajo') + ' del agujero' : 'del ' + (nom === 'de la ranura' ? 'primer centro' : 'centro')} al borde ${ref.borde} de la pieza. Mueve ${nom === 'de la ranura' ? 'la ranura' : nom === 'del agujero' ? 'el agujero' : 'el taladro'} sin cambiar su forma.</div>`;""")
open(P, 'w', encoding='utf-8').write(s)
print('Calcador: posición de los agujeros rectangulares y de otras formas:', P)
