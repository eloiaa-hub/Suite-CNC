"""Calcador v101-v102 / Corrector v47-v48: el Corrector revisa el final del programa (v102: también la fresa arriba al terminar y
bajar en diagonal) y la numeración de los bloques.
- Error (seguridad): el programa arranca el husillo y no termina (sin M02 ni M30; un fragmento sin M03, como la tabla
  de la hoja de soluciones de una herramienta, no se revisa), o termina arrancando el husillo (M03/M04 después del último
  corte, sin M05 ni fin de programa): «para terminar, M05 y M30 (o M02)».
- Error (seguridad): el programa termina con la fresa dentro de la pieza (Z<0). Aviso: termina con la fresa abajo (Z<5).
- Aviso: bajar en diagonal (entrar en el material moviéndose en X/Y desde arriba, o con más de 15° de pendiente).
- Aviso: M30 con el husillo en marcha (falta M05 antes); instrucciones después del fin de programa.
- Aviso (no baja la nota): números de bloque de 1 en 1 (mejor N10, N20…), o que no crecen. Sin números de bloque, nada.
Uso: python3 fin_programa.py <carpeta de la suite>   (construir_calcador.sh lo pone tras entregas_documentos.py)"""
import sys, os
P = os.path.join(sys.argv[1] if len(sys.argv) > 1 else '.', 'calcador.html')
s = open(P, encoding='utf-8').read()
def rep(a, b, cnt=1):
    global s
    n = s.count(a); assert n == cnt, f'{n} apariciones (se esperaban {cnt}) de: {a[:100]}'
    s = s.replace(a, b)
i0 = s.index('function interpretarISO(texto) {'); i1 = s.index('\n}\n', i0)
f = s[i0:i1]; s0, s1 = s[:i0], s[i1:]
def repf(a, b):
    global f
    assert f.count(a) == 1, f'interpretarISO: {f.count(a)} de {a[:80]}'
    f = f.replace(a, b)
repf("    let hayF = false, avisoF = false;",
     "    let hayF = false, avisoF = false;\n    const fin = { m:null, li:null, et:'', husillo:false, despues:null, arranque:null, numeros:[] };   // el final del programa y los números de bloque")
repf("        const nPal = palabras.find(w => w.l === 'N'), etiqueta = nPal ? 'N' + nPal.s : 'línea ' + (li + 1);",
     "        const nPal = palabras.find(w => w.l === 'N'), etiqueta = nPal ? 'N' + nPal.s : 'línea ' + (li + 1);\n"
     "        if (nPal) fin.numeros.push({ n:nPal.v, li, etiqueta });\n"
     "        if (fin.m !== null && !fin.despues && palabras.some(w => w.l !== 'N')) fin.despues = { li, etiqueta };")
repf("          if (Ms.includes(3) || Ms.includes(4)) est.husillo = true;\n",
     "          if (Ms.includes(3) || Ms.includes(4)) { est.husillo = true; if (fin.m === null) fin.arranque = { li, etiqueta, m: Ms.includes(4) ? 'M04' : 'M03', nSegs: segs.length }; }\n"
     "          if ((Ms.includes(2) || Ms.includes(30)) && fin.m === null) { fin.m = Ms.includes(30) ? 30 : 2; fin.li = li; fin.et = etiqueta; fin.husillo = est.husillo === true && !Ms.includes(5); fin.arranqueAntes = fin.arranque; fin.z = z; }\n")
repf("    notas.forEach(n => { if (typeof n.seg === 'number') n.seg = segs[n.seg]; });",
     """    // ── El final del programa ──
    const ultimaLinea = (() => { for (let k = lineas.length - 1; k >= 0; k--) if (lineas[k].replace(/\\([^)]*\\)/g, '').replace(/;.*$/, '').trim()) return k; return null; })();
    const hayCorte = segs.some(sg => sg.corte);
    // husillo arrancado después del último corte (y sin pararlo): «N22 M03» al final
    const arr = fin.m === null ? fin.arranque : fin.arranqueAntes, ultCorte = segs.reduce((k, sg, j) => sg.corte ? j : k, -1);
    const arrancaAlFinal = hayCorte && arr && arr.nSegs > ultCorte && (fin.m === null ? est.husillo === true : fin.husillo);
    if (arrancaAlFinal) nota('error', arr.li, `${arr.etiqueta}: ${arr.m} arranca el husillo, y el programa ya ha terminado de cortar. Para terminar se escribe M05 (parar el husillo) y M30 (fin de programa), o M02.`, { cat:'seguridad', pista:'al final: G0 Z20 · M05 · M30' });
    if (fin.m === null && hayCorte && fin.arranque && !arrancaAlFinal) nota('error', ultimaLinea, 'El programa no termina: falta el fin de programa, M05 (parar el husillo) y M30 (o M02).', { cat:'seguridad', pista:'al final: G0 Z20 · M05 · M30' });
    if (fin.m === 30 && fin.husillo && !arrancaAlFinal) nota('aviso', fin.li, `${fin.et}: M30 con el husillo en marcha: escribe antes M05 para pararlo (M30 lo para en muchas máquinas, pero conviene escribirlo).`);
    if (fin.despues) nota('aviso', fin.despues.li, `${fin.despues.etiqueta}: va después del fin de programa (M${String(fin.m).padStart(2, '0')} en ${fin.et}): la máquina termina ahí y no lo ejecuta.`);
    // la fresa, arriba al terminar (los programas con Z)
    const zFin = fin.m !== null ? fin.z : z, lFin = fin.m !== null ? fin.li : ultimaLinea, eFin = fin.m !== null ? fin.et : 'Al final';
    if (hayZ && hayCorte && zFin !== null && zFin !== undefined) {
        if (zFin < -1e-9) nota('error', lFin, `${eFin}: el programa termina con la fresa dentro de la pieza (Z${fmt(zFin, 3)}). Antes del fin, sube a la altura de seguridad (G0 Z20).`, { cat:'seguridad', pista:'al final: G0 Z20 · M05 · M30' });
        else if (zFin < 5 - 1e-9) nota('aviso', lFin, `${eFin}: el programa termina con la fresa abajo (Z${fmt(zFin, 3)}): antes del fin, sube a la altura de seguridad (G0 Z20).`);
    }
    // bajar en diagonal: entrar en el material a la vez que se mueve en X/Y, desde arriba o con mucha pendiente (una rampa suave, de pocos grados, sí vale)
    if (hayZ) {
        const diag = segs.filter(sg => sg.corte && !sg.rapido && sg.z0 !== null && sg.z1 !== null && sg.z1 < -1e-9 && sg.z1 < sg.z0 - 1e-9 && dist(sg.p1, sg.p2) > 1e-6
            && (sg.z0 > 1e-9 || Math.atan2(sg.z0 - sg.z1, dist(sg.p1, sg.p2)) > 15 * Math.PI / 180));
        if (diag.length) { const d0 = diag[0]; nota('aviso', d0.linea, `${d0.etiqueta}: baja en diagonal, de Z${fmt(d0.z0, 3)} a Z${fmt(d0.z1, 3)} a la vez que se mueve en X/Y${diag.length > 1 ? ` (y ${diag.length - 1} más)` : ''}. La fresa no corta bien de punta en diagonal: primero se baja en vertical, con el avance de penetración (G1 Z… F300), y después se corta en X/Y. (Una rampa suave, de pocos grados, sí es una forma de entrar.)`); }
    }
    // ── Los números de bloque (si los hay): de 10 en 10 y siempre creciendo ──
    if (fin.numeros.length >= 3) {
        const N = fin.numeros, baja = N.find((x, k) => k && x.n <= N[k - 1].n);
        if (baja) { const k = N.indexOf(baja); nota('aviso', baja.li, `${baja.etiqueta}: los números de bloque tienen que ir creciendo, y este va después de ${N[k - 1].etiqueta}${baja.n === N[k - 1].n ? ' (repetido)' : ''}.`); }
        else if (N.every((x, k) => !k || x.n - N[k - 1].n === 1)) nota('aviso', N[0].li, `Los números de bloque van de 1 en 1 (${N[0].etiqueta}, ${N[1].etiqueta}, ${N[2].etiqueta}…): es mejor de 10 en 10 (N10, N20, N30…), así se pueden intercalar líneas sin renumerar el programa.`);
    }
    notas.forEach(n => { if (typeof n.seg === 'number') n.seg = segs[n.seg]; });""")
s = s0 + f + s1
# la hoja de soluciones con varias herramientas arranca el husillo (S… M03): que termine como pide el Corrector, con M05 y M30
rep("""        if (d.grupos.length) zLinea(`G0 Z${zSeg}`);
        if (modal === 'G16') lineas.push('G15');
        return lineas.join('\\n') + '\\n';""", """        if (d.grupos.length) zLinea(`G0 Z${zSeg}`);
        if (modal === 'G16') lineas.push('G15');
        if (tActual !== null) lineas.push('M05', 'M30');
        return lineas.join('\\n') + '\\n';""")
open(P, 'w', encoding='utf-8').write(s)
print('Calcador: el Corrector revisa el final del programa (M05 y M30, o M02) y los números de bloque')
