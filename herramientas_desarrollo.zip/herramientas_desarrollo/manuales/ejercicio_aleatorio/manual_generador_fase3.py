"""Manual del Calcador: 🧩 Ejercicio aleatorio, fase 3 (niveles, piezas escalonadas y series para la clase). Uso (tras node capt_generador.js): python3 manual_generador_fase3.py <suite>"""
import sys, os, io, base64, re
from PIL import Image
D = sys.argv[1] if len(sys.argv) > 1 else '../../..'
P = os.path.join(D, 'manual_calcador.html'); s = open(P, encoding='utf-8').read()
assert 'Serie para la clase' not in s, 'ya aplicado'
im = Image.open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'capturas', 'generador3.png')).convert('RGB')
im = im.resize((1500, round(im.height * 1500 / im.width)), Image.LANCZOS); b = io.BytesIO(); im.save(b, 'WEBP', quality=80, method=6)
src = 'data:image/webp;base64,' + base64.b64encode(b.getvalue()).decode()
def rep(a, c):
    global s
    assert s.count(a) == 1, (s.count(a), a[:80]); s = s.replace(a, c)
rep('<li><strong>Tamaño</strong>: el ancho y el alto máximos', '''<li><strong>Nivel</strong>: pone de una vez las formas, las esquinas y los lados de cada paso de la progresión de clase:
<ol><li><strong>Solo rectas horizontales y verticales</strong>: rectángulos y piezas <strong>escalonadas</strong> (un rectángulo con muescas en las esquinas y quizá una ranura en un lado: piezas en L, en T o en U), con agujeros rectangulares.</li>
<li><strong>Rectas inclinadas</strong>: lo mismo, con <strong>chaflanes</strong> (rectas a 45°, por proyecciones enteras).</li>
<li><strong>Arcos con el centro en la rejilla</strong>: redondeos, esquinas hacia dentro, círculos y colisos; I y J salen enteros.</li>
<li><strong>Arcos que piden calcular I y J</strong>: además, lados en arco abombado o hundido y polígonos (con polares).</li></ol>
Si después cambias algo a mano, el nivel pasa a «Libre».</li>
<li><strong>Tamaño</strong>: el ancho y el alto máximos''')
rep('<li><strong>Piezas</strong> e <strong>interiores de cada pieza</strong>: cuántos (de… a…) y qué formas pueden salir para cada cosa.</li>',
    '<li><strong>Piezas</strong> e <strong>interiores de cada pieza</strong>: cuántos (de… a…) y qué formas pueden salir para cada cosa. La forma <em>Escalonada</em> solo sale como pieza.</li>')
m = re.search(r'(<figure class="ancha"><img src=")[^"]+(" alt="La ventana 🧩 Ejercicio aleatorio)', s); assert m
s = s[:m.start()] + m.group(1) + src + m.group(2) + s[m.end():]
rep('El número y los parámetros se guardan en el JSON, y el proyecto se llama «Ejercicio aleatorio» y su número.</p>',
    '''El número y los parámetros se guardan en el JSON, y el proyecto se llama «Ejercicio aleatorio» y su número.</p>
<h3>Serie para la clase</h3>
<p>Para dar <strong>un ejercicio distinto a cada alumno</strong>, del mismo nivel: en <em>Serie para la clase</em>, escribe cuántos ejercicios quieres (por ejemplo, 25). Son los números seguidos desde el primero de las propuestas que se ven, con los parámetros de la ventana.</p>
<ul>
<li><span class="boton">📚 Guardar en la biblioteca</span> los guarda en la carpeta <em>Aleatorios/Serie</em> (con el número del primero y el nivel). Cada uno lleva en el cajetín su número de orden (1, 2, 3…) y en el título su número de ejercicio, para saber cuál tiene cada alumno.</li>
<li><span class="boton">🖨 Sus hojas</span> y <span class="boton">📋 Sus soluciones</span> los guardan también e imprimen todas las hojas, o todas las soluciones, de una vez.</li>
</ul>
<p>El dibujo que tengas abierto no cambia. Desde la biblioteca se puede abrir cualquiera de ellos, corregirlo o usarlo en la corrección masiva.</p>''')
s = s.replace('Calcador de contornos v87 · Por Eloi A.A.', 'Calcador de contornos v88 · Por Eloi A.A.')
open(P, 'w', encoding='utf-8').write(s); print('manual_calcador.html: niveles y series')
