"""Calcador (y Corrector): un solo Simulador 3D. «➜ Abrir en el Simulador» abre simulador3d.html (el que tiene el editor)
y los textos ya no hablan del Simulador del profesor.
Uso: python3 simulador_unico_calc.py <carpeta de la suite>   (después de centros_arcos.py)
"""
import sys, os
P = os.path.join(sys.argv[1] if len(sys.argv) > 1 else '.', 'calcador.html')
s = open(P, encoding='utf-8').read()
def rep(a, b, cnt=1):
    global s
    n = s.count(a); assert n == cnt, f'{n} apariciones (se esperaban {cnt}) de: {a[:100]}'
    s = s.replace(a, b)
rep("window.open('simulador3d_profesor.html#desdeCalcador', '_blank')", "window.open('simulador3d.html#desdeCalcador', '_blank')")
rep("Simulador del profesor", "Simulador 3D", 3)
open(P, 'w', encoding='utf-8').write(s)
print('Calcador: un solo Simulador 3D:', P)
