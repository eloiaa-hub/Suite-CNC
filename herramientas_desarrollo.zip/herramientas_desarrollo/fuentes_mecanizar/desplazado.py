"""Calcador v113 / Corrector v58: trazado desplazado. Si el programa no encaja con la pieza pero sí moviéndolo (otro cero
pieza), el primer error dice «Trazado desplazado: … movido X+80 Y+50: el cero pieza que ha usado no es el del plano, lo ha
puesto en la esquina de abajo a la izquierda…», y la lista lo marca. Los demás errores y la nota no cambian.
Uso: python3 desplazado.py <carpeta de la suite>   (construir_calcador.sh lo pone tras altura_corte.py)"""
import sys, os
AQUI = os.path.dirname(os.path.abspath(__file__))
P = os.path.join(sys.argv[1] if len(sys.argv) > 1 else '.', 'calcador.html')
s = open(P, encoding='utf-8').read()
def rep(a, b, cnt=1):
    global s
    n = s.count(a); assert n == cnt, f'{n} apariciones (se esperaban {cnt}) de: {a[:100]}'
    s = s.replace(a, b)
JS = open(os.path.join(AQUI, 'desplazado.js'), encoding='utf-8').read()
rep("// Arrastrar archivos a la ventana de corrección masiva; ordenar por columna", JS + "// Arrastrar archivos a la ventana de corrección masiva; ordenar por columna")
rep("<td>${VER_TXT[v.veredicto]}</td>", "<td>${VER_TXT[v.veredicto]}${extraVeredicto(it)}</td>", 2)
rep("    .mv-inf { font-size:12px; cursor:help; }", """    .mv-despl { font-size:12px; color:#b0301f; font-weight:600; cursor:help; }
    .mv-inf { font-size:12px; cursor:help; }""")
rep("""Si un programa no corta porque la fresa nunca baja de Z0""", """Si el recorrido tiene la forma de la pieza pero movido (ha usado otro cero pieza), el primer error es «Trazado desplazado», con cuánto está movido y dónde ha puesto el cero, y en la lista sale «· trazado desplazado». Si un programa no corta porque la fresa nunca baja de Z0""")
open(P, 'w', encoding='utf-8').write(s)
print('Calcador: trazado desplazado (otro cero pieza)')
