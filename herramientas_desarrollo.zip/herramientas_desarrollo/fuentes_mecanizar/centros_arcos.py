"""Calcador: los ejes que marcan el centro de arcos, círculos y colisos, en su propia capa: una cruz de 5 mm por línea,
rojo oscuro y más gruesa, para que no se confunda con las líneas de cota. En el SVG y las hojas, el contorno de la pieza más grueso que las cotas. 
Uso: python3 centros_arcos.py <carpeta de la suite>   (después de ejercicio_aleatorio.py)
"""
import sys, os
P = os.path.join(sys.argv[1] if len(sys.argv) > 1 else '.', 'calcador.html')
s = open(P, encoding='utf-8').read()
def rep(a, b, cnt=1):
    global s
    n = s.count(a); assert n == cnt, f'{n} apariciones (se esperaban {cnt}) de: {a[:100]}'
    s = s.replace(a, b)
rep("    const V = { L:[], F:[], T:[] }, Hc = { L:[], F:[], T:[] };", "    const V = { L:[], F:[], T:[], E:[] }, Hc = { L:[], F:[], T:[], E:[] };")
rep("    const linea = (a, b) => cur.L.push([a, b]);\n    const flecha = (tip, dir) =>", "    const linea = (a, b) => cur.L.push([a, b]);\n    const eje = (a, b) => cur.E.push([a, b]);            // líneas de centro: su propia capa\n    const flecha = (tip, dir) =>")
rep("    const ejes = (C, e) => { linea(add(C, { x:-e, y:0 }), add(C, { x:e, y:0 })); linea(add(C, { x:0, y:-e }), add(C, { x:0, y:e })); };",
    "    const ejes = (C, e) => { eje(add(C, { x:-e, y:0 }), add(C, { x:e, y:0 })); eje(add(C, { x:0, y:-e }), add(C, { x:0, y:e })); };")
# la cruz de cada centro: 5 mm por línea (2,5 mm a cada lado), también en taladros y ranuras
rep("            ejes(circ.c, circ.r + 3*u);\n", "            ejes(circ.c, 2.5);\n")
rep("            ejes(ranura.c1, ranura.r + 3*u); ejes(ranura.c2, ranura.r + 3*u);\n", "            ejes(ranura.c1, 2.5); ejes(ranura.c2, 2.5);\n")
rep("            ejes(a.c, 5*u);\n", "            ejes(a.c, 2.5);\n")
# en las hojas y el SVG, el contorno de la pieza bastante más grueso que las cotas (unos 3 pt en una pieza de 200 mm)
rep("""stroke="${c}" stroke-width="${enColor ? '0.45' : '0.35'}" stroke-linejoin="round">""", """stroke="${c}" stroke-width="${f(Math.max(enColor ? 0.6 : 0.7, u * (enColor ? 2.2 : 2.6)))}" stroke-linejoin="round">""")
rep("    return { L:V.L, T:V.T, F:V.F, ocultas:Hc };", "    return { L:V.L, T:V.T, F:V.F, E:V.E, ocultas:Hc };")
# pantalla
rep("    const { L, T, F, ocultas } = memoCotas.v;", "    const { L, T, F, ocultas } = memoCotas.v, E = memoCotas.v.E || [];")
rep("    const capa = (L, F, T, alfa) => {\n        ctx.save(); ctx.globalAlpha = alfa;",
    """    const capa = (L, F, T, alfa, E) => {
        ctx.save(); ctx.globalAlpha = alfa;
        if (E && E.length) { ctx.strokeStyle = colores.centro; ctx.lineWidth = 1.7; ctx.lineCap = 'round'; ctx.beginPath();
            E.forEach(([a, b]) => { const sa = aPantalla(a), sb = aPantalla(b); ctx.moveTo(sa.x, sa.y); ctx.lineTo(sb.x, sb.y); }); ctx.stroke(); ctx.lineCap = 'butt'; }""")
rep("    if (cfgCotas.verOcultas) capa(ocultas.L, ocultas.F, ocultas.T, 0.3);\n    capa(L, F, T, 1);",
    "    if (cfgCotas.verOcultas) capa(ocultas.L, ocultas.F, ocultas.T, 0.3, ocultas.E);\n    capa(L, F, T, 1, E);")
rep("        cota: modoOscuro ? '#f0a35e' : '#b35a10',", "        cota: modoOscuro ? '#f0a35e' : '#b35a10', centro: modoOscuro ? '#ff7b7b' : '#9b1c1c',")
# SVG (y con él, las hojas de ejercicio y de soluciones)
rep("    const cot = !conCotas ? { L:[], T:[], F:[] }", "    const cot = !conCotas ? { L:[], T:[], F:[], E:[] }")
rep("    cot.L.forEach(([a, b]) => extra.push(a, b));\n", "    cot.L.forEach(([a, b]) => extra.push(a, b));\n    (cot.E || []).forEach(([a, b]) => extra.push(a, b));\n")
rep("""        cot.T.forEach(t => svg += `    <text x="${f(t.p.x)}" y="${f(-t.p.y)}" stroke="none\"""", """        cot.T.forEach(t => svg += `    <text x="${f(t.p.x)}" y="${f(-t.p.y)}" stroke="none\"""")
rep("""    if (conCotas && (cot.L.length || cot.T.length)) {""", """    if (conCotas && cot.E && cot.E.length) {
        // cruces de los centros: en color, rojo oscuro; en negro, negras; las dos, más gruesas que las cotas
        svg += `  <g id="CENTROS" stroke="${enColor ? '#9b1c1c' : '#000000'}" stroke-width="${f(u * 1.6)}" stroke-linecap="round">\\n`;
        cot.E.forEach(([a, b]) => svg += `    <line x1="${f(a.x)}" y1="${f(-a.y)}" x2="${f(b.x)}" y2="${f(-b.y)}"/>\\n`);
        svg += `  </g>\\n`;
    }
    if (conCotas && (cot.L.length || cot.T.length)) {""")
rep("se desactivan con «Centros de arcos».</p>", "se desactivan con «Centros de arcos». Los ejes que marcan los centros (de arcos, taladros y ranuras) van en rojo oscuro y más gruesos que las cotas, para que no se confundan con ellas; en el SVG y en las hojas en negro, negra y gruesa.</p>")
open(P, 'w', encoding='utf-8').write(s)
print('Calcador: ejes de los centros en su capa:', P)
