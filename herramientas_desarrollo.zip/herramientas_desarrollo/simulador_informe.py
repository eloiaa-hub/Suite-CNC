"""Simulador 3D: 🧾 Informe de entrega para Aules (PDF con el programa, la simulación terminada,
la revisión y un código de comprobación que el Corrector verifica).
Uso: python3 simulador_informe.py <carpeta de la suite>      (si ya está aplicado, solo actualiza el código JS)
"""
import sys, os, re
AQUI = os.path.dirname(os.path.abspath(__file__))
SUITE = sys.argv[1] if len(sys.argv) > 1 else '.'
leer = lambda f: open(os.path.join(AQUI, 'fuentes_mecanizar', f), encoding='utf-8').read()
JS = '// <informe-entrega>\n' + leer('entregas_comun.js') + leer('informe_entrega.js') + '// </informe-entrega>\n'
CSS = """
    /* 🧾 Informe de entrega */
    #informeFondo { position:fixed; inset:0; background:rgba(20,30,40,.45); display:none; align-items:center; justify-content:center; z-index:215; }
    #informeFondo.visible { display:flex; }
    #informeVentana { background:var(--bg-panel); width:min(560px, 94vw); max-height:92vh; display:flex; flex-direction:column; border-radius:10px; box-shadow:var(--shadow); overflow:hidden; }
    #informeVentana .cab { display:flex; align-items:center; justify-content:space-between; padding:12px 18px; border-bottom:1px solid var(--border-color); }
    #informeVentana .cab h2 { margin:0; font-size:15px; }
    #informeVentana .cuerpo { padding:12px 18px 4px; font-size:13px; line-height:1.5; overflow:auto; }
    #informeVentana .cuerpo input[type=text] { width:100%; box-sizing:border-box; padding:6px 9px; font:inherit; border:1px solid var(--border-color); border-radius:6px; background:var(--bg-app); color:inherit; }
    #informeVentana .cuerpo input[type=text]:focus { outline:2px solid rgba(0,90,156,.35); border-color:#005A9C; }
    #informeVentana .cuerpo .fila2 { margin-top:10px; }
    #informeVentana .cuerpo > label { display:block; margin-top:8px; }
    #infImagen { display:block; width:100%; max-height:230px; object-fit:contain; margin:10px 0 6px; border:1px solid var(--border-color); border-radius:6px; background:var(--bg-app); }
    #infResumen > div { margin:3px 0; }
    #infResumen .ok { color:#1e8a4c; font-weight:600; } #infResumen .mal { color:#c0392b; font-weight:600; } #infResumen .av { color:#b8730a; font-weight:600; }
    #infResumen .cod b { font-family:ui-monospace, Consolas, monospace; font-size:15px; letter-spacing:.5px; }
    #informeVentana .acciones { display:flex; gap:8px; justify-content:flex-end; padding:10px 18px 16px; border-top:1px solid var(--border-color); }
    #informeVentana .acciones button:disabled { opacity:.5; cursor:not-allowed; }
"""
HTML = """<div id="informeFondo" onclick="if(event.target===this) cerrarInforme()">
  <div id="informeVentana" role="dialog" aria-labelledby="informeTitulo">
    <div class="cab"><h2 id="informeTitulo">🧾 Informe de entrega</h2><button class="panel-cerrar" onclick="cerrarInforme()" title="Cerrar">✕</button></div>
    <div class="cuerpo">
      <p class="nota-herr" style="margin-top:0">Un PDF para subir a Aules <b>junto con tu programa</b>: lleva el programa, la imagen de la simulación terminada (con la vista que tengas ahora, 2D o 3D), el resultado de la revisión y un <b>código de comprobación</b>. Si se cambia el programa o el informe, el código deja de coincidir y el profesor lo ve al corregir.</p>
      <div class="fila2">
        <div><span class="etq">Nombre y apellidos</span><input type="text" id="infAlumno" oninput="actualizarInforme()" placeholder="Como aparece en Aules" title="Tu nombre: sale en el informe y en el nombre del archivo. Se recuerda para la próxima vez"></div>
        <div style="flex:.5"><span class="etq">Grupo</span><input type="text" id="infGrupo" oninput="actualizarInforme()" placeholder="1.º DA" title="Tu grupo o curso (opcional)"></div>
      </div>
      <label><span class="etq">Ejercicio</span><input type="text" id="infEjercicio" oninput="actualizarInforme()" title="Nombre o número del ejercicio. Si has cargado el plano (.json), se toma de él"></label>
      <img id="infImagen" alt="Simulación terminada">
      <div id="infResumen"></div>
    </div>
    <div class="acciones">
      <button onclick="cerrarInforme()">Cancelar</button>
      <button class="principal" id="infDescargar" onclick="descargarInforme()">⬇ Descargar el PDF</button>
    </div>
  </div>
</div>
"""
AYUDA = """      <h3>Informe de entrega (🧾 Entrega)</h3>
      <p>Para entregar un ejercicio en Aules: carga tu programa (y, si lo tienes, el plano .json del ejercicio), comprueba la simulación y pulsa <b>🧾 Entrega</b>. Escribe tu nombre y pulsa <b>⬇ Descargar el PDF</b>. El PDF lleva tu programa completo, la imagen de la simulación terminada (con la vista que tengas en ese momento, 2D o 3D), la revisión del programa, la comparación con el plano y un <b>código de comprobación</b>.</p>
      <p>Sube a Aules <b>el PDF y tu programa</b> (.nc). El profesor los abre con el Corrector: si el programa no es el del informe, o si el informe se ha cambiado, el código deja de coincidir y lo verá marcado.</p>

"""
for nombre in ('simulador3d.html',):
    P = os.path.join(SUITE, nombre); s = open(P, encoding='utf-8').read()
    if '// <informe-entrega>' in s:   # ya aplicado: solo se actualiza el código
        a = s.index('// <informe-entrega>'); b = s.index('// </informe-entrega>\n') + len('// </informe-entrega>\n')
        s = s[:a] + JS + s[b:]; open(P, 'w', encoding='utf-8').write(s); print(nombre, ': código del informe actualizado'); continue
    def rep(a, b, cnt=1):
        global s
        n = s.count(a); assert n == cnt, f'{nombre}: {n} apariciones (se esperaban {cnt}) de: {a[:90]}'
        s = s.replace(a, b)
    rep('    #ayudaFondo { position:fixed;', CSS.lstrip('\n') + '    #ayudaFondo { position:fixed;')
    rep('<div id="ayudaFondo" onclick="if(event.target===this) cerrarAyuda()">', HTML + '<div id="ayudaFondo" onclick="if(event.target===this) cerrarAyuda()">')
    rep('<button onclick="resetCamara()" title="Volver a encuadrar la pieza desde el punto de vista actual">🎯<span class="lbl"> Encuadrar</span></button>',
        '<button onclick="resetCamara()" title="Volver a encuadrar la pieza desde el punto de vista actual">🎯<span class="lbl"> Encuadrar</span></button>\n        <button onclick="abrirInforme()" title="Informe de entrega para Aules: un PDF con tu programa, la simulación terminada, la revisión y un código de comprobación">🧾<span class="lbl"> Entrega</span></button>')
    rep('      <h3>Grabar un vídeo</h3>', AYUDA + '      <h3>Grabar un vídeo</h3>')
    rep('// ── Revisión del programa: errores y avisos típicos ──', JS + '\n// ── Revisión del programa: errores y avisos típicos ──')
    # versión
    m = re.search(r'(class="ver-suite"[^>]*>(?:Profesor · )?V)(\d+)', s); v = int(m.group(2))
    s = s[:m.start(2)] + str(v + 1) + s[m.end(2):]
    open(P, 'w', encoding='utf-8').write(s)
    print(f'{nombre}: informe de entrega · V{v} → V{v + 1}')
