"""Simulador 3D V44 (corrección): el ángulo de la V (y el Ø) se pueden escribir en el panel.
Al rehacer la simulación con cada tecla, el panel se volvía a rellenar con la herramienta del tramo y pisaba lo que se
estaba escribiendo (al teclear «6» de «60» quedaba «10», el mínimo). Ahora el panel solo se rellena al pasar a otra T.
El ángulo es el de la punta entera (90° = 45° a cada lado del eje), y la etiqueta lo dice.
Uso: python3 simulador_angulo_v.py <carpeta de la suite>      (ya aplicado: no se vuelve a ejecutar)"""
import sys, os
RUTA = os.path.join(sys.argv[1] if len(sys.argv) > 1 else '.', 'simulador3d.html')
s = open(RUTA, encoding='utf-8').read()
assert 'tPanelMostrada' not in s, 'ya aplicado'
def rep(a, b, cnt=1):
    global s
    assert s.count(a) == cnt, (a[:70], s.count(a)); s = s.replace(a, b)
rep("        if (hM) { const g = id => document.getElementById(id);",
    "        if (hM && hM.T !== tPanelMostrada) { tPanelMostrada = hM.T; const g = id => document.getElementById(id);")
rep("let herrPanel = {};", "let herrPanel = {}, tPanelMostrada = null;   // tPanelMostrada: la T cuyos datos enseña el panel")
rep("    herrPanel = {};\n    const lineas = texto.split(", "    herrPanel = {}; tPanelMostrada = null;\n    const lineas = texto.split(")
rep('<label class="etq">Ángulo de la V (°)</label>', '<label class="etq" title="El ángulo de la punta entera: una V de 90° tiene 45° a cada lado del eje">Ángulo de la V (°, punta entera)</label>')
open(RUTA, 'w', encoding='utf-8').write(s)
print('Simulador V44: el ángulo de la V se puede escribir')
