// ── Rúbrica: la nota por apartados (opcional; por defecto, la nota de siempre) ──
// Geometría (la pieza: en proporción al contorno bien mecanizado, menos lo de cada corte que daña), compensación, lo pedido,
// seguridad, el final del programa, el formato (números de bloque, códigos de clase…) y los comentarios, con los pesos que
// se elijan. Se guarda con el ejercicio (cfgCorr.rubrica), como los criterios de siempre.
const RUBRICA = [
    ['geo', 'Geometría', 4, 'La pieza: en proporción al contorno bien mecanizado, menos lo de cada corte que se mete en la pieza'],
    ['comp', 'Compensación', 1.5, 'G41/G42 en el lado bueno, con su entrada y su salida (con un aviso, la mitad)'],
    ['pedido', 'Lo pedido', 1.5, 'Programación, entrada, sentido y herramienta pedidos'],
    ['seg', 'Seguridad', 1, 'Sin rápidos peligrosos (con un aviso, como bajar en diagonal, la mitad)'],
    ['fin', 'Final del programa', 1, 'La fresa arriba, M05 y M30 (o M02) (con un aviso, la mitad)'],
    ['formato', 'Formato', 0.5, 'Números de bloque, códigos dados en clase, T101 M06, S… M03 (cada aviso resta un cuarto)'],
    ['coment', 'Comentarios', 0.5, 'Al menos la mitad de las líneas comentadas (menos, en proporción)']];
const rubricaActiva = () => esObj(cfgCorr.rubrica) && cfgCorr.rubrica.modo === 'apartados';
function pesosRubrica() { const p = esObj(cfgCorr.rubrica) && esObj(cfgCorr.rubrica.pesos) ? cfgCorr.rubrica.pesos : {}; const o = {}; RUBRICA.forEach(([k, , d]) => { const v = +p[k]; o[k] = isFinite(v) && v >= 0 ? Math.min(100, v) : d; }); return o; }
const esFinal = h => (h.pista && /al final/.test(h.pista)) || /fin de programa|M30|M02|termina con la fresa|programa no termina|el programa ya ha terminado/.test(h.msg);
const esFormato = h => h.cat === 'clase' || /números de bloque|coma decimal/.test(h.msg);
const esComp = h => h.cat === 'compensacion' || (h.tipo === 'aviso' && /G4[12]|compensaci/.test(h.msg));
function apartadosRubrica(r, v) {
    const P = pesosRubrica(), N = critNota(), H = (r && r.hallazgos) || [], esLinea = h => h.linea !== null && h.linea !== undefined;
    const sin = v.veredicto === 'vacio' || v.veredicto === 'error';
    const parte = (err, av) => err ? 0 : av ? 0.5 : 1;
    const E = f => H.filter(h => h.tipo === 'error' && f(h)), A = f => H.filter(h => h.tipo === 'aviso' && f(h));
    const errGeo = H.filter(h => h.tipo === 'error' && h.cat === 'geometria' && (esLinea(h) || h.resumen)).reduce((n, h) => n + (h.resumen || 1), 0);
    const f = {};
    f.geo = sin || !P.geo ? 0 : Math.max(0, v.cob * P.geo - N.pen * errGeo) / P.geo;
    f.comp = parte(E(esComp).length, A(esComp).length);
    f.pedido = v.incumple ? 0 : 1;
    f.seg = parte(E(h => h.cat === 'seguridad' && !esFinal(h)).length, A(h => /diagonal|rápido/.test(h.msg) && !esFinal(h)).length);
    f.fin = parte(E(esFinal).length, A(esFinal).length);
    f.formato = Math.max(0, 1 - 0.25 * A(esFormato).length);
    { const L = (r && r.prog && r.prog.lineas) || [], cod = L.filter(l => l.replace(/\([^)]*\)/g, '').replace(/;.*$/, '').trim()), con = cod.filter(l => /\(|;/.test(l));
      f.coment = cod.length ? Math.min(1, (con.length / cod.length) / 0.5) : 0; }
    return RUBRICA.map(([k, nom]) => ({ k, nom, peso: P[k], frac: sin ? 0 : f[k], puntos: sin ? 0 : Math.round(P[k] * f[k] * 100) / 100 }));
}
const _valorarCorreccionRub = valorarCorreccion;
valorarCorreccion = function (r) {
    const v = _valorarCorreccionRub.apply(this, arguments);
    if (!rubricaActiva()) return v;
    const ap = apartadosRubrica(r, v), max = ap.reduce((a, x) => a + x.peso, 0) || 1;
    v.rub = ap; v.notaSiempre = v.nota;
    v.nota = Math.round(ap.reduce((a, x) => a + x.puntos, 0) / max * 100) / 10;
    return v;
};
// El desglose del informe y los criterios del resumen, según el modo
function tablaDesglose(v, N) {
    if (v.rub) return `<table class="des"><tr>${v.rub.map(x => `<th>${x.nom}</th>`).join('')}<th>Contorno bien mecanizado</th></tr>
                <tr>${v.rub.map(x => `<td>${nf(x.puntos, 2)} / ${nf(x.peso, 1)}</td>`).join('')}<td>${pct(v.cob)}</td></tr></table>`;
    return `<table class="des"><tr><th>Geometría</th><th>Lo pedido</th><th>Seguridad</th><th>Contorno bien mecanizado</th></tr>
                <tr><td>${nf(v.desglose.geo, 2)} / ${nf(N.geo, 1)}</td><td>${nf(v.desglose.pedido, 1)} / ${nf(N.pedido, 1)}</td><td>${nf(v.desglose.seg, 1)} / ${nf(N.seg, 1)}</td><td>${pct(v.cob)}</td></tr></table>`;
}
function textoCriterios(N) {
    if (rubricaActiva()) { const P = pesosRubrica(), tot = RUBRICA.reduce((a, [k]) => a + P[k], 0);
        return `Nota orientativa sobre 10, por apartados (rúbrica, ${nf(tot, 1)} puntos en total): ${RUBRICA.map(([k, nom]) => `${nom.toLowerCase()} ${nf(P[k], 1)}`).join(', ')}. En la geometría, −${nf(N.pen, 2)} por cada corte que se mete en la pieza.`; }
    return `Nota orientativa sobre 10: geometría ${nf(N.geo, 1)} (en proporción al contorno bien mecanizado, −${nf(N.pen, 2)} por cada corte que se mete en la pieza), lo pedido ${nf(N.pedido, 1)} y seguridad ${nf(N.seg, 1)}.`;
}
// La ventana de la rúbrica
function editarRubrica() {
    let ov = document.getElementById('modalRubrica');
    if (!ov) { ov = document.createElement('div'); ov.className = 'modal-overlay'; ov.id = 'modalRubrica'; ov.onclick = e => { if (e.target === ov) ov.classList.remove('visible'); }; document.body.appendChild(ov); }
    const P = pesosRubrica();
    ov.innerHTML = `<div class="help-modal" style="width:min(640px,100%)"><div class="help-header"><h2>⚙ Rúbrica: la nota por apartados</h2><button class="help-close" onclick="document.getElementById('modalRubrica').classList.remove('visible')">✕</button></div>
        <div class="help-content"><p class="ctx-nota" style="margin-top:0">Los puntos de cada apartado. La nota se pasa a 10 aunque no sumen 10; con 0, el apartado no cuenta. El descuento por cada corte que se mete en la pieza es el de «− por corte que daña».</p>
        <table class="par-tabla rub-tabla">${RUBRICA.map(([k, nom, d, t]) => `<tr><td><b>${nom}</b><div class="ctx-nota" style="margin:0">${t}</div></td><td class="n"><input type="number" min="0" max="100" step="0.25" data-k="${k}" value="${P[k]}" style="width:64px"></td></tr>`).join('')}
        <tr><td style="text-align:right">Total</td><td class="n" id="rubTotal"></td></tr></table>
        <div class="btn-row" style="margin-top:10px"><button class="btn-action sec" id="rubDef">Los pesos de partida</button><button class="btn-action" id="rubOk">Usar la rúbrica y recorregir</button></div></div></div>`;
    const tot = () => { ov.querySelector('#rubTotal').textContent = nf([...ov.querySelectorAll('input[data-k]')].reduce((a, i) => a + (+i.value || 0), 0), 2); };
    ov.querySelectorAll('input[data-k]').forEach(i => i.oninput = tot); tot();
    ov.querySelector('#rubDef').onclick = () => { ov.querySelectorAll('input[data-k]').forEach(i => { i.value = RUBRICA.find(x => x[0] === i.dataset.k)[2]; }); tot(); };
    ov.querySelector('#rubOk').onclick = () => { const p = {}; ov.querySelectorAll('input[data-k]').forEach(i => { p[i.dataset.k] = Math.max(0, +String(i.value).replace(',', '.') || 0); });
        cfgCorr.rubrica = { modo: 'apartados', pesos: p }; ov.classList.remove('visible'); sincronizarModoNota(); guardarAutoPronto(); recorregirMasiva(); snack('Nota por apartados (rúbrica)'); };
    ov.classList.add('visible');
}
function cambiarModoNota(sel) {
    if (sel.value === 'apartados') { cfgCorr.rubrica = { modo: 'apartados', pesos: pesosRubrica() }; } else if (esObj(cfgCorr.rubrica)) cfgCorr.rubrica.modo = 'siempre';
    sincronizarModoNota(); guardarAutoPronto(); recorregirMasiva();
}
function sincronizarModoNota() {
    const s = document.getElementById('mvModoNota'); if (!s) return;
    s.value = rubricaActiva() ? 'apartados' : 'siempre';
    document.querySelectorAll('.mv-crit-siempre').forEach(e => { e.style.display = rubricaActiva() ? 'none' : ''; });
    const b = document.getElementById('mvBtnRub'); if (b) b.style.display = rubricaActiva() ? '' : 'none';
    const c = document.getElementById('mvClase'); if (c) c.checked = cfgClase.activo;
}
const _sincronizarRequisitosMasivaRub = sincronizarRequisitosMasiva;
sincronizarRequisitosMasiva = function () { const r = _sincronizarRequisitosMasivaRub.apply(this, arguments); sincronizarModoNota(); return r; };
