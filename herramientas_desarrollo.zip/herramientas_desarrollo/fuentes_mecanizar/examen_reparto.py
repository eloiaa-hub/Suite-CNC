"""Calcador v108 / Corrector v53: 👥 Preparar el examen (desde 🎲 Variantes): repartir las variantes a la lista de la clase
(pegada o el CSV de Aules), imprimir las hojas con el nombre de cada alumno, las soluciones y la lista del reparto. El reparto
se guarda en el navegador y la corrección masiva lo usa para saber qué variante le tocaba a cada uno (o se abre su CSV).
Uso: python3 examen_reparto.py <carpeta de la suite>   (construir_calcador.sh lo pone tras variantes_medidas.py)"""
import sys, os
AQUI = os.path.dirname(os.path.abspath(__file__))
P = os.path.join(sys.argv[1] if len(sys.argv) > 1 else '.', 'calcador.html')
s = open(P, encoding='utf-8').read()
def rep(a, b, cnt=1):
    global s
    n = s.count(a); assert n == cnt, f'{n} apariciones (se esperaban {cnt}) de: {a[:100]}'
    s = s.replace(a, b)
JS = open(os.path.join(AQUI, 'examen_reparto.js'), encoding='utf-8').read()
rep("// Arrastrar archivos a la ventana de corrección masiva; ordenar por columna", JS + "// Arrastrar archivos a la ventana de corrección masiva; ordenar por columna")
rep("""                <button class="btn-action" onclick="guardarVariantesBib('hoja')">🖨 Imprimir sus hojas</button>""",
    """                <button class="btn-action" onclick="abrirRepartoExamen()" title="La lista de la clase: a cada alumno su variante, y sus hojas con el nombre. La corrección masiva sabrá qué variante le tocaba a cada uno">👥 Preparar el examen (repartir)…</button>
                <button class="btn-action sec" onclick="guardarVariantesBib('hoja')">🖨 Imprimir sus hojas</button>""")
rep("    .mv-inf { font-size:12px; cursor:help; }",
    """    .rep-cuerpo { display:grid; grid-template-columns: 300px 1fr; gap:16px; } .rep-cuerpo textarea { width:100%; box-sizing:border-box; font:13px/1.5 inherit; padding:6px 8px; border:1px solid var(--border-color); border-radius:6px; }
    .rep-der #repTabla { max-height:52vh; overflow:auto; } .rep-tabla select { padding:1px 4px; } .rep-acc .btn-action { width:auto; }
    @media (max-width: 700px) { .rep-cuerpo { grid-template-columns: 1fr; } }
    .mv-inf { font-size:12px; cursor:help; }""")
rep("""Si el nombre del archivo, la carpeta del alumno o un comentario al principio del programa dicen la variante que le tocaba («12B», «variante B»), se corrige con esa""",
    """Si las variantes se repartieron con <strong>👥 Preparar el examen</strong> (en 🎲 Variantes), se sabe la que le tocaba a cada alumno; si no, si el nombre del archivo, la carpeta del alumno o un comentario al principio del programa la dicen («12B», «variante B»), se corrige con esa""")
open(P, 'w', encoding='utf-8').write(s)
print('Calcador: preparar el examen (reparto de variantes)')
