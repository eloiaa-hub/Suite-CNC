"""Calcador v103 / Corrector v49: botones para ocultar y mostrar el panel izquierdo (opciones) y el derecho (programa),
para tener más grande la zona de dibujo; la barra de herramientas sigue siempre visible. Y un botón para ver u ocultar
la rejilla (el imán a la rejilla, ▦ Rejilla, sigue aparte). Se recuerda en el navegador.
Uso: python3 interfaz_paneles.py <carpeta de la suite>   (después de interfaz_calcador.py; construir_calcador.sh lo hace así)"""
import sys, os
P = os.path.join(sys.argv[1] if len(sys.argv) > 1 else '.', 'calcador.html')
s = open(P, encoding='utf-8').read()
def rep(a, b, cnt=1):
    global s
    n = s.count(a); assert n == cnt, f'{n} apariciones (se esperaban {cnt}) de: {a[:100]}'
    s = s.replace(a, b)
rep("""            <div class="zoom-controls">
                <div class="zoom-btn" onclick="zoomBoton(1.25)" title="Acercar">+</div>""",
    """            <div class="vista-controls">
                <div class="zoom-btn btn-vista" id="btnPanelIzq" onclick="alternarPanel('izq')" title="Ocultar el panel izquierdo (opciones) para ver más grande el dibujo · tecla F7">◧</div>
                <div class="zoom-btn btn-vista" id="btnPanelDer" onclick="alternarPanel('der')" title="Ocultar el panel derecho (mecanizado y programa) para ver más grande el dibujo · tecla F8">◨</div>
                <div class="zoom-btn btn-vista" id="btnVerRejilla" onclick="alternarVerRejilla()" title="Ver u ocultar la rejilla del dibujo (el imán a la rejilla es el botón ▦ Rejilla)">👁 Rejilla</div>
            </div>
            <div class="zoom-controls">
                <div class="zoom-btn" onclick="zoomBoton(1.25)" title="Acercar">+</div>""")
rep("""    .zoom-controls { position: absolute; bottom: 12px; right: 12px; display: flex; gap: 4px; }""",
    """    .zoom-controls { position: absolute; bottom: 12px; right: 12px; display: flex; gap: 4px; }
    .vista-controls { position: absolute; top: 10px; right: 12px; display: flex; gap: 4px; z-index: 5; }
    .btn-vista.oculto { background: var(--accent-light); color: var(--accent); border-color: var(--accent); }
    #btnVerRejilla.visible { background: var(--accent); color: #fff; border-color: var(--accent); }
    html.sin-izq .action-panel, html.sin-der .tutor-panel { display: none !important; }""")
rep("    dibujarRejilla();\n    if (fondo) dibujarFondo(V);", "    if (verRejilla) dibujarRejilla();\n    if (fondo) dibujarFondo(V);")
JS = r"""
// ── Vista: ocultar los paneles (la barra de herramientas siempre se ve) y la rejilla ──
const VISTA_CLAVE = 'calcador_vista';
var verRejilla = true;
function guardarVista() { try { localStorage.setItem(VISTA_CLAVE, JSON.stringify({ izq: document.documentElement.classList.contains('sin-izq'), der: document.documentElement.classList.contains('sin-der'), rejilla: verRejilla })); } catch (e) {} }
function pintarBotonesVista() {
    const h = document.documentElement.classList, b = (id, oculto, t) => { const e = document.getElementById(id); if (e) { e.classList.toggle('oculto', oculto); e.title = t; } };
    b('btnPanelIzq', h.contains('sin-izq'), h.contains('sin-izq') ? 'Mostrar el panel izquierdo (opciones) · tecla F7' : 'Ocultar el panel izquierdo (opciones) para ver más grande el dibujo · tecla F7');
    b('btnPanelDer', h.contains('sin-der'), h.contains('sin-der') ? 'Mostrar el panel derecho (mecanizado y programa) · tecla F8' : 'Ocultar el panel derecho (mecanizado y programa) para ver más grande el dibujo · tecla F8');
    { const e = document.getElementById('btnVerRejilla'); if (e) e.classList.toggle('visible', verRejilla); }
    b('btnVerRejilla', false, verRejilla ? 'Ocultar la rejilla del dibujo (el imán a la rejilla es el botón ▦ Rejilla)' : 'Ver la rejilla del dibujo (el imán a la rejilla es el botón ▦ Rejilla)');
}
function alternarPanel(cual, forzar) {
    const cls = cual === 'izq' ? 'sin-izq' : 'sin-der', h = document.documentElement.classList;
    const ocultar = forzar === undefined ? !h.contains(cls) : !!forzar;
    h.toggle(cls, ocultar);   // (la vista guarda su centro: el dibujo sigue centrado en la zona más ancha)
    try { redimensionar(); } catch (e) {}
    // con más (o menos) sitio, el dibujo se encuadra para llenar la zona
    try { if (contornos.some(c => c.pts.length >= 2)) encuadrar(); else render(); } catch (e) {}
    pintarBotonesVista(); guardarVista();
}
function alternarVerRejilla(forzar) {
    verRejilla = forzar === undefined ? !verRejilla : !!forzar;
    pintarBotonesVista(); guardarVista(); try { render(); } catch (e) {}
}
(function () {
    try { const v = JSON.parse(localStorage.getItem(VISTA_CLAVE) || '{}'); if (v && typeof v === 'object') {
        if (v.izq) document.documentElement.classList.add('sin-izq'); if (v.der) document.documentElement.classList.add('sin-der'); if (v.rejilla === false) verRejilla = false; } } catch (e) {}
    window.addEventListener('DOMContentLoaded', pintarBotonesVista);
    document.addEventListener('keydown', e => {
        if (e.key !== 'F7' && e.key !== 'F8') return;
        if (document.querySelector('.modal-overlay.visible')) return;
        e.preventDefault(); alternarPanel(e.key === 'F7' ? 'izq' : 'der');
    });
})();
"""
rep("function dibujarRejilla() {", JS.lstrip('\n') + "function dibujarRejilla() {")
# la ayuda del programa
rep("""            <h3>Imán a la rejilla</h3>""", """            <h3>Más sitio para dibujar</h3>
            <p>Arriba a la derecha del dibujo: <strong>◧</strong> oculta o muestra el panel izquierdo (tecla <span class="kbd">F7</span>), <strong>◨</strong> el derecho (tecla <span class="kbd">F8</span>) y <strong>👁 Rejilla</strong> oculta o muestra la rejilla (solo lo que se ve; el imán es ▦ Rejilla). La barra de herramientas se ve siempre, y el dibujo se encuadra para llenar la zona.</p>
            <h3>Imán a la rejilla</h3>""")
rep("""                <tr><td><span class="kbd">G</span></td><td>Imán a la rejilla: activar o desactivar.</td></tr>""", """                <tr><td><span class="kbd">G</span></td><td>Imán a la rejilla: activar o desactivar.</td></tr>
                <tr><td><span class="kbd">F7</span> · <span class="kbd">F8</span></td><td>Ocultar o mostrar el panel izquierdo · el derecho.</td></tr>""")
open(P, 'w', encoding='utf-8').write(s)
print('Calcador: ocultar los paneles izquierdo y derecho, y ver u ocultar la rejilla')
