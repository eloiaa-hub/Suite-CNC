"""Construye apuntes_iso.html (los apuntes «Códigos ISO de la Suite CNC») en la carpeta de la suite.
Uso (desde esta carpeta, después de python3 diagramas.py y LANG=C.UTF-8 node capt_iso.js):
  python3 construir_apuntes.py ../../..
Mete los dibujos ({{svg:nombre}}, de diagramas/) y después usa ../anidador_calculadora/construir_manual.py
para las capturas ({{img:…}}, de capturas/) y el estilo de los manuales."""
import sys, os, re, subprocess
AQUI = os.path.dirname(os.path.abspath(__file__)); D = os.path.abspath(sys.argv[1] if len(sys.argv) > 1 else os.path.join(AQUI, '../../..'))
s = open(os.path.join(AQUI, 'fuente_apuntes_iso.html'), encoding='utf-8').read()
def svg(m):
    # los dibujos de los apuntes y, para el capítulo de Pitágoras, los de ../arcos_pitagoras/diagramas/ (|62% = ancho)
    f = os.path.join(AQUI, 'diagramas', m.group(1) + '.svg')
    if not os.path.exists(f): f = os.path.join(AQUI, '..', 'arcos_pitagoras', 'diagramas', m.group(1) + '.svg')
    t = open(f, encoding='utf-8').read()
    return re.sub(r'style="width:[^"]*"', f'style="width:{m.group(2)}"', t, count=1) if m.group(2) else t
s = re.sub(r'\{\{svg:([a-z0-9_]+)(?:\|([0-9]+%))?\}\}', svg, s)
tmp = os.path.join(AQUI, '_fuente_con_dibujos.html'); open(tmp, 'w', encoding='utf-8').write(s)
try:
    subprocess.run([sys.executable, os.path.join(AQUI, '..', 'anidador_calculadora', 'construir_manual.py'), tmp, os.path.join(AQUI, 'capturas'),
                    os.path.join(D, 'apuntes_iso.html'), 'Códigos ISO de la Suite CNC — Apuntes para el alumnado', os.path.join(D, 'manual_corrector.html')], check=True)
finally: os.remove(tmp)
