"""Dibujos de los apuntes «Taladros: los ciclos fijos». Usa la clase D de ../guia_iso/diagramas.py.
Uso: python3 diagramas.py  (los deja en diagramas/). Vistas de lado: x en mm y la «y» del dibujo es la Z."""
import os, math
AQUI = os.path.dirname(os.path.abspath(__file__))
src = open(os.path.join(AQUI, '..', 'guia_iso', 'diagramas.py'), encoding='utf-8').read()
src = src[:src.index('\nd = D(')].replace("os.path.join(os.path.dirname(os.path.abspath(__file__)), 'diagramas')", repr(os.path.join(AQUI, 'diagramas')))
exec(src)
MARTIR = '#e7dcc8'

def num(d, p, n, col, dx=0, dy=0):
    x, y = d.P(*p); x += dx; y += dy
    d.add(f'<circle cx="{x}" cy="{y}" r="9" fill="{col}"/><text x="{x}" y="{y + 4.2}" fill="#fff" font-size="12" font-weight="700" text-anchor="middle" font-family="\'Segoe UI\',Arial,sans-serif">{n}</text>')

def broca(d, x, zpunta, dia=8, largo=16, col='#9aa6b2'):
    h = (dia / 2) / math.tan(math.radians(59))
    d.poli([(x - dia / 2, zpunta + h + largo), (x - dia / 2, zpunta + h), (x, zpunta), (x + dia / 2, zpunta + h), (x + dia / 2, zpunta + h + largo)], TINTA, 1.2, fill=col)

def tablero(d, x0, x1, esp=19, martir=0):
    d.rect((x0, -esp), (x1, 0), GRIS, MADERA, 1.2)
    if martir: d.rect((x0 - 3, -esp - martir), (x1 + 3, -esp), GRIS, MARTIR, 1.0)

def plano(d, x0, x1, z, txt, col=GRIS, xt=None, dy=4):
    d.linea((x0, z), (x1, z), col, 1, dash='6 4'); d.texto((xt if xt is not None else x1, z), txt, col, 12, 'start', '600', dx=6, dy=dy)

# 1. La secuencia de un ciclo (G81 con G99)
d = D(640, 330, esc=5.2, x0=40, y0=174)
tablero(d, 0, 64, 19, 4)
plano(d, -4, 70, 20, 'plano inicial: Z20 (donde está la fresa)')
plano(d, -4, 70, 2, 'plano R: R2', NAR, dy=-3)
plano(d, -4, 70, 0, 'Z0: la cara de arriba', TINTA, dy=13)
plano(d, -4, 70, -20, 'fondo: Z-20', ROJO)
d.rect((26, -20), (34, 0), GRIS, '#ffffff', 0.8)
broca(d, 10, 20, largo=6)
d.linea((10, 20.6), (29.4, 20.6), AZUL, 2, dash='6 4', flecha=True); num(d, (20, 20.6), 1, AZUL, dy=-14)
d.linea((30, 20), (30, 2.8), AZUL, 2, dash='6 4', flecha=True); num(d, (30, 11), 2, AZUL, dx=-16)
d.linea((31.2, 2), (31.2, -19.2), NAR, 2.6, flecha=True); num(d, (31.2, -9), 3, NAR, dx=16)
d.linea((28.8, -20), (28.8, 1.2), AZUL, 2, dash='6 4', flecha=True); num(d, (28.8, -9), 4, AZUL, dx=-16)
d.linea((-2, -2), (-2, -2), GRIS)
d.texto((-4, -29), 'Rápido (G0): discontinuo y azul · al avance F: continuo y naranja', GRIS, 11.5)
d.svg('ciclo')

# 2. G98 y G99: un sargento entre dos agujeros
def panel(d, ox, modo):
    tablero(d, ox, ox + 80, 19)
    d.rect((ox + 35, 0), (ox + 45, 12), TINTA, '#c7ced6', 1.2); d.texto((ox + 40, 12), 'sargento', GRIS, 11, 'middle', '600', dy=-6)
    for x in (ox + 15, ox + 65): d.rect((x - 4, -19), (x + 4, 0), GRIS, '#fff', 0.8)
    plano(d, ox - 2, ox + 82, 20, '', GRIS); plano(d, ox - 2, ox + 82, 2, '', NAR)
    d.linea((ox + 15, -19), (ox + 15, 2 if modo == 99 else 20), AZUL, 2, dash='6 4', flecha=True)
    if modo == 99:
        d.linea((ox + 15, 2), (ox + 34, 2), ROJO, 2.4, dash='6 4', flecha=True)
        d.texto((ox + 36, 4), '✖', ROJO, 22, 'middle', '700', dy=8); d.texto((ox + 40, 30), 'G99: sube solo a R2 y choca', ROJO, 13, 'middle', '700')
    else:
        d.linea((ox + 15, 20), (ox + 65, 20), AZUL, 2, dash='6 4', flecha=True)
        d.linea((ox + 65, 20), (ox + 65, -18), NAR, 2.4, flecha=True)
        d.texto((ox + 40, 30), 'G98: sube a Z20 y pasa por encima', VERDE, 13, 'middle', '700')
    d.texto((ox - 2, 20), 'Z20', GRIS, 11, 'end', dx=-4, dy=4); d.texto((ox - 2, 2), 'R2', NAR, 11, 'end', '700', dx=-4, dy=4)
d = D(640, 200, esc=3.2, x0=40, y0=81)
panel(d, 0, 99); panel(d, 100, 98)
d.svg('g98g99')

# 3. G83: picoteo
d = D(640, 310, esc=4.6, x0=60, y0=280)
d.rect((0, -45), (110, 0), GRIS, MADERA, 1.2)
plano(d, -4, 112, 2, 'R2', NAR, dy=-3); plano(d, -4, 112, 0, 'Z0', TINTA, dy=13); plano(d, -4, 112, -40, 'Z-40', ROJO)
prev = 0
for k, z in enumerate((-8, -16, -24, -32, -40)):
    x = 12 + k * 20
    d.rect((x - 4, z), (x + 4, 0), GRIS, '#fff', 0.8)
    if prev: d.linea((x - 1.5, 2), (x - 1.5, prev + 0.5), AZUL, 1.8, dash='5 3', flecha=True)
    d.linea((x, prev + (0.5 if prev else 2)), (x, z + 0.6), NAR, 2.4, flecha=True)
    d.linea((x + 1.5, z), (x + 1.5, 1.4), AZUL, 1.8, dash='5 3', flecha=True)
    d.texto((x, z), f'{k + 1}.º', TINTA, 12, 'middle', '700', dy=16)
    prev = z
d.texto((12, -4), 'Q8', NAR, 12, 'start', '700', dx=8)
d.texto((-4, -51), 'G83 G99 X… Y… Z-40 R2 Q8 F250: baja 8 mm, sale hasta R2 para sacar la viruta, vuelve a bajar en rápido', GRIS, 11.5)
d.texto((-4, -51), 'hasta casi donde lo dejó y taladra otros 8 mm… hasta Z-40.', GRIS, 11.5, dy=16)
d.svg('g83')

# 4. Agujero pasante: la punta de la broca
d = D(640, 290, esc=5.6, x0=40, y0=230)
for ox, zf, txt, col in ((0, -19, 'Z-19: la punta llega al fondo, pero el agujero no sale entero por abajo', ROJO), (55, -21.5, 'Z-21.5: muerde el martiriño y el agujero sale entero', VERDE)):
    tablero(d, ox, ox + 40, 19, 6)
    h = 4 / math.tan(math.radians(59))
    dd = [(ox + 16, 0), (ox + 16, max(zf + h, -19)), ]
    pts = [(ox + 16, 0), (ox + 16, zf + h), (ox + 20, zf), (ox + 24, zf + h), (ox + 24, 0)]
    d.poli(pts, GRIS, 0.8, fill='#ffffff', cerrar=True)
    broca(d, ox + 20, zf, largo=8, col='rgba(154,166,178,.55)')
    d.linea((ox - 5, zf), (ox + 46, zf), col, 1, dash='4 3')
    d.texto((ox + 20, -27), txt.split(':')[0], col, 13, 'middle', '700', dy=8)
    for i, t in enumerate(txt.split(':')[1].strip().split(', ')):
        d.texto((ox + 20, -27), t, col, 11.5, 'middle', dy=24 + 15 * i)
d.texto((0, 0), 'tablero de 19', GRIS, 11, 'start', dx=2, dy=-6); d.texto((0, -19), 'martiriño', GRIS, 11, 'start', dx=2, dy=24)
d.svg('pasante')
print('dibujos en', os.path.join(AQUI, 'diagramas'))
