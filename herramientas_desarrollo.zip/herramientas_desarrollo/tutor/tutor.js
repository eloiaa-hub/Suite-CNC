// ════════════════════════════════════════════════════════════════════
//  TUTOR G-CODE: el Calcador para aprender G-code.
//  Mientras se dibuja, el programa de la pieza se escribe solo, línea a línea y comentado
//  (👁 Aprender), o lo escribe el alumno y el Tutor le corrige cada línea (✍ Practicar).
//  Un ejercicio del profesor (JSON guardado con «🎓 Ejercicio para el Tutor» en el Calcador)
//  se abre solo en Practicar: se ve el plano, pero no el programa.
// ════════════════════════════════════════════════════════════════════
const TU = {
    modo: 'aprender', ejercicio: null, nivel: 3, pestana: 'programa', sel: -1, verAbs: true,
    prog: null, sim: null, practica: null, ultimaFirma: ''
};
try { const g = JSON.parse(localStorage.getItem('tutor_pref') || 'null'); if (g && typeof g === 'object') { if (g.nivel >= 1 && g.nivel <= 3) TU.nivel = g.nivel; if (typeof g.verAbs === 'boolean') TU.verAbs = g.verAbs; } } catch (e) {}
function tuGuardarPref() { try { localStorage.setItem('tutor_pref', JSON.stringify({ nivel: TU.nivel, verAbs: TU.verAbs })); } catch (e) {} }
const tuF = v => { v = Math.round(v * 1000) / 1000; const r = Math.round(v); return Math.abs(v - r) < 5e-4 ? String(r === 0 ? 0 : r) : String(+v.toFixed(3)); };
const tuEsc = t => String(t === undefined || t === null ? '' : t).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
const tuSinTildes = t => String(t).normalize('NFD').replace(/[̀-ͯ]/g, '');
function tuArco(p1, p2, b) {
    const s = (1 / b - b) / 2;
    const c = { x: (p1.x + p2.x) / 2 - s * (p2.y - p1.y) / 2, y: (p1.y + p2.y) / 2 + s * (p2.x - p1.x) / 2 };
    return { c, r: Math.hypot(p1.x - c.x, p1.y - c.y), g: b > 0 ? 'G3' : 'G2', grados: Math.abs(4 * Math.atan(b)) * 180 / Math.PI };
}
// Coordenadas, compensación y opciones: las del ejercicio del profesor o las de ⚙️ Mecanizado
function tuCoord() { return TU.ejercicio && TU.ejercicio.coord ? TU.ejercicio.coord : (['G90', 'G91', 'mixta'].includes(cfgMec.coord) ? cfgMec.coord : 'G90'); }
function tuComp() { return TU.ejercicio && TU.ejercicio.comp ? TU.ejercicio.comp : (['G40', 'G41', 'G42', 'auto'].includes(cfgMec.comp) ? cfgMec.comp : 'G40'); }

// ── Los trazados, en el orden en que se mecanizan, con su letra ──
function tuTrazados() {
    const tipos = tiposResueltos();
    const items = contornos.map((c, ci) => ({ c, ci, tipo: tipos[ci] }))
        .filter(o => o.c.pts.length >= 2 && (o.tipo === 'abierto' || contornoValido(o.c)) && !(typeof esIsla === 'function' && esIsla(o.c)));
    const rango = o => { try { return rangoMecanizado(o.tipo, o.c); } catch (e) { return o.tipo === 'abierto' ? -1 : o.tipo === 'interior' ? 0 : 1; } };
    items.forEach((o, k) => { o.r = rango(o); o.k = k; });
    items.sort((a, b) => a.r - b.r || a.k - b.k);
    const letras = { interior: 'ABCDGHJLMN', exterior: 'PQRSUVWXY', abierto: 'KLMNR' }, usadas = { interior: 0, exterior: 0, abierto: 0 };
    items.forEach(o => { const t = o.tipo === 'interior' ? 'interior' : o.tipo === 'abierto' ? 'abierto' : 'exterior'; const L = letras[t]; const k = usadas[t]++; o.letra = k < L.length ? L[k] : L[L.length - 1] + (k - L.length + 2); o.clase = t; });
    return items;
}

// ── El programa: una línea por movimiento, con su comentario y lo que hace en el dibujo ──
function tuGenerar() {
    const d = Math.max(0.1, +cfgFresa.d || 6), R = d / 2, coord = tuCoord(), compCfg = tuComp();
    const zSeg = Math.abs(+cfgMec.zSeg) || 20, prof = Math.abs(+cfgMec.prof) || 3, paso = Math.abs(+cfgMec.paso) || prof;
    const F = Math.max(1, +cfgMec.F || 1000), Fz = +cfgMec.Fz > 0 ? Math.min(+cfgMec.Fz, F) : F, S = Math.max(1, +cfgMec.S || 12000), T = normT(cfgMec.T) || 101;
    const zs = []; if (paso > 0 && paso < prof - 1e-9) for (let z = paso; z < prof - 1e-9; z += paso) zs.push(-z); zs.push(-prof);
    const L = [], puntos = [], etiquetas = [], malos = new Set();
    const add = (cod, com, extra) => L.push({ cod, com, ...(extra || {}) });
    const sep = com => L.push({ cod: '', com, sep: true });
    const nombre = (TU.ejercicio && TU.ejercicio.nombre) || document.getElementById('projectName').value || 'pieza';
    const items = tuTrazados();
    add(`(${tuSinTildes(nombre).toUpperCase().replace(/[()]/g, '')})`, '', { titulo: true });
    add('G71 G90', coord === 'G90' ? 'milímetros y coordenadas absolutas' : 'milímetros; empezamos en absolutas');
    add(`T${T} M06`, `fresa de Ø${tuF(d)}`);
    add(`S${tuF(S)} M03`, `arranca el husillo a ${tuF(S)} rpm`);
    add(`G0 Z${tuF(zSeg)}`, 'sube a la altura de seguridad');
    let modal = 'G90', cur = { x: 0, y: 0 };
    const xyAbs = p => `X${tuF(p.x)} Y${tuF(p.y)}`, xyInc = (a, b) => `X${tuF(+tuF(b.x) - +tuF(a.x))} Y${tuF(+tuF(b.y) - +tuF(a.y))}`;   // con los puntos ya redondeados: en G91 no se acumula el error
    items.forEach((it, idx) => {
        const c = it.c, n = c.pts.length, cerrado = c.cerrado, nom = k => it.letra + ((k % n) + 1);
        let segs = tramos(c).map(t => ({ p1: t.p1, p2: t.p2, b: t.b || 0, a: nom(t.i), bn: nom(t.j) }));
        // tabla de puntos
        const filas = [];
        for (let k = 0; k < (cerrado ? n : n); k++) {
            const llega = k === 0 ? null : segs[k - 1];
            filas.push({ nombre: nom(k), p: c.pts[k], llega });
        }
        if (cerrado) filas.push({ nombre: nom(0), p: c.pts[0], llega: segs[segs.length - 1], cierra: true });
        // compensación: lado, punto de entrada (en el medio de un lado recto) y punto de aproximación (fuera del contorno)
        let lado = null, E = null, Ap = null, eNom = null, apNom = null, debe = null, mal = false, ccw = false;
        if (cerrado && compCfg !== 'G40') {
            const m = muestrearContorno(c); ccw = areaFirmada(m) > 0;
            debe = it.clase === 'interior' ? (ccw ? 'G41' : 'G42') : (ccw ? 'G42' : 'G41');      // por fuera de la pieza, por dentro de los agujeros
            lado = compCfg === 'auto' ? debe : compCfg; mal = lado !== debe;
            const largo = s => Math.hypot(s.p2.x - s.p1.x, s.p2.y - s.p1.y);
            const k = segs.findIndex(s => !s.b && largo(s) >= Math.max(2, d));
            let u;
            eNom = 'E' + (idx + 1); apNom = 'F' + (idx + 1);
            if (k >= 0) {
                const s = segs[k]; E = { x: (s.p1.x + s.p2.x) / 2, y: (s.p1.y + s.p2.y) / 2 }; u = { x: (s.p2.x - s.p1.x) / largo(s), y: (s.p2.y - s.p1.y) / largo(s) };
                segs = [{ p1: E, p2: s.p2, b: 0, a: eNom, bn: s.bn }].concat(segs.slice(k + 1), segs.slice(0, k), [{ p1: s.p1, p2: E, b: 0, a: s.a, bn: eNom }]);
            } else {
                const s = segs[0]; E = s.p1; eNom = s.a;
                const ar = tuArco(s.p1, s.p2, s.b), rx = s.p1.x - ar.c.x, ry = s.p1.y - ar.c.y, rl = Math.hypot(rx, ry) || 1;
                u = s.b > 0 ? { x: -ry / rl, y: rx / rl } : { x: ry / rl, y: -rx / rl };
            }
            const nrm = lado === 'G41' ? { x: -u.y, y: u.x } : { x: u.y, y: -u.x };
            let dist = d + 2;
            if (it.clase === 'interior') { const bb = bboxPts(m); dist = Math.max(Math.min(dist, 0.4 * Math.min(bb.x1 - bb.x0, bb.y1 - bb.y0)), Math.min(R + 0.5, dist)); }
            Ap = { x: E.x + nrm.x * dist, y: E.y + nrm.y * dist };
            etiquetas.push({ nombre: eNom, p: E, tipo: 'entrada', ci: it.ci }, { nombre: apNom, p: Ap, tipo: 'fuera', ci: it.ci });
        }
        c.pts.forEach((p, k) => { if (!cerrado || k < n) etiquetas.push({ nombre: nom(k), p, tipo: it.clase, ci: it.ci }); });
        puntos.push({ letra: it.letra, clase: it.clase, filas, lado, E, Ap, eNom, apNom, cerrado, debe, mal, ccw, n });
        if (mal) malos.add(it.ci);
        const inicio = Ap || segs[0].p1, inicioNom = Ap ? apNom : segs[0].a;
        if (idx > 0) { add(modal === 'G91' ? `G90 G0 Z${tuF(zSeg)}` : `G0 Z${tuF(zSeg)}`, 'sube antes de ir al siguiente trazado' + (modal === 'G91' ? ' (la Z, siempre en G90)' : '')); modal = 'G90'; }
        const titulo = it.clase === 'interior' ? 'Interior' : it.clase === 'abierto' ? 'Trazo abierto (sin cerrar)' : 'Exterior';
        sep(`── ${titulo}: ${it.letra}1 … ${it.letra}${n}${lado ? ` (entra en ${eNom} con ${lado})` : ''} ──`);
        const irA = (p, pNom, primero) => {
            if (coord === 'G91' && !primero) { add(`G91 G0 ${xyInc(cur, p)}`, `en rápido hasta ${pNom}, desde donde está la fresa`, { ci: it.ci }); modal = 'G91'; }
            else { add((modal === 'G91' ? 'G90 ' : '') + `G0 ${xyAbs(p)}`, `en rápido hasta encima de ${pNom}` + (Ap && p === Ap ? (mal ? ' (⚠ dentro de la pieza)' : it.clase === 'interior' ? ', dentro del agujero' : ', fuera de la pieza') : '') + (coord !== 'G90' ? ', desde el cero pieza' : ''), { ci: it.ci }); modal = 'G90'; }
            cur = { ...p };
        };
        irA(inicio, inicioNom, idx === 0);
        zs.forEach((z, kp) => {
            if (kp > 0 && !cerrado && !Ap) {     // trazo abierto con varias pasadas: sube y vuelve al principio
                add(modal === 'G91' ? `G90 G0 Z${tuF(zSeg)}` : `G0 Z${tuF(zSeg)}`, 'sube para volver al principio del trazo'); modal = 'G90';
                irA(inicio, inicioNom, false);
            }
            add((modal === 'G91' ? 'G90 ' : '') + `G1 Z${tuF(z)} F${tuF(Fz)}`, (zs.length === 1 ? 'baja despacio a la profundidad' : `pasada ${kp + 1} de ${zs.length}: baja a Z${tuF(z)}`) + (coord !== 'G90' ? ' (la Z, en G90)' : ''), { ci: it.ci });
            modal = 'G90';
            let pf = ` F${tuF(F)}`;
            if (Ap) {
                const lTxt = lado === 'G41' ? 'izquierda' : 'derecha';
                if (coord === 'G91') { add(`G91 ${lado} G1 ${xyInc(cur, E)}${pf}`, `entrada a ${eNom}: activa ${lado} (la fresa va a la ${lTxt} del contorno; pasa a G91)` + (mal ? ` ⚠ aquí va ${debe}` : ''), { ci: it.ci }); modal = 'G91'; }
                else add(`${lado} G1 ${xyAbs(E)}${pf}`, `entrada a ${eNom}: activa ${lado} (la fresa va a la ${lTxt} del contorno)` + (mal ? ` ⚠ aquí va ${debe}` : ''), { ci: it.ci });
                cur = { ...E }; pf = '';
            }
            segs.forEach((s, k) => {
                const ultimo = k === segs.length - 1, arc = !!s.b;
                let pre = '', xy;
                if (coord === 'G90' || (coord === 'mixta' && ultimo && cerrado)) { if (modal === 'G91') { pre = 'G90 '; modal = 'G90'; } xy = xyAbs(s.p2); }
                else { if (modal === 'G90') { pre = 'G91 '; modal = 'G91'; } xy = xyInc(s.p1, s.p2); }
                const ar = arc ? tuArco(s.p1, s.p2, s.b) : null;
                const ij = arc ? ` I${tuF(ar.c.x - s.p1.x)} J${tuF(ar.c.y - s.p1.y)}` : '';
                let com = arc ? `${s.a} → ${s.bn}: arco ${ar.g === 'G2' ? 'horario' : 'antihorario'} R${tuF(ar.r)}, centro X${tuF(ar.c.x)} Y${tuF(ar.c.y)}` : `${s.a} → ${s.bn}: recta`;
                if (ultimo && cerrado) com += pre.startsWith('G90') && coord !== 'G90' ? ' (cierra, en G90)' : ' (cierra)';
                else if (coord !== 'G90' && pre) com += pre.startsWith('G91') ? ' (pasa a G91)' : ' (vuelve a G90)';
                add(`${pre}${arc ? ar.g : 'G1'} ${xy}${ij}${pf}`, com, { ci: it.ci, seg: s });
                pf = ''; cur = { ...s.p2 };
            });
            if (Ap) {
                if (coord === 'G91') add(`G40 G1 ${xyInc(cur, Ap)}`, `salida a ${apNom}: anula la compensación`, { ci: it.ci });
                else add((modal === 'G91' ? 'G90 ' : '') + `G40 G1 ${xyAbs(Ap)}`, `salida a ${apNom}: anula la compensación` + (modal === 'G91' ? ' (vuelve a G90)' : ''), { ci: it.ci });
                if (coord !== 'G91') modal = 'G90';
                cur = { ...Ap };
            }
        });
    });
    add(modal === 'G91' ? `G90 G0 Z${tuF(zSeg)}` : `G0 Z${tuF(zSeg)}`, 'sube a la altura de seguridad' + (modal === 'G91' ? ' (vuelve a absolutas)' : ''));
    if (items.length) add('G0 X0 Y0', 'vuelve encima del cero pieza');
    add('M05', 'para el husillo');
    add('M30', 'fin del programa');
    const ancho = Math.min(30, Math.max(16, ...L.filter(l => !l.sep && !l.titulo).map(l => l.cod.length + 2)));
    L.forEach(l => { l.texto = l.sep ? '; ' + l.com : l.titulo ? l.cod : l.com ? l.cod.padEnd(ancho) + '; ' + l.com : l.cod; });
    return { malos, ancho, lineas: L, texto: L.map(l => l.texto).join('\n') + '\n', puntos, etiquetas, vacio: !items.length, coord, comp: compCfg, R, nombre };
}

// ════════════════════════════════════════════════
//  Estado modal de una línea (para corregir lo que escribe el alumno)
// ════════════════════════════════════════════════
function tuEstado0() { return { abs: true, mot: null, comp: 40, unit: 1, F: null, S: null, T: null, x: 0, y: 0, z: null, ms: [], w: {}, gs: [], mov: null }; }
function tuAplicar(st0, linea) {
    const st = { ...st0, ms: [], w: {}, gs: [], mov: null, error: null };
    let l = String(linea).replace(/\([^)]*\)/g, ' ').split(';')[0].trim().toUpperCase();
    if (!l) return st;
    l = l.replace(/(\d),(\d)/g, '$1.$2').replace(/([A-Z])\s+(?=[-+.\d])/g, '$1').replace(/([-+])\s+(?=[.\d])/g, '$1');
    const re = /[A-Z][-+]?(?:\d+\.?\d*|\.\d+)/g, pal = l.match(re) || [];
    const resto = l.replace(re, ' ').trim();
    if (resto) { st.error = `No entiendo «${resto.split(/\s+/)[0]}»: cada palabra es una letra seguida de un número (por ejemplo, X25 o G1).`; return st; }
    pal.forEach(p => { const Lt = p[0], v = parseFloat(p.slice(1)); if (Lt === 'G') st.gs.push(Math.round(v)); else if (Lt === 'M') st.ms.push(Math.round(v)); else st.w[Lt] = v; });
    st.gs.forEach(g => {
        if (g === 90) st.abs = true; else if (g === 91) st.abs = false;
        else if (g >= 0 && g <= 3) st.mot = g;
        else if (g === 40 || g === 41 || g === 42) st.comp = g;
        else if (g === 20 || g === 70) st.unit = 25.4; else if (g === 21 || g === 71) st.unit = 1;
    });
    if ('F' in st.w) st.F = st.w.F; if ('S' in st.w) st.S = st.w.S; if ('T' in st.w) st.T = normT(st.w.T);
    const w = st.w, f = st.unit;
    if ('X' in w || 'Y' in w || 'Z' in w) {
        const nx = 'X' in w ? (st.abs ? w.X * f : st0.x + w.X * f) : st0.x;
        const ny = 'Y' in w ? (st.abs ? w.Y * f : st0.y + w.Y * f) : st0.y;
        const nz = 'Z' in w ? (st.abs ? w.Z * f : (st0.z === null ? 0 : st0.z) + w.Z * f) : st0.z;
        const mot = st.mot === null ? 0 : st.mot;
        st.mov = { mot, x0: st0.x, y0: st0.y, z0: st0.z, x: nx, y: ny, z: nz, c: null };
        if (mot === 2 || mot === 3) {
            if ('I' in w || 'J' in w) st.mov.c = { x: st0.x + (w.I || 0) * f, y: st0.y + (w.J || 0) * f };
            else if ('R' in w) {
                const dx = nx - st0.x, dy = ny - st0.y, dd = Math.hypot(dx, dy), r = Math.abs(w.R * f);
                if (dd > 1e-9 && r >= dd / 2 - 1e-6) {
                    const h = Math.sqrt(Math.max(0, r * r - dd * dd / 4)), mx = (st0.x + nx) / 2, my = (st0.y + ny) / 2, ux = -dy / dd, uy = dx / dd;
                    const cands = [{ x: mx + ux * h, y: my + uy * h }, { x: mx - ux * h, y: my - uy * h }];
                    const barrido = c => { const a0 = Math.atan2(st0.y - c.y, st0.x - c.x), a1 = Math.atan2(ny - c.y, nx - c.x); let dA = a1 - a0; if (mot === 3) { while (dA <= 0) dA += TAU; } else { while (dA >= 0) dA -= TAU; } return Math.abs(dA); };
                    const corto = w.R >= 0, b0 = barrido(cands[0]), b1 = barrido(cands[1]);
                    st.mov.c = corto ? (b0 <= b1 ? cands[0] : cands[1]) : (b0 >= b1 ? cands[0] : cands[1]);
                }
            }
        }
        st.x = nx; st.y = ny; st.z = nz;
    }
    return st;
}
// ¿Hace lo mismo la línea del alumno que la del programa? Devuelve null si sí, o el motivo
function tuComparar(prev, e, s, lin) {
    if (s.error) return s.error;
    const tol = 2e-3, igual = (a, b) => a === b || (a !== null && b !== null && Math.abs(a - b) < tol), M2 = m => 'M' + String(m).padStart(2, '0');
    const QUE_M = { 3: 'arrancar el husillo', 5: 'parar el husillo', 6: 'cambiar la herramienta', 30: 'terminar el programa', 2: 'terminar el programa' };
    const norm = m => m === 2 ? 30 : m;
    const mE = new Set(e.ms.map(norm)), mS = new Set(s.ms.map(norm));
    for (const m of mE) if (!mS.has(m)) return `Falta ${M2(m)}: en esta línea hay que ${QUE_M[m] || 'usar esa función'}.`;
    for (const m of mS) if (!mE.has(m)) return `Sobra ${M2(m)}: aquí no toca ${QUE_M[m] || 'esa función'}.`;
    if (!igual(e.T, s.T)) return s.T === prev.T ? 'Falta la herramienta: la T con su número (míralo en ⚙️ Mecanizado).' : `La herramienta no es T${s.T}: es la de ⚙️ Mecanizado.`;
    if (!igual(e.S, s.S)) return s.S === prev.S ? 'Falta la S con las vueltas del husillo (mira ⚙️ Mecanizado).' : `El husillo no gira a S${s.S}: mira ⚙️ Mecanizado.`;
    if (e.unit !== s.unit) return 'Las medidas van en milímetros: G71 (o G21).';
    if (e.abs !== s.abs) {
        const soloZ = e.mov && 'Z' in e.w && !('X' in e.w) && !('Y' in e.w);
        if (e.abs) return soloZ ? 'La Z va siempre en G90 (absolutas): escribe G90 en esta línea.' : 'Aquí el programa va (o vuelve) a G90, absolutas: escríbelo en la línea.';
        return 'Aquí el programa va en G91, incrementales: si venía de G90, escribe G91 en la línea.';
    }
    if (e.comp !== s.comp) {
        if (e.comp === 40) return 'Esta es la salida del contorno: anula la compensación con G40 en este movimiento.';
        if (s.comp === 40) return `Esta es la entrada al contorno: activa la compensación (G41 o G42) en este movimiento.`;
        return `La compensación va del otro lado: G41 deja la fresa a la izquierda del sentido de avance y G42, a la derecha. Mira la flecha del sentido en el dibujo.`;
    }
    if (!!e.mov !== !!s.mov) return e.mov ? 'En esta línea la fresa se mueve: faltan las coordenadas.' : 'En esta línea la fresa no se mueve: sobran las coordenadas.';
    if (e.mov) {
        const a = e.mov.mot, b = s.mov.mot, arc = m => m === 2 || m === 3;
        if (a !== b) {
            if (a === 0) return 'Aquí la fresa no corta: va en rápido, con G0.';
            if (b === 0) return 'Aquí la fresa corta: no puede ir en rápido (G0).' + (a === 1 ? ' Es una recta: G1.' : ' Es un arco: G2 o G3.');
            if (a === 1) return 'Este tramo es una recta (G1), no un arco.';
            if (!arc(b)) return 'Este tramo es un arco: G2 (horario) o G3 (antihorario).';
            return 'El sentido del arco no es ese: G2 es horario (como las agujas del reloj) y G3, antihorario. Mira la flecha del sentido en el dibujo.';
        }
        const ejes = ['X', 'Y', 'Z'].filter(k => !igual(e.mov[k.toLowerCase()], s.mov[k.toLowerCase()]));
        if (ejes.length) {
            // ¿ha escrito lo que se mueve en G90, o el punto en G91? (mirando todos los ejes de la línea)
            const esc = ['X', 'Y', 'Z'].filter(q => q in s.w), dsd = q => prev[q.toLowerCase()] === null ? 0 : prev[q.toLowerCase()];
            if (esc.length && esc.some(q => Math.abs(e.mov[q.toLowerCase()] - dsd(q)) > tol)) {
                if (s.abs && esc.every(q => igual(s.w[q] * s.unit, e.mov[q.toLowerCase()] - dsd(q)))) return 'Estás en G90: cada número es el punto al que va la fresa, medido desde el cero pieza, no lo que se mueve.';
                if (!s.abs && esc.every(q => igual(s.w[q] * s.unit, e.mov[q.toLowerCase()]))) return `Estás en G91: cada número es lo que se mueve la fresa desde donde está (X${tuF(prev.x)} Y${tuF(prev.y)}), no el punto al que va.`;
            }
            const k = ejes[0], kk = k.toLowerCase(), desde = prev[kk] === null ? 0 : prev[kk], dE = e.mov[kk] - desde, vS = s.w[k];
            const bien = ['X', 'Y', 'Z'].filter(q => !ejes.includes(q) && (q in s.w));
            const ok = bien.length ? ` (la ${bien.join(' y la ')} está bien)` : '';
            if (vS === undefined) return `Falta la ${k}: la fresa también se mueve en ${k}.`;
            if (s.abs && igual(vS * s.unit, dE) && Math.abs(dE) > tol) return `Estás en G90: la ${k} es el punto al que va, medido desde el cero pieza, no lo que se mueve${ok}.`;
            if (!s.abs && igual(vS * s.unit, e.mov[kk]) && Math.abs(dE - vS) > tol) return `Estás en G91: la ${k} es lo que se mueve desde donde está la fresa (${k}${tuF(desde)}), no el punto al que va${ok}.`;
            if (igual(-vS * s.unit, s.abs ? e.mov[kk] : dE)) return `Revisa el signo de la ${k}${ok}.` + (!s.abs ? (k === 'Z' ? ' En G91, Z negativa es bajar.' : ` En G91, ${k} negativa es hacia ${k === 'X' ? 'la izquierda' : 'abajo'}.`) : '');
            return `La ${k} no es correcta${ok}. ` + (s.abs ? 'Sácala de las cotas del plano, desde el cero pieza.' : 'En G91 es lo que se mueve: la diferencia entre el punto al que va y el punto en el que está.');
        }
        if (arc(a)) {
            if (!s.mov.c) return 'Al arco le falta el centro (I y J) o el radio (R).';
            if (!igual(e.mov.c.x, s.mov.c.x) || !igual(e.mov.c.y, s.mov.c.y)) {
                if ('I' in s.w || 'J' in s.w) {
                    const iE = e.mov.c.x - prev.x, jE = e.mov.c.y - prev.y, I = s.w.I || 0, J = s.w.J || 0;
                    if (igual(I, e.mov.c.x) && igual(J, e.mov.c.y) && (Math.abs(iE - I) > tol || Math.abs(jE - J) > tol)) return `I y J se cuentan desde el punto de partida del arco (X${tuF(prev.x)} Y${tuF(prev.y)}), no desde el cero pieza.`;
                    if (igual(-I, iE) && igual(J, jE) && Math.abs(iE) > tol) return 'Revisa el signo de I.';
                    if (igual(I, iE) && igual(-J, jE) && Math.abs(jE) > tol) return 'Revisa el signo de J.';
                    if (igual(I, iE)) return 'La I está bien; revisa la J (la distancia en Y desde el inicio del arco hasta su centro).';
                    if (igual(J, jE)) return 'La J está bien; revisa la I (la distancia en X desde el inicio del arco hasta su centro).';
                    return 'El centro del arco no es ese: I es la distancia en X desde el inicio del arco hasta el centro, y J, en Y.';
                }
                const rE = Math.hypot(e.mov.c.x - prev.x, e.mov.c.y - prev.y);
                if (igual(Math.abs(s.w.R), rE)) return 'Con ese signo de R sale el otro arco: R positivo es el arco corto (180° o menos) y R negativo, el largo.';
                return 'El radio del arco no es ese.';
            }
        }
    }
    const tieneF = /F[-+]?[\d.]/i.test(lin.cod);
    if (!igual(e.F, s.F)) {
        if (!('F' in s.w)) return tieneF ? (e.mov && e.mov.mot === 1 && 'Z' in e.w && !('X' in e.w) ? 'Falta el avance F para bajar: el de penetración de ⚙️ Mecanizado.' : 'Falta el avance F: el de corte de ⚙️ Mecanizado.') : 'Falta el avance F.';
        return `El avance no es F${tuF(s.F)}: ` + (e.mov && 'Z' in e.w && !('X' in e.w) ? 'para bajar se usa el de penetración' : 'para cortar se usa el de corte') + ' de ⚙️ Mecanizado.';
    }
    return null;
}

// ════════════════════════════════════════════════
//  Simulación sobre el dibujo (con la compensación real) y explicación de cada línea
// ════════════════════════════════════════════════
function tuTextoActivo() {
    if (!TU.prog) return '';
    if (TU.modo === 'aprender') return TU.prog.texto;
    const p = TU.practica; if (!p) return '';
    return TU.prog.lineas.slice(0, p.idx).map((l, i) => l.sep || l.titulo ? l.texto : (p.escritas[i] || l.cod)).join('\n') + '\n';
}
function tuConstruirSim() {
    const texto = tuTextoActivo();
    TU.sim = null; TU.explic = [];
    if (!texto.trim()) return;
    try {
        const prog = interpretarISO(texto), R = Math.max(0, (+cfgFresa.d || 0) / 2);
        if (!TU.prog.maquina) prog.segs.forEach(sg => { sg.T = null; });      // en el programa de la solución manda el Ø de ⚙️ Mecanizado (en el de la máquina, cada T con el suyo)
        const { items, T } = itemsDePrograma(prog, R);
        const finLinea = {}; items.forEach(it => { finLinea[it.linea] = it.t1; });
        TU.sim = { items, T, t: TU.sim ? TU.sim.t : 0, finLinea, jugando: false, raf: null };
    } catch (e) { console.warn('Tutor: simulación', e); }
    try { const moves = TUTSIM.parsear(texto); TU.explic = TUTSIM.explicar(texto, moves); } catch (e) { console.warn('Tutor: explicación', e); TU.explic = []; }
}
function tuIrALinea(i) {
    TU.sel = i;
    const s = TU.sim;
    if (s) {
        let t = 0; for (let k = 0; k <= i; k++) if (s.finLinea[k] !== undefined) t = s.finLinea[k];
        s.t = t;
    }
    tuPintarLista(); tuPintarExplicacion(); render();
}
function tuPaso(dir) {
    const n = TU.prog ? (TU.modo === 'aprender' ? TU.prog.lineas.length : TU.practica.idx) : 0; if (!n) return;
    tuPausa();
    const conMov = i => TU.sim && TU.sim.finLinea[i] !== undefined;
    let i = TU.sel;
    if (dir > 0) { do { i++; } while (i < n - 1 && !conMov(i) && !TU.prog.lineas[i].cod); }
    else { do { i--; } while (i > 0 && !conMov(i) && !TU.prog.lineas[i].cod); }
    tuIrALinea(Math.max(0, Math.min(n - 1, i)));
}
function tuInicio() { tuPausa(); TU.sel = -1; if (TU.sim) TU.sim.t = 0; tuPintarLista(); tuPintarExplicacion(); render(); }
function tuFin() { const n = TU.modo === 'aprender' ? (TU.prog ? TU.prog.lineas.length : 0) : (TU.practica ? TU.practica.idx : 0); if (n) tuIrALinea(n - 1); }
function tuPausa() { const s = TU.sim; if (s && s.jugando) { s.jugando = false; cancelAnimationFrame(s.raf); } tuBotonPlay(); }
function tuPlay() {
    const s = TU.sim; if (!s) return;
    if (s.jugando) { tuPausa(); return; }
    if (s.t >= s.T - 1e-9) s.t = 0;
    s.jugando = true; tuBotonPlay();
    let ult = performance.now();
    const tick = ahora => {
        if (!s.jugando || TU.sim !== s) return;
        const dt = Math.min(0.1, (ahora - ult) / 1000); ult = ahora;
        s.t = Math.min(s.T, s.t + dt * (typeof SIM_BASE === 'number' ? SIM_BASE : 18) * 2 * TU.vel);
        const i = itemEnLista(s.items, Math.max(0, s.t - 1e-9)), it = s.items[i];
        if (it && it.linea !== TU.sel) { TU.sel = it.linea; tuPintarLista(); tuPintarExplicacion(); }
        render();
        if (s.t >= s.T - 1e-9) { tuPausa(); return; }
        s.raf = requestAnimationFrame(tick);
    };
    s.raf = requestAnimationFrame(tick);
}
TU.vel = 1;
TU.fuente = 'solucion';
try { const f = localStorage.getItem('calcador2_fuente'); if (f === 'maquina') TU.fuente = f; } catch (e) {}
function tuBotonPlay() { const b = document.getElementById('tuPlay'); if (b) { const j = !!(TU.sim && TU.sim.jugando); b.textContent = j ? '⏸' : '▶'; b.classList.toggle('activo', j); } }

// Dibujo: nombres de los puntos, el recorrido hecho, la fresa y, al practicar, el tramo que toca
function tutorDibujar() {
    if (!TU.prog || TU.prog.vacio) return;
    ctx.save(); ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
    const oscuro = typeof modoOscuro !== 'undefined' && !!modoOscuro;
    // 1) el recorrido hecho y la fresa
    const s = TU.sim;
    if (s && (TU.sel >= 0 || s.jugando)) {
        const i = s.t <= 0 ? -1 : itemEnLista(s.items, Math.max(0, s.t - 1e-9)), act = i >= 0 ? s.items[i] : null;
        const f = act ? Math.min(1, (s.t - act.t0) / act.dur) : 0, D = Math.max(0, +cfgFresa.d || 0);
        const trazo = (g, color, w, dash) => { ctx.strokeStyle = color; ctx.lineWidth = w; ctx.setLineDash(dash || []); ctx.beginPath(); muestrasSeg(g, 2 / view.z).forEach((q, k) => { const p = aPantalla(q); k ? ctx.lineTo(p.x, p.y) : ctx.moveTo(p.x, p.y); }); ctx.stroke(); ctx.setLineDash([]); };
        const hechosIt = s.items.filter((x, k) => x.tipo === 'xy' && k < i);
        const centros = hechosIt.map(x => ({ g: x.cg || x.sg, rapido: x.rapido, comp: !!x.cg && x.cg !== x.sg, linea: x.linea })).filter(c => c.g);
        const malL = l => { const li = TU.prog.lineas[l]; return !!li && li.ci !== undefined && TU.prog.malos.has(li.ci); };
        const hechos = hechosIt.filter(x => x.sg).map(x => ({ g: x.sg, rapido: x.rapido, linea: x.linea }));
        if (act && act.tipo === 'xy') { if (act.sg) hechos.push({ g: segParcial(act.sg, f), rapido: act.rapido, linea: act.linea }); const g = act.cg || act.sg; if (g) centros.push({ g: segParcial(g, f), rapido: act.rapido, comp: !!act.cg && act.cg !== act.sg, linea: act.linea }); }
        ctx.lineCap = 'round'; ctx.lineJoin = 'round';
        if (D > 0) centros.filter(c => !c.rapido).forEach(c => trazo(c.g, malL(c.linea) ? 'rgba(231,76,60,.28)' : 'rgba(230,126,34,.15)', D * view.z));
        hechos.forEach(h => h.rapido ? trazo(h.g, '#7f8c8d', 1.4, [5, 4]) : trazo(h.g, h.linea === TU.sel ? '#d35400' : '#c4580c', h.linea === TU.sel ? 4 : 2.4));
        centros.filter(c => c.comp).forEach(c => trazo(c.g, '#8e44ad', 1.4, [4, 3]));
        let hAct = act; if (hAct && hAct.tipo !== 'xy') for (let k = i; k >= 0; k--) if (s.items[k].tipo === 'xy') { hAct = s.items[k]; break; }
        if (act) {
            const pz = puntoItem(act, f), q = aPantalla(pz.p), rr = Math.max(5, D / 2 * view.z), corta = !act.rapido && pz.z !== null && pz.z < -1e-9;
            ctx.beginPath(); ctx.arc(q.x, q.y, rr, 0, TAU); ctx.fillStyle = corta ? 'rgba(230,126,34,.45)' : 'rgba(255,255,255,.35)'; ctx.fill();
            ctx.strokeStyle = corta ? '#c4580c' : '#5d6d7e'; ctx.lineWidth = 2; ctx.setLineDash(corta ? [] : [4, 3]); ctx.stroke(); ctx.setLineDash([]);
            ctx.beginPath(); ctx.moveTo(q.x - 6, q.y); ctx.lineTo(q.x + 6, q.y); ctx.moveTo(q.x, q.y - 6); ctx.lineTo(q.x, q.y + 6); ctx.strokeStyle = oscuro ? '#ecf0f1' : '#2c3e50'; ctx.lineWidth = 1.2; ctx.stroke();
        }
    }
    // 2) al practicar: el tramo que hay que programar ahora
    if (TU.modo === 'practicar' && TU.practica && !TU.practica.fin) {
        const l = TU.prog.lineas[TU.practica.idx];
        if (l && l.seg) {
            const g = l.seg.b ? (() => { const a = tuArco(l.seg.p1, l.seg.p2, l.seg.b), a1 = Math.atan2(l.seg.p1.y - a.c.y, l.seg.p1.x - a.c.x); return { tipo: 'A', p1: l.seg.p1, p2: l.seg.p2, c: a.c, r: a.r, a1, theta: 4 * Math.atan(l.seg.b) }; })() : { tipo: 'L', p1: l.seg.p1, p2: l.seg.p2 };
            ctx.strokeStyle = '#27ae60'; ctx.lineWidth = 5; ctx.globalAlpha = 0.75; ctx.setLineDash([9, 6]); ctx.beginPath();
            muestrasSeg(g, 2 / view.z).forEach((q, k) => { const p = aPantalla(q); k ? ctx.lineTo(p.x, p.y) : ctx.moveTo(p.x, p.y); }); ctx.stroke(); ctx.setLineDash([]); ctx.globalAlpha = 1;
            const p2 = aPantalla(l.seg.p2); ctx.beginPath(); ctx.arc(p2.x, p2.y, 6, 0, TAU); ctx.fillStyle = '#27ae60'; ctx.fill();
        }
    }
    // 3) los nombres de los puntos
    if (document.getElementById('tuNombres') ? document.getElementById('tuNombres').checked : true) {
        ctx.font = '600 12px Segoe UI, Arial, sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        const porCi = {}; TU.prog.etiquetas.forEach(e => { (porCi[e.ci] = porCi[e.ci] || []).push(e); });
        const usados = [];
        TU.prog.etiquetas.forEach(e => {
            const c = contornos[e.ci]; if (!c || c.texto) return;                              // un texto de grabado: sus trazos, sin nombres (sería ilegible)
            if (TU.prog.maquina && (e.tipo === 'entrada' || e.tipo === 'fuera')) return;      // la entrada de la máquina la pone ⚙️ Mecanizar
            const m = muestrearContorno(c), cx = m.reduce((a, q) => a + q.x, 0) / m.length, cy = m.reduce((a, q) => a + q.y, 0) / m.length;
            const P = aPantalla(e.p), C = aPantalla({ x: cx, y: cy });
            let dx = C.x - P.x, dy = C.y - P.y; const dd = Math.hypot(dx, dy) || 1; dx /= dd; dy /= dd;
            if (e.tipo === 'interior' || e.tipo === 'fuera') { dx = -dx; dy = -dy; }
            if (e.tipo === 'fuera') { dx = 0; dy = -1; }
            let x = P.x + dx * 15, y = P.y + dy * 15;
            for (let k = 0; k < 4 && usados.some(u => Math.abs(u.x - x) < 18 && Math.abs(u.y - y) < 12); k++) y -= 12;
            usados.push({ x, y });
            const col = e.tipo === 'entrada' ? '#27ae60' : e.tipo === 'fuera' ? '#8e44ad' : '#d35400';
            if (e.tipo === 'fuera' || e.tipo === 'entrada') { ctx.beginPath(); ctx.arc(P.x, P.y, 3.5, 0, TAU); ctx.fillStyle = col; ctx.fill(); }
            const wTxt = ctx.measureText(e.nombre).width + 6;
            ctx.fillStyle = oscuro ? 'rgba(27,35,43,.85)' : 'rgba(255,255,255,.85)'; ctx.fillRect(x - wTxt / 2, y - 8, wTxt, 16);
            ctx.fillStyle = col; ctx.fillText(e.nombre, x, y);
        });
        ctx.textAlign = 'start'; ctx.textBaseline = 'alphabetic';
    }
    ctx.restore();
}

// ════════════════════════════════════════════════
//  El panel: programa, puntos, contornos, explicación y práctica
// ════════════════════════════════════════════════
function tuColorear(cod) {
    return tuEsc(cod).replace(/(^|\s)(G0*0?)(?=\s|$)/g, '$1<span class="tu-g0">$2</span>').replace(/(^|\s)(G\d+)(?=\s|$)/g, (m, a, g) => /tu-g0/.test(m) ? m : `${a}<span class="tu-g">${g}</span>`).replace(/(^|\s)(M\d+)(?=\s|$)/g, '$1<span class="tu-m">$2</span>');
}
function tuPintarLista() {
    const cont = document.getElementById('tuLista'); if (!cont || !TU.prog) return;
    const L = TU.prog.lineas, apr = TU.modo === 'aprender', p = TU.practica;
    const hasta = apr ? L.length : (p ? p.idx : 0);
    let h = '';
    for (let i = 0; i < hasta; i++) {
        const l = L[i], ex = TU.explic && TU.explic[i];
        const cod = l.sep ? '' : l.titulo ? l.cod : (!apr && p.escritas[i] !== undefined ? p.escritas[i] : l.cod);
        const abs = TU.verAbs && ex && ex.abs ? `<span class="tu-abs" title="En G91 cada número es lo que se mueve. Aquí la fresa queda, en absolutas, en ${tuEsc(ex.abs)}">→ ${tuEsc(ex.abs)}</span>` : '';
        const marca = !apr && p.estado[i] ? `<span class="tu-ok ${p.estado[i]}" title="${p.estado[i] === 'bien' ? 'Bien a la primera' : p.estado[i] === 'ayuda' ? 'Bien, después de algún fallo' : 'Vista con «Ver la línea»'}">${p.estado[i] === 'bien' ? '✓' : p.estado[i] === 'ayuda' ? '✓' : '👁'}</span>` : '';
        h += `<div class="tu-l${l.sep ? ' sep' : ''}${i === TU.sel ? ' sel' : ''}" data-i="${i}"><span class="tu-n">${i + 1}</span>${marca}<span class="tu-c"${l.sep || l.titulo ? '' : ` style="min-width:${TU.prog.ancho - 1}ch"`}>${l.sep ? '' : (l.titulo ? `<span class="tu-com">${tuEsc(cod)}</span>` : tuColorear(cod))}</span>${abs}${l.com ? `<span class="tu-com">; ${tuEsc(l.com)}</span>` : ''}</div>`;
    }
    if (!apr && p && !p.fin) {
        const quedan = L.slice(p.idx).filter(l => !l.sep).length;
        h += `<div class="tu-l actual" id="tuFilaActual"><span class="tu-n">${p.idx + 1}</span><input id="tuEntrada" type="text" autocomplete="off" spellcheck="false" placeholder="Escribe la línea ${p.idx + 1} y pulsa Intro" value="${tuEsc(p.borrador || '')}"></div>`;
        h += `<div class="tu-quedan">… ${quedan > 1 ? 'quedan ' + quedan + ' líneas' : 'es la última línea'}</div>`;
    }
    if (TU.prog.vacio) h += `<div class="tu-vacio">${TU_C2 ? 'Dibuja un contorno (o ábrelo con 📂 Abrir) y aquí se irá escribiendo su programa, línea a línea.' : 'Dibuja un contorno (o abre un ejemplo en 📚) y aquí se irá escribiendo su programa, línea a línea.'}</div>`;
    cont.innerHTML = h;
    cont.querySelectorAll('.tu-l[data-i]').forEach(el => el.onclick = () => tuIrALinea(+el.dataset.i));
    const e = document.getElementById('tuEntrada');
    if (e) {
        e.onkeydown = ev => { if (ev.key === 'Enter') { ev.preventDefault(); tuComprobar(); } ev.stopPropagation(); };
        e.oninput = () => { TU.practica.borrador = e.value; };
        e.onkeyup = ev => ev.stopPropagation();
        if (TU.enfocar) { TU.enfocar = false; setTimeout(() => { e.focus(); e.setSelectionRange(e.value.length, e.value.length); }, 0); }
        const fila = document.getElementById('tuFilaActual'); if (fila && fila.offsetTop > cont.scrollTop + cont.clientHeight - 30) cont.scrollTop = fila.offsetTop - cont.clientHeight / 2;
    }
    const sel = cont.querySelector('.tu-l.sel'); if (sel && (sel.offsetTop < cont.scrollTop || sel.offsetTop > cont.scrollTop + cont.clientHeight - 24)) cont.scrollTop = sel.offsetTop - cont.clientHeight / 3;
    const info = document.getElementById('tuInfoLinea'); if (info) info.textContent = TU.sel >= 0 ? `Línea ${TU.sel + 1} / ${hasta}` : `${hasta} líneas`;
}
function tuPintarExplicacion() {
    const caja = document.getElementById('tuExplicar'); if (!caja) return;
    const i = TU.sel, e = i >= 0 && TU.explic ? TU.explic[i] : null;
    if (!e || !TU.prog) { caja.innerHTML = TU.modo === 'aprender' ? (TU_C2 ? '<p class="tu-gris">Haz clic en una línea del programa o avanza con ▶▏ (o las flechas ← →) para ver qué hace y cómo se mueve la fresa en el dibujo.</p>' : '<p class="tu-gris">Haz clic en una línea del programa o avanza con ▶▏ para ver qué hace y cómo se mueve la fresa en el dibujo.</p>') : ''; return; }
    const l = TU.prog.lineas[i], cod = TU.modo === 'practicar' && TU.practica.escritas[i] !== undefined ? TU.practica.escritas[i] : (l.sep ? '; ' + l.com : l.cod);
    let h = `<div class="tu-ex-cab">💬 Línea ${i + 1}: <code>${tuColorear(cod)}</code></div><ul>`;
    e.frases.forEach(fr => { h += '<li>' + (fr.cod ? '<b>' + tuEsc(fr.cod) + '</b> ' : '') + tuEsc(fr.txt.charAt(0).toUpperCase() + fr.txt.slice(1)) + '</li>'; });
    h += '</ul>';
    if (e.sumas && e.sumas.length) h += `<div class="tu-ex-sumas"><b>📍 Dónde queda (en absolutas):</b> ${e.sumas.map(tuEsc).join(' · ')}</div>`;
    if (e.resultado) h += `<div class="tu-ex-res">${tuEsc(e.resultado)}</div>`;
    e.notas.forEach(t => { h += `<div class="tu-ex-nota">${tuEsc(t)}</div>`; });
    caja.innerHTML = h;
}
function tuPintarPuntos() {
    const cont = document.getElementById('tuPuntos'); if (!cont || !TU.prog) return;
    if (TU.ejercicio) { cont.innerHTML = '<p class="tu-gris">En un ejercicio, las coordenadas de los puntos las sacas tú de las cotas del plano. Los nombres de los puntos (P1, P2…) sí se ven en el dibujo.</p>'; return; }
    if (TU.prog.vacio) { cont.innerHTML = '<p class="tu-gris">Aún no hay contornos.</p>'; return; }
    const inc = TU.prog.coord !== 'G90';
    let h = `<table class="tu-tabla"><tr><th>Punto</th><th>X</th><th>Y</th>${inc ? '<th>ΔX</th><th>ΔY</th>' : ''}<th>Llega con</th><th>Centro</th><th>I</th><th>J</th></tr>`;
    TU.prog.puntos.forEach(g => {
        const cols = inc ? 9 : 7;
        h += `<tr class="grupo"><td colspan="${cols}">${g.clase === 'interior' ? 'Interior' : g.clase === 'abierto' ? 'Trazo abierto' : 'Exterior'} · ${g.letra}1 … ${g.letra}${g.filas.length - (g.cerrado ? 1 : 0)}${g.lado ? ` · entra en ${g.eNom} con ${g.lado}` : ''}</td></tr>`;
        if (g.lado) h += `<tr class="aux"><td><b>${g.apNom}</b></td><td>${tuF(g.Ap.x)}</td><td>${tuF(g.Ap.y)}</td>${inc ? '<td></td><td></td>' : ''}<td colspan="4">fuera del contorno: aquí baja la fresa</td></tr><tr class="aux"><td><b>${g.eNom}</b></td><td>${tuF(g.E.x)}</td><td>${tuF(g.E.y)}</td>${inc ? `<td>${tuF(g.E.x - g.Ap.x)}</td><td>${tuF(g.E.y - g.Ap.y)}</td>` : ''}<td colspan="4">entrada: G1 con ${g.lado}</td></tr>`;
        g.filas.forEach((f, k) => {
            const ll = f.llega, arc = ll && ll.b;
            const ar = arc ? tuArco(ll.p1, ll.p2, ll.b) : null;
            const d = inc ? (ll ? `<td>${tuF(f.p.x - ll.p1.x)}</td><td>${tuF(f.p.y - ll.p1.y)}</td>` : '<td>—</td><td>—</td>') : '';
            const llega = !ll ? '— (inicio)' : `${arc ? ar.g + (ar.g === 'G2' ? ' (horario)' : ' (antihorario)') : 'G1 (recta)'}${f.cierra ? ': cierra' : ''}`;
            const ctr = arc ? `<td>X${tuF(ar.c.x)} Y${tuF(ar.c.y)}</td><td>${tuF(ar.c.x - ll.p1.x)}</td><td>${tuF(ar.c.y - ll.p1.y)}</td>` : '<td></td><td></td><td></td>';
            h += `<tr${f.cierra ? ' class="cierre"' : ''}><td><b>${tuEsc(f.nombre)}</b></td><td>${tuF(f.p.x)}</td><td>${tuF(f.p.y)}</td>${d}<td>${llega}</td>${ctr}</tr>`;
        });
    });
    h += '</table><p class="tu-gris">Los arcos: I y J van del punto donde empieza el arco a su centro. ' + (inc ? 'ΔX y ΔY: lo que se mueve la fresa desde el punto anterior (lo que se escribe en G91).' : '') + '</p>';
    cont.innerHTML = h;
}
function tuPestana(t) {
    TU.pestana = t;
    document.querySelectorAll('#tutorPanel .tu-tabs button').forEach(b => b.classList.toggle('activo', b.dataset.t === t));
    ['programa', 'puntos', 'contornos'].forEach(k => { const el = document.getElementById('tuVista_' + k); if (el) el.hidden = k !== t; });
    if (t === 'puntos') tuPintarPuntos();
}

// ── Practicar ──
function tuNuevaPractica(conservar) {
    const L = TU.prog ? TU.prog.lineas : [];
    const ant = conservar && TU.practica ? TU.practica : null;
    const p = { idx: 0, escritas: {}, estado: {}, fallos: 0, intentos: 0, bien: 0, ayuda: 0, vistas: 0, borrador: '', msg: null, fin: false, esperadas: L.map(l => l.cod), fallosLinea: 0 };
    if (ant) {      // se conserva lo hecho mientras el programa no cambie
        let k = 0; while (k < ant.idx && k < L.length && ant.esperadas[k] === L[k].cod) k++;
        for (let i = 0; i < k; i++) { if (ant.escritas[i] !== undefined) p.escritas[i] = ant.escritas[i]; if (ant.estado[i]) p.estado[i] = ant.estado[i]; }
        p.idx = k; ['bien', 'ayuda', 'vistas'].forEach(c => p[c] = Object.values(p.estado).filter(v => v === c).length); p.fallos = ant.fallos;
    }
    TU.practica = p; tuSaltarAuto(); TU.enfocar = true;
}
function tuSaltarAuto() {
    const p = TU.practica, L = TU.prog.lineas;
    while (p.idx < L.length && (L[p.idx].sep || L[p.idx].titulo)) p.idx++;
    if (p.idx >= L.length) p.fin = true;
}
function tuEstadoTras(i) {
    // estado modal después de la línea i del programa esperado
    let st = tuEstado0(); const L = TU.prog.lineas;
    for (let k = 0; k <= i; k++) if (!L[k].sep && !L[k].titulo) st = tuAplicar(st, L[k].cod);
    return st;
}
function tuComprobar() {
    const p = TU.practica, L = TU.prog.lineas; if (!p || p.fin) return;
    const e = document.getElementById('tuEntrada'), txt = (e ? e.value : '').trim();
    if (!txt) { tuMensaje('info', 'Escribe la línea y pulsa Intro (o ✔ Comprobar).'); return; }
    const prev = tuEstadoTras(p.idx - 1), lin = L[p.idx];
    const esp = tuAplicar(prev, lin.cod), alu = tuAplicar(prev, txt);
    const motivo = tuComparar(prev, esp, alu, lin);
    p.intentos++;
    if (motivo) { p.fallos++; p.fallosLinea++; tuMensaje('mal', '✗ ' + motivo + (p.fallosLinea >= 2 ? ' Si te atascas: 💡 Pista o 👁 Ver la línea.' : '')); TU.enfocar = true; const en = document.getElementById('tuEntrada'); if (en) { en.classList.remove('tiembla'); void en.offsetWidth; en.classList.add('tiembla'); en.focus(); } return; }
    tuAceptar(txt, p.fallosLinea ? 'ayuda' : 'bien');
    tuMensaje('bien', p.fallosLinea ? '✓ Ahora sí.' : ['✓ ¡Bien!', '✓ Correcto.', '✓ Perfecto.', '✓ ¡Eso es!'][p.idx % 4]);
}
function tuAceptar(txt, estado) {
    const p = TU.practica, i = p.idx;
    p.escritas[i] = txt; p.estado[i] = estado; p[estado === 'vistas' ? 'vistas' : estado]++; p.fallosLinea = 0; p.borrador = ''; p.pista = false;
    p.idx++; tuSaltarAuto();
    tuConstruirSim(); TU.sel = i; if (TU.sim && TU.sim.finLinea[i] !== undefined) TU.sim.t = TU.sim.finLinea[i];
    TU.enfocar = true; tuPintarTodo();
}
function tuPista() {
    const p = TU.practica; if (!p || p.fin) return; const l = TU.prog.lineas[p.idx];
    p.pista = true; p.fallosLinea = Math.max(p.fallosLinea, 1);
    tuMensaje('info', '💡 ' + (l.com ? l.com.charAt(0).toUpperCase() + l.com.slice(1) + '.' : 'Mira el tramo marcado en verde en el dibujo.') + (l.seg ? ' En el dibujo, en verde, el tramo que toca.' : ''));
    TU.enfocar = true; tuPintarLista();
}
function tuVerLinea() {
    const p = TU.practica; if (!p || p.fin) return; const l = TU.prog.lineas[p.idx];
    if (TU.ejercicio && p.fallosLinea < 2) { tuMensaje('info', 'En un ejercicio, «Ver la línea» se puede usar después de dos intentos. Prueba con 💡 Pista.'); return; }
    tuAceptar(l.cod, 'vistas');
    tuMensaje('info', `👁 La línea era: ${l.cod}` + (l.com ? `  (${l.com})` : ''));
}
function tuMensaje(tipo, txt) { const p = TU.practica; if (p) p.msg = { tipo, txt }; tuPintarPractica(); }
function tuPintarPractica() {
    const caja = document.getElementById('tuPractica'); if (!caja) return;
    if (TU.modo !== 'practicar' || !TU.practica) { caja.hidden = true; return; }
    caja.hidden = false;
    const p = TU.practica, total = TU.prog.lineas.filter(l => !l.sep && !l.titulo).length, hechas = Object.keys(p.estado).length;
    let h = `<div class="tu-pr-barra"><div style="width:${total ? Math.round(100 * hechas / total) : 0}%"></div></div>`;
    h += `<div class="tu-pr-cuenta">${hechas} de ${total} líneas · <span class="bien">✓ ${p.bien} a la primera</span> · <span class="ayuda">✓ ${p.ayuda} con algún fallo</span> · <span class="vistas">👁 ${p.vistas} vistas</span></div>`;
    if (p.fin) {
        const nota = total ? Math.round(10 * (p.bien + 0.5 * p.ayuda) / total * 10) / 10 : 0;
        h += `<div class="tu-msg bien">🎉 ¡Programa terminado! ${p.bien} de ${total} líneas a la primera${p.vistas ? `, ${p.vistas} vistas` : ''}. Nota orientativa: <b>${String(nota).replace('.', ',')}</b> / 10.</div>`;
        h += `<div class="tu-pr-bot"><button onclick="tuEnviarSimulador()">➜ Probarlo en el Simulador</button><button onclick="tuDescargar(true)">⬇ Mi programa (.nc)</button><button onclick="tuNuevaPractica(); tuPintarTodo()">↺ Otra vez</button></div>`;
    } else {
        h += `<div class="tu-pr-bot"><button class="principal" onclick="tuComprobar()" title="Comprueba la línea (Intro)">✔ Comprobar</button><button onclick="tuPista()" title="El comentario de la línea y, en el dibujo, el tramo que toca">💡 Pista</button><button onclick="tuVerLinea()" title="Escribe la línea por ti (cuenta como vista)">👁 Ver la línea</button></div>`;
        if (p.msg) h += `<div class="tu-msg ${p.msg.tipo}">${tuEsc(p.msg.txt)}</div>`;
    }
    caja.innerHTML = h;
}
function tuModo(m) {
    if (m === 'aprender' && TU.ejercicio) { snack('Es un ejercicio: el programa lo escribes tú (✍ Practicar)'); m = 'practicar'; }
    tuPausa();
    TU.modo = m; TU.sel = -1;
    const bA = document.getElementById('tuBtnAprender'), bP = document.getElementById('tuBtnPracticar');
    if (bA) bA.classList.toggle('activo', m === 'aprender'); if (bP) bP.classList.toggle('activo', m === 'practicar');
    if (m === 'practicar' && !TU.practica) tuNuevaPractica();
    TU.enfocar = m === 'practicar';
    tuConstruirSim(); tuPintarTodo();
}
function tuPintarAviso() {
    const el = document.getElementById('tuAviso'); if (!el) return;
    const g = TU.prog ? TU.prog.puntos.filter(x => x.mal) : [];
    const am = TU.prog && TU.prog.avisosMaq ? TU.prog.avisosMaq : [];
    el.hidden = !g.length && !am.length;
    el.innerHTML = am.map(a => '⚠ ' + tuEsc(a)).concat(g.map(x => {
        const ext = x.clase !== 'interior', sentido = x.ccw ? 'antihorario' : 'horario';
        return `⚠ <b>${ext ? 'Exterior' : 'Interior'} ${x.letra}1 … ${x.letra}${x.n}</b>: con ${x.lado} la fresa va ${ext ? 'por dentro de la pieza' : 'por fuera del agujero'} y se come la pieza (en rojo en el dibujo). `
            + `Este contorno va en sentido ${sentido}: para ir ${ext ? 'por fuera' : 'por dentro'}, <b>${x.debe}</b>. O elige «G41/G42 · por fuera de la pieza y por dentro de los agujeros».`;
    })).join('<br>');
}
function tuFuente(f) {
    TU.fuente = f === 'maquina' ? 'maquina' : 'solucion';
    try { localStorage.setItem('calcador2_fuente', TU.fuente); } catch (e) {}
    tuPintarFuente(); TU.sel = -1; tuRefrescar(true);
}
function tuPintarFuente() {
    const a = document.getElementById('tuFuenteSol'), b = document.getElementById('tuFuenteMaq'); if (!a) return;
    a.classList.toggle('activo', TU.fuente === 'solucion'); b.classList.toggle('activo', TU.fuente === 'maquina');
    document.getElementById('tutorPanel').classList.toggle('maquina', TU.fuente === 'maquina');
}
// El programa de ⚙️ Mecanizar (el de la máquina), con las mismas opciones, como lista de líneas
function tuProgMaquina(sol) {
    const P = { feed: cfgMec.F, feedZ: cfgMec.Fz, feedPos: cfgMec.F0, tool: cfgMec.T, toolR: (+cfgFresa.d || 0) / 2, spindle: cfgMec.S, zSafe: Math.abs(+cfgMec.zSeg),
        zTotal: -Math.abs(+cfgMec.prof), zStep: Math.abs(+cfgMec.paso), sobre: Math.max(0, +cfgMec.acab || 0), coord: cfgMec.coord, comp: cfgMec.comp,
        estrategia: cfgMec.estr, unidades: cfgMec.unid, orden: cfgMec.orden, nombre: nombreProyecto(), nombreHerr: cfgFresa.herr ? cfgFresa.herr.nombre : '' };
    let out; try { out = sol.vacio ? { error: 'Dibuja o abre una pieza' } : MEC.generar(trazadosParaMecanizar(), P); } catch (e) { out = { error: 'Error interno: ' + e.message }; }
    const nc = out.error ? '; ⚠ ' + out.error : out.nc.replace(/\r/g, '').replace(/\n+$/, '');
    const lineas = nc.split('\n').map(t => { const i = t.indexOf(';'), cod = (i >= 0 ? t.slice(0, i) : t).trim(), com = i >= 0 ? t.slice(i).replace(/^;+\s?/, '').trim() : '';
        return cod ? { cod, com } : { cod: '', com, sep: true }; });
    const ancho = Math.min(30, Math.max(16, ...lineas.filter(l => !l.sep).map(l => l.cod.length + 2)));
    lineas.forEach((l, k) => { l.texto = nc.split('\n')[k]; });
    return { ...sol, maquina: true, lineas, texto: nc + '\n', ancho, avisosMaq: out.error ? [out.error] : (out.avisos || []) };
}
function tuPintarTodo() {
    tuPintarAviso(); tuNotaHerr();
    const apr = TU.modo === 'aprender';
    document.getElementById('tutorPanel').classList.toggle('practicando', !apr);
    document.getElementById('tuDescargar').hidden = !apr;
    tuPintarLista(); tuPintarExplicacion(); tuPintarPractica();
    if (TU.pestana === 'puntos') tuPintarPuntos();
    tuPintarEjercicio(); tuBotonPlay(); render();
}
function tuPintarEjercicio() {
    const b = document.getElementById('tuEjercicio'); if (!b) return;
    document.documentElement.classList.toggle('tu-es-ejercicio', !!TU.ejercicio);
    if (!TU.ejercicio) { b.hidden = true; return; }
    b.hidden = false;
    const comp = { G40: 'sin compensación (G40)', auto: 'con compensación G41/G42', G41: 'con G41', G42: 'con G42' }[TU.ejercicio.comp] || '';
    b.innerHTML = `🎓 <b>Ejercicio:</b> ${tuEsc(TU.ejercicio.nombre || '')}<br><span>Escribe tú el programa, en ${TU.ejercicio.coord === 'mixta' ? 'mixta (G90 y G91)' : TU.ejercicio.coord}, ${comp}. Las medidas, en las cotas del plano.</span> <button onclick="tuSalirEjercicio()" title="Deja el ejercicio y vuelve a dibujar libremente">✕ Dejar el ejercicio</button>`;
}
function tuSalirEjercicio() {
    if (TU.practica && Object.keys(TU.practica.estado).length && !TU.practica.fin && !confirm('¿Dejar el ejercicio? Se pierde lo que llevas escrito.')) return;
    TU.ejercicio = null; TU.practica = null; tuGuardarEjercicio(); tuPintarMec(); tuRefrescar(true); tuModo('aprender'); setHerramienta('linea');
}
function tuGuardarEjercicio() { try { localStorage.setItem('tutor_ejercicio', JSON.stringify(TU.ejercicio)); } catch (e) {} }

// ── ⚙️ Mecanizado (las opciones del programa) ──
const TU_CAMPOS = { tuT: 'T', tuProf: 'prof', tuPaso: 'paso', tuF: 'F', tuFz: 'Fz', tuS: 'S', tuCoord: 'coord', tuCompSel: 'comp', tuF0: 'F0', tuZseg: 'zSeg', tuAcab: 'acab', tuEstr: 'estr', tuOrden: 'orden', tuUnid: 'unid' };
function tuPintarMec() {
    Object.entries(TU_CAMPOS).forEach(([id, k]) => { const el = document.getElementById(id); if (el) el.value = cfgMec[k]; });
    const d = document.getElementById('tuD'); if (d) d.value = cfgFresa.d;
    const fijo = !!TU.ejercicio;
    if (fijo) { document.getElementById('tuCoord').value = tuCoord(); document.getElementById('tuCompSel').value = tuComp(); }
    ['tuCoord', 'tuCompSel'].forEach(id => { const el = document.getElementById(id); el.disabled = fijo; el.title = fijo ? 'Lo fija el ejercicio del profesor' : el.dataset.tip || ''; });
}
function tuFijarD(v) { const f = document.getElementById('fresaD'); f.value = v; f.dispatchEvent(new Event('input')); const d = document.getElementById('tuD'); if (d && document.activeElement !== d) d.value = v; }
// La T y el Ø van juntos: una T de la base de herramientas tiene su Ø (el Simulador la usa con ese Ø).
// Si el Ø no es el de la T, se usa la T de la base con ese Ø o, si no hay, un número libre (fresa a mano).
function tuCasarHerr(avisar) {
    const T = normT(cfgMec.T) || 101, d = +cfgFresa.d, h = HB.porT(T), base = HB.leer(), otra = base.find(x => Math.abs(x.d - d) < 1e-6);
    if (h ? Math.abs(h.d - d) < 1e-6 : !otra) return false;      // ya casan, o es una fresa a mano que no está en la base
    let nT = otra ? otra.T : null;
    if (!nT) { for (let k = 101; k < 1000; k++) if (!base.some(x => x.T === k)) { nT = k; break; } }
    cfgMec.T = nT; const el = document.getElementById('tuT'); if (el) el.value = nT;
    if (avisar) snack(otra ? `La fresa de Ø${tuF(d)} es la T${nT} de la base de herramientas` : `T${T} es la fresa de Ø${tuF(h.d)}: para Ø${tuF(d)} se usa T${nT} (no está en la base de herramientas)`);
    return true;
}
function tuNotaHerr() {
    const el = document.getElementById('tuHerrNota'); if (!el) return;
    const T = normT(cfgMec.T), h = HB.porT(T);
    el.textContent = h ? `T${T}: ${h.nombre || 'fresa'} de la base de herramientas (Ø${tuF(h.d)})` : `T${T}: no está en la base de herramientas, fresa de Ø${tuF(+cfgFresa.d)}`;
}
function tuLeerMec(ev) {
    const id = ev && ev.target && ev.target.id;
    if (id === 'tuD') { const v = numES(ev.target.value); if (v > 0) { tuFijarD(v); tuCasarHerr(true); } }
    if (id === 'tuT') { const v = numES(ev.target.value), h = v > 0 ? HB.porT(normT(v)) : null; if (h) { tuFijarD(h.d); const d = document.getElementById('tuD'); if (d) d.value = h.d; } }
    Object.entries(TU_CAMPOS).forEach(([k2, k]) => {
        const el = document.getElementById(k2); if (!el || el.disabled) return;
        if (el.tagName === 'SELECT') cfgMec[k] = el.value; else { const v = numES(el.value); if (isFinite(v) && (v > 0 || (k === 'acab' && v === 0))) cfgMec[k] = v; }
    });
    if (id === 'tuOrden') { try { refrescar(); } catch (e) {} }      // el plano renumera las entradas E1, E2…
    guardarAutoPronto(); tuRefrescar(true);
}

// ── Regenerar el programa cuando cambia el dibujo o las opciones ──
let tTuRef = null;
function tutorRefrescar() { clearTimeout(tTuRef); tTuRef = setTimeout(() => tuRefrescar(false), 120); }
function tuFirma() { return JSON.stringify([contornos.map(c => [c.pts, c.b, c.cerrado, c.tipo]), cfgFresa.d, cfgMec.T, cfgMec.F, cfgMec.Fz, cfgMec.S, cfgMec.zSeg, cfgMec.prof, cfgMec.paso, tuCoord(), tuComp(), cfgMec.orden, cfgMec.acab, cfgMec.estr, cfgMec.unid, cfgMec.F0, TU.fuente, TU_C2 ? contornos.map(c => c.mec || null) : 0, document.getElementById('projectName').value, TU.ejercicio && TU.ejercicio.nombre]); }
function tuRefrescar(forzar) {
    const f = tuFirma(); if (!forzar && f === TU.ultimaFirma) return; TU.ultimaFirma = f;
    const antes = TU.prog ? TU.prog.lineas.length : 0;
    try { const sol = tuGenerar(); TU.prog = TU_C2 && TU.fuente === 'maquina' ? tuProgMaquina(sol) : sol; } catch (e) { console.error('Tutor', e); return; }
    if (TU.modo === 'practicar') tuNuevaPractica(true);
    tuConstruirSim();
    if (TU.modo === 'aprender') {
        // al dibujar, la línea nueva queda marcada (se ve cómo crece el programa)
        if (TU.prog.lineas.length !== antes && TU.sel !== -1) TU.sel = Math.min(TU.sel, TU.prog.lineas.length - 1);
        if (TU.sel >= TU.prog.lineas.length) TU.sel = -1;
    }
    tuPintarTodo();
}
function tuDescargar(mio) {
    if (!TU.prog || TU.prog.vacio) { snack('Aún no hay programa'); return; }
    const txt = mio ? tuTextoActivo() : TU.prog.texto;
    descargar(txt.replace(/\n/g, '\r\n'), (TU.prog.nombre || 'pieza').replace(/[\\/:*?"<>|]/g, '_') + '.nc', 'text/plain');
}
function tuEnviarSimulador() {
    if (!TU.prog || TU.prog.vacio) { snack('Aún no hay programa'); return; }
    let txt = tuTextoActivo();
    if (TU.modo === 'practicar' && TU.practica && !TU.practica.fin) txt += '; (programa sin terminar)\nM30\n';
    abrirEnSimulador(txt, (TU.prog.nombre || 'pieza') + '.nc');
}

// ── Nivel de dibujo: las herramientas se abren poco a poco ──
const TU_NIVELES = {
    1: ['editar', 'linea', 'rectangulo', 'poligono', 'cotaman', 'medir', 'origen', 'mover', 'calibrar'],
    2: ['editar', 'linea', 'arco3', 'arcoT', 'circulo', 'ranura', 'rectangulo', 'poligono', 'tangente', 'cotaman', 'medir', 'origen', 'mover', 'calibrar'],
    3: null
};
function tuNivel(n) {
    if (TU_C2) return;
    TU.nivel = +n || 3; tuGuardarPref();
    const ok = TU_NIVELES[TU.nivel];
    document.querySelectorAll('#toolStrip .tool-btn').forEach(b => { b.style.display = (b.dataset.h === 'texto' || (ok && !ok.includes(b.dataset.h))) ? 'none' : ''; });
    const s = document.getElementById('tuNivel'); if (s) s.value = String(TU.nivel);
    if (ok && !ok.includes(herramienta) && !TU.ejercicio) setHerramienta('linea');
}

// ── 📚 Ejemplos y ejercicios ──
function tuAbrirEjemplos() {
    const m = document.getElementById('tuModalEj'), lista = document.getElementById('tuListaEj');
    const grupos = {}; TU_EJEMPLOS.forEach((e, i) => { (grupos[e.grupo] = grupos[e.grupo] || []).push({ e, i }); });
    lista.innerHTML = Object.entries(grupos).map(([g, xs]) => `<div class="tu-ej-grupo"><h4>${tuEsc(g)}</h4><div class="tu-ej-items">${xs.map(({ e, i }) =>
        `<button onclick="tuCargarEjemplo(${i})" title="${e.ejercicio ? 'Ejercicio: escribes tú el programa' : 'Ejemplo: ves su programa'} · ${e.coord === 'mixta' ? 'mixta' : e.coord}"><span>${e.ejercicio ? '🎓' : '👁'}</span>${tuEsc(e.nombre)}<small>${e.coord === 'mixta' ? 'mixta' : e.coord}</small></button>`).join('')}</div></div>`).join('');
    m.classList.add('visible');
}
function tuCerrarEjemplos() { document.getElementById('tuModalEj').classList.remove('visible'); }
function tuCargarEjemplo(i) {
    const e = TU_EJEMPLOS[i]; if (!e) return;
    if (contornos.length && TU.practica && Object.keys(TU.practica.estado).length && !TU.practica.fin && !confirm('¿Abrir otro? Se pierde lo que llevas escrito.')) return;
    tuCerrarEjemplos();
    guardarUndo();
    const d = JSON.parse(JSON.stringify(e.datos));
    d.tutor = e.ejercicio ? { ejercicio: true, coord: e.coord, comp: 'G40' } : { ejemplo: true, coord: e.coord };
    abrirJSONDatos(d);
}
// Un JSON abierto: si es un ejercicio del profesor, el Tutor pasa a Practicar sin enseñar el programa
function tuAlAbrirJSON(d) {
    if (TU_C2) { TU.sel = -1; tuPintarMec(); tuRefrescar(true); try { encuadrar(); } catch (e) {} return; }
    const t = d && typeof d === 'object' ? d.tutor : null;
    TU.practica = null; TU.sel = -1;
    if (t && t.ejercicio) {
        TU.ejercicio = { coord: ['G90', 'G91', 'mixta'].includes(t.coord) ? t.coord : 'G90', comp: ['G40', 'G41', 'G42', 'auto'].includes(t.comp) ? t.comp : 'G40', nombre: d.nombre || document.getElementById('projectName').value };
        tuGuardarEjercicio(); tuPintarMec(); tuRefrescar(true); tuModo('practicar'); try { encuadrar(); } catch (e) {}
        setHerramienta('medir');
        snack('Ejercicio: escribe tú el programa, línea a línea. Las medidas, en las cotas del plano');
    } else {
        TU.ejercicio = null; tuGuardarEjercicio(); tuCasarHerr(false);
        if (t && t.coord && ['G90', 'G91', 'mixta'].includes(t.coord)) cfgMec.coord = t.coord;
        tuPintarMec(); tuRefrescar(true); tuModo(TU.modo === 'practicar' ? 'practicar' : 'aprender'); try { encuadrar(); } catch (e) {}
    }
}

// ── Ayuda ──
function tuAyuda() { document.getElementById('tuModalAyuda').classList.add('visible'); }
function tuCerrarAyuda() { document.getElementById('tuModalAyuda').classList.remove('visible'); }

// ── Arranque ──
function tutorIniciar() {
    // el panel de contornos del Calcador pasa a la pestaña «Contornos»
    const destino = document.getElementById('tuVista_contornos');
    document.querySelectorAll('.right-panel > *').forEach(el => { if (el.tagName !== 'H3') destino.appendChild(el); });
    Object.keys(TU_CAMPOS).concat(['tuD']).forEach(id => { const el = document.getElementById(id); if (el) el.addEventListener(el.tagName === 'SELECT' ? 'change' : 'input', tuLeerMec); });
    document.getElementById('fresaD').addEventListener('input', () => { const d = document.getElementById('tuD'); if (d && document.activeElement !== d) d.value = cfgFresa.d; tutorRefrescar(); });
    document.getElementById('tuAbs').checked = TU.verAbs;
    document.getElementById('tuAbs').addEventListener('change', e => { TU.verAbs = e.target.checked; tuGuardarPref(); tuPintarLista(); });
    document.getElementById('tuNombres').addEventListener('change', () => render());
    // «Comprobar mecanizado» del Calcador, apagado: el recorrido de la fresa dibujado ya enseña hasta dónde llega
    { const c = document.getElementById('chkFresa'); if (c && c.checked) { c.checked = false; c.dispatchEvent(new Event('change')); } cfgFresa.ver = false; }
    document.getElementById('tuVel').addEventListener('input', e => { TU.vel = Math.pow(2, +e.target.value); });
    if (!TU_C2) try { const e = JSON.parse(localStorage.getItem('tutor_ejercicio') || 'null'); if (e && typeof e === 'object' && e.coord) TU.ejercicio = e; } catch (e) {}
    if (TU_C2) { tuPintarFuente(); const hs = document.getElementById('tuHbSel');
        if (hs) HB.montarSelector(hs, h => { aplicarHerramientaCalc(h); Object.assign(cfgMec, { T: h.T, F: h.F, S: h.S }); if (h.Fz > 0) cfgMec.Fz = h.Fz; if (h.paso > 0) cfgMec.paso = h.paso; tuPintarMec(); guardarAutoPronto(); tuRefrescar(true); }); }
    tuNivel(TU.nivel);
    tuCasarHerr(false);
    tuPintarMec();
    tuRefrescar(true);
    tuModo(TU.ejercicio ? 'practicar' : 'aprender');
    if (TU.ejercicio) setHerramienta('medir');
}
