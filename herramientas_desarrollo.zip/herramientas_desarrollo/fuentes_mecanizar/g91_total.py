#!/usr/bin/env python3
"""Calcador v128, Tutor v7: nueva opción «G91 total»: tras el punto de partida, todo en incrementales, también la Z.
La opción G91 de siempre sigue igual (con la Z en G90), y los apuntes y los programas resueltos no cambian.
Uso: python3 g91_total.py CARPETA_DE_LA_SUITE (después de cotas_cero.py)."""
import os, re, sys
d = sys.argv[1] if len(sys.argv) > 1 else '.'
def parche(nombre, ver):
    global s
    p = os.path.join(d, nombre); s = open(p, encoding='utf-8').read()
    def rep(a, b, opc=False):
        global s
        if opc and a not in s: return
        assert s.count(a) == 1, (nombre, s.count(a), a[:80]); s = s.replace(a, b)
    # selectores
    rep('<option value="G91">G91 · incrementales</option><option value="mixta">Mixta · G90 y G91</option>', '<option value="G91">G91 · con la Z en G90</option><option value="G91T">G91 · total (también la Z)</option><option value="mixta">Mixta · G90 y G91</option>')
    rep('<select id="mecCoord"><option value="G90">G90 · absolutas</option><option value="G91">G91 · incrementales</option>', '<select id="mecCoord"><option value="G90">G90 · absolutas</option><option value="G91">G91 · con la Z en G90</option><option value="G91T">G91 · total (también la Z)</option>', True)
    rep('G91: lo que se mueve la fresa · Mixta:', 'G91: lo que se mueve la fresa, con la Z en G90 · G91 total: también la Z, tras un punto de partida en G90 · Mixta:')
    # listas válidas y textos
    s = s.replace("['G90', 'G91', 'mixta'].includes(cfgMec.coord)", "['G90', 'G91', 'G91T', 'mixta'].includes(cfgMec.coord)").replace("['G90', 'G91', 'mixta'].includes(t.coord)", "['G90', 'G91', 'G91T', 'mixta'].includes(t.coord)")
    s = s.replace("${coord === 'mixta' ? 'mixta' : coord}", "${coord === 'mixta' ? 'mixta' : coord === 'G91T' ? 'G91 total' : coord}")
    s = s.replace("${TU.ejercicio.coord === 'mixta' ? 'mixta (G90 y G91)' : TU.ejercicio.coord}", "${TU.ejercicio.coord === 'mixta' ? 'mixta (G90 y G91)' : TU.ejercicio.coord === 'G91T' ? 'G91 total (también la Z)' : TU.ejercicio.coord}")
    s = s.replace("${e.coord === 'mixta' ? 'mixta' : e.coord}", "${e.coord === 'mixta' ? 'mixta' : e.coord === 'G91T' ? 'G91 total' : e.coord}")
    # el programa de ⚙️ Solución
    rep("    let modal = 'G90', cur = { x: 0, y: 0 };", """    let modal = 'G90', cur = { x: 0, y: 0 }, curZ = zSeg;
    const isT = coord === 'G91T', inc91 = coord === 'G91' || isT, conG91 = () => modal === 'G91' ? '' : 'G91 ';
    if (isT && items.length) add('G0 X0 Y0', 'encima del cero pieza: el punto de partida, desde aquí todo es G91');""")
    rep("        if (idx > 0) { add(modal === 'G91' ? `G90 G0 Z${tuF(zSeg)}`", "        if (idx > 0 && isT) { add(`G0 Z${tuF(zSeg - curZ)}`, `sube ${tuF(zSeg - curZ)} mm antes de ir al siguiente trazado`); curZ = zSeg; }\n        else if (idx > 0) { add(modal === 'G91' ? `G90 G0 Z${tuF(zSeg)}`")
    rep("            if (coord === 'G91' && !primero) { add(`G91 G0 ${xyInc(cur, p)}`", "            if (isT) { add(`${conG91()}G0 ${xyInc(cur, p)}`, `en rápido hasta ${pNom}, desde donde está la fresa` + (modal === 'G91' ? '' : ' (pasa a G91)'), { ci: it.ci }); modal = 'G91'; }\n            else if (coord === 'G91' && !primero) { add(`G91 G0 ${xyInc(cur, p)}`")
    rep("                add(modal === 'G91' ? `G90 G0 Z${tuF(zSeg)}` : `G0 Z${tuF(zSeg)}`, 'sube para volver al principio del trazo'); modal = 'G90';", "                if (isT) { add(`G0 Z${tuF(zSeg - curZ)}`, 'sube para volver al principio del trazo'); curZ = zSeg; }\n                else { add(modal === 'G91' ? `G90 G0 Z${tuF(zSeg)}` : `G0 Z${tuF(zSeg)}`, 'sube para volver al principio del trazo'); modal = 'G90'; }")
    rep("            add((modal === 'G91' ? 'G90 ' : '') + `G1 Z${tuF(z)} F${tuF(Fz)}`,", "            if (isT) { add(`${conG91()}G1 Z${tuF(z - curZ)} F${tuF(Fz)}`, (zs.length === 1 ? 'baja despacio' : `pasada ${kp + 1} de ${zs.length}: baja`) + ` ${tuF(curZ - z)} mm, hasta Z${tuF(z)}`, { ci: it.ci }); curZ = z; modal = 'G91'; }\n            else { add((modal === 'G91' ? 'G90 ' : '') + `G1 Z${tuF(z)} F${tuF(Fz)}`,")
    rep("            modal = 'G90';\n            let pf = ` F${tuF(F)}`;", "            modal = 'G90'; }\n            let pf = ` F${tuF(F)}`;")
    rep("                if (coord === 'G91') { add(`G91 ${lado} G1 ${xyInc(cur, E)}${pf}`", "                if (isT) add(`${lado} G1 ${xyInc(cur, E)}${pf}`, `entrada a ${eNom}: activa ${lado} (la fresa va a la ${lTxt} del contorno)` + (mal ? ` ⚠ aquí va ${debe}` : ''), { ci: it.ci });\n                else if (coord === 'G91') { add(`G91 ${lado} G1 ${xyInc(cur, E)}${pf}`")
    rep("                if (coord === 'G91') add(`G40 G1 ${xyInc(cur, Ap)}`", "                if (inc91) add(`G40 G1 ${xyInc(cur, Ap)}`")
    rep("                if (coord !== 'G91') modal = 'G90';", "                if (!inc91) modal = 'G90';")
    rep("    add(modal === 'G91' ? `G90 G0 Z${tuF(zSeg)}` : `G0 Z${tuF(zSeg)}`, 'sube a la altura de seguridad' + (modal === 'G91' ? ' (vuelve a absolutas)' : ''));\n    if (items.length) add('G0 X0 Y0', 'vuelve encima del cero pieza');",
        "    if (isT && items.length) { add(`G0 Z${tuF(zSeg - curZ)}`, `sube ${tuF(zSeg - curZ)} mm, a la altura de seguridad`); add(`G0 ${xyInc(cur, { x: 0, y: 0 })}`, 'vuelve encima del cero pieza'); add('G90', 'deja la máquina en absolutas para el siguiente programa'); }\n    else {\n    add(modal === 'G91' ? `G90 G0 Z${tuF(zSeg)}` : `G0 Z${tuF(zSeg)}`, 'sube a la altura de seguridad' + (modal === 'G91' ? ' (vuelve a absolutas)' : ''));\n    if (items.length) add('G0 X0 Y0', 'vuelve encima del cero pieza');\n    }")
    # la ventana de Mecanizar (no está en todos los programas)
    if "coordMode = P.coord === 'G91' ? 'G91' : 'G90'" in s:
        rep("coordMode = P.coord === 'G91' ? 'G91' : 'G90'", "esTotal = P.coord === 'G91T', coordMode = P.coord === 'G91' || esTotal ? 'G91' : 'G90'")
        rep("isIncr ? 'Incremental (G91)' :", "esTotal ? 'Incremental total (G91, también la Z)' : isIncr ? 'Incremental (G91)' :")
        rep("""            if (isIncr) nc += `G90              ; absoluto para posicionamiento\\n`;
            nc += `G0 X${fmtNum(x)} Y${fmtNum(y)} F${feedPos}   ; ${txt}\\n`; moveCur(x, y);
            if (isIncr) nc += `G91              ; volver a incremental\\n`;""", """            if (esTotal) { nc += `G0 ${fmtXY(x, y)} F${feedPos}   ; ${txt}\\n`; moveCur(x, y); return; }
            if (isIncr) nc += `G90              ; absoluto para posicionamiento\\n`;
            nc += `G0 X${fmtNum(x)} Y${fmtNum(y)} F${feedPos}   ; ${txt}\\n`; moveCur(x, y);
            if (isIncr) nc += `G91              ; volver a incremental\\n`;""")
        rep("        nc += `G0 X0 Y0 F${feedPos}   ; -> Cero pieza\\n`;\n        if (isIncr) nc += `G91              ; volver a incremental\\n`;", "        nc += `G0 X0 Y0 F${feedPos}   ; -> Cero pieza\\n`;\n        if (esTotal) cur = { x:0, y:0, z:zSafe };\n        if (isIncr) nc += `G91              ; volver a incremental\\n`;")
        n = s.count("            if (isIncr) nc += `G90              ; absoluto para posicionamiento\\n`;\n            nc += `G0 X${fmtNum(pIni.x)} Y${fmtNum(pIni.y)} F${feedPos}")
        assert n == 1, n
        s = s.replace("            if (isIncr) nc += `G90              ; absoluto para posicionamiento\\n`;\n            nc += `G0 X${fmtNum(pIni.x)} Y${fmtNum(pIni.y)} F${feedPos}", "            if (isIncr && !esTotal) nc += `G90              ; absoluto para posicionamiento\\n`;\n            nc += `G0 ${esTotal ? fmtXY(pIni.x, pIni.y) : `X${fmtNum(pIni.x)} Y${fmtNum(pIni.y)}`} F${feedPos}")
        rep("            moveCur(pIni.x, pIni.y);\n            if (isIncr) nc += `G91              ; volver a incremental\\n`;", "            moveCur(pIni.x, pIni.y);\n            if (isIncr && !esTotal) nc += `G91              ; volver a incremental\\n`;")
        rep("""        if (isIncr) nc += `G90              ; absoluto para retorno\\n`;
        nc += `\\n; ── Retorno a Cero Pieza ──\\n`;
        nc += `G0 X0 Y0 F${feedPos}   ; -> Cero pieza\\n`;""", """        if (isIncr && !esTotal) nc += `G90              ; absoluto para retorno\\n`;
        nc += `\\n; ── Retorno a Cero Pieza ──\\n`;
        nc += esTotal ? `G0 ${fmtXY(0, 0)} F${feedPos}   ; -> Cero pieza\\nG90              ; deja la máquina en absolutas\\n` : `G0 X0 Y0 F${feedPos}   ; -> Cero pieza\\n`;""")
    m = re.search(r'vertical-align:middle">v(\d+)</span></span>', s)
    if m and ver: s = s.replace(m.group(0), m.group(0).replace('v' + m.group(1), ver), 1)
    open(p, 'w', encoding='utf-8').write(s); print(nombre + ': G91 total')
parche('calcador.html', 'v128')
parche('tutor.html', 'v7')
