"""Calcador / Corrector: corrección masiva directamente desde el .zip de entregas de Aules (Moodle).
- 📂 Añadir programas… y arrastrar admiten el .zip: cada alumno sale del nombre de su carpeta
  («Apellidos, Nombre_123456_assignsubmission_file_»), también si la descarga es sin carpetas.
- Lee los programas (.nc, .txt…), el texto en línea (onlinetext.html) y el 🧾 informe de entrega del Simulador (.pdf):
  comprueba su código y que el programa entregado es el del informe.
Uso: python3 entregas_aules.py <carpeta de la suite>
"""
import sys, os
AQUI = os.path.dirname(os.path.abspath(__file__))
P = os.path.join(sys.argv[1] if len(sys.argv) > 1 else '.', 'calcador.html')
s = open(P, encoding='utf-8').read()
def rep(a, b, cnt=1):
    global s
    n = s.count(a)
    assert n == cnt, f'{n} apariciones (se esperaban {cnt}) de: {a[:100]}'
    s = s.replace(a, b)
leer = lambda f: open(os.path.join(AQUI, f), encoding='utf-8').read()

# 1) Bloques comunes (zip, SHA-256, informe) antes de la corrección masiva
rep("function nombreAlumno(archivo) {", leer('zip_lector.js') + leer('entregas_comun.js') + "function nombreAlumno(archivo) {")

# 2) Añadir programas: archivos sueltos, .zip de Aules e informes .pdf
rep("""async function anadirProgramas(files) {
    const lista = [...files].filter(f => f && f.size < 2e6);
    if (!lista.length) return;
    let n = 0;
    for (const f of lista) { const t = await leerArchivoTexto(f); if (t === null) continue; const it = { alumno:nombreAlumno(f.name), archivo:f.name, texto:t }; corregirAlumno(it); masiva.lista.push(it); n++; }
    corr = null; pintarMasiva();
    snack(`${n} programa(s) añadido(s) y corregido(s)`);
}""", r"""const EXT_PROGRAMA = /\.(nc|txt|iso|cnc|tap|gcode|ngc|mpf|h|ptp|anc|eia)$/i;
const pareceGcode = t => /(^|\n)\s*(N\d+\s*)?[GM]0*[0-3]\b/i.test(t) || /(^|\n)\s*(N\d+\s*)?G[0-9]+[^\n]*[XYZ]-?[\d.]/i.test(t);
// Clasifica un archivo entregado: programa, texto en línea o informe del Simulador
function anotarEntrega(dest, ruta, bytes, alumno) {
    const base = ruta.split('/').pop();
    if (/\.pdf$/i.test(base)) { const inf = leerInformePDF(bytes); if (inf) { dest.push({ alumno: alumno || inf.alumno || nombreAlumno(base), archivo:base, tipo:'informe', informe:inf }); return true; } return false; }
    if (/^onlinetext\.html?$/i.test(base) || /_onlinetext_/i.test(base)) { const t = textoDeHTML(textoDeBytes(bytes)); if (t && pareceGcode(t)) { dest.push({ alumno, archivo:'Texto en línea', tipo:'texto', texto:t }); return true; } return false; }
    if (!EXT_PROGRAMA.test(base) || bytes.length > 2e6) return false;
    dest.push({ alumno: alumno || nombreAlumno(base.replace(/^.*?_\d+_assign(?:submission|feedback)_[a-z]*_?/i, '')), archivo:base.replace(/^.*?_\d+_assign(?:submission|feedback)_(?:file_)?/i, ''), tipo:'programa', texto:textoDeBytes(bytes) });
    return true;
}
async function entregasDeZip(ab, dest, ignorados, nivel) {
    const ent = listarZip(ab).filter(e => !/(^|\/)(__MACOSX|\.)/.test(e.nombre));
    // sin el formato de Aules: si los programas están en varias carpetas, cada carpeta es un alumno
    const carpetas = new Set(ent.filter(e => e.nombre.includes('/')).map(e => e.nombre.split('/').slice(0, -1).join('/')));
    for (const e of ent) {
        const partes = e.nombre.split('/');
        let alumno = alumnoDeRuta(e.nombre);
        if (!alumno && partes.length > 1 && carpetas.size > 1) alumno = partes[partes.length - 2];
        try {
            if (/\.zip$/i.test(e.nombre) && !nivel) {   // el alumno ha subido un .zip: se abre (un nivel)
                const sub = []; await entregasDeZip((await e.leer()).slice().buffer, sub, ignorados, 1);
                sub.forEach(x => { if (alumno) x.alumno = alumno; dest.push(x); }); continue;
            }
            if (!(EXT_PROGRAMA.test(e.nombre) || /\.(pdf|html?)$/i.test(e.nombre)) || e.tam > 2e7) { ignorados.push(e.nombre); continue; }
            if (!anotarEntrega(dest, e.nombre, await e.leer(), alumno)) ignorados.push(e.nombre);
        } catch (err) { ignorados.push(e.nombre + ' (' + err.message + ')'); }
    }
}
// Estado del informe de entrega de un alumno (texto corto y si está bien)
function estadoInforme(it) {
    const inf = it.informe; if (!inf) return null;
    if (!inf.valido) return { ok:false, txt:'El informe de entrega se ha modificado: su código de comprobación no coincide' };
    if (it.desdeInforme) return { ok:true, txt:`Programa tomado del informe de entrega (código ${inf.codigo}, ${inf.fecha})` };
    if (huellaPrograma(inf.programa) !== huellaPrograma(it.texto)) return { ok:false, txt:`El programa entregado no es el del informe de entrega (código ${inf.codigo}, ${inf.fecha})` };
    return { ok:true, txt:`El informe de entrega coincide con el programa (código ${inf.codigo}, ${inf.fecha})` };
}
async function anadirProgramas(files) {
    const lista = [...files].filter(Boolean);
    if (!lista.length) return;
    const ent = [], ignorados = [], problemas = [];
    for (const f of lista) {
        try {
            if (/\.zip$/i.test(f.name)) { await entregasDeZip(await f.arrayBuffer(), ent, ignorados, 0); continue; }
            if (f.size > 2e7) { ignorados.push(f.name); continue; }
            if (!anotarEntrega(ent, f.name, new Uint8Array(await f.arrayBuffer()), alumnoDeRuta(f.name))) ignorados.push(f.name);
        } catch (e) { problemas.push(`${f.name}: ${e.message}`); }
    }
    // por alumno: sus programas (o el texto en línea si no hay archivo) y su informe de entrega
    const grupos = new Map();
    ent.forEach(x => { const k = (x.alumno || '').trim() || x.archivo; if (!grupos.has(k)) grupos.set(k, []); grupos.get(k).push(x); });
    let n = 0, nInf = 0;
    grupos.forEach((xs, alumno) => {
        let progs = xs.filter(x => x.tipo === 'programa'); if (!progs.length) progs = xs.filter(x => x.tipo === 'texto');
        const infs = xs.filter(x => x.tipo === 'informe');
        const items = progs.map(x => ({ alumno: progs.length > 1 ? `${alumno} · ${x.archivo}` : alumno, archivo:x.archivo, texto:x.texto }));
        if (!items.length) infs.forEach(x => items.push({ alumno: infs.length > 1 ? `${alumno} · ${x.archivo}` : alumno, archivo:x.archivo, texto:x.informe.programa, informe:x.informe, desdeInforme:true }));
        else infs.forEach(x => { const it = items.find(i => huellaPrograma(i.texto) === huellaPrograma(x.informe.programa)) || items.find(i => i.archivo === x.informe.archivo) || (items.length === 1 ? items[0] : null); if (it && !it.informe) it.informe = x.informe; });
        items.forEach(it => { corregirAlumno(it); masiva.lista.push(it); n++; if (it.informe) nInf++; });
    });
    corr = null; pintarMasiva();
    snack(`${n} programa(s) añadido(s) y corregido(s)${nInf ? ` · ${nInf} con informe de entrega` : ''}${ignorados.length ? ` · ${ignorados.length} archivo(s) que no son programas, sin usar` : ''}`);
    if (problemas.length) alert('No se han podido leer:\n\n' + problemas.join('\n'));
    if (ignorados.length) console.info('Archivos sin usar:', ignorados);
}""")

# 3) Selector de archivos: también .zip y .pdf
rep("""<input type="file" id="mvArchivos" multiple accept=".nc,.txt,.iso,.cnc,.tap,.gcode,.ngc,.mpf,.h" style="display:none" onchange="anadirProgramas(this.files); this.value=''">
                <button class="btn-action" onclick="document.getElementById('mvArchivos').click()">📂 Añadir programas…</button>""",
"""<input type="file" id="mvArchivos" multiple accept=".nc,.txt,.iso,.cnc,.tap,.gcode,.ngc,.mpf,.h,.zip,.pdf" style="display:none" onchange="anadirProgramas(this.files); this.value=''">
                <button class="btn-action" onclick="document.getElementById('mvArchivos').click()" title="Los programas de los alumnos (.nc, .txt…), o directamente el .zip que descarga Aules con «Descargar todas las entregas»: cada alumno sale del nombre de su carpeta. Si entregan el 🧾 informe del Simulador (.pdf), se comprueba que coincide con el programa">📂 Añadir programas o zip de Aules…</button>""")

# 4) Mensaje de la lista vacía
rep("""Añade los programas de los alumnos con <strong>📂 Añadir programas…</strong> o <strong>arrastra aquí</strong> los archivos (.nc, .txt, .iso…).<br>Cada archivo es un alumno: su nombre se toma del nombre del archivo.""",
"""Añade los programas de los alumnos con <strong>📂 Añadir programas o zip de Aules…</strong> o <strong>arrastra aquí</strong> los archivos (.nc, .txt, .iso…) o el <strong>.zip de Aules</strong> («Descargar todas las entregas»).<br>Con el zip, cada alumno sale del nombre de su carpeta; con archivos sueltos, del nombre del archivo. Si entregan el 🧾 informe del Simulador (.pdf), se comprueba que coincide con el programa.""")

# 5) Marca del informe junto al nombre
rep("""<td class="mv-al" title="${esc(it.archivo)}">${esc(it.alumno)}</td>""",
"""<td class="mv-al" title="${esc(it.archivo)}">${esc(it.alumno)}${(e => e ? ` <span class="mv-inf ${e.ok ? 'ok' : 'mal'}" title="${esc(e.txt)}">🧾${e.ok ? '' : '⚠️'}</span>` : '')(estadoInforme(it))}</td>""")
rep(""".params-box.visor-si > button[onclick*="abrirMasiva"] { order: -4; }""",
""".params-box.visor-si > button[onclick*="abrirMasiva"] { order: -4; }
    .mv-inf { font-size:12px; cursor:help; } .mv-inf.mal { filter:none; } .mv-inf.ok { opacity:.85; }""")

# 6) CSV: columna del informe de entrega
rep("""'Nota', 'Geometría', 'Lo pedido', 'Seguridad', 'Observaciones']];""", """'Nota', 'Geometría', 'Lo pedido', 'Seguridad', 'Informe de entrega', 'Observaciones']];""")
rep("""d(v.desglose.geo), d(v.desglose.pedido), d(v.desglose.seg), obs]); });""", """d(v.desglose.geo), d(v.desglose.pedido), d(v.desglose.seg), (e => e ? e.txt : '')(estadoInforme(it)), obs]); });""")

# 7) Informe impreso del alumno
rep("""<div class="al"><span>Alumno/a:</span> <b>${esc(it.alumno)}</b> <span class="ar">(${esc(it.archivo)})</span></div>""",
"""<div class="al"><span>Alumno/a:</span> <b>${esc(it.alumno)}</b> <span class="ar">(${esc(it.archivo)})</span></div>
            ${(e => e ? `<div class="ar" style="margin:-4px 0 8px;color:${e.ok ? '#1e7a46' : '#b0301f'}">🧾 ${esc(e.txt)}</div>` : '')(estadoInforme(it))}""")

# 8) Ayuda
rep("y añade o arrastra los programas de toda la clase (cada archivo es un alumno; su nombre se toma del nombre del archivo).",
    "y añade o arrastra los programas de toda la clase (cada archivo es un alumno; su nombre se toma del nombre del archivo) o, directamente, el <strong>.zip de Aules</strong> («Descargar todas las entregas»): cada alumno sale del nombre de su carpeta, también con el texto en línea o con un .zip dentro. Si el alumno entrega el <strong>🧾 informe de entrega</strong> del Simulador (.pdf), se comprueba su código y que el programa es el del informe (🧾 junto al nombre; 🧾⚠️ si no coincide); si solo entrega el informe, se corrige el programa que lleva dentro.")
open(P, 'w', encoding='utf-8').write(s)
print('Calcador: corrección desde el zip de Aules e informes de entrega:', P)
