"""Calcador: cerrar un trazo de un solo arco con una recta (arco + cuerda) y «Unir con el extremo más cercano»
también con el otro extremo del mismo trazo (lo cierra con una recta).
Antes, un arco de 3 puntos seguido de una recta hasta su inicio no se cerraba (pedía 3 puntos) y la unión buscaba
siempre otro contorno, aunque el extremo más cercano fuera el inicio del propio trazo.
Uso: python3 cierre_arcos.py <carpeta de la suite>   (después de simulador_unico_calc.py)
"""
import sys, os
P = os.path.join(sys.argv[1] if len(sys.argv) > 1 else '.', 'calcador.html')
s = open(P, encoding='utf-8').read()
def rep(a, b, cnt=1):
    global s
    n = s.count(a); assert n == cnt, f'{n} apariciones (se esperaban {cnt}) de: {a[:100]}'
    s = s.replace(a, b)
# 1. Dibujando: clic en el primer punto con solo dos puntos. Cierra si algún tramo es un arco (o si el último lo es)
rep("    if (cierra && (n >= 3 || b)) {",
    "    if (cierra && (n >= 3 || b || c.b.slice(0, n - 1).some(x => x))) {      // dos puntos: cierra si hay un arco (arco + cuerda)")
# 2. «Cerrar con una recta»: también un arco solo
rep("    if (c.pts.length < 3) { snack('Hacen falta al menos 3 puntos para cerrar con una recta'); return; }",
    "    if (c.pts.length < 3 && !(c.pts.length === 2 && c.b[0])) { snack('Hacen falta al menos 3 puntos (o un arco) para cerrar con una recta'); return; }")
# 3. Unir con el extremo más cercano: cuenta también el otro extremo del propio trazo (entonces lo cierra)
rep("""function unirConMasCercano(ci, vi) {
    const c = contornos[ci], n = c.pts.length, p = c.pts[vi];
    let mejor = null;
""", """function unirConMasCercano(ci, vi) {
    const c = contornos[ci], n = c.pts.length, p = c.pts[vi];
    let mejor = null;
    // el otro extremo del mismo trazo: se cierra con una recta (si hay superficie: 3 puntos o algún arco)
    if (n >= 3 || (n === 2 && c.b[0])) mejor = { propio:true, d:dist(p, c.pts[vi === 0 ? n - 1 : 0]) };
""")
rep("""    if (!mejor) { snack('No hay otro contorno abierto con el que unir'); return; }
    guardarUndo();
    if (vi === 0 && n > 1) invertirContorno(c);""", """    if (!mejor) { snack('No hay otro contorno abierto con el que unir'); return; }
    guardarUndo();
    if (mejor.propio) {
        if (mejor.d < 1e-7 && n >= 3) { c.pts.pop(); c.b.pop(); }          // los extremos ya coinciden: el último tramo es el cierre
        else c.b[c.pts.length - 1] = 0;
        c.cerrado = true;
        if (!contornoValido(c) || seCruza(c)) { deshacer(); snack('Ese cierre no encierra una superficie (o se cruza consigo mismo)'); return; }
        if (dib && dib.ci === ci) dib = null;
        sel = ci; ajusteAuto(ci);
        snack(mejor.d < 1e-7 ? 'Contorno cerrado' : `Contorno cerrado con una recta de ${fmt(mejor.d, 3)} mm`); refrescar(); return;
    }
    if (vi === 0 && n > 1) invertirContorno(c);""")
rep("'<button id=\"cUnir\">🔗 Unir con el contorno abierto más cercano</button>",
    "'<button id=\"cUnir\" title=\"Con el extremo abierto más cercano: el de otro trazo (los une) o el otro extremo de este (lo cierra con una recta)\">🔗 Unir o cerrar con el extremo más cercano</button>")
rep("También: herramienta Editar, clic derecho en un extremo → «Unir con el contorno abierto más cercano».</td></tr>",
    "Un arco solo se cierra con una recta (su cuerda) al hacer clic en su primer punto. También: herramienta Editar, clic derecho en un extremo → «Unir o cerrar con el extremo más cercano» (si el más cercano es el otro extremo del mismo trazo, lo cierra con una recta).</td></tr>")
open(P, 'w', encoding='utf-8').write(s)
print('Calcador: cerrar un arco con una recta y unir con el extremo más cercano (también el propio):', P)
