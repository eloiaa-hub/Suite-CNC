#!/bin/sh
# Guía del Tutor G-Code: fuente_guia_tutor.html + capturas de img/ → guia_tutor.html y guia_tutor.pdf (en la carpeta de la suite)
# Antes, las capturas (desde esta carpeta): LANG=C.UTF-8 node capt_tutor.js
set -e
cd "$(dirname "$0")"
S=../../..
python3 ../anidador_calculadora/construir_manual.py fuente_guia_tutor.html img $S/guia_tutor.html "Tutor G-Code — Guía para el alumnado y el profesorado"
cd $S && SOLO=guia_tutor LANG=C.UTF-8 node herramientas_desarrollo/generar_pdf_manuales.js .
python3 herramientas_desarrollo/aligerar_pdf.py guia_tutor.pdf /tmp/guia_tutor_lig.pdf && mv /tmp/guia_tutor_lig.pdf guia_tutor.pdf
pdfinfo guia_tutor.pdf | grep Pages
