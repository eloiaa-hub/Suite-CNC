// ── Corrección masiva: programas entregados en un documento (Word, LibreOffice, RTF) en lugar de en texto ──
// Se saca el texto del documento y se corrige igual, pero se avisa de que el formato no es el pedido (.txt, .nc o .gcode).
const EXT_DOCUMENTO = /\.(odt|ott|fodt|docx|docm|dotx|doc|rtf|wpd)$/i;
const FORMATO_PEDIDO = 'debe ser un archivo de texto (.txt, .nc o .gcode)';
// Lo que el procesador de textos cambia al escribir: guiones largos, espacios duros, comillas tipográficas, «ﬁ»…
function limpiarTextoDocumento(t) {
    return String(t).replace(/[‐-―−﹣－]/g, '-').replace(/[  -​  　]/g, ' ')
        .replace(/[‘’‚′]/g, "'").replace(/[“”„″]/g, '"').replace(/…/g, '...')
        .replace(/[‌‍⁠﻿­]/g, '').replace(/\r\n?/g, '\n').replace(/[ \t]+\n/g, '\n').replace(/\n{3,}/g, '\n\n').trim();
}
// Recorre el XML de un documento: cada párrafo, una línea
function textoXMLDocumento(xml, tipo) {
    const d = new DOMParser().parseFromString(xml, 'application/xml'); if (d.getElementsByTagName('parsererror').length) return '';
    let out = '';
    const ir = n => {
        if (n.nodeType === 3) { if (tipo === 'odt') out += n.nodeValue; return; }
        if (n.nodeType !== 1) return;
        const l = n.localName;
        if (tipo === 'odt') {
            if (l === 's') { out += ' '.repeat(Math.max(1, parseInt(n.getAttribute('text:c') || n.getAttribute('c') || '1', 10) || 1)); return; }
            if (l === 'tab') { out += '\t'; return; } if (l === 'line-break') { out += '\n'; return; }
            if (l === 'annotation' || l === 'note-citation' || l === 'tracked-changes' || l === 'sequence-decls') return;
            if (l === 'note') return;
        } else {
            if (l === 't') { out += n.textContent; return; } if (l === 'tab') { out += '\t'; return; } if (l === 'br' || l === 'cr') { out += '\n'; return; }
            if (l === 'delText' || l === 'instrText' || l === 'del' || l === 'commentReference' || l === 'footnoteReference') return;
        }
        for (const c of n.childNodes) ir(c);
        if (l === 'p' || l === 'h') out += '\n';
    };
    const cuerpo = tipo === 'odt' ? (d.getElementsByTagNameNS('*', 'text')[0] || d.documentElement) : (d.getElementsByTagNameNS('*', 'body')[0] || d.documentElement);
    ir(cuerpo); return out;
}
// RTF (WordPad, TextEdit): sin grupos de control, con \par, \tab, \'hh y \uN
function textoDeRTF(r) {
    let out = '', i = 0, salto = 0; const pila = [], DESTINOS = /^(fonttbl|colortbl|stylesheet|info|pict|header|footer|headerl|headerr|footerl|footerr|object|themedata|colorschememapping|datastore|latentstyles|listtable|listoverridetable|rsidtbl|generator|xmlnstbl|mmathPr)$/;
    let ignorar = false, uc = 1;
    while (i < r.length) {
        const c = r[i];
        if (c === '{') { pila.push({ ignorar, uc }); i++; if (r.startsWith('\\*', i)) ignorar = true; continue; }
        if (c === '}') { const p = pila.pop() || { ignorar:false, uc:1 }; ignorar = p.ignorar; uc = p.uc; i++; continue; }
        if (c === '\\') {
            const n = r[i + 1];
            if (n === '\\' || n === '{' || n === '}') { if (!ignorar) out += n; i += 2; continue; }
            if (n === "'") { if (!ignorar && salto <= 0) out += new TextDecoder('windows-1252').decode(new Uint8Array([parseInt(r.substr(i + 2, 2), 16) || 32])); else salto--; i += 4; continue; }
            if (n === '\n' || n === '\r') { if (!ignorar) out += '\n'; i += 2; continue; }
            const m = /^([a-zA-Z]+)(-?\d+)? ?/.exec(r.slice(i + 1, i + 40));
            if (!m) { i += 2; continue; }
            const w = m[1], v = m[2]; i += 1 + m[0].length;
            if (DESTINOS.test(w)) { ignorar = true; continue; }
            if (ignorar) continue;
            if (w === 'par' || w === 'line' || w === 'row' || w === 'sect' || w === 'page') out += '\n';
            else if (w === 'tab' || w === 'cell') out += '\t';
            else if (w === 'uc') uc = +v || 0;
            else if (w === 'u') { out += String.fromCharCode((+v + 65536) % 65536); salto = uc; }
            else if (w === 'emdash' || w === 'endash') out += '-';
            continue;
        }
        if (c === '\r' || c === '\n') { i++; continue; }
        if (!ignorar) { if (salto > 0) salto--; else out += c; }
        i++;
    }
    return out;
}
// Word antiguo (.doc, binario OLE): no se interpreta el formato; se busca el texto (en 8 bits o en UTF-16) que parece un programa
function textoDeDOC(b) {
    const trozos = [];
    const buscar = txt => { const re = /[^\x00-\x08\x0B\x0C\x0E-\x1F\x7F�\uD800-\uDFFF]{6,}/g; let m; while ((m = re.exec(txt))) trozos.push(m[0]); };
    buscar(new TextDecoder('windows-1252').decode(b));
    const u16 = new TextDecoder('utf-16le').decode(b.length % 2 ? b.subarray(0, b.length - 1) : b); buscar(u16);
    const linea = l => /^\s*(N\d+\s*)?([GMTSFXYZIJR]-?[\d.]|\(|;|%)/i.test(l);
    let mejor = '', puntos = 0;
    trozos.forEach(t => { const ls = t.replace(/\r\n?/g, '\n').split('\n'), p = ls.filter(linea).length; if (p > puntos) { puntos = p; mejor = ls; } });
    if (!puntos || !pareceGcode(mejor.join('\n'))) return '';
    let a = 0, z = mejor.length - 1; while (a < z && !linea(mejor[a])) a++; while (z > a && !linea(mejor[z])) z--;
    return mejor.slice(a, z + 1).join('\n');
}
// El programa de un documento: { texto, formato } o null si no es un documento (o no se puede leer)
async function programaDeDocumento(nombre, bytes) {
    const ext = ((/\.([a-z0-9]+)$/i.exec(nombre) || [])[1] || '').toLowerCase();
    const b = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
    const pk = b[0] === 0x50 && b[1] === 0x4B, ole = b[0] === 0xD0 && b[1] === 0xCF && b[2] === 0x11 && b[3] === 0xE0;
    const cab = new TextDecoder('latin1').decode(b.subarray(0, 64)), rtf = /^\s*\{\\rtf/.test(cab), fodt = /^\s*<\?xml/.test(cab) && /office:document/.test(new TextDecoder('utf-8').decode(b.subarray(0, 2000)));
    if (!pk && !ole && !rtf && !fodt) return null;
    const conExt = n => `${n}${ext && !new RegExp('\\.' + ext + '\\b', 'i').test(n) ? ` guardado como .${ext}` : ''}`;
    let texto = '', formato = '';
    if (pk) {
        const ent = listarZip(b.slice().buffer), busca = n => ent.find(e => e.nombre === n);
        const odt = busca('content.xml'), docx = busca('word/document.xml');
        if (odt) { texto = textoXMLDocumento(textoDeBytes(await odt.leer()), 'odt'); formato = conExt('un documento de LibreOffice (.odt)'); }
        else if (docx) { texto = textoXMLDocumento(textoDeBytes(await docx.leer()), 'docx'); formato = conExt('un documento de Word (.docx)'); }
        else return null;
    } else if (fodt) { texto = textoXMLDocumento(textoDeBytes(b), 'odt'); formato = conExt('un documento de LibreOffice (.fodt)'); }
    else if (rtf) { texto = textoDeRTF(new TextDecoder('latin1').decode(b)); formato = conExt('un documento RTF (WordPad o TextEdit, .rtf)'); }
    else { texto = textoDeDOC(b); formato = conExt('un documento de Word antiguo (.doc)') + (texto ? '; el texto se ha recuperado buscándolo dentro del archivo: revisa que el programa esté completo' : ''); }
    texto = limpiarTextoDocumento(texto);
    return { texto, formato: `Formato de archivo incorrecto: es ${formato}; ${FORMATO_PEDIDO}.` };
}
// Igual que anotarEntrega, pero si el archivo es un documento (por su extensión o por lo que lleva dentro, aunque se llame .nc o .txt)
async function anotarEntregaDoc(dest, ruta, bytes, alumno) {
    const base = ruta.split('/').pop();
    if (EXT_DOCUMENTO.test(base) || EXT_PROGRAMA.test(base)) {
        let doc = null; try { doc = await programaDeDocumento(base, bytes); } catch (e) { doc = null; }
        if (doc) {
            const al = alumno || nombreAlumno(base.replace(/^.*?_\d+_assign(?:submission|feedback)_[a-z]*_?/i, '')), ar = base.replace(/^.*?_\d+_assign(?:submission|feedback)_(?:file_)?/i, '');
            // sin programa dentro (o ilegible): solo cuenta si el alumno no entrega nada más
            if (!doc.texto || !pareceGcode(doc.texto)) { dest.push({ alumno:al, archivo:ar, tipo:'docsin', texto:'', formato:doc.formato + ' No se ha encontrado ningún programa dentro del documento.' }); return true; }
            dest.push({ alumno: alumno || nombreAlumno(base.replace(/^.*?_\d+_assign(?:submission|feedback)_[a-z]*_?/i, '')), archivo:base.replace(/^.*?_\d+_assign(?:submission|feedback)_(?:file_)?/i, ''), tipo:'programa', texto:doc.texto, formato:doc.formato });
            return true;
        }
    }
    return anotarEntrega(dest, ruta, bytes, alumno);
}
