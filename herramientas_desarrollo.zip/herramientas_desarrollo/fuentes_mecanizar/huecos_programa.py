"""Calcador v108 / Corrector v53: 📝 Cuestionario para Aules, pregunta «Completar el programa» (huecos). El programa de la
solución sin comentarios con N palabras en blanco (G2/G3, G41/G42, I J, X Y); en Aules, una pregunta Cloze que se corrige
sola, en cada variante; y la hoja para imprimir con los huecos numerados y las soluciones. Por defecto, 0 huecos (no cambia
el cuestionario de siempre).
Uso: python3 huecos_programa.py <carpeta de la suite>   (construir_calcador.sh lo pone tras examen_reparto.py)"""
import sys, os
AQUI = os.path.dirname(os.path.abspath(__file__))
P = os.path.join(sys.argv[1] if len(sys.argv) > 1 else '.', 'calcador.html')
s = open(P, encoding='utf-8').read()
def rep(a, b, cnt=1):
    global s
    n = s.count(a); assert n == cnt, f'{n} apariciones (se esperaban {cnt}) de: {a[:100]}'
    s = s.replace(a, b)
JS = open(os.path.join(AQUI, 'huecos_programa.js'), encoding='utf-8').read()
rep("async function abrirCuestionario() {", JS + "async function abrirCuestionario() {")
# hasta 12 huecos (los demás tipos, hasta 6)
rep('''<input type="number" min="0" max="6" step="1" value="${cuestCfg[k]}" data-k="${k}"''', '''<input type="number" min="0" max="${k === 'huecos' ? 12 : 6}" step="1" value="${cuestCfg[k]}" data-k="${k}"''')
rep("cuestCfg[el.dataset.k] = Math.max(0, Math.min(6, Math.round(+el.value) || 0))", "cuestCfg[el.dataset.k] = Math.max(0, Math.min(el.dataset.k === 'huecos' ? 12 : 6, Math.round(+el.value) || 0))")
# la vista previa: los huecos de texto (G2, G41…) con su respuesta
rep("    const ver = t => t.replace(/\\{1:NUMERICAL:=([^:}]+):[^}]*\\}/g, '<b class=\"cu-sol\">$1</b>')",
    "    const ver = t => t.replace(/\\{1:SHORTANSWER:=([^~}]+)[^}]*\\}/g, '<b class=\"cu-sol\">$1</b>').replace(/\\{1:NUMERICAL:=([^:}]+):[^}]*\\}/g, '<b class=\"cu-sol\">$1</b>')")
rep("""                <button class="btn-action" id="cuDescargar" onclick="descargarCuestionario()" title="Descarga el archivo .xml para importarlo en el banco de preguntas de Aules">⬇ Descargar el XML de Moodle</button>""",
    """                <button class="btn-action" id="cuDescargar" onclick="descargarCuestionario()" title="Descarga el archivo .xml para importarlo en el banco de preguntas de Aules">⬇ Descargar el XML de Moodle</button>
                <button class="btn-action sec" onclick="imprimirHuecos()" title="Para hacerlo en papel: cada variante con el plano y el programa con los huecos numerados, y la hoja de soluciones">🖨 Imprimir «Completar el programa»</button>""")
rep("""¿G2 o G3? y ¿G41 o G42? Cada pregunta""", """¿G2 o G3?, ¿G41 o G42? y «Completar el programa» (el programa de la solución con huecos: G2/G3, G41/G42, I J, X Y; también se imprime para hacerlo en papel). Cada pregunta""")
open(P, 'w', encoding='utf-8').write(s)
print('Calcador: cuestionario, completar el programa (huecos)')
