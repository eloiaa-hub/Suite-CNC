// Capturas del manual del Calcador: recortar (vista previa) y el panel de alinear, repartir y bloquear
const path = require('path'), fs = require('fs');
const { lanzar, SUITE } = require('../../pruebas/comun.js');
const OUT = path.join(__dirname, 'capturas'); fs.mkdirSync(OUT, { recursive: true });
(async () => {
  const b = await lanzar(); const ctx = await b.newContext({ viewport: { width: 1400, height: 880 }, deviceScaleFactor: 1.5 }), p = await ctx.newPage(); p.on('dialog', d => d.accept());
  await p.goto('file://' + path.join(SUITE, 'calcador.html')); await p.evaluate(() => localStorage.clear()); await p.reload(); await p.waitForTimeout(700);
  // un marco de 120 x 80 con dos travesaños que se cruzan: se recorta lo que sobra
  await p.evaluate(() => { contornos.length = 0; const L = (a, b) => ({ pts: [a, b], b: [0, 0], cerrado: false, tipo: 'auto' });
    contornos.push({ pts: [{ x:0, y:0 }, { x:120, y:0 }, { x:120, y:80 }, { x:0, y:80 }], b: [0, 0, 0, 0], cerrado: true, tipo: 'auto' });
    contornos.push(L({ x:-15, y:40 }, { x:135, y:40 }), L({ x:60, y:-15 }, { x:60, y:95 }));
    contornos[0].bloqueado = true; asegurarUids(); setHerramienta('recortar'); encuadrar(); refrescar(); });
  const q = await p.evaluate(() => { const r = cv.getBoundingClientRect(), s = aPantalla({ x:-9, y:40 }); return { x: r.left + s.x, y: r.top + s.y }; });
  await p.mouse.move(q.x, q.y); await p.waitForTimeout(200);
  await p.evaluate(() => { const s = document.getElementById('snackbar'); if (s) s.classList.remove('show'); });
  const cvb = await p.evaluate(() => { const r = cv.getBoundingClientRect(); return { x: r.left, y: r.top, width: r.width, height: r.height }; });
  await p.screenshot({ path: path.join(OUT, 'recortar.png'), clip: cvb });
  // tres piezas seleccionadas: el panel con alinear, repartir y bloquear
  await p.evaluate(() => { contornos.length = 0; const R = (x, y, w, h) => ({ pts: [{ x, y }, { x:x + w, y }, { x:x + w, y:y + h }, { x, y:y + h }], b: [0, 0, 0, 0], cerrado: true, tipo: 'auto' });
    contornos.push(R(0, 0, 40, 25), R(55, 12, 30, 30), R(110, 4, 25, 45)); asegurarUids(); setHerramienta('editar'); seleccionarVarios([0, 1, 2], false); encuadrar(); refrescar(); });
  await p.waitForTimeout(300); await p.evaluate(() => { const s = document.getElementById('snackbar'); if (s) s.classList.remove('show'); document.getElementById('propsContorno').scrollIntoView(); });
  await p.locator('#propsContorno').screenshot({ path: path.join(OUT, 'panel.png') });
  await b.close(); console.log('capturas en', OUT);
})();
