// ── ⬆ Notas para Aules: rellenar la «hoja de calificaciones» de la tarea con la nota y un comentario ──
// En Aules (Moodle), en la tarea: Calificaciones → «Descargar hoja de calificaciones». Se abre aquí, se rellena la columna
// de la calificación (escalada a la calificación máxima de la tarea) y la de los comentarios de retroalimentación (si la
// tarea los tiene), y se descarga el mismo archivo para «Subir hoja de calificaciones». Cada alumno se casa por su número
// de participante (el del zip de Aules: «Nombre_123456_assignsubmission_file_») o, si no, por su nombre.
masiva.ids = masiva.ids || {};
const _alumnoDeRutaAules = alumnoDeRuta;
alumnoDeRuta = function (ruta) {
    const n = _alumnoDeRutaAules(ruta);
    if (n) { const m = /(?:^|\/)([^/]*?)_(\d+)_assign(?:submission|feedback)_/i.exec(ruta); if (m) masiva.ids[n] = m[2]; }
    return n;
};
const normNomAules = t => String(t || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9ñ ]+/g, ' ').split(' ').filter(Boolean).sort().join(' ');
// CSV: separador, comillas y BOM como en el original
function leerCSVAules(txt) {
    const bom = txt.charCodeAt(0) === 0xfeff; if (bom) txt = txt.slice(1);
    const l1 = txt.split(/\r?\n/)[0], sep = (l1.match(/;/g) || []).length > (l1.match(/,/g) || []).length ? ';' : ',';
    const filas = []; let f = [], c = '', q = false;
    for (let i = 0; i < txt.length; i++) {
        const ch = txt[i];
        if (q) { if (ch === '"') { if (txt[i + 1] === '"') { c += '"'; i++; } else q = false; } else c += ch; }
        else if (ch === '"') q = true; else if (ch === sep) { f.push(c); c = ''; }
        else if (ch === '\n' || ch === '\r') { if (ch === '\r' && txt[i + 1] === '\n') i++; f.push(c); c = ''; if (f.length > 1 || f[0] !== '') filas.push(f); f = []; }
        else c += ch;
    }
    if (c !== '' || f.length) { f.push(c); filas.push(f); }
    return { filas, sep, bom, crlf: /\r\n/.test(txt), comillas: /^"/.test(l1) };   // (comillas: si el original las pone en todos los campos, como Moodle)
}
const escribirCSVAules = h => (h.bom ? '﻿' : '') + h.filas.map(f => f.map(x => h.comillas || /[",;\n\r]/.test(x) || x === '' ? '"' + String(x).replace(/"/g, '""') + '"' : x).join(h.sep)).join(h.crlf ? '\r\n' : '\n') + (h.crlf ? '\r\n' : '\n');
function columnasAules(cab) {
    const b = re => cab.findIndex(x => re.test(String(x).normalize('NFD').replace(/[̀-ͯ]/g, '')));
    return { id: b(/^(identificador|identifier|id)$/i), nombre: b(/nom(bre)? complet|full ?name/i), nota: b(/^(calificacion|qualificacio|grade)$/i),
             max: b(/(calificacion|qualificacio|grade).*(max)|maxim.*(calificacion|qualificacio|grade)/i), com: b(/retroaliment|feedback|comentari/i) };
}
// El resultado de cada alumno (si entrega varios programas, el mejor)
function resultadosAules() {
    const por = new Map();
    masiva.lista.forEach(it => {
        if (!it.v || it.v.veredicto === 'pendiente') return;
        const base = Object.keys(masiva.ids).filter(n => it.alumno === n || it.alumno.startsWith(n + ' · ')).sort((a, b) => b.length - a.length)[0] || it.alumno.replace(/ · .*$/, '');
        const ant = por.get(base); if (!ant || it.v.nota > ant.it.v.nota) por.set(base, { it, id: masiva.ids[base] || ((/^Participante (\d+)$/.exec(base) || [])[1]) || null });
    });
    return por;
}
function comentarioAules(it) {
    const v = it.v, r = it.r || {}, nf1 = x => String(Math.round(x * 10) / 10).replace('.', ',');
    const t = [`Nota orientativa del Corrector: ${nf1(v.nota)} sobre 10. ${VER_TXT[v.veredicto].replace(/^\S+\s/, '')}.`];
    if (it.variante) t.push(`Corregido con la variante ${it.variante}.`);
    const err = (r.hallazgos || []).filter(h => h.tipo === 'error'), av = (r.hallazgos || []).filter(h => h.tipo === 'aviso');
    if (err.length) t.push('Errores: ' + err.slice(0, 4).map(h => h.msg.replace(/\s+/g, ' ')).join(' · ') + (err.length > 4 ? ` (y ${err.length - 4} más)` : ''));
    if (av.length) t.push(`${av.length} aviso${av.length === 1 ? '' : 's'}: ${av.slice(0, 2).map(h => h.msg.replace(/\s+/g, ' ')).join(' · ')}${av.length > 2 ? '…' : ''}`);
    if (r.error) t.push(r.error);
    if (it.formato) t.push(it.formato);
    return t.join('\n');
}
// Rellena la hoja; devuelve el texto y lo que ha casado
function rellenarHojaAules(txt, opc) {
    const h = leerCSVAules(txt), cab = h.filas[0] || [], C = columnasAules(cab);
    if (C.nota < 0 || (C.id < 0 && C.nombre < 0)) return { error: 'No parece la hoja de calificaciones de una tarea de Aules: falta la columna «Calificación» o la del identificador.' };
    const res = resultadosAules(), usados = new Set(), casados = [], sinEntrega = [];
    const porId = new Map(), porNom = new Map();
    res.forEach((x, n) => { if (x.id) porId.set(x.id, n); porNom.set(normNomAules(n), n); });
    for (let i = 1; i < h.filas.length; i++) {
        const f = h.filas[i]; while (f.length < cab.length) f.push('');
        const id = C.id >= 0 ? ((/(\d+)/.exec(f[C.id]) || [])[1] || '') : '', nom = C.nombre >= 0 ? f[C.nombre] : '';
        const clave = (id && porId.get(id)) || porNom.get(normNomAules(nom));
        if (!clave || usados.has(clave)) { sinEntrega.push(nom || f[C.id]); continue; }
        usados.add(clave); const { it } = res.get(clave);
        const maxTxt = C.max >= 0 ? f[C.max] : '', coma = /,/.test(maxTxt) || (!maxTxt && opc.coma);
        const max = parseFloat(String(maxTxt).replace(',', '.')) || opc.max || 10;
        const nota = Math.round(it.v.nota / 10 * max * 100) / 100, notaTxt = nota.toFixed(2);
        f[C.nota] = coma ? notaTxt.replace('.', ',') : notaTxt;
        if (C.com >= 0 && opc.comentario) f[C.com] = comentarioAules(it);
        casados.push({ nombre: nom || clave, alumno: clave, nota, max, por: id && porId.get(id) ? 'número de participante' : 'nombre' });
    }
    const sinCasar = [...res.keys()].filter(n => !usados.has(n));
    return { texto: escribirCSVAules(h), casados, sinEntrega, sinCasar, hayCom: C.com >= 0 };
}
function abrirNotasAules() {
    if (!masiva.lista.length) { snack('No hay programas en la lista'); return; }
    if (!hayPieza() && !(masiva.variantes || []).length) { snack('Abre antes el ejercicio (📂 Abrir ejercicio…)'); return; }
    let ov = document.getElementById('modalAules');
    if (!ov) { ov = document.createElement('div'); ov.className = 'modal-overlay'; ov.id = 'modalAules'; ov.onclick = e => { if (e.target === ov) ov.classList.remove('visible'); }; document.body.appendChild(ov); }
    ov.innerHTML = `<div class="help-modal" style="width:min(680px,100%)"><div class="help-header"><h2>⬆ Notas para Aules</h2><button class="help-close" onclick="document.getElementById('modalAules').classList.remove('visible')">✕</button></div>
        <div class="help-content">
        <ol class="aules-pasos"><li>En la tarea de Aules: <b>Ver todas las entregas</b> → <b>Acción sobre las calificaciones</b> → <b>Descargar hoja de calificaciones</b> (activa antes, en la configuración de la tarea, «Hoja de calificaciones fuera de línea» y, si quieres el comentario, «Comentarios de retroalimentación»).</li>
        <li>Ábrela aquí: se rellena la calificación de cada alumno (la nota orientativa, sobre la calificación máxima de la tarea) y su comentario.</li>
        <li>En Aules: <b>Subir hoja de calificaciones</b>, con la casilla «Permitir actualizar registros modificados más recientemente en Moodle» si ya habías puesto alguna nota.</li></ol>
        <label class="aules-op"><input type="checkbox" id="aulesCom" checked> Poner el comentario (la nota, el veredicto y sus errores principales)</label>
        <input type="file" id="aulesCSV" accept=".csv,text/csv" style="display:none">
        <div class="btn-row" style="margin-top:10px"><button class="btn-action" id="aulesAbrir">📂 Abrir la hoja de calificaciones…</button></div>
        <div id="aulesRes"></div></div></div>`;
    const esc = t => String(t).replace(/&/g, '&amp;').replace(/</g, '&lt;');
    ov.querySelector('#aulesAbrir').onclick = () => ov.querySelector('#aulesCSV').click();
    ov.querySelector('#aulesCSV').onchange = async ev => {
        const f = ev.target.files[0]; ev.target.value = ''; if (!f) return;
        const r = rellenarHojaAules(await f.text(), { comentario: ov.querySelector('#aulesCom').checked });
        const d = ov.querySelector('#aulesRes');
        if (r.error) { d.innerHTML = `<p class="aules-mal">⚠️ ${esc(r.error)}</p>`; return; }
        const nombre = f.name.replace(/\.csv$/i, '') + ' - con notas.csv';
        d.innerHTML = `<p><b>${r.casados.length}</b> alumno${r.casados.length === 1 ? '' : 's'} con nota${r.hayCom ? (ov.querySelector('#aulesCom').checked ? ' y comentario' : ' (sin comentario)') : ' (la hoja no tiene la columna de comentarios: actívalos en la tarea si los quieres)'}${r.sinEntrega.length ? ` · ${r.sinEntrega.length} sin entrega en la lista (se dejan como estaban)` : ''}.</p>
            ${r.sinCasar.length ? `<p class="aules-mal">⚠️ No se han encontrado en la hoja: <b>${r.sinCasar.map(esc).join(', ')}</b>. Ponles la nota a mano o cambia su nombre en la lista para que coincida con Aules.</p>` : ''}
            <table class="par-tabla"><tr><th>Alumno/a</th><th>Calificación</th><th>Casado por</th></tr>${r.casados.map(c => `<tr><td>${esc(c.nombre)}</td><td class="n">${String(c.nota).replace('.', ',')} / ${String(c.max).replace('.', ',')}</td><td>${c.por}</td></tr>`).join('')}</table>
            <div class="btn-row"><button class="btn-action" id="aulesBajar">⬇ Descargar «${esc(nombre)}»</button></div>`;
        d.querySelector('#aulesBajar').onclick = () => { descargar(r.texto, nombre, 'text/csv;charset=utf-8'); snack('Hoja descargada: súbela en la tarea de Aules con «Subir hoja de calificaciones»'); };
    };
    ov.classList.add('visible');
}
