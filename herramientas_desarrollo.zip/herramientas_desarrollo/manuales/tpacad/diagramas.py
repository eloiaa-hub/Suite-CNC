"""Dibujos de los apuntes «Programas ISO para TpaCAD». Usa la clase D de ../guia_iso/diagramas.py.
Uso: python3 diagramas.py  (los deja en diagramas/)"""
import os, math
AQUI = os.path.dirname(os.path.abspath(__file__))
src = open(os.path.join(AQUI, '..', 'guia_iso', 'diagramas.py'), encoding='utf-8').read()
src = src[:src.index('\nd = D(')].replace("os.path.join(os.path.dirname(os.path.abspath(__file__)), 'diagramas')", repr(os.path.join(AQUI, 'diagramas')))
exec(src)

def num(d, p, n, col, dx=0, dy=0):
    x, y = d.P(*p); x += dx; y += dy
    d.add(f'<circle cx="{x}" cy="{y}" r="9" fill="{col}"/><text x="{x}" y="{y + 4.2}" fill="#fff" font-size="12" font-weight="700" text-anchor="middle" font-family="\'Segoe UI\',Arial,sans-serif">{n}</text>')

def pieza():
    pts = [(60, 0), (120, 0), (120, 40)]
    pts += [(100 + 20 * math.cos(math.radians(a)), 40 + 20 * math.sin(math.radians(a))) for a in range(0, 91, 6)]
    pts += [(75, 60)] + [(60 + 15 * math.cos(math.radians(a)), 60 + 15 * math.sin(math.radians(a))) for a in range(0, -181, -6)]
    pts += [(20, 60)] + [(20 + 20 * math.cos(math.radians(a)), 40 + 20 * math.sin(math.radians(a))) for a in range(90, 181, 6)]
    pts += [(0, 0), (60, 0)]
    return pts

# 1. Cómo lo lee TpaCAD: un perfil por cada G0 y un agujero por cada G81
d = D(640, 330, esc=3.3, x0=40, y0=90)
d.poli([(p[0], p[1]) for p in pieza()], TINTA, 1, fill=MADERA)
d.poli([(60, -8), (60, 0)] + pieza() + [(60, -8)], NAR, 2.6)
d.punto((60, -8), NAR, 6); num(d, (60, -8), 'G0', NAR, dx=-26, dy=6)
d.texto((60, -8), 'mecanizado 1 (setup): G0 X… Y… Z20 T101 S12000', NAR, 12, 'start', '700', dx=10, dy=18)
d.texto((60, -8), 'G42 · G1 · G2 · G3 … hasta el siguiente G0', NAR, 12, 'start', dx=10, dy=33)
for x in (30, 90):
    d.circ((x, 30), 4, AZUL, 2, fill='#ffffff'); d.linea((x - 2, 30), (x + 2, 30), AZUL, 1.2); d.linea((x, 28), (x, 32), AZUL, 1.2)
d.texto((30, 30), 'G81', AZUL, 12, 'middle', '700', dy=-16); d.texto((90, 30), 'G81', AZUL, 12, 'middle', '700', dy=-16)
d.texto((126, 52), 'Mecanizado 1 (setup)', NAR, 14, 'start', '700'); d.texto((126, 46), 'el contorno, con su fresa y su corrección', NAR, 11.5)
d.texto((126, 34), 'Agujeros', AZUL, 14, 'start', '700'); d.texto((126, 28), 'una línea G81 por agujero', AZUL, 11.5)
d.texto((126, 14), 'Todo en la cara 1 (la de arriba).', GRIS, 11.5); d.texto((126, 9), 'TpaCAD decide cómo llega la', GRIS, 11.5); d.texto((126, 4), 'máquina a cada perfil y agujero.', GRIS, 11.5)
d.cero((0, 0))
d.svg('perfiles')

# 2. Cuadrante de máquina
d = D(640, 230, esc=1, x0=0, y0=0)
cx, cy, L = 220, 115, 70
for (i, j, n) in ((0, 0, 2), (1, 0, 1), (0, 1, 3), (1, 1, 4)):
    d.add(f'<rect x="{cx - L + i * L}" y="{cy - L + j * L}" width="{L}" height="{L}" fill="{"#dfe5eb" if n != 1 else "#cfe3f3"}" stroke="#fff" stroke-width="2"/>')
    d.add(f'<text x="{cx - L / 2 + i * L}" y="{cy - L / 2 + j * L + 7}" font-size="22" font-weight="700" fill="#1c2733" text-anchor="middle" font-family="\'Segoe UI\',Arial,sans-serif">{n}</text>')
d.add(f'<line x1="{cx - L - 10}" y1="{cy}" x2="{cx + L + 18}" y2="{cy}" stroke="#c0392b" stroke-width="2" marker-end="url(#fc0392b)"/><text x="{cx + L + 22}" y="{cy + 5}" fill="#c0392b" font-size="14" font-weight="700" font-family="Arial">X+</text>')
d.add(f'<line x1="{cx}" y1="{cy + L + 10}" x2="{cx}" y2="{cy - L - 14}" stroke="#1e8449" stroke-width="2" marker-end="url(#f1e8449)"/><text x="{cx + 6}" y="{cy - L - 8}" fill="#1e8449" font-size="14" font-weight="700" font-family="Arial">Y+</text>')
for k, t in enumerate(['1: X e Y positivas (lo normal en clase).', '2: X negativas · 3: X e Y negativas · 4: Y negativas.', 'Con 2, 3 o 4, TpaCAD pasa las cotas a positivas', 'usando las medidas de la pieza.']):
    d.add(f'<text x="340" y="{80 + 20 * k}" fill="{"#1c2733" if k == 0 else "#5b6878"}" font-size="12.5" font-weight="{700 if k == 0 else 400}" font-family="\'Segoe UI\',Arial,sans-serif">{t}</text>')
d.svg('cuadrantes', '80%')
print('dibujos en', os.path.join(AQUI, 'diagramas'))
