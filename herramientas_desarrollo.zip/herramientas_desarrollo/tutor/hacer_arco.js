// ── «◠ Hacer arco»: los puntos elegidos con la doble flecha (seguidos, de un contorno) se cambian por un solo arco ──
// Dos formas: «por los puntos» (los extremos quedan y el arco pasa lo más cerca posible de los demás) y «tangente a los
// tramos de al lado» (empalme con las rectas anterior y siguiente, que se recortan o alargan). El radio: el calculado,
// redondeado a 0,5 mm o escrito. Vista previa en discontinua naranja con la desviación máxima.
var arcoEd = null;
const cfgArcoEd = { modo:'tangente', radio:'calc' };
// Los puntos elegidos, si son seguidos y de un solo contorno: { ci, a, b, idx:[a…b] } o { error }
function tramoElegido() {
    if (!selPuntos || selPuntos.size < 3) return { error:'Elige al menos 3 puntos seguidos de la curva' };
    const cis = new Set(), S = new Set();
    selPuntos.forEach(k => { const [ci, vi] = k.split(':').map(Number); cis.add(ci); S.add(vi); });
    if (cis.size > 1) return { error:'Los puntos tienen que ser de un solo contorno' };
    const ci = [...cis][0], c = contornos[ci]; if (!c) return { error:'El contorno ya no existe' };
    const n = c.pts.length;
    if (S.size >= n) return { error:'Has elegido todos los puntos del contorno: elige solo los de la curva' };
    let a, b;
    if (c.cerrado) {
        const fins = [...S].filter(i => !S.has((i + 1) % n)), inis = [...S].filter(i => !S.has((i - 1 + n) % n));
        if (fins.length !== 1 || inis.length !== 1) return { error:'Los puntos elegidos tienen que ir seguidos' };
        a = inis[0]; b = fins[0];
    } else {
        const l = [...S].sort((x, y) => x - y); a = l[0]; b = l[l.length - 1];
        if (b - a + 1 !== l.length) return { error:'Los puntos elegidos tienen que ir seguidos' };
    }
    const idx = []; for (let i = a; ; i = (i + 1) % n) { idx.push(i); if (i === b) break; }
    return { ci, a, b, idx, n };
}
// Muestras de la curva: los vértices y el punto medio de cada tramo (en un arco, el de su curva)
function muestrasTramo(c, idx) {
    const ts = tramos(c), out = [];
    idx.forEach((i, k) => { out.push(c.pts[i]); if (k < idx.length - 1) { const t = ts.find(x => x.i === i); if (!t) return;
        if (!t.b) out.push(mulv(add(t.p1, t.p2), 0.5)); else { const A = arcoDeBulge(t.p1, t.p2, t.b); if (A) out.push(add(A.c, mulv({ x:Math.cos(A.a1 + A.theta / 2), y:Math.sin(A.a1 + A.theta / 2) }, A.r))); } } });
    return out;
}
// Mínimo de f en [x0, x1]: barrido y sección áurea
function minimo1D(f, x0, x1, n) {
    let mejor = x0, fm = Infinity;
    for (let k = 0; k <= n; k++) { const x = x0 + (x1 - x0) * k / n, v = f(x); if (v < fm) { fm = v; mejor = x; } }
    let lo = Math.max(x0, mejor - (x1 - x0) / n), hi = Math.min(x1, mejor + (x1 - x0) / n); const g = (Math.sqrt(5) - 1) / 2;
    for (let it = 0; it < 60; it++) { const m1 = hi - g * (hi - lo), m2 = lo + g * (hi - lo); if (f(m1) < f(m2)) hi = m2; else lo = m1; }
    return (lo + hi) / 2;
}
function desviacion(Q, C, R) { return Q.reduce((m, q) => Math.max(m, Math.abs(dist(q, C) - R)), 0); }
// Calcula el arco sin aplicarlo
function calcularArco(ed) {
    const c = contornos[ed.ci]; if (!c) return { ok:false, msg:'El contorno ya no existe' };
    const { a, b, idx, n } = ed, P1 = c.pts[a], P2 = c.pts[b], Q = muestrasTramo(c, idx);
    // «escrito» con la casilla vacía: el calculado
    const Rpedido = ed.radio === 'escrito' && String(ed.R || '').trim() !== '' ? numES(ed.R) : null;
    if (Rpedido !== null && !(Rpedido > 0)) return { ok:false, msg:'Escribe un radio mayor que 0' };
    const redondear = R => Math.max(0.5, Math.round(R * 2) / 2);
    if (ed.modo === 'tangente') {
        const ts = tramos(c), tPrev = ts.find(t => t.j === a), tNext = ts.find(t => t.i === b);
        if (!tPrev || !tNext) return { ok:false, msg:'Para que sea tangente hace falta un tramo antes y otro después: usa «por los puntos»' };
        if (tPrev.b || tNext.b) return { ok:false, msg:'Los tramos de al lado tienen que ser rectas para que el arco sea tangente: usa «por los puntos»' };
        const A0 = tPrev.p1, B0 = tNext.p2, u1 = norm(sub(P1, A0)), u2 = norm(sub(B0, P2)), cr = cross(u1, u2);
        if (Math.abs(cr) < 1e-6) return { ok:false, msg:'Las rectas de al lado son paralelas: usa «por los puntos»' };
        // corte de las dos rectas
        const s = cross(sub(P2, A0), u2) / cr, X = add(A0, mulv(u1, s));
        const fi = Math.acos(Math.max(-1, Math.min(1, dot(mulv(u1, -1), u2))));         // ángulo entre las dos rectas en el corte
        const t2 = Math.tan(fi / 2), s2 = Math.sin(fi / 2), w = norm(sub(u2, u1));
        const dMax = Math.min(dot(sub(X, A0), u1), dot(sub(B0, X), u2));
        if (!(dMax > 1e-6)) return { ok:false, msg:'Las rectas de al lado no se cortan hacia la curva: usa «por los puntos»' };
        const geo = R => { const d = R / t2; return { C: add(X, mulv(w, R / s2)), T1: add(X, mulv(u1, -d)), T2: add(X, mulv(u2, d)), d }; };
        const Rmax = dMax * t2 * 0.999;
        let R = minimo1D(R => { const g = geo(R); return Q.reduce((s3, q) => s3 + (dist(q, g.C) - R) ** 2, 0); }, Rmax * 1e-3, Rmax, 300);
        const Rcalc = R;
        if (ed.radio === 'red') R = redondear(R); else if (Rpedido) R = Rpedido;
        if (R > Rmax / 0.999 + 1e-9) return { ok:false, msg:`Con R${fmt(R, 3)} el arco no cabe entre las rectas de al lado (como mucho R${fmt(Rmax, 3)})`, Rcalc };
        const g = geo(R), ccw = cr > 0, bul = bulgeAlrededor(g.T1, g.T2, g.C, ccw);
        return { ok:true, modo:'tangente', C:g.C, R, Rcalc, ini:g.T1, fin:g.T2, b:bul, dev:desviacion(Q, g.C, R) };
    }
    // por los puntos: los extremos quedan; el centro, en su mediatriz
    const L = dist(P1, P2); if (L < 1e-6) return { ok:false, msg:'El primer y el último punto coinciden' };
    const M = mulv(add(P1, P2), 0.5), u = norm(sub(P2, P1)), nn = { x:-u.y, y:u.x };
    const Cde = t => add(M, mulv(nn, t)), f = t => { const C = Cde(t), R = dist(P1, C); return Q.reduce((s3, q) => s3 + (dist(q, C) - R) ** 2, 0); };
    let t = minimo1D(f, -60 * L, 60 * L, 1200);
    const Rcalc = dist(P1, Cde(t)); let R = Rcalc;
    if (ed.radio === 'red') R = redondear(R); else if (Rpedido) R = Rpedido;
    if (R < L / 2 - 1e-9) return { ok:false, msg:`R${fmt(R, 3)} es menor que la mitad de la distancia entre el primer y el último punto (${fmt(L / 2, 3)})`, Rcalc };
    if (R !== Rcalc) t = Math.sign(t || 1) * Math.sqrt(Math.max(0, R * R - L * L / 4));
    const C = Cde(t);
    // el sentido: el del lado donde están los puntos (el punto del medio)
    const qm = Q[Math.floor(Q.length / 2)];
    const op = [true, false].map(ccw => { const bb = bulgeAlrededor(P1, P2, C, ccw), A = arcoDeBulge(P1, P2, bb); const m = A ? add(A.c, mulv({ x:Math.cos(A.a1 + A.theta / 2), y:Math.sin(A.a1 + A.theta / 2) }, A.r)) : P1; return { bb, d: dist(m, qm) }; });
    const bul = op[0].d <= op[1].d ? op[0].bb : op[1].bb;
    return { ok:true, modo:'puntos', C, R, Rcalc, ini:P1, fin:P2, b:bul, dev:desviacion(Q, C, R) };
}
function aplicarArco(ed, res) {
    const c = contornos[ed.ci]; if (!c || !res.ok) return;
    guardarUndo();
    const interior = new Set(ed.idx.slice(1, -1)), pts = [], bs = [];
    for (let i = 0; i < ed.n; i++) {
        if (interior.has(i)) continue;
        if (i === ed.a) { pts.push({ ...c.pts[i], x:res.ini.x, y:res.ini.y }); bs.push(res.b); }
        else if (i === ed.b) { pts.push({ ...c.pts[i], x:res.fin.x, y:res.fin.y }); bs.push(c.b[i] || 0); }
        else { pts.push(c.pts[i]); bs.push(c.b[i] || 0); }
    }
    c.pts = pts; c.b = bs; if (!c.cerrado) c.b[c.pts.length - 1] = 0;
    selPuntos.clear(); if (typeof memoTipos !== 'undefined') memoTipos = null;
    refrescar(); actualizarEstado(); if (typeof guardarAutoPronto === 'function') guardarAutoPronto();
}
function abrirHacerArco() {
    const t = tramoElegido(); if (t.error) { snack(t.error); return; }
    const c = contornos[t.ci]; if (c.bloqueado || c.texto || c.deTexto) { snack('Ese contorno no se puede cambiar'); return; }
    const ts = tramos(c), puedeTan = ts.some(x => x.j === t.a && !x.b) && ts.some(x => x.i === t.b && !x.b);
    arcoEd = { ...t, modo: puedeTan ? cfgArcoEd.modo : 'puntos', radio: cfgArcoEd.radio, R: '', res:null };
    ctxPanel.innerHTML = `
        <div class="ctx-titulo">◠ Hacer un arco con ${t.idx.length} puntos de C${t.ci + 1}</div>
        <div class="param-line">Forma <select id="haModo"><option value="tangente">tangente a los tramos de al lado</option><option value="puntos">por los puntos (los extremos quedan)</option></select></div>
        <div class="param-line">Radio <select id="haRadio"><option value="calc">el calculado</option><option value="red">redondeado a 0,5 mm</option><option value="escrito">escrito:</option></select> <input type="number" id="haR" step="0.1" min="0.01" style="width:80px" disabled></div>
        <div class="ctx-nota" id="haInfo"></div>
        <button class="principal" id="haOk">Aplicar</button>
        <div class="ctx-nota">Intro aplica · Esc cancela · se puede deshacer</div>`;
    // la ventana, arriba, en el lado contrario a los puntos elegidos (para no tapar la vista previa)
    ctxPanel.style.minWidth = '360px'; colocarCtx(0, 0);
    { let sx = 0, m = 0; selPuntos.forEach(k => { const [ci, vi] = k.split(':').map(Number), q = contornos[ci] && contornos[ci].pts[vi]; if (q) { sx += aPantalla(q).x; m++; } });
      const w = ctxPanel.offsetWidth; ctxPanel.style.left = (m && sx / m > W / 2 ? 8 : Math.max(8, W - w - 8)) + 'px'; ctxPanel.style.top = '48px'; }
    const g = id => document.getElementById(id), Mo = g('haModo'), Ra = g('haRadio'), RR = g('haR');
    Mo.value = arcoEd.modo; Ra.value = arcoEd.radio; RR.disabled = arcoEd.radio !== 'escrito';
    const previa = () => {
        if (!arcoEd) return; arcoEd.R = RR.value; const res = calcularArco(arcoEd); arcoEd.res = res;
        if (res.Rcalc && !RR.value) RR.placeholder = fmt(res.Rcalc, 3);
        const info = g('haInfo'), f = v => fmt(v, 3);
        if (!res.ok) info.innerHTML = `<span style="color:#c0392b">⚠ ${res.msg}</span>`;
        else {
            const dmax = Math.max(1, 0.1 * res.R), malo = res.dev > dmax, flojo = res.dev > 0.2;
            info.innerHTML = `R${f(res.R)}${res.R !== res.Rcalc ? ` (calculado R${f(res.Rcalc)})` : ''} · centro X${f(res.C.x)} Y${f(res.C.y)}<br>` +
                `<span style="color:${malo ? '#c0392b' : flojo ? '#b9770e' : 'inherit'}">desviación máx. ${fmt(res.dev, 2)} mm${malo ? ' — estos puntos no forman un arco' : flojo ? ' — revisa que sea la curva que buscas' : ''}</span>`;
            if (malo) res.ok = false;
        }
        g('haOk').disabled = !res.ok; render();
    };
    Mo.onchange = () => { arcoEd.modo = cfgArcoEd.modo = Mo.value; previa(); };
    Ra.onchange = () => { arcoEd.radio = cfgArcoEd.radio = Ra.value; RR.disabled = Ra.value !== 'escrito'; if (!RR.disabled) { if (!RR.value && arcoEd.res && arcoEd.res.Rcalc) RR.value = +arcoEd.res.Rcalc.toFixed(2); RR.focus(); RR.select(); } previa(); };
    RR.oninput = previa;
    const aplicar = () => { const ed = arcoEd; if (!ed || !ed.res || !ed.res.ok) return; const res = ed.res; aplicarArco(ed, res); cerrarCtx();
        snack(`${ed.idx.length} puntos → un arco R${fmt(res.R, 3)}${res.modo === 'tangente' ? ', tangente a los tramos de al lado' : ''} (desviación máx. ${fmt(res.dev, 2)} mm)`); };
    g('haOk').onclick = aplicar;
    ctxPanel.querySelectorAll('input, select').forEach(el => el.addEventListener('keydown', ev => {
        if (ev.key === 'Enter') { ev.preventDefault(); aplicar(); } else if (ev.key === 'Escape') { ev.preventDefault(); cerrarCtx(); } }));
    previa(); setTimeout(() => Mo.focus(), 20);
}
function dibujarPreviaArco() {
    if (!arcoEd || !arcoEd.res || !arcoEd.res.C) return;
    const r = arcoEd.res, c = contornos[arcoEd.ci]; if (!c) return;
    ctx.save(); ctx.strokeStyle = r.ok ? '#e67e22' : '#c0392b'; ctx.lineWidth = 2.4; ctx.setLineDash([7, 5]);
    if (r.ini && r.fin && r.b !== undefined) { const A = arcoDeBulge(r.ini, r.fin, r.b); if (A) { const s = aPantalla(A.c); ctx.beginPath(); ctx.arc(s.x, s.y, A.r * view.z, -A.a1, -(A.a1 + A.theta), A.theta > 0); ctx.stroke(); } }
    if (r.modo === 'tangente') { const ts = tramos(c), tp = ts.find(t => t.j === arcoEd.a), tn = ts.find(t => t.i === arcoEd.b);
        const seg = (p, q) => { const a1 = aPantalla(p), a2 = aPantalla(q); ctx.beginPath(); ctx.moveTo(a1.x, a1.y); ctx.lineTo(a2.x, a2.y); ctx.stroke(); };
        if (tp) seg(tp.p1, r.ini); if (tn) seg(r.fin, tn.p2); }
    ctx.setLineDash([]); const s = aPantalla(r.C); ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(s.x - 8, s.y); ctx.lineTo(s.x + 8, s.y); ctx.moveTo(s.x, s.y - 8); ctx.lineTo(s.x, s.y + 8); ctx.stroke();
    ctx.restore();
}
// El botón «◠ Hacer arco», junto a los puntos elegidos
function colocarBotonArco() {
    let bt = document.getElementById('btnHacerArco');
    if (!bt) { bt = document.createElement('div'); bt.id = 'btnHacerArco'; bt.className = 'zoom-btn'; bt.textContent = '◠ Hacer arco (A)'; bt.title = 'Cambia los puntos elegidos por un solo arco';
        bt.onclick = e => { e.stopPropagation(); abrirHacerArco(); }; bt.addEventListener('pointerdown', e => e.stopPropagation()); document.getElementById('canvasWrap').appendChild(bt); }
    const ver = herramienta === 'puntos' && selPuntos && selPuntos.size >= 3 && !arcoEd && !tramoElegido().error;
    bt.style.display = ver ? '' : 'none'; if (!ver) return;
    let x = -Infinity, y = Infinity; selPuntos.forEach(k => { const [ci, vi] = k.split(':').map(Number), q = contornos[ci] && contornos[ci].pts[vi]; if (!q) return; const s = aPantalla(q); x = Math.max(x, s.x); y = Math.min(y, s.y); });
    bt.style.left = Math.min(W - 130, Math.max(4, x + 14)) + 'px'; bt.style.top = Math.max(4, y - 34) + 'px';
}
