#!/usr/bin/env python3
"""◠ Practicar I J: el Calcador envía los contornos de la pieza a Arcos I J (arcos_ij.html), en el mismo orden,
sentido y cero pieza que la tabla de soluciones. Uso: python3 arcos_calcador.py CARPETA_DE_LA_SUITE"""
import os, re, sys
d = sys.argv[1] if len(sys.argv) > 1 else '.'
p = os.path.join(d, 'calcador.html')
s = open(p, encoding='utf-8').read()
def rep(a, b):
    global s
    assert s.count(a) == 1, (s.count(a), a[:80])
    s = s.replace(a, b)
BOTON = '''<button class="btn-action sec" onclick="abrirEnArcosIJ()" title="Abre los arcos de esta pieza en Arcos I J, para practicar G2/G3, X Y e I J con ellos">◠ Practicar I J</button>\n                '''
m = re.search(r'<button class="btn-action sec" onclick="exportarEjercicioTutor\(\)"[^\n]*\n\s*</div>', s); assert m
txt = m.group(0); i = txt.rindex('</div>')
s = s.replace(txt, txt[:txt.index('\n')] + '\n                    ' + BOTON.rstrip() + '\n' + txt[txt.index('\n') + 1:], 1)
JS = r"""// ◠ Practicar I J: los contornos de la pieza, con el orden, el sentido y el cero de la tabla de soluciones
let paraArcos = null;
function abrirEnArcosIJ() {
    const tipos = tiposResueltos(), selO = document.getElementById('tbOrigen');
    const lista = contornos.map((c, i) => ({ c, i })).filter(o => o.c.pts.length >= 2 && !soloFabricar(o.c))
        .sort((a, b) => (rangoMecanizado(tipos[a.i], contornos[a.i]) - rangoMecanizado(tipos[b.i], contornos[b.i])) || a.i - b.i);
    let off = { x:0, y:0 };
    if (!selO || selO.value === 'pieza') {
        const base = contornos.filter((c, i) => c.cerrado && tipos[i] !== 'interior');
        const usar = base.length ? base : contornos.filter(c => c.pts.length >= 2);
        if (usar.length) { const bb = bboxPts([].concat(...usar.map(c => c.pts.concat(muestrearContorno(c))))); off = { x:bb.x0, y:bb.y0 }; }
    }
    const pt = p => { const q = sub(p, off); return { x:q.x, y:q.y }; };
    const envio = lista.map(({ c, i }) => ({ cerrado: !!c.cerrado, clase: tipos[i], grabado: !!esGrabado(c), tramos: tramos(c).map(t => {
        if (!t.b) return { t:'L', a: pt(t.p1), b: pt(t.p2) };
        const a = arcoDeBulge(t.p1, t.p2, t.b);
        return { t:'A', a: pt(t.p1), b: pt(t.p2), C: pt(a.c), R: a.r, g: t.b > 0 ? 'G3' : 'G2' };
    }) }));
    if (!envio.some(c => !c.grabado && c.tramos.some(t => t.t === 'A'))) { snack('Esta pieza no tiene arcos que practicar'); return; }
    paraArcos = { tipo:'arcos-calcador', nombre: nombreProyecto(), contornos: envio };
    try { localStorage.setItem('suiteCNC:paraArcos', JSON.stringify({ ...paraArcos, t: Date.now() })); } catch (e) {}
    const w = window.open('arcos_ij.html#desdeCalcador', '_blank');
    if (!w) { snack('El navegador ha bloqueado la pestaña nueva: permite las ventanas emergentes para este archivo'); return; }
    snack('Abriendo los arcos de la pieza en Arcos I J…');
}
window.addEventListener('message', e => {
    const d = e.data; if (!d || typeof d !== 'object') return;
    if (d.tipo === 'arcos-listo' && paraArcos && e.source) { e.source.postMessage(paraArcos, '*'); paraArcos = null; }
});
// ── Abrir el plano y su solución en el Simulador 3D ──"""
rep('// ── Abrir el plano y su solución en el Simulador 3D ──', JS)
m = re.search(r'vertical-align:middle">v(\d+)</span></span>', s); assert m
s = s.replace(m.group(0), m.group(0).replace('v' + m.group(1), 'v119'), 1)
open(p, 'w', encoding='utf-8').write(s)
print('calcador.html: ◠ Practicar I J, v119')
