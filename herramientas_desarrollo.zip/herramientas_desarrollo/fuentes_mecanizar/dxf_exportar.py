"""Calcador: el DXF exportado se abre en AutoCAD.
Antes se escribía un DXF mínimo (solo ENTITIES, sin versión) con LWPOLYLINE: AutoCAD lo toma como R12, donde
LWPOLYLINE no existe, y lo abría vacío. Ahora es un DXF R12 completo (AC1009, como el del Anidador): cabecera con
versión, página de códigos y extensión, tablas de tipos de línea y capas, y POLYLINE/VERTEX con los arcos como
bulge («Polilíneas con arcos») o LINE/ARC («Líneas y arcos»). Capas: PERFIL, INTERIOR, ABIERTO, CAJERA, ISLA y TEXTO.
Uso: python3 dxf_exportar.py <carpeta de la suite>
"""
import sys, os
P = os.path.join(sys.argv[1] if len(sys.argv) > 1 else '.', 'calcador.html')
s = open(P, encoding='utf-8').read()
def rep(a, b, cnt=1):
    global s
    n = s.count(a); assert n == cnt, f'{n} apariciones (se esperaban {cnt}) de: {a[:100]}'
    s = s.replace(a, b)
i = s.index('function exportarDXF() {'); j = s.index('let cfgExport = { svgColor:false };')
s = s[:i] + r"""// DXF R12 (AC1009) completo: lo abren AutoCAD, LibreCAD, QCAD… y el propio Calcador. Las polilíneas llevan los
// arcos como bulge (POLYLINE/VERTEX, que sí existen en R12; LWPOLYLINE no) o se escriben como LINE y ARC.
const CAPAS_DXF_CALC = [['PERFIL', 5], ['INTERIOR', 1], ['ABIERTO', 3], ['CAJERA', 6], ['ISLA', 4], ['TEXTO', 2]];
function textoDXFCalc() {
    const { lista } = contornosExportables();
    const todos = contornos.filter(c => c.pts.length >= 2 && c.pts.every(p => isFinite(p.x) && isFinite(p.y)));
    if (!todos.length) return null;
    const tipos = tiposResueltos();
    const off = desplazamientoOrigen(lista.length ? lista : todos.map(c => ({ c })));
    const f = v => { const t = (+v).toFixed(4).replace(/\.?0+$/, ''); return t === '-0' || t === '' ? '0' : t; };
    const modo = document.getElementById('selDxf').value;
    const L = [], g = (c, v) => L.push(String(c), String(v));
    const capaDe = (c, i) => c.texto || c.deTexto ? 'TEXTO' : esCajera(c) ? 'CAJERA' : esIsla(c) ? 'ISLA' : tipos[i] === 'interior' ? 'INTERIOR' : tipos[i] === 'abierto' ? 'ABIERTO' : 'PERFIL';
    const bb = bboxPts([].concat(...todos.map(c => muestrearContorno(c).concat(c.pts))).map(p => sub(p, off)));
    g(0, 'SECTION'); g(2, 'HEADER'); g(9, '$ACADVER'); g(1, 'AC1009'); g(9, '$DWGCODEPAGE'); g(3, 'ANSI_1252');
    g(9, '$INSBASE'); g(10, 0); g(20, 0); g(30, 0);
    g(9, '$EXTMIN'); g(10, f(bb.x0)); g(20, f(bb.y0)); g(30, 0); g(9, '$EXTMAX'); g(10, f(bb.x1)); g(20, f(bb.y1)); g(30, 0);
    g(9, '$LIMMIN'); g(10, f(bb.x0)); g(20, f(bb.y0)); g(9, '$LIMMAX'); g(10, f(bb.x1)); g(20, f(bb.y1));
    g(9, '$MEASUREMENT'); g(70, 1); g(0, 'ENDSEC');
    g(0, 'SECTION'); g(2, 'TABLES');
    g(0, 'TABLE'); g(2, 'LTYPE'); g(70, 1); g(0, 'LTYPE'); g(2, 'CONTINUOUS'); g(70, 0); g(3, 'Solid line'); g(72, 65); g(73, 0); g(40, 0); g(0, 'ENDTAB');
    g(0, 'TABLE'); g(2, 'LAYER'); g(70, CAPAS_DXF_CALC.length + 1);
    [['0', 7]].concat(CAPAS_DXF_CALC).forEach(([n, col]) => { g(0, 'LAYER'); g(2, n); g(70, 0); g(62, col); g(6, 'CONTINUOUS'); });
    g(0, 'ENDTAB'); g(0, 'ENDSEC');
    g(0, 'SECTION'); g(2, 'ENTITIES');
    contornos.forEach((c, i) => {
        if (!todos.includes(c)) return;
        const capa = capaDe(c, i), pts = c.pts.map(p => sub(p, off));
        if (modo === 'lw') {
            g(0, 'POLYLINE'); g(8, capa); g(66, 1); g(10, 0); g(20, 0); g(30, 0); g(70, c.cerrado ? 1 : 0);
            pts.forEach((p, k) => {
                g(0, 'VERTEX'); g(8, capa); g(10, f(p.x)); g(20, f(p.y)); g(30, 0);
                const b = (k < pts.length - 1 || c.cerrado) ? (c.b[k] || 0) : 0;
                if (Math.abs(b) > 1e-12) g(42, (+b).toFixed(10));
            });
            g(0, 'SEQEND'); g(8, capa);
        } else {
            tramos({ ...c, pts }).forEach(t => {
                if (!t.b) { g(0, 'LINE'); g(8, capa); g(10, f(t.p1.x)); g(20, f(t.p1.y)); g(30, 0); g(11, f(t.p2.x)); g(21, f(t.p2.y)); g(31, 0); return; }
                const a = arcoDeBulge(t.p1, t.p2, t.b); if (!a) return;
                let a0 = a.a1, a1 = a.a1 + a.theta; if (a.theta < 0) [a0, a1] = [a1, a0];
                const gr = x => (wrap(x) * 180 / Math.PI).toFixed(6);
                g(0, 'ARC'); g(8, capa); g(10, f(a.c.x)); g(20, f(a.c.y)); g(30, 0); g(40, f(a.r)); g(50, gr(a0)); g(51, gr(a1));
            });
        }
    });
    g(0, 'ENDSEC'); g(0, 'EOF');
    return L.join('\r\n') + '\r\n';
}
function exportarDXF() {
    const { abiertos } = contornosExportables();
    const dxf = textoDXFCalc();
    if (!dxf) { snack('No hay contornos que exportar'); return; }
    descargar(dxf, nombreProyecto() + '.dxf', 'application/dxf');
    snack('DXF exportado en mm (R12: se abre en AutoCAD, LibreCAD y otros CAD)' + (abiertos ? ` · incluye ${abiertos} contorno(s) abierto(s) en la capa ABIERTO` : ''));
}
""" + s[j:]
rep("«Polilínea con arcos» genera LWPOLYLINE con bulge; «Líneas y arcos (R12)» genera entidades LINE y ARC sueltas, la opción más compatible con AutoCAD.", "Es un DXF R12 completo, que abren AutoCAD, LibreCAD y los demás CAD: «Polilíneas con arcos (R12)» guarda cada contorno como POLYLINE con sus arcos; «Líneas y arcos (R12)», como LINE y ARC sueltos. Capas: PERFIL, INTERIOR, ABIERTO, CAJERA, ISLA y TEXTO.")
rep('<option value="lw" selected>Polilínea con arcos</option>', '<option value="lw" selected>Polilíneas con arcos (R12)</option>')
open(P, 'w', encoding='utf-8').write(s)
print('Calcador: DXF R12 completo:', P)
