"""Calcador v108 / Corrector v53: ⬆ Notas para Aules en la corrección masiva. Rellena la «hoja de calificaciones» que
descarga la tarea de Aules (Moodle) con la nota de cada alumno (escalada a la calificación máxima) y un comentario, casando
por el número de participante del zip de Aules o por el nombre, y la devuelve para «Subir hoja de calificaciones».
Uso: python3 aules_notas.py <carpeta de la suite>   (construir_calcador.sh lo pone tras parecidos_masiva.py)"""
import sys, os
AQUI = os.path.dirname(os.path.abspath(__file__))
P = os.path.join(sys.argv[1] if len(sys.argv) > 1 else '.', 'calcador.html')
s = open(P, encoding='utf-8').read()
def rep(a, b, cnt=1):
    global s
    n = s.count(a); assert n == cnt, f'{n} apariciones (se esperaban {cnt}) de: {a[:100]}'
    s = s.replace(a, b)
JS = open(os.path.join(AQUI, 'aules_notas.js'), encoding='utf-8').read()
rep("// Arrastrar archivos a la ventana de corrección masiva; ordenar por columna", JS + "// Arrastrar archivos a la ventana de corrección masiva; ordenar por columna")
rep("""<button class="btn-action sec" onclick="exportarCSVMasiva()" title="Tabla para Excel o LibreOffice">⬇ CSV</button>""",
    """<button class="btn-action sec" onclick="exportarCSVMasiva()" title="Tabla para Excel o LibreOffice">⬇ CSV</button>
                <button class="btn-action sec" onclick="abrirNotasAules()" title="Rellena la hoja de calificaciones de la tarea de Aules con la nota y un comentario de cada alumno, para subirla de una vez">⬆ Notas para Aules</button>""")
rep("    .mv-inf { font-size:12px; cursor:help; }",
    """    .aules-pasos { margin:0 0 10px 18px; padding:0; font-size:13px; line-height:1.5; } .aules-pasos li { margin-bottom:4px; }
    .aules-op { display:block; font-size:13px; } .aules-mal { color:#b0301f; }
    .mv-inf { font-size:12px; cursor:help; }""")
rep("""la columna «Parecido con» del CSV. Es un indicio, no una prueba.""",
    """la columna «Parecido con» del CSV. Es un indicio, no una prueba. <strong>⬆ Notas para Aules</strong> rellena la hoja de calificaciones de la tarea (en Aules: «Descargar hoja de calificaciones») con la nota de cada alumno, sobre la calificación máxima de la tarea, y un comentario con su veredicto y sus errores principales; se descarga y se sube en Aules con «Subir hoja de calificaciones». Cada alumno se reconoce por su número de participante del zip de Aules o por su nombre.""")
open(P, 'w', encoding='utf-8').write(s)
print('Calcador: notas para Aules (hoja de calificaciones)')
