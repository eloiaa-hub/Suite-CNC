"""Simulador 3D V44 (revisión de robustez): al cambiar solo el tipo o el ángulo de la fresa de una T del programa,
no se rehace la trayectoria (no cambia: solo el Ø la cambia, por la compensación); basta con rehacer el material.
Uso: python3 simulador_robustez.py <carpeta de la suite>      (ya aplicado: no se vuelve a ejecutar)"""
import sys, os
RUTA = os.path.join(sys.argv[1] if len(sys.argv) > 1 else '.', 'simulador3d.html')
s = open(RUTA, encoding='utf-8').read()
a = "    herrVista = null; recalcularTrayectoria(); if (typeof evaluarPlano === 'function') evaluarPlano();"
assert s.count(a) == 1, 'ya aplicado o cambiado'
s = s.replace(a, """    herrVista = null;
    if ('d' in campos) { recalcularTrayectoria(); if (typeof evaluarPlano === 'function') evaluarPlano(); }
    else { asignarHerramientas(gcodeMoves); if (material) { reiniciarMaterial(); actualizarMaterial(indicePlano); } moverHerramientaA(indicePlano); }""")
open(RUTA, 'w', encoding='utf-8').write(s)
print('Simulador: cambio de tipo o ángulo sin rehacer la trayectoria')
