"""Reduce las capturas JPEG de un PDF de manual: a lo sumo MAXPX píxeles de ancho y calidad Q.
Uso: python3 reducir_pdf.py entrada.pdf salida.pdf [MAXPX=1300] [Q=80]"""
import sys, io
import pikepdf
from pikepdf import Name
from PIL import Image
ent, sal = sys.argv[1], sys.argv[2]
MAXPX = int(sys.argv[3]) if len(sys.argv) > 3 else 1300
Q = int(sys.argv[4]) if len(sys.argv) > 4 else 80
pdf = pikepdf.open(ent); antes = despues = 0; n = 0
for obj in pdf.objects:
    if not isinstance(obj, pikepdf.Stream) or obj.get('/Subtype') != Name.Image or obj.get('/Filter') != Name.DCTDecode: continue
    raw = obj.read_raw_bytes(); im = Image.open(io.BytesIO(raw))
    if im.mode not in ('RGB', 'L'): continue
    w, h = im.size
    if w > MAXPX: im = im.resize((MAXPX, round(h * MAXPX / w)), Image.LANCZOS)
    b = io.BytesIO(); im.save(b, 'JPEG', quality=Q, optimize=True, progressive=True); nuevo = b.getvalue()
    if len(nuevo) < len(raw) * 0.9:
        obj.write(nuevo, filter=Name.DCTDecode); obj.Width, obj.Height = im.size; antes += len(raw); despues += len(nuevo); n += 1
pdf.save(sal, compress_streams=True)
print(f'{sal}: {n} imágenes, {antes/1e6:.1f} → {despues/1e6:.1f} MB')
