// ── Que el trazado puntúe: sin cortar (altura de corte incorrecta) o desplazado (otro cero pieza) ──
// Si el recorrido es el de la pieza pero no corta, o está movido, la geometría se lleva un porcentaje de sus puntos (cfgCorr.notaTrazado,
// de partida el 50 %), en proporción al contorno que recorre bien. Lo pedido y la seguridad se cuentan como siempre.
const TRAZADO_DEF = 50;
const pctTrazado = () => { const v = +cfgCorr.notaTrazado; return isFinite(v) && v >= 0 ? Math.min(100, v) : TRAZADO_DEF; };
const _valorarCorreccionTraz = valorarCorreccion;
valorarCorreccion = function (r) {
    const v = _valorarCorreccionTraz.apply(this, arguments);
    if (!r || r.error) return v;
    const t = r.desplazado ? { cob: r.desplazado.cob || 0, que: 'desplazado' } : r.trazado ? { cob: r.trazado.cob || 0, que: 'altura' } : null;
    const f = pctTrazado() / 100; if (!t || !f) return v;
    const N = critNota(), max = N.geo + N.pedido + N.seg || 1;
    if (v.rub) {
        const g = v.rub.find(x => x.k === 'geo'), pts = Math.round(g.peso * f * t.cob * 100) / 100;
        if (pts > g.puntos) { g.puntos = pts; g.frac = f * t.cob; g.trazado = t.que; const tot = v.rub.reduce((a, x) => a + x.peso, 0) || 1; v.nota = Math.round(v.rub.reduce((a, x) => a + x.puntos, 0) / tot * 100) / 10; v.trazadoPuntua = t.que; }
        return v;
    }
    const geo = Math.round(N.geo * f * t.cob * 100) / 100;
    if (geo > v.desglose.geo) { v.desglose.geo = geo; v.nota = Math.round((geo + v.desglose.pedido + v.desglose.seg) / max * 100) / 10; v.trazadoPuntua = t.que; }
    return v;
};
