"""Un solo Simulador 3D para todos: el del profesor (con editor de G-code) pasa a ser simulador3d.html, sin «Profesor»,
y simulador3d_profesor.html queda como una página que lleva al nuevo (para los enlaces antiguos de Aules).
Uso (una sola vez, ya aplicado): python3 simulador_unico.py <carpeta de la suite>
"""
import sys, os
D = sys.argv[1] if len(sys.argv) > 1 else '..'
P = os.path.join(D, 'simulador3d_profesor.html')
s = open(P, encoding='utf-8').read()
assert 'pill-profesor" title' in s, 'ya aplicado: simulador3d_profesor.html ya no es el simulador'
def rep(a, b, cnt=1):
    global s
    n = s.count(a); assert n == cnt, f'{n} apariciones (se esperaban {cnt}) de: {a[:100]}'
    s = s.replace(a, b)
rep('<title>Simulador G-Code 3D (Profesor) — Por Eloi A.A.</title>', '<title>Simulador G-Code 3D — Por Eloi A.A.</title>')
rep('>Profesor · V39</span></h1>', '>V40</span></h1>')
rep('        <span class="pill-profesor" title="Versión para profesores: permite editar y guardar el G-code">PROFESOR</span>\n', '')
rep('<h3>Editar y guardar el G-code (versión Profesor)</h3>', '<h3>Editar y guardar el G-code</h3>')
rep('<h3>Simulador G-Code 3D (versión del profesor)</h3>', '<h3>Simulador G-Code 3D</h3>')
rep('// ── Edición del G-code (solo versión Profesor) ─', '// ── Edición del G-code ─')
open(os.path.join(D, 'simulador3d.html'), 'w', encoding='utf-8').write(s)
open(P, 'w', encoding='utf-8').write('''<!DOCTYPE html>
<html lang="es"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Simulador G-Code 3D — Por Eloi A.A.</title>
<script>location.replace('simulador3d.html' + location.search + location.hash);</script>
<style>body{font-family:'Segoe UI',Arial,sans-serif;margin:40px;color:#1c2733}</style></head>
<body><p>El Simulador del profesor ahora es el <a href="simulador3d.html">Simulador 3D</a>, el mismo para profesorado y alumnado (con el editor de G-code).</p></body></html>
''')
print('simulador3d.html: el simulador con editor, para todos · simulador3d_profesor.html: lleva al nuevo')
