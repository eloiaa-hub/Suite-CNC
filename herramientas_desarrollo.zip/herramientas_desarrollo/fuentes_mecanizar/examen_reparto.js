// ── 👥 Preparar el examen: repartir las variantes a la clase ──
// Desde 🎲 Variantes: la lista de alumnos (pegada, o el CSV de participantes / la hoja de calificaciones de Aules), el reparto
// (en el orden de la lista o al azar, y se puede cambiar a mano), las hojas con el nombre de cada alumno, las soluciones de
// cada variante y la lista del reparto. Las variantes se guardan en la biblioteca (Variantes/<ejercicio>) y el reparto queda
// guardado en el navegador: la corrección masiva lo usa para saber qué variante le tocaba a cada uno.
const REPARTO_CLAVE = 'calcador_repartos';
function repartosGuardados() { try { return JSON.parse(localStorage.getItem(REPARTO_CLAVE) || '{}') || {}; } catch (e) { return {}; } }
function guardarReparto(carpeta, rep) { const t = repartosGuardados(); t[carpeta] = rep; try { localStorage.setItem(REPARTO_CLAVE, JSON.stringify(t)); } catch (e) {} }
let repEx = { alumnos: [], modo: 'orden' };     // alumnos: [{ n, id, v }]  (v = letra de la variante)
// La lista de alumnos: un nombre por línea, o un CSV de Aules (participantes u hoja de calificaciones)
function alumnosDeTexto(txt) {
    const l1 = txt.split(/\r?\n/).find(l => l.trim()) || '';
    if (/[;,]/.test(l1) && /nombre|nom\b|apellido|cognom|identificador|first ?name|surname/i.test(l1)) {
        const h = leerCSVAules(txt), cab = h.filas[0].map(x => String(x).normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().trim());
        const b = re => cab.findIndex(x => re.test(x));
        const iCom = b(/^(nombre completo|nom complet|full ?name)$/), iNom = b(/^(nombre|nom|first ?name)$/), iApe = b(/^(apellidos?|apellido\(s\)|cognoms?|surname|last ?name)$/), iId = b(/^(identificador|identifier)$/);
        return h.filas.slice(1).map(f => ({ n: (iCom >= 0 ? f[iCom] : [iNom >= 0 ? f[iNom] : '', iApe >= 0 ? f[iApe] : ''].join(' ')).replace(/\s+/g, ' ').trim(), id: iId >= 0 ? ((/(\d+)/.exec(f[iId]) || [])[1] || '') : '' })).filter(a => a.n);
    }
    return txt.split(/\r?\n/).map(l => l.replace(/^\s*\d+[.)-]?\s+/, '').replace(/\t+/g, ' ').trim()).filter(Boolean).map(n => ({ n, id: '' }));
}
function repartirVariantes(alumnos, letras, modo) {
    const orden = alumnos.map((a, k) => k);
    if (modo === 'azar') for (let i = orden.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [orden[i], orden[j]] = [orden[j], orden[i]]; }
    orden.forEach((k, i) => { alumnos[k].v = letras[i % letras.length]; });
    return alumnos;
}
function carpetaVariantes() { return `Variantes/${nombreProyecto()}`; }
const etqVar = v => { const h = v.datos && v.datos.calcador && v.datos.calcador.cfgHoja; return (h && h.num) || v.letra; };
function abrirRepartoExamen() {
    if (!varGen.length) { snack('Primero, las variantes'); return; }
    const guardado = repartosGuardados()[carpetaVariantes()];
    if (guardado && !repEx.alumnos.length) repEx.alumnos = guardado.alumnos.map(a => ({ ...a }));
    let ov = document.getElementById('modalReparto');
    if (!ov) { ov = document.createElement('div'); ov.className = 'modal-overlay'; ov.id = 'modalReparto'; ov.onclick = e => { if (e.target === ov) ov.classList.remove('visible'); }; document.body.appendChild(ov); }
    ov.innerHTML = `<div class="help-modal" style="width:min(820px,100%)"><div class="help-header"><h2>👥 Preparar el examen: repartir las variantes</h2><button class="help-close" onclick="document.getElementById('modalReparto').classList.remove('visible')">✕</button></div>
        <div class="help-content rep-cuerpo">
        <div class="rep-izq">
            <div class="cr-req-t">La clase</div>
            <textarea id="repLista" rows="12" placeholder="Un alumno por línea (en el orden en que se sientan, si quieres que los de al lado tengan variantes distintas), o abre la lista de Aules"></textarea>
            <input type="file" id="repCSV" accept=".csv,.txt" style="display:none">
            <div class="btn-row"><button class="btn-action sec" id="repAbrir" title="El CSV de participantes del curso (Participantes → descargar) o la hoja de calificaciones de la tarea (con el número de participante, para casar después las entregas)">📂 Lista de Aules (CSV)…</button></div>
            <div class="cr-req-t" style="margin-top:8px">Reparto</div>
            <label class="aules-op"><input type="radio" name="repModo" value="orden" ${repEx.modo !== 'azar' ? 'checked' : ''}> En el orden de la lista (A, B, C… y vuelta a empezar)</label>
            <label class="aules-op"><input type="radio" name="repModo" value="azar" ${repEx.modo === 'azar' ? 'checked' : ''}> Al azar (las mismas veces cada variante)</label>
            <div class="btn-row" style="margin-top:6px"><button class="btn-action" id="repRepartir">🎲 Repartir</button></div>
            <p class="ctx-nota">Variantes: ${varGen.map(v => `<b>${etqVar(v)}</b> (${v.desc})`).join(' · ')}</p>
        </div>
        <div class="rep-der">
            <div id="repTabla"></div>
            <div class="btn-row rep-acc"><button class="btn-action" id="repHojas">🖨 Hojas con el nombre</button><button class="btn-action sec" id="repSol">📋 Soluciones de las variantes</button><button class="btn-action sec" id="repCSVbajar">⬇ Lista del reparto (CSV)</button></div>
            <p class="ctx-nota">Al imprimir, las variantes se guardan en la biblioteca (carpeta <i>${carpetaVariantes()}</i>) y el reparto queda guardado: en la corrección masiva, al elegir estas variantes, cada programa se corrige con la que le tocaba y avisa si ha hecho otra.</p>
        </div></div></div>`;
    const g = id => ov.querySelector('#' + id), letras = varGen.map(v => v.letra);
    g('repLista').value = repEx.alumnos.map(a => a.n).join('\n');
    const pintar = () => {
        const esc = t => String(t).replace(/&/g, '&amp;').replace(/</g, '&lt;');
        const cuenta = letras.map(l => repEx.alumnos.filter(a => a.v === l).length);
        g('repTabla').innerHTML = repEx.alumnos.length ? `<table class="par-tabla rep-tabla"><tr><th>#</th><th>Alumno/a</th><th>Variante</th></tr>${repEx.alumnos.map((a, k) => `<tr><td class="n">${k + 1}</td><td>${esc(a.n)}${a.id ? ` <small>(${a.id})</small>` : ''}</td><td><select data-k="${k}">${varGen.map(v => `<option value="${v.letra}" ${a.v === v.letra ? 'selected' : ''}>${esc(etqVar(v))}</option>`).join('')}</select></td></tr>`).join('')}</table>
            <p class="ctx-nota">${letras.map((l, i) => `${etqVar(varGen[i])}: ${cuenta[i]}`).join(' · ')}</p>` : '<p class="ctx-nota">Escribe o abre la lista de la clase y pulsa 🎲 Repartir.</p>';
        g('repTabla').querySelectorAll('select').forEach(s => s.onchange = () => { repEx.alumnos[+s.dataset.k].v = s.value; guardarRepartoActual(); pintar(); });
    };
    const leerLista = () => { const nuevos = alumnosDeTexto(g('repLista').value), prev = new Map(repEx.alumnos.map(a => [a.n, a]));
        repEx.alumnos = nuevos.map(a => ({ ...a, id: a.id || (prev.get(a.n) || {}).id || '', v: (prev.get(a.n) || {}).v })); };
    g('repAbrir').onclick = () => g('repCSV').click();
    g('repCSV').onchange = async ev => { const f = ev.target.files[0]; ev.target.value = ''; if (!f) return; repEx.alumnos = alumnosDeTexto(await f.text());
        g('repLista').value = repEx.alumnos.map(a => a.n).join('\n'); repartirVariantes(repEx.alumnos, letras, repEx.modo); guardarRepartoActual(); pintar();
        snack(`${repEx.alumnos.length} alumnos leídos de «${f.name}»${repEx.alumnos.some(a => a.id) ? ', con su número de participante' : ''}`); };
    ov.querySelectorAll('input[name="repModo"]').forEach(r => r.onchange = () => { repEx.modo = r.value; });
    g('repRepartir').onclick = () => { leerLista(); if (!repEx.alumnos.length) { snack('Escribe antes la lista de la clase'); return; } repartirVariantes(repEx.alumnos, letras, repEx.modo); guardarRepartoActual(); pintar(); };
    const listo = () => { leerLista(); if (!repEx.alumnos.length) { snack('Escribe antes la lista de la clase'); return false; } if (repEx.alumnos.some(a => !letras.includes(a.v))) repartirVariantes(repEx.alumnos.filter(a => !letras.includes(a.v)), letras, repEx.modo); guardarRepartoActual(); pintar(); return true; };
    g('repHojas').onclick = async () => { if (listo()) { await guardarVariantesExamen(); await imprimirHojasReparto(); } };
    g('repSol').onclick = async () => { if (listo()) { const ids = await guardarVariantesExamen(); cerrarVariantes(); ov.classList.remove('visible'); await imprimirLoteBib(ids, 'sol'); } };
    g('repCSVbajar').onclick = () => { if (!listo()) return; const c = t => '"' + String(t).replace(/"/g, '""') + '"';
        descargar('﻿' + [['Alumno', 'Variante', 'Identificador'], ...repEx.alumnos.map(a => [a.n, etqVar(varGen.find(v => v.letra === a.v)), a.id ? 'Participante ' + a.id : ''])].map(f => f.map(c).join(';')).join('\r\n'), `${nombreProyecto()} - reparto de variantes.csv`, 'text/csv;charset=utf-8'); };
    pintar(); ov.classList.add('visible');
}
function guardarRepartoActual() {
    guardarReparto(carpetaVariantes(), { fecha: new Date().toISOString(), titulo: cfgHoja.titulo || nombreProyecto(),
        alumnos: repEx.alumnos.map(a => ({ n: a.n, id: a.id || '', v: a.v, etq: (() => { const v = varGen.find(x => x.letra === a.v); return v ? etqVar(v) : ''; })() })) });
}
// Las variantes, a la biblioteca (como «📚 Guardar en la biblioteca»)
async function guardarVariantesExamen() {
    await bibCargar();
    const nombre = nombreProyecto(), ids = [];
    for (const v of varGen) { const ruta = `Variantes/${nombre}/${nombre} - ${v.letra}.json`; const e = entradaDe(v.datos, ruta, `${nombre} - ${v.letra}.json`); await bibGuardarEntrada(e); ids.push(e.id); }
    await bibCargar(); return ids;
}
// Las hojas: la de cada variante, una vez; después, una por alumno con su nombre en el cajetín
async function imprimirHojasReparto() {
    const htmlDe = new Map(), a = estadoGuardado(), sn = window.snack, op = window.open, color = !!cfgHoja.color;
    let capt = null; window.snack = () => {}; window.open = () => ({ document: { open() {}, write(h) { capt = (capt || '') + h; }, close() {} } });
    try { for (const v of varGen) { capt = null; (typeof _tuAbrirJSONDatos === 'function' ? _tuAbrirJSONDatos : abrirJSONDatos)(JSON.parse(JSON.stringify(v.datos))); cfgHoja.color = color; abrirHoja(); imprimirHoja(); cerrarHoja(); if (capt) htmlDe.set(v.letra, capt); } }
    catch (e) { console.warn(e); sn('Error al preparar las hojas: ' + e.message); }
    finally { window.snack = sn; window.open = op; restaurarEstado(a); refrescar(); }
    const esc = t => String(t).replace(/&/g, '&amp;').replace(/</g, '&lt;');
    const partes = repEx.alumnos.filter(x => htmlDe.has(x.v)).map(x => htmlDe.get(x.v)
        .replace('<span class="et">Alumno/a</span>&nbsp;', `<span class="et">Alumno/a</span><span class="v">${esc(x.n)}</span>`)
        .replace('<span>Alumno/a: ______________________</span>', `<span>Alumno/a: ${esc(x.n)}</span>`));
    if (!partes.length) { snack('No se ha podido generar ninguna hoja'); return; }
    let estilos = '', cuerpos = '';
    partes.forEach((h, k) => {
        const css = (h.match(/<style>([\s\S]*?)<\/style>/) || [])[1] || '', cuerpo = ((h.match(/<body>([\s\S]*)<\/body>/) || [])[1] || '').replace(/<script[\s\S]*?<\/script>/g, '');
        estilos += prefijarCSS(css, 'ej' + k, 'pag' + k);
        cuerpos += `<div class="ej${k}">${cuerpo}</div>\n`;
    });
    const html = `<!DOCTYPE html><html lang="es"><head><meta charset="UTF-8"><title>Examen ${esc(cfgHoja.titulo || nombreProyecto())}: hojas de ${partes.length} alumnos</title>
<style>body { margin: 0; } ${estilos}</style></head><body>${cuerpos}
<script>window.onload = () => setTimeout(() => window.print(), 300);<\/script></body></html>`;
    const w = window.open('', '_blank');
    if (!w) { snack('El navegador ha bloqueado la ventana de impresión: permite las ventanas emergentes para este archivo'); return; }
    w.document.open(); w.document.write(html); w.document.close();
    snack(`${partes.length} hojas, cada una con el nombre del alumno y su variante`);
}
// ── En la corrección masiva: la variante que le tocaba, según el reparto guardado ──
masiva.reparto = null;
function repartoParaVariantes(vs) {
    const T = repartosGuardados(), carpetas = new Set(vs.map(v => { const e = (bib.lista || []).find(x => x.id === v.id); return e ? e.ruta.split('/').slice(0, -1).join('/') : ''; }).filter(Boolean));
    for (const c of carpetas) if (T[c]) return { ...T[c], carpeta: c };
    // (variantes abiertas desde archivos: el reparto cuyas etiquetas coinciden)
    const etqs = new Set(vs.map(v => v.etq));
    return Object.entries(T).map(([c, r]) => ({ ...r, carpeta: c })).find(r => r.alumnos.length && r.alumnos.every(a => etqs.has(a.etq))) || null;
}
const _varianteAsignadaRep = varianteAsignada;
varianteAsignada = function (it) {
    const R = masiva.reparto;
    if (R && R.alumnos && R.alumnos.length) {
        const base = Object.keys(masiva.ids || {}).filter(n => it.alumno === n || it.alumno.startsWith(n + ' · ')).sort((a, b) => b.length - a.length)[0] || it.alumno.replace(/ · .*$/, '');
        const id = (masiva.ids || {})[base], nb = normNomAules(base);
        const a = (id && R.alumnos.find(x => x.id && x.id === id)) || R.alumnos.find(x => normNomAules(x.n) === nb)
            || R.alumnos.find(x => { const p = normNomAules(x.n).split(' '), q = nb.split(' '); return p.length >= 2 && q.length >= 2 && (p.every(w => q.includes(w)) || q.every(w => p.includes(w))); });
        if (a) { const v = masiva.variantes.find(x => x.etq === a.etq) || masiva.variantes.find(x => x.letra && x.letra === a.v); if (v) return v; }
    }
    return _varianteAsignadaRep(it);
};
// al elegir las variantes, se busca su reparto; y se puede abrir el CSV de un reparto
const _elegirVariantesMasivaRep = elegirVariantesMasiva;
elegirVariantesMasiva = async function () {
    await _elegirVariantesMasivaRep.apply(this, arguments);
    const ov = document.getElementById('modalVarMasiva'); if (!ov) return;
    const si = ov.querySelector('#varMasivaSi'), fila = si && si.parentNode; if (!fila) return;
    const nota = document.createElement('p'); nota.className = 'ctx-nota'; nota.id = 'varMasivaRep';
    const T = repartosGuardados(), conRep = [...ov.querySelectorAll('input[data-carpeta]')].map(c => c.dataset.carpeta).filter(c => T[c]);
    nota.textContent = conRep.length ? `👥 Con reparto guardado (la variante que le tocaba a cada alumno): ${conRep.map(c => `${c.replace(/^Variantes\//, '')} (${T[c].alumnos.length} alumnos)`).join(', ')}.`
        : 'Sin reparto guardado: la variante que le tocaba sale del nombre del archivo, de su carpeta o de un comentario («12B»), o abre la lista del reparto.';
    fila.parentNode.insertBefore(nota, fila);
    const inp = document.createElement('input'); inp.type = 'file'; inp.accept = '.csv'; inp.style.display = 'none';
    const b = document.createElement('button'); b.className = 'btn-action sec'; b.textContent = '📂 Reparto (CSV)…'; b.title = 'La lista del reparto de variantes (Alumno; Variante), la que descarga 👥 Preparar el examen';
    b.onclick = () => inp.click(); fila.insertBefore(b, si); fila.appendChild(inp);
    inp.onchange = async ev => { const f = ev.target.files[0]; ev.target.value = ''; if (!f) return;
        const h = leerCSVAules(await f.text()), cab = h.filas[0].map(x => String(x).toLowerCase()), iA = cab.findIndex(x => /alumn|nombre|nom/.test(x)), iV = cab.findIndex(x => /variant/.test(x)), iI = cab.findIndex(x => /identif/.test(x));
        if (iA < 0 || iV < 0) { snack('El CSV tiene que tener las columnas «Alumno» y «Variante»'); return; }
        masiva.repartoArchivo = { titulo: f.name.replace(/\.csv$/i, ''), alumnos: h.filas.slice(1).filter(x => x[iA]).map(x => ({ n: x[iA], etq: x[iV], v: (/([A-Z])$/i.exec(x[iV]) || [])[1] || '', id: iI >= 0 ? ((/(\d+)/.exec(x[iI]) || [])[1] || '') : '' })) };
        nota.textContent = `Reparto: ${masiva.repartoArchivo.titulo} (${masiva.repartoArchivo.alumnos.length} alumnos, del archivo)`; };
    const siOrig = si.onclick, no = ov.querySelector('#varMasivaNo'), noOrig = no.onclick;
    no.onclick = () => { masiva.reparto = null; noOrig(); };
    si.onclick = () => { const vsAntes = masiva.variantes; siOrig();
        if (masiva.variantes !== vsAntes || masiva.variantes.length) { masiva.reparto = masiva.repartoArchivo || repartoParaVariantes(masiva.variantes); masiva.repartoArchivo = null; if (masiva.reparto) recorregirMasiva(); } };
};
