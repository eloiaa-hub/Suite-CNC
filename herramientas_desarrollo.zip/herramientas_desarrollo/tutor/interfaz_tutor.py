#!/usr/bin/env python3
"""Tutor v5: las mejoras de la interfaz del Calcador (interfaz_paneles.py e interfaz_ordenada.py), adaptadas al Tutor.
 · Vista, arriba a la derecha del dibujo: ◧ ◨ (F7, F8) │ 👁 Rejilla · 🏷 Nombres · 📏 Cotas. Se recuerda en el navegador.
 · ↶ Deshacer, ↷ Rehacer, ⭘ Cerrar y ✓ Terminar, al pie de la barra de herramientas.
 · Pestaña Dibujo: «Cotas y marcas» (abierto) y «Ajustar medidas» (plegado), en desplegables.
 · 🖼 Fondo en la barra de arriba, junto a Abrir. «📍 Absolutas», con texto.
 · Al abrir un ejemplo o un ejercicio con el panel derecho oculto, el panel se vuelve a mostrar (ahí está el programa).
Uso: python3 interfaz_tutor.py <carpeta de la suite>   (justo después de construir_tutor.py)"""
import os, sys
P = os.path.join(sys.argv[1] if len(sys.argv) > 1 else '.', 'tutor.html')
s = open(P, encoding='utf-8').read()
def rep(a, b, cnt=1):
    global s
    n = s.count(a); assert n == cnt, f'{n} apariciones (se esperaban {cnt}) de: {a[:100]}'
    s = s.replace(a, b)
rep("""            <div class="zoom-controls">
                <div class="zoom-btn" onclick="zoomBoton(1.25)" title="Acercar">+</div>""",
    """            <div class="vista-controls">
                <div class="zoom-btn btn-vista" id="btnPanelIzq" onclick="alternarPanel('izq')">◧</div>
                <div class="zoom-btn btn-vista" id="btnPanelDer" onclick="alternarPanel('der')">◨</div>
                <span class="vsep"></span>
                <div class="zoom-btn btn-vista" id="btnVerRejilla" onclick="alternarVerRejilla()">👁 Rejilla</div>
                <div class="zoom-btn btn-vista" id="btnVerNombres" onclick="alternarCasillaVista('tuNombres')">🏷 Nombres</div>
                <div class="zoom-btn btn-vista" id="btnVerCotas" onclick="alternarCasillaVista('chkCotas')">📏 Cotas</div>
            </div>
            <div class="zoom-controls">
                <div class="zoom-btn" onclick="zoomBoton(1.25)" title="Acercar">+</div>""")
rep('</style>\n</head>', """
    /* ═══ Tutor v5: la interfaz del Calcador ═══ */
    .vista-controls { position: absolute; top: 10px; right: 12px; display: flex; gap: 4px; z-index: 5; }
    .vista-controls .vsep { width: 8px; }
    .btn-vista.oculto { background: var(--accent-light); color: var(--accent); border-color: var(--accent); }
    #btnVerRejilla.visible, #btnVerNombres.visible, #btnVerCotas.visible { background: var(--accent); color: #fff; border-color: var(--accent); }
    html.sin-izq .action-panel, html.sin-der .tutor-panel { display: none !important; }
    .tool-strip .tool-acc { border: none; background: transparent; color: var(--text-main); border-radius: 5px; font-size: 16px; padding: 0; cursor: pointer; }
    .tool-strip .tool-acc:hover:not(:disabled) { background: var(--accent-light); color: var(--accent); }
    .tool-strip .tool-acc:disabled { opacity: .3; cursor: default; }
    .c2-cotas > .param-line, .c2-ajuste > .param-line { margin-top: 5px; }
    .c2-cotas > button, .c2-ajuste > button { margin-top: 7px; width: 100%; }
    html.tu-es-ejercicio #btnFondoArriba, html.tu-es-ejercicio .tool-strip .tool-acc { display: none !important; }
</style>
</head>""")
rep("document.querySelectorAll('#toolStrip .tool-btn').forEach(b => { b.style.display = (b.dataset.h === 'texto'", "document.querySelectorAll('#toolStrip .tool-btn:not(.tool-acc)').forEach(b => { b.style.display = (b.dataset.h === 'texto'")
rep('<input id="tuAbs" type="checkbox"> 📍</label>', '<input id="tuAbs" type="checkbox"> 📍 Absolutas</label>')
rep("    dibujarRejilla();\n    if (fondo) dibujarFondo(V);", "    if (verRejilla) dibujarRejilla();\n    if (fondo) dibujarFondo(V);")
VISTA = r"""
// ── Vista: ocultar los paneles (la barra de herramientas siempre se ve), la rejilla, los nombres y las cotas ──
const VISTA_CLAVE = 'tutor_vista';
var verRejilla = true;
function guardarVista() { const h = document.documentElement.classList; try { localStorage.setItem(VISTA_CLAVE, JSON.stringify({ izq: h.contains('sin-izq'), der: h.contains('sin-der'), rejilla: verRejilla })); } catch (e) {} }
function pintarBotonesVista() {
    const h = document.documentElement.classList, $ = id => document.getElementById(id);
    const panel = (id, cls, nom, tecla) => { const e = $(id); if (!e) return; const o = h.contains(cls); e.classList.toggle('oculto', o); e.title = (o ? 'Mostrar el panel ' + nom : 'Ocultar el panel ' + nom + ' para ver más grande el dibujo') + ' · tecla ' + tecla; };
    panel('btnPanelIzq', 'sin-izq', 'izquierdo (opciones)', 'F7');
    panel('btnPanelDer', 'sin-der', 'derecho (programa)', 'F8');
    const vista = (id, on, tOn, tOff) => { const e = $(id); if (e) { e.classList.toggle('visible', on); e.title = on ? tOn : tOff; } };
    vista('btnVerRejilla', verRejilla, 'Ocultar la rejilla del dibujo (el imán a la rejilla es el botón ▦ Rejilla)', 'Ver la rejilla del dibujo (el imán a la rejilla es el botón ▦ Rejilla)');
    const c = id => { const e = $(id); return !!(e && e.checked); };
    vista('btnVerNombres', c('tuNombres'), 'Ocultar los nombres de los puntos (P1, P2… A1…)', 'Ver los nombres de los puntos (P1, P2… A1…)');
    vista('btnVerCotas', c('chkCotas'), 'Ocultar las cotas automáticas («Acotar automáticamente»)', 'Ver las cotas automáticas («Acotar automáticamente»)');
}
function alternarPanel(cual, forzar) {
    const cls = cual === 'izq' ? 'sin-izq' : 'sin-der', h = document.documentElement.classList;
    const ocultar = forzar === undefined ? !h.contains(cls) : !!forzar;
    if (ocultar === h.contains(cls)) return;
    h.toggle(cls, ocultar);
    try { redimensionar(); } catch (e) {}
    // con más (o menos) sitio, el dibujo se encuadra para llenar la zona
    try { if (contornos.some(c => c.pts.length >= 2)) encuadrar(); else render(); } catch (e) {}
    pintarBotonesVista(); guardarVista();
}
function alternarVerRejilla(forzar) {
    verRejilla = forzar === undefined ? !verRejilla : !!forzar;
    pintarBotonesVista(); guardarVista(); try { render(); } catch (e) {}
}
function alternarCasillaVista(id) { const c = document.getElementById(id); if (c) c.click(); pintarBotonesVista(); }
(function () {
    try { const v = JSON.parse(localStorage.getItem(VISTA_CLAVE) || '{}'); if (v && typeof v === 'object') {
        if (v.izq) document.documentElement.classList.add('sin-izq'); if (v.der) document.documentElement.classList.add('sin-der'); if (v.rejilla === false) verRejilla = false; } } catch (e) {}
    document.addEventListener('keydown', e => {
        if (e.key !== 'F7' && e.key !== 'F8') return;
        if (document.querySelector('.modal-overlay.visible')) return;
        e.preventDefault(); alternarPanel(e.key === 'F7' ? 'izq' : 'der');
    });
})();
"""
rep("function dibujarRejilla() {", VISTA.lstrip('\n') + "function dibujarRejilla() {")
ORDEN = r"""
// ═══ Tutor v5: la interfaz del Calcador, una vez montadas las pestañas ═══
window.addEventListener('load', () => setTimeout(() => {
    const $ = id => document.getElementById(id);
    // Deshacer, Rehacer, Cerrar y Terminar, al pie de la barra de herramientas
    const st = $('toolStrip'), dibP = $('c2PaneDib');
    if (st && dibP) {
        const div = document.createElement('div'); div.className = 'tool-divider'; st.appendChild(div);
        const mover = (el, ico, tip) => { if (!el) return; el.className = 'tool-btn tool-acc'; el.textContent = ico; el.title = tip; el.dataset.tip = tip; st.appendChild(el); };
        mover(dibP.querySelector('button[onclick="deshacer()"]'), '↶', 'Deshacer (Ctrl+Z)');
        mover(dibP.querySelector('button[onclick="rehacer()"]'), '↷', 'Rehacer (Ctrl+Y)');
        mover($('btnCerrar'), '⭘', 'Cerrar: une el último punto con el primero');
        mover($('btnTerminar'), '✓', 'Terminar: deja el contorno abierto (Esc)');
        dibP.querySelectorAll(':scope > .btn-row').forEach(r => { if (!r.children.length) r.remove(); });
    }
    // Dibujo: «Cotas y marcas» y «Ajustar medidas» en desplegables
    if (dibP) {
        const det = (cls, titulo) => { const d = document.createElement('details'); d.className = 'c2-opciones ' + cls; d.innerHTML = '<summary>' + titulo + '</summary>'; return d; };
        const cotas = det('c2-cotas', 'Cotas y marcas'), linea = id => { const e = $(id); return e && e.closest('.param-line'); };
        ['chkCotas', 'selNivelCotas', 'selIncl', 'chkCero', 'chkEntrada', 'chkSentido', 'chkCentros', 'chkCadena', 'chkVerOcultas'].forEach(id => { const l = linea(id); if (l) cotas.appendChild(l); });
        const rest = dibP.querySelector('button[onclick="restaurarCotas()"]'); if (rest) cotas.appendChild(rest);
        const aj = dibP.querySelector('.ajuste-box'), ajuste = det('c2-ajuste', 'Ajustar medidas');
        if (aj) { [...aj.children].forEach(ch => ajuste.appendChild(ch)); aj.remove(); }
        cotas.open = true;
        dibP.appendChild(cotas); dibP.appendChild(ajuste);
    }
    // 🖼 Fondo en la barra de arriba, junto a Abrir; al cargarlo, se enseñan sus ajustes
    const barra = document.querySelector('.c2-archivo'), ff = $('fileFondo');
    if (barra && ff) {
        const bAbrir = [...barra.children].find(b => /Abrir/.test(b.textContent));
        const bf = document.createElement('button'); bf.className = 'btn-manual'; bf.id = 'btnFondoArriba'; bf.textContent = '🖼 Fondo';
        bf.title = 'Carga una foto o imagen del plano (PNG, JPG) para calcarlo. Sus ajustes están en el apartado Fondo del panel izquierdo';
        bf.onclick = () => ff.click();
        if (bAbrir) bAbrir.after(bf);
        ff.addEventListener('change', () => setTimeout(() => {
            alternarPanel('izq', false);
            const pf = $('c2PaneFondo'); if (pf) pf.scrollIntoView({ block: 'nearest', behavior: 'smooth' }); }, 300));
    }
    // Las casillas de siempre siguen y van a la par con los botones (también al abrir un ejercicio)
    ['tuNombres', 'chkCotas'].forEach(id => { const c = $(id); if (c) c.addEventListener('change', pintarBotonesVista); });
    pintarBotonesVista(); setInterval(pintarBotonesVista, 600);
    // Al abrir un ejemplo o un ejercicio, el programa tiene que verse
    if (typeof tuCargarEjemplo === 'function') { const o = tuCargarEjemplo; tuCargarEjemplo = function () { const r = o.apply(this, arguments); alternarPanel('der', false); return r; }; }
    if (TU.ejercicio) alternarPanel('der', false);
}, 60));
"""
i = s.rindex('</body>'); s = s[:i] + '<script>' + ORDEN + '</script>\n' + s[i:]
rep("<h3>Imán a la rejilla</h3>", """<h3>Más sitio para dibujar</h3>
            <p>Arriba a la derecha del dibujo: <strong>◧</strong> oculta o muestra el panel izquierdo (tecla <span class="kbd">F7</span>) y <strong>◨</strong> el derecho (tecla <span class="kbd">F8</span>). <strong>👁 Rejilla</strong>, <strong>🏷 Nombres</strong> y <strong>📏 Cotas</strong> enseñan u ocultan la rejilla, los nombres de los puntos y las cotas automáticas. La barra de herramientas se ve siempre, con ↶ ↷ (deshacer, rehacer) y ⭘ ✓ (cerrar, terminar) al pie.</p>
            <h3>Imán a la rejilla</h3>""", cnt=s.count("<h3>Imán a la rejilla</h3>"))
if s.count('<tr><td><span class="kbd">G</span></td><td>Imán a la rejilla: activar o desactivar.</td></tr>') == 1:
    rep('<tr><td><span class="kbd">G</span></td><td>Imán a la rejilla: activar o desactivar.</td></tr>', '<tr><td><span class="kbd">G</span></td><td>Imán a la rejilla: activar o desactivar.</td></tr>\n                <tr><td><span class="kbd">F7</span> · <span class="kbd">F8</span></td><td>Ocultar o mostrar el panel izquierdo · el derecho.</td></tr>')
open(P, 'w', encoding='utf-8').write(s)
print('Tutor: ocultar los paneles y la interfaz del Calcador')
