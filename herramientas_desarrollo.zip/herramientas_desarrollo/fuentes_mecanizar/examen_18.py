#!/usr/bin/env python3
"""Calcador v121: 🎲 Variantes hasta 26 (antes, 8), para que cada alumno de la clase tenga la suya, y ◠ Examen de I J…, que abre
Arcos I J con su ventana de examen para Aules. Uso: python3 examen_18.py CARPETA_DE_LA_SUITE (después de hoja_ij.py)."""
import os, re, sys
d = sys.argv[1] if len(sys.argv) > 1 else '.'
p = os.path.join(d, 'calcador.html'); s = open(p, encoding='utf-8').read()
def rep(a, b):
    global s
    assert s.count(a) == 1, (s.count(a), a[:80]); s = s.replace(a, b)
rep('id="varN" min="2" max="8"', 'id="varN" min="2" max="26"')
rep("Object.assign(varCfg, { n: Math.max(2, Math.min(8, +g('varN').value || 4))", "Object.assign(varCfg, { n: Math.max(2, Math.min(26, +g('varN').value || 4))")
b = '<button class="btn-action sec" onclick="abrirHojaIJ()"'
i = s.index(b); j = s.index('</button>', i) + len('</button>')
s = s[:j] + '''\n                    <button class="btn-action sec" onclick="window.open('arcos_ij.html#profesor', '_blank')" title="Abre Arcos I J con la ventana para preparar un examen que Aules corrige solo">◠ Examen de I J…</button>''' + s[j:]
# Con la clase entera: quien tiene variante asignada y la ha hecho bien no se corrige con todas (con 18 alumnos y 20 variantes, son 360 correcciones)
rep("""    const res = new Map(items.map(it => [it, []]));
    masiva.variantes.forEach(v => conVariante(v, () => items.forEach(it => {
        let r; try { r = corregirPrograma(it.texto); } catch (e) { r = { error: 'No se ha podido interpretar: ' + e.message }; }
        res.get(it).push({ v, r, val: valorarCorreccion(r) });
    })));""", """    const res = new Map(items.map(it => [it, []])), asignada = new Map(items.map(it => [it, varianteAsignada(it)]));
    const corrige = (v, lista) => { if (lista.length) conVariante(v, () => lista.forEach(it => {
        let r; try { r = corregirPrograma(it.texto); } catch (e) { r = { error: 'No se ha podido interpretar: ' + e.message }; }
        res.get(it).push({ v, r, val: valorarCorreccion(r) });
    })); };
    masiva.variantes.forEach(v => corrige(v, items.filter(it => asignada.get(it) === v)));
    const hecho = it => asignada.get(it) && res.get(it)[0] && res.get(it)[0].val.veredicto === 'bien';
    masiva.variantes.forEach(v => corrige(v, items.filter(it => !hecho(it) && asignada.get(it) !== v)));""")
rep("""if (!tempVariantes) tempVariantes = setTimeout(() => { tempVariantes = null; const l = [...colaVariantes]; colaVariantes.clear(); corregirConVariantes(l); corr = null; pintarMasiva(); }, 0);""",
    """if (!tempVariantes) { const av = document.getElementById('masivaAviso') || document.body.appendChild(Object.assign(document.createElement('div'), { id:'masivaAviso', textContent:'Corrigiendo con las variantes… puede tardar un poco' })); av.style.cssText = 'position:fixed;left:50%;top:18px;transform:translateX(-50%);z-index:99999;padding:10px 18px;border-radius:8px;background:rgba(20,30,45,.92);color:#fff;font:600 15px Segoe UI,Arial,sans-serif;pointer-events:none';
        tempVariantes = setTimeout(() => { tempVariantes = null; const l = [...colaVariantes]; colaVariantes.clear(); try { corregirConVariantes(l); } finally { const q = document.getElementById('masivaAviso'); if (q) q.remove(); } corr = null; pintarMasiva(); }, 60); }""")
rep("clearTimeout(tempVariantes); tempVariantes = null; colaVariantes.clear();", "clearTimeout(tempVariantes); tempVariantes = null; colaVariantes.clear(); { const q = document.getElementById('masivaAviso'); if (q) q.remove(); }")
m = re.search(r'vertical-align:middle">v(\d+)</span></span>', s); assert m
s = s.replace(m.group(0), m.group(0).replace('v' + m.group(1), 'v121'), 1)
open(p, 'w', encoding='utf-8').write(s); print('calcador.html: hasta 26 variantes y ◠ Examen de I J, v121')
