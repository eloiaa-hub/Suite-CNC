"""Construye cabecera_programa.html (apuntes «La cabecera del programa») en la carpeta de la suite.
Uso (desde esta carpeta): python3 construir.py ../../..   (hace antes los dibujos con diagramas.py)
y el PDF: SOLO=cabecera_programa node herramientas_desarrollo/generar_pdf_manuales.js .   (desde la carpeta de la suite)"""
import sys, os, re, subprocess
AQUI = os.path.dirname(os.path.abspath(__file__)); D = os.path.abspath(sys.argv[1] if len(sys.argv) > 1 else os.path.join(AQUI, '../../..'))
subprocess.run([sys.executable, os.path.join(AQUI, 'diagramas.py')], check=True)     # los dibujos (fresadora de mano, G90/G91, G40 y la F)
s = open(os.path.join(AQUI, 'fuente_cabecera.html'), encoding='utf-8').read()
def svg(m):
    t = open(os.path.join(AQUI, 'diagramas', m.group(1) + '.svg'), encoding='utf-8').read()
    return re.sub(r'style="width:[^"]*"', f'style="width:{m.group(2)}"', t, count=1) if m.group(2) else t
s = re.sub(r'\{\{svg:([a-z0-9_]+)(?:\|([0-9]+%))?\}\}', svg, s)
tmp = os.path.join(AQUI, '_fuente_con_dibujos.html'); open(tmp, 'w', encoding='utf-8').write(s)
try:
    subprocess.run([sys.executable, os.path.join(AQUI, '..', 'anidador_calculadora', 'construir_manual.py'), tmp, AQUI,
                    os.path.join(D, 'cabecera_programa.html'), 'La cabecera del programa — Apuntes para el alumnado', os.path.join(D, 'manual_corrector.html')], check=True)
finally: os.remove(tmp)
