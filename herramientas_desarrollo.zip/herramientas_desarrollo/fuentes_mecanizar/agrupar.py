"""Calcador: agrupar contornos (Ctrl+G / Ctrl+Mayús+G) y mover la selección con las flechas.
- Un grupo se selecciona entero con un clic en cualquiera de sus contornos (o con el recuadro), y así se mueve, gira,
  escala, copia o borra junto. Alt + clic selecciona un solo contorno del grupo (para su mecanizado, por ejemplo).
  Se guarda en el JSON (c.grupo); las copias (pegar, matrices, copias de las transformaciones) son grupos nuevos.
- Flechas: mueven la selección 1 mm (Mayús: 10 mm; Ctrl: 0,1 mm). Sin nada seleccionado, siguen recorriendo la pieza.
  Esc quita la selección.
Uso: python3 agrupar.py <carpeta de la suite>
"""
import sys, os
P = os.path.join(sys.argv[1] if len(sys.argv) > 1 else '.', 'calcador.html')
s = open(P, encoding='utf-8').read()
def rep(a, b, cnt=1):
    global s
    n = s.count(a); assert n == cnt, f'{n} apariciones (se esperaban {cnt}) de: {a[:100]}'
    s = s.replace(a, b)

# ── datos: el grupo viaja con el contorno
rep("""        if (typeof c.uid === 'string') n.uid = c.uid;
        if (esObj(c.forma)""", """        if (typeof c.uid === 'string') n.uid = c.uid;
        if (typeof c.grupo === 'string' && c.grupo.length < 80) n.grupo = c.grupo;
        if (esObj(c.forma)""")
rep("""    if (c.deTexto) n.deTexto = JSON.parse(JSON.stringify(c.deTexto));
    return n;
}""", """    if (c.deTexto) n.deTexto = JSON.parse(JSON.stringify(c.deTexto));
    if (c.grupo) n.grupo = c.grupo;
    return n;
}""")
# copias de las transformaciones (matrices, «hacer copia»): cada copia de un grupo es un grupo nuevo
rep("""        const nuevosIds = {};   // cada copia de un texto es un texto nuevo
        ids.forEach(i => { const n = clonarTransf(contornos[i], fn, espejo);
            if (n.texto) {""", """        const nuevosIds = {}, nuevosGr = {};   // cada copia de un texto (o de un grupo) es un texto (o grupo) nuevo
        ids.forEach(i => { const n = clonarTransf(contornos[i], fn, espejo);
            if (n.grupo) { const v = n.grupo; n.grupo = nuevosGr[v] || (nuevosGr[v] = nuevoGrupo()); }
            if (n.texto) {""")
# pegar: grupos nuevos
rep("""    const mUid = {}, mTxt = {}, mDt = {};""", """    const mUid = {}, mTxt = {}, mDt = {}, mGr = {};""")
rep("""        if (c.deTexto) { const v = c.deTexto.id; c.deTexto.id = mDt[v] || (mDt[v] = nuevoId('d')); }
    });""", """        if (c.deTexto) { const v = c.deTexto.id; c.deTexto.id = mDt[v] || (mDt[v] = nuevoId('d')); }
        if (c.grupo) { const v = c.grupo; c.grupo = mGr[v] || (mGr[v] = nuevoGrupo()); }
    });""")

# ── selección: un contorno de un grupo selecciona el grupo entero (Alt + clic: solo ese)
rep("""function expandirTextos() { [...selSet].forEach(i => { const c = contornos[i]; if (c && c.texto) idsTexto(c.texto.id).forEach(j => selSet.add(j)); }); }
function seleccionarUno(ci) { sel = ci; selSet = new Set(ci >= 0 ? [ci] : []); expandirTextos(); }""",
"""// (y los de un grupo, con todo el grupo; al seleccionar un solo contorno de un grupo con Alt + clic, no)
let selSuelta = false;
function expandirTextos() {
    [...selSet].forEach(i => { const c = contornos[i]; if (c && c.texto) idsTexto(c.texto.id).forEach(j => selSet.add(j)); });
    if (!selSuelta) [...selSet].forEach(i => { const c = contornos[i]; if (c && c.grupo) idsGrupo(c.grupo).forEach(j => { selSet.add(j); const d = contornos[j]; if (d && d.texto) idsTexto(d.texto.id).forEach(k => selSet.add(k)); }); });
}
function seleccionarUno(ci) { sel = ci; selSet = new Set(ci >= 0 ? [ci] : []); expandirTextos(); }
// ── Grupos ──
let contadorGrupo = 0;
const nuevoGrupo = () => 'g' + Date.now().toString(36) + (contadorGrupo++).toString(36) + Math.random().toString(36).slice(2, 5);
const idsGrupo = g => contornos.map((c, i) => c.grupo === g ? i : -1).filter(i => i >= 0);
function gruposDe(ids) { return [...new Set(ids.map(i => contornos[i] && contornos[i].grupo).filter(Boolean))]; }
function seleccionarSuelto(ci) { selSuelta = true; try { seleccionarUno(ci); } finally { selSuelta = false; } }
function agruparSeleccion() {
    const ids = seleccionados();
    if (ids.length < 2) { snack('Selecciona antes dos o más contornos (Mayús + clic o un recuadro) para agruparlos'); return; }
    guardarUndo();
    const g = nuevoGrupo(); ids.forEach(i => { contornos[i].grupo = g; });
    seleccionarVarios(ids, false); refrescar();
    snack(`Agrupados ${ids.length} contornos: un clic en cualquiera los selecciona todos (Alt + clic, uno solo) · Ctrl+Mayús+G desagrupa`);
}
function desagruparSeleccion() {
    const ids = seleccionados(), gs = gruposDe(ids);
    if (!gs.length) { snack('Lo seleccionado no está agrupado'); return; }
    guardarUndo();
    contornos.forEach(c => { if (gs.includes(c.grupo)) delete c.grupo; });
    refrescar();
    snack(`${gs.length === 1 ? 'Grupo deshecho' : gs.length + ' grupos deshechos'}: los contornos vuelven a seleccionarse por separado`);
}
// ── Mover la selección con las flechas (1 mm; Mayús: 10 mm; Ctrl: 0,1 mm) ──
let ultimoEmpujon = { t:0, clave:'' };
function empujarSeleccion(dx, dy) {
    const ids = seleccionados(); if (!ids.length) return false;
    const clave = ids.slice().sort((a, b) => a - b).join(',');
    // varias pulsaciones seguidas se deshacen de una vez
    if (Date.now() - ultimoEmpujon.t > 1500 || ultimoEmpujon.clave !== clave) guardarUndo();
    ultimoEmpujon = { t:Date.now(), clave };
    const d = { x:dx, y:dy };
    ids.forEach(i => { const c = contornos[i]; c.pts = c.pts.map(q => add(q, d));
        if (c.mec && c.mec.puentes && Array.isArray(c.mec.puentes.pts)) c.mec.puentes.pts = c.mec.puentes.pts.map(q => add(q, d));
        if (c.texto && c.texto.receta && c.texto.receta.pos) c.texto.receta.pos = add(c.texto.receta.pos, d); });
    refrescar();
    const bb = bboxSeleccion(ids);
    document.getElementById('stSnap').textContent = `Movido ΔX ${fmt(dx, 2)} ΔY ${fmt(dy, 2)} · esquina X${fmt(bb.x0, 2)} Y${fmt(bb.y0, 2)}`;
    return true;
}""")
rep("""function alternarSel(ci) {
    selSet = new Set(seleccionados());
    const grupo = contornos[ci] && contornos[ci].texto ? idsTexto(contornos[ci].texto.id) : [ci];""",
"""function alternarSel(ci) {
    selSet = new Set(seleccionados());
    const c0 = contornos[ci];
    let grupo = c0 && c0.grupo ? idsGrupo(c0.grupo) : c0 && c0.texto ? idsTexto(c0.texto.id) : [ci];
    grupo = [...new Set(grupo.flatMap(j => contornos[j] && contornos[j].texto ? idsTexto(contornos[j].texto.id) : [j]))];""")
# clic con Alt: solo ese contorno
rep("""            else seleccionarUno(h.ci);
            refrescar();
        }
    }
    actualizarEstado();""", """            else if (e.altKey) seleccionarSuelto(h.ci);
            else seleccionarUno(h.ci);
            refrescar();
        }
    }
    actualizarEstado();""")
# arrastrar un contorno de un grupo (sin seleccionar antes): se lleva el grupo
rep("""            if (h.tipo === 'vertice') { guardarUndo(); seleccionarUno(h.ci);""", """            if (h.tipo === 'vertice') { guardarUndo(); if (!esSel(h.ci)) seleccionarUno(h.ci);""")

# ── panel de la selección múltiple: agrupar / desagrupar
rep("""        <div class="ctx-nota">Mayús o Ctrl + clic añade o quita · arrastra en vacío para seleccionar con recuadro</div>
        <button class="btn-action danger" id="pDelMulti">✕ Borrar selección</button>""",
"""        <div class="ctx-nota">Mayús o Ctrl + clic añade o quita · arrastra en vacío para seleccionar con recuadro · flechas: mover 1 mm (Mayús: 10 mm; Ctrl: 0,1 mm)</div>
        ${(gs => gs.length === 1 && ids.every(i => contornos[i].grupo === gs[0] || contornos[i].texto) ? `<div class="ctx-nota">🔗 <strong>Grupo</strong> de ${idsGrupo(gs[0]).length} contornos: se seleccionan, mueven y copian juntos (Alt + clic: uno solo)</div>` : gs.length ? `<div class="ctx-nota">🔗 Incluye ${gs.length} grupo${gs.length === 1 ? '' : 's'}</div>` : '')(gruposDe(ids))}
        <div class="btn-row">
            <button class="btn-action sec" id="pAgrupar" title="Une los contornos seleccionados en un grupo: un clic en cualquiera de ellos los selecciona todos (Ctrl+G)">🔗 Agrupar</button>
            ${gruposDe(ids).length ? `<button class="btn-action sec" id="pDesagrupar" title="Deshace los grupos de la selección (Ctrl+Mayús+G)">⛓ Desagrupar</button>` : ''}
        </div>
        <button class="btn-action danger" id="pDelMulti">✕ Borrar selección</button>""")
rep("""        document.getElementById('pDelMulti').onclick = borrarSeleccion;""",
    """        document.getElementById('pDelMulti').onclick = borrarSeleccion;
        document.getElementById('pAgrupar').onclick = agruparSeleccion;
        { const b = document.getElementById('pDesagrupar'); if (b) b.onclick = desagruparSeleccion; }""")

# ── teclado: Ctrl+G, Ctrl+Mayús+G, flechas y Esc
rep("""    if (!e.ctrlKey && !e.metaKey && !e.altKey && ['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown'].includes(e.key)) {
        e.preventDefault();""", """    // flechas con algo seleccionado (herramienta Editar): mover la selección
    if (!VISOR && !e.altKey && herramienta === 'editar' && !dib && !trf && seleccionados().length && ['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown'].includes(e.key)) {
        e.preventDefault();
        const paso = e.shiftKey ? 10 : (e.ctrlKey || e.metaKey) ? 0.1 : 1;
        empujarSeleccion(e.key === 'ArrowLeft' ? -paso : e.key === 'ArrowRight' ? paso : 0, e.key === 'ArrowDown' ? -paso : e.key === 'ArrowUp' ? paso : 0);
        return;
    }
    if (!e.ctrlKey && !e.metaKey && !e.altKey && ['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown'].includes(e.key)) {
        e.preventDefault();""")
rep("""    if ((e.ctrlKey || e.metaKey) && (k === 'c' || k === 'x') && !dib) {""",
    """    if ((e.ctrlKey || e.metaKey) && k === 'g') { e.preventDefault(); if (!dib) { if (herramienta !== 'editar') setHerramienta('editar'); e.shiftKey ? desagruparSeleccion() : agruparSeleccion(); } return; }
    if ((e.ctrlKey || e.metaKey) && (k === 'c' || k === 'x') && !dib) {""")
rep("""    if (e.key === 'Escape') { cerrarCtx(); if (dib || circ || ran || auxPend || formaPend || cotaPend) terminarDibujo(); else { medida = null; cal = null; render(); } actualizarEstado(); return; }""",
    """    if (e.key === 'Escape') { cerrarCtx(); if (dib || circ || ran || auxPend || formaPend || cotaPend) terminarDibujo(); else { medida = null; cal = null; if (herramienta === 'editar' && seleccionados().length) { seleccionarUno(-1); refrescar(); } render(); } actualizarEstado(); return; }""")

# ── dibujo: un marco discontinuo alrededor de cada grupo seleccionado
rep("""    dibujarCotas();
    dibujarPrevia(V);""", """    dibujarCotas();
    dibujarGruposSel();
    dibujarPrevia(V);""")
rep("""function dibujarRejilla() {""", """function dibujarGruposSel() {
    if (VISOR || typeof gruposDe !== 'function') return;
    const gs = gruposDe(seleccionados()); if (!gs.length) return;
    ctx.save(); ctx.strokeStyle = colores.acento; ctx.lineWidth = 1; ctx.setLineDash([6, 4]); ctx.globalAlpha = 0.8;
    gs.forEach(g => { const ids = idsGrupo(g); if (!ids.length) return; const bb = bboxSeleccion(ids), a = aPantalla({ x:bb.x0, y:bb.y1 }), b = aPantalla({ x:bb.x1, y:bb.y0 });
        ctx.strokeRect(a.x - 6.5, a.y - 6.5, b.x - a.x + 13, b.y - a.y + 13);
        ctx.setLineDash([]); ctx.font = '11px system-ui, sans-serif'; const tw = ctx.measureText('🔗 grupo').width; ctx.fillStyle = colores.fondo || '#fff'; ctx.fillRect(b.x + 6.5 - tw - 6, a.y - 6.5 - 16, tw + 6, 15); ctx.fillStyle = colores.acento; ctx.fillText('🔗 grupo', b.x + 6.5 - tw - 3, a.y - 6.5 - 4); ctx.setLineDash([6, 4]); });
    ctx.restore();
}
function dibujarRejilla() {""")

# ── ayuda (❓)
rep("""            <p><strong>📝 Cuestionario para Aules</strong>""", """            <p><strong>🔗 Agrupar</strong> (Editar): selecciona varios contornos (Mayús + clic o un recuadro) y pulsa <kbd>Ctrl</kbd>+<kbd>G</kbd> o <em>🔗 Agrupar</em> en el panel. Desde entonces, un clic en cualquiera de ellos selecciona el grupo entero, que se mueve, gira, escala, copia o borra junto; <kbd>Alt</kbd> + clic selecciona un solo contorno del grupo (por ejemplo, para cambiar su mecanizado). <kbd>Ctrl</kbd>+<kbd>Mayús</kbd>+<kbd>G</kbd> o <em>⛓ Desagrupar</em> lo deshace. Los grupos se guardan en el JSON, y cada copia de un grupo es un grupo nuevo.</p>
            <p><strong>Mover con las flechas</strong> (Editar): con algo seleccionado, las flechas lo mueven 1 mm (<kbd>Mayús</kbd>: 10 mm; <kbd>Ctrl</kbd>: 0,1 mm); varias pulsaciones seguidas se deshacen de una vez. Sin nada seleccionado, siguen recorriendo la pieza bloque a bloque. <kbd>Esc</kbd> quita la selección.</p>
            <p><strong>📝 Cuestionario para Aules</strong>""")

# Alt + clic sobre un contorno de la selección (sin arrastrar): se queda solo ese
rep("""                arrastre = { tipo:'contorno', ci:h.ci, ids, ini:p,""", """                arrastre = { tipo:'contorno', ci:h.ci, alt:e.altKey, ids, ini:p,""")
rep("""    else if (a.tipo === 'vertice' || a.tipo === 'manija' || a.tipo === 'contorno') {
        if (!a.movido) undoStack.pop();""", """    else if (a.tipo === 'vertice' || a.tipo === 'manija' || a.tipo === 'contorno') {
        if (!a.movido) { undoStack.pop(); if (a.tipo === 'contorno') { if (a.alt) seleccionarSuelto(a.ci); else seleccionarUno(a.ci); } }""")
open(P, 'w', encoding='utf-8').write(s)
print('Calcador: grupos y mover con las flechas:', P)
