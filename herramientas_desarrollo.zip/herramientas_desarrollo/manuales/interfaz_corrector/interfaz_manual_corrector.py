"""Manual del Corrector con la interfaz nueva (Corrector v44, la del Calcador v95): Nuevo, Abrir, Guardar y Biblioteca
arriba; a la izquierda, Corregir / Ejercicios y Exportar; a la derecha, el programa de la pieza con ⚙️ Mecanizado.
Cambia los textos y las dos capturas de la pantalla (capt_corrector.js y numerar.py, en capturas/).
Uso: python3 interfaz_manual_corrector.py <manual_corrector.html>"""
import sys, os, re, io, base64
from PIL import Image
P = sys.argv[1]; IMG = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'capturas')
s = open(P, encoding='utf-8').read()
assert 'pestaña ✅ Corregir' not in s, 'El manual ya tiene la interfaz nueva'

def rep(a, b, cnt=1):
    global s
    n = s.count(a); assert n == cnt, f'{n} apariciones (se esperaban {cnt}) de: {a[:100]}'
    s = s.replace(a, b)

def imagen_antes_de(pie, archivo, pie_nuevo=None, q=86):
    """Cambia la imagen de la figura cuyo pie empieza por «pie»."""
    global s
    k = s.index('<figcaption>' + pie); i = s.rindex('<img src="data:', 0, k); j = s.index('"', i + 10)
    im = Image.open(os.path.join(IMG, archivo)).convert('RGB'); b = io.BytesIO(); im.save(b, 'WEBP', quality=q, method=6)
    s = s[:i] + '<img src="data:image/webp;base64,' + base64.b64encode(b.getvalue()).decode() + s[j:]
    if pie_nuevo:
        k = s.index('<figcaption>' + pie); f = s.index('</figcaption>', k)
        s = s[:k] + '<figcaption>' + pie_nuevo + s[f:]

# ── 1. Qué es ──
rep('<li><strong>Genera</strong> el programa de la máquina con ⚙️ Mecanizar y abre el ejercicio en el Simulador.</li>',
    '<li><strong>Enseña</strong> el programa de la pieza (el de la solución o el de la máquina, con ⚙️ Mecanizar), lo recorre sobre el plano y lo abre en el Simulador 3D.</li>')
rep('<p>Para el dibujo, las cotas, la biblioteca y el resto de opciones del ejercicio, consulta el <strong>manual del Calcador</strong>.</p>',
    '<p>Tiene la misma apariencia que el Calcador, sin las herramientas de dibujo. Para el dibujo, las cotas, la biblioteca y el resto de opciones del ejercicio, consulta el <strong>manual del Calcador</strong>.</p>')

# ── 2. La pantalla ──
imagen_antes_de('El Corrector con un ejercicio abierto.', 'pantalla_num.png')
i = s.index('<table class="zonas">', s.index('El Corrector con un ejercicio abierto.')); j = s.index('</table>', i) + 8
filas = [
    '<strong>Barra superior.</strong> El nombre del ejercicio, <span class="boton">🗋 Nuevo</span>, <span class="boton">📂 Abrir</span>, <span class="boton">💾 Guardar</span>, <span class="boton">🗂 Biblioteca</span> y <span class="boton">📖 Manual</span>.',
    '<strong>Barra de estado.</strong> Lo que se puede hacer en cada momento.',
    '<strong>Panel izquierdo</strong>, en pestañas: <strong>✅ Corregir</strong> (<span class="boton">✅ Un programa</span> y <span class="boton">📚 Toda la clase</span>) y <strong>🧩 Ejercicios</strong> (<span class="boton">🖨 Hoja</span>, <span class="boton">📋 Soluciones</span>, <span class="boton">🎲 Variantes…</span> y <span class="boton">📝 Aules…</span>). Debajo, <strong>Exportar</strong>: DXF y SVG, con sus opciones.',
    '<strong>El plano.</strong> La pieza con sus cotas, el cero pieza y la entrada E. <strong>Arrastra</strong> para desplazar, usa la <strong>rueda</strong> para ampliar y pulsa <code>F</code> para encuadrarlo todo.',
    '<strong>Zoom.</strong> Ampliar, reducir, mostrar la rejilla y <span class="boton">Encuadrar</span>.',
    '<strong>⚙️ Mecanizado</strong>, en el panel derecho. Arriba se elige qué programa se ve: <span class="boton">📋 Solución</span> (el de la tabla de soluciones, comentado línea a línea) o <span class="boton">⚙️ Máquina</span> (el de ⚙️ Mecanizar). Debajo, las coordenadas, la compensación, la fresa, las pasadas y los avances, y el botón de la <strong>Ventana de Mecanizar</strong> (capítulo 12).',
    '<strong>El programa de la pieza</strong>, en las pestañas <span class="boton">📜 Programa</span> y <span class="boton">📋 Puntos</span>, con el reproductor, <span class="boton">⬇ Guardar .nc</span> y <span class="boton">➜ Simulador 3D</span> (capítulo 8).']
s = s[:i] + '<table class="zonas">\n' + ''.join(f'<tr><td class="n">{n}</td><td>{t}</td></tr>\n' for n, t in enumerate(filas, 1)) + '</table>' + s[j:]

# ── 3. Abrir ──
rep('<li><span class="boton">📂 Abrir .json</span> abre un ejercicio guardado desde el Calcador.', '<li><span class="boton">📂 Abrir</span>, en la barra de arriba, abre un ejercicio guardado desde el Calcador (.json).')
rep('<li><span class="boton">🗂 Biblioteca</span> abre los ejercicios', '<li><span class="boton">🗂 Biblioteca</span>, a su lado, abre los ejercicios')

# ── 4 y 7. Corregir ──
rep('<li>Pulsa <span class="boton">✅ Corregir programa</span>.</li>', '<li>En la pestaña ✅ Corregir, pulsa <span class="boton">✅ Un programa</span>.</li>')
rep('<li>Pulsa <span class="boton">📚 Corrección masiva</span>. El ejercicio abierto', '<li>En la pestaña ✅ Corregir, pulsa <span class="boton">📚 Toda la clase</span>. El ejercicio abierto')

# ── 8. Demostrar los errores en clase ──
imagen_antes_de('El reproductor de la barra superior', 'recorrido.png',
    'El programa de la pieza en el panel derecho, con «G41/G42 según el trazado»: la fresa recorre el contorno con su huella; la línea en curso está marcada y debajo se explica.')
rep('<li><strong>El programa de la pieza</strong>: los botones de la barra superior (⏮ ▏◀ ▶ ⏸ ▶▏ ⏭) recorren la solución sobre el plano, con la huella de la fresa. Teclas: ← y → bloque a bloque, ↑ reproducir, ↓ pausa, Mayús + ← / → al principio y al final.</li>',
    '<li><strong>El programa de la pieza</strong>: en el panel derecho, los botones ⏮ ▏◀ ▶ ▶▏ ⏭ recorren el programa sobre el plano, con la huella de la fresa; la línea en curso se marca y debajo se explica qué hace. También puedes hacer clic en cualquier línea. Con <span class="boton">📋 Solución</span> se ve el de la tabla de soluciones; con <span class="boton">⚙️ Máquina</span>, el de ⚙️ Mecanizar. Teclas: ← y → línea a línea, ↑ reproducir, ↓ pausa, Mayús + ← / → al principio y al final.</li>')
rep('<li><strong>La compensación</strong>: el selector junto a esos botones muestra la pieza en G40, con <strong>G41/G42 según el trazado</strong> (cada uno con su lado) o con <strong>G41 o G42 en todos</strong>, para enseñar qué pasa con el lado equivocado: la barra de estado lo avisa.</li>',
    '<li><strong>La compensación</strong>: la <strong>Compensación</strong> de ⚙️ Mecanizado escribe el programa en G40, con <strong>G41/G42 según el trazado</strong> (cada uno con su lado) o con <strong>G41 o G42 en todos</strong>, para enseñar qué pasa con el lado equivocado: el panel lo avisa en un recuadro rojo y el corte que se mete en la pieza se dibuja en rojo.</li>')

# ── 9, 10 y 11. Hojas, variantes y Aules (pestaña Ejercicios) ──
rep('<li><span class="boton">🖨 Hoja de ejercicio</span>: un A4', '<li><span class="boton">🖨 Hoja</span> (pestaña 🧩 Ejercicios): un A4')
rep('<li><span class="boton">📋 Soluciones</span>: la <strong>tabla de coordenadas</strong>', '<li><span class="boton">📋 Soluciones</span> (en la misma pestaña): la <strong>tabla de coordenadas</strong>')
rep('<p><span class="boton">🎲 Variantes para examen…</span> crea versiones', '<p><span class="boton">🎲 Variantes…</span> (pestaña 🧩 Ejercicios) crea versiones')
rep('<span class="boton">📝 Cuestionario para Aules…</span> (panel Exportar)', '<span class="boton">📝 Aules…</span> (pestaña 🧩 Ejercicios)')

# ── 12. ⚙️ Mecanizar y Simulador ──
rep('<li><span class="boton">⚙️ Mecanizar (G-code)…</span>: prepara el programa de la máquina, igual que en el Calcador: herramienta de la base (y la de cada contorno, con su cambio <code>T… M06</code>), pasadas, acabado, puentes, grabados, cajeras y compensación (G41/G42 según el trazado), con vista previa, descarga del .nc y <span class="boton">➜ Abrir en el Simulador</span>. Está explicado en el manual del Calcador (capítulo 21).</li>',
    '<li><span class="boton">⚙️ Máquina</span>, arriba en el panel derecho: el programa de la máquina, igual que en el Calcador: herramienta de la base (y la de cada contorno, con su cambio <code>T… M06</code>), pasadas, acabado, puentes, grabados, cajeras y compensación. Los datos comunes están en ⚙️ Mecanizado; el botón <span class="boton">⚙️ Ventana de Mecanizar…</span> abre la ventana de siempre, con todos los datos, la vista previa, el resumen y el tiempo estimado, y avisa si con «G41 en todos» o «G42 en todos» algún contorno queda del lado equivocado. Está explicado en el manual del Calcador (capítulo 21).</li>')
rep('<li><span class="boton">➜ Abrir en el Simulador</span>: abre el Simulador 3D con el plano y el programa de la solución, para verla mecanizada en 3D o en 2D.</li>',
    '<li><span class="boton">⬇ Guardar .nc</span> guarda el programa que se ve en el panel, y <span class="boton">➜ Simulador 3D</span> lo abre en el Simulador 3D con el plano, para verlo mecanizado en 3D o en 2D.</li>')
rep('<li><span class="boton">💾 Guardar (.json)</span>: guarda el ejercicio.', '<li><span class="boton">💾 Guardar</span>, en la barra de arriba: guarda el ejercicio (.json).')
rep('<li><span class="boton">⬇ DXF</span> y <span class="boton">⬇ SVG</span>: la pieza a escala 1:1', '<li><span class="boton">⬇ DXF</span> y <span class="boton">⬇ SVG</span>, en la pestaña Exportar: la pieza a escala 1:1')

assert 'panel Exportar' not in s and 'barra superior (⏮' not in s, re.findall('.{60}panel Exportar.{30}', s)
open(P, 'w', encoding='utf-8').write(s)
print(f'manual_corrector.html: interfaz nueva ({len(s) // 1024} KB)')
