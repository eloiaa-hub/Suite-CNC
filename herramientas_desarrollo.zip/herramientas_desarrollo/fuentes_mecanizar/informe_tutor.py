"""Calcador v97 / Corrector v45: en «Toda la clase», los informes de ✍ Practicar del Tutor G-Code (🧾 Informe para Aules)
se leen como los del Simulador: se corrige su programa y se comprueba el código; además, el estado del informe dice
cómo lo ha hecho el alumno (líneas a la primera, vistas, pistas y nota orientativa del Tutor).
Uso: python3 informe_tutor.py <carpeta de la suite>   (después de aviso_lado_mec.py)"""
import sys, os
P = os.path.join(sys.argv[1] if len(sys.argv) > 1 else '.', 'calcador.html')
s = open(P, encoding='utf-8').read()
def rep(a, b, cnt=1):
    global s
    n = s.count(a); assert n == cnt, f'{n} apariciones (se esperaban {cnt}) de: {a[:100]}'
    s = s.replace(a, b)
rep("""// Estado del informe de entrega de un alumno (texto corto y si está bien)
function estadoInforme(it) {""", """// Del informe del Tutor (✍ Practicar): cómo ha escrito el programa
function resumenTutor(inf) {
    const t = inf && inf.tutor; if (!t || typeof t !== 'object') return '';
    return ` · informe del Tutor: ${t.bien | 0} de ${t.total | 0} líneas a la primera, ${t.ayuda | 0} con fallos, ${t.vistas | 0} vistas, ${t.pistas | 0} pistas, nota orientativa ${String(t.nota).replace('.', ',')}`;
}
// Estado del informe de entrega de un alumno (texto corto y si está bien)
function estadoInforme(it) {""")
rep("""    if (it.desdeInforme) return { ok:true, txt:`Programa tomado del informe de entrega (código ${inf.codigo}, ${inf.fecha})` };""",
    """    if (it.desdeInforme) return { ok:true, txt:`Programa tomado del informe de entrega (código ${inf.codigo}, ${inf.fecha})` + resumenTutor(inf) };""")
rep("""    return { ok:true, txt:`El informe de entrega coincide con el programa (código ${inf.codigo}, ${inf.fecha})` };""",
    """    return { ok:true, txt:`El informe de entrega coincide con el programa (código ${inf.codigo}, ${inf.fecha})` + resumenTutor(inf) };""")
open(P, 'w', encoding='utf-8').write(s)
print('Calcador: los informes del Tutor en «Toda la clase»')
