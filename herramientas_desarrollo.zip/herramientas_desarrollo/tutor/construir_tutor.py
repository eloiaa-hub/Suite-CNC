#!/usr/bin/env python3
"""Genera tutor.html (Tutor G-Code, para el alumnado) a partir de calcador.html.
Quita lo que es del profesor (ejercicio aleatorio, importar DXF/SVG, cuestionario, variantes, DXF/SVG,
corrección, soluciones, hojas) y añade el panel del Tutor (tutor.js, tutor.css, tutor_panel.html),
la explicación de cada línea del Simulador 3D y los ejemplos (programas resueltos y biblioteca de inicio).
Uso: python3 construir_tutor.py CARPETA_DE_LA_SUITE"""
import json, os, re, sys
VERSION_TUTOR = 'v1'
AQUI = os.path.dirname(os.path.abspath(__file__))
DEV = os.path.dirname(AQUI)
d = sys.argv[1] if len(sys.argv) > 1 else '.'
leer = lambda *p: open(os.path.join(*p), encoding='utf-8').read()
s = leer(d, 'calcador.html')
sim = leer(d, 'simulador3d.html')
vcal = re.search(r'vertical-align:middle">(v\d+)</span></span>', s).group(1)

def rep(a, b, cnt=1):
    global s
    n = s.count(a)
    assert n == cnt, f'esperaba {cnt} y hay {n}: {a[:90]}'
    s = s.replace(a, b)

# ── El intérprete y la explicación de líneas del Simulador 3D, aparte (TUTSIM) ──
def funcion(texto, nombre):
    i = texto.index('function ' + nombre + '(')
    j = texto.index('{', i); prof = 0
    for k in range(j, len(texto)):
        if texto[k] == '{': prof += 1
        elif texto[k] == '}':
            prof -= 1
            if prof == 0: return texto[i:k + 1]
    raise ValueError(nombre)
exp = leer(DEV, 'fuentes_mecanizar', 'explicar_linea.js')
exp = exp[exp.index('const EXPL_G'):exp.index('let explicaciones')]
TUTSIM = ('// Intérprete y explicación de líneas del Simulador 3D (los mismos que en simulador3d.html)\nconst TUTSIM = (() => {\n'
          + 'const Z_SEGURIDAD = 10;\n'
          + '\n'.join(funcion(sim, f) for f in ['parsearGcode3D', 'normT', 'centroArcoIJ', 'centroArcoR', 'entidadDeMovimiento'])
          + '\n' + exp + '\nreturn { parsear: parsearGcode3D, explicar: explicarPrograma };\n})();\n')

# ── Ejemplos: los programas resueltos (se ve el programa) y la biblioteca de inicio (ejercicios) ──
ej = []
RES = os.path.join(DEV, 'manuales', 'resueltos', 'piezas')
for n, (f, nombre, coord) in enumerate([('e104', 'Pieza en L', 'G90'), ('e102', 'Pieza escalonada', 'G90'), ('e108', 'Placa con un agujero rectangular', 'G90'),
        ('e109', 'Pieza en cruz con un agujero', 'G90'), ('e303', 'Placa con esquinas hacia dentro', 'G90'), ('muesca_a', 'Pieza con muesca', 'G90'),
        ('e301', 'Ranura (colisa)', 'G90'), ('aro', 'Aro', 'G90'), ('e302', 'Placa con una esquina redondeada', 'mixta'), ('e306', 'Placa con esquina cóncava y agujero', 'mixta')], 1):
    datos = json.loads(leer(RES, f + '.json'))
    datos['nombre'] = f'Resuelto {n} - {nombre}'
    ej.append({'grupo': 'Programas resueltos (los de los apuntes): ves el programa', 'nombre': f'{n} · {nombre}', 'coord': coord, 'ejercicio': False, 'datos': datos})
plan = leer(DEV, 'biblioteca_inicio', 'plan.js')
progs = [re.findall(r"'(g90|g91|mix|libre)'", m) for m in re.findall(r'prog:\[([^\]]*)\]', plan)]
nombres = re.findall(r"nombre:'([^']*)'", plan)
bib = json.loads(leer(d, 'biblioteca_inicio', 'Biblioteca_de_inicio.json'))
COORD = {'g90': 'G90', 'g91': 'G91', 'mix': 'mixta', 'libre': 'G90'}
for e in bib['ejercicios']:
    partes = e['ruta'].split('/')
    nivel = partes[1]; k = int(partes[2][:2]) - 1; nv = nombres.index(nivel)
    datos = e['datos']
    ej.append({'grupo': f'Biblioteca de inicio · {nivel}: lo escribes tú', 'nombre': datos.get('nombre', partes[2]).replace('Inicio ', 'Ejercicio '), 'coord': COORD[progs[nv][k]], 'ejercicio': True, 'datos': datos})
EJEMPLOS = 'const TU_EJEMPLOS = ' + json.dumps(ej, ensure_ascii=False, separators=(',', ':')) + ';\n'

# ── El documento ──
assert s.startswith('<!DOCTYPE html>\n<html lang="es">'), 'cabecera inesperada'
s = s.replace('<html lang="es">', '<html lang="es" data-tutor="1">', 1)
rep('<title>Calcador de contornos — Por Eloi A.A.</title>', '<title>Tutor G-Code — Por Eloi A.A.</title>')
rep(f'⬡ Calcador de contornos — Por Eloi A.A.<span class="ver-suite" title="Versión del programa" style="font-size:11px;font-weight:600;padding:1px 7px;margin-left:8px;border-radius:9px;background:rgba(0,90,156,.12);color:#005A9C;vertical-align:middle">{vcal}</span>',
    f'🎓 Tutor G-Code — Por Eloi A.A.<span class="ver-suite" title="Versión del programa (hecho a partir del Calcador {vcal})" style="font-size:11px;font-weight:600;padding:1px 7px;margin-left:8px;border-radius:9px;background:rgba(0,90,156,.12);color:#005A9C;vertical-align:middle">{VERSION_TUTOR}</span>')
# sesión propia
n = s.count("'calcador_estado"); s = s.replace("'calcador_estado", "'tutor_estado"); assert n == 6, n
# estilos
rep('</style>\n</head>', leer(AQUI, 'tutor.css') + """    .params-box.visor-si > button[onclick*="abrirMec"], .params-box.visor-si > button[onclick*="abrirCuestionario"], .params-box.visor-si > button[onclick*="abrirVariantes"],
    .params-box.visor-si > button[onclick*="abrirCorregir"], .params-box.visor-si > button[onclick*="abrirMasiva"], .params-box.visor-si > button[onclick*="exportarEjercicioTutor"],
    .params-box.visor-si > .btn-row:has(button[onclick*="exportarDXF"]), .params-box.visor-si > .btn-row:has(button[onclick*="abrirHoja"]),
    .params-box.visor-si > .param-line { display: none !important; }
    /* el panel Exportar del Calcador no se ve: abrir, guardar, nuevo y el Simulador están arriba, en «Tutor» */
    .section-label.visor-si, .params-box.visor-si { display: none !important; }
    /* el panel izquierdo, como el del Calcador: Dibujo / Construcción / Formas en pestañas (los imanes, plegados en Dibujo) y Fondo */
    .c2-archivo { display: flex; gap: 4px; }
    .c2-archivo .btn-manual { white-space: nowrap; }
    .action-panel { width: 292px !important; padding-right: 10px !important; }
    .section-label:has(+ .tu-seccion), .tu-seccion { display: none !important; }
    .c2-tabs-izq { padding: 0 2px; margin-bottom: -10px; flex-shrink: 0; border-bottom: 1px solid var(--border-color); }
    .c2-tabs-izq button { flex: 1; font-size: 12.5px; white-space: nowrap; padding-left: 6px; padding-right: 6px; }
    .c2-tabs-izq.c2-una button { flex: 0 0 50%; }
    .c2-pane { border-top-left-radius: 0; border-top-right-radius: 0; border-top: 0; }
    .params-box[hidden] { display: none !important; }
    .c2-opciones { font-size: 12px; }
    .c2-opciones summary { cursor: pointer; color: var(--text-muted); padding: 2px 0; }
    .c2-imanes { margin-bottom: 4px; }
    .c2-imanes > .params-box { margin-top: 6px; }
    #tuNivelLinea select { max-width: 130px; }
</style>\n</head>""")
# ayuda propia; sin biblioteca ni manual del Calcador (ocultos por CSS)
rep('<span class="icon-gear" onclick="abrirAyuda()" title="Ayuda rápida">❓</span>', '<span class="icon-gear" onclick="tuAyuda()" title="Cómo funciona el Tutor">❓</span>')
# Sección «Tutor» en lugar de «Ejercicio» (el ejercicio aleatorio es del profesor)
i = s.index('                <div class="section-label">Ejercicio</div>'); j = s.index('                <div class="section-label">Fondo</div>')
s = s[:i] + '''                <div class="section-label">Tutor</div>
                <div class="params-box tu-seccion">
                    <div class="param-line" id="tuNivelLinea">Herramientas de dibujo
                        <select id="tuNivel" onchange="tuNivel(this.value)" title="Las herramientas se abren poco a poco"><option value="1">1 · Rectas</option><option value="2">2 · Rectas y arcos</option><option value="3">3 · Todas</option></select></div>
                </div>

''' + s[j:]
# Fondo: solo imágenes (importar DXF y SVG es del profesor)
rep('<input type="file" id="fileFondo" accept=".png,.jpg,.jpeg,.gif,.webp,.bmp,.svg,.dxf"', '<input type="file" id="fileFondo" accept=".png,.jpg,.jpeg,.gif,.webp,.bmp"')
rep("""onclick="document.getElementById('fileFondo').click()">🖼 Cargar imagen, SVG o DXF</button>""", """onclick="document.getElementById('fileFondo').click()">🖼 Cargar una imagen del plano</button>""")
rep('Sin fondo. Carga el plano a calcar: foto o imagen (PNG, JPG), SVG o DXF.', 'Sin fondo. Puedes poner debajo una foto del plano (PNG o JPG) para calcarlo.', 2)
rep("""    const ext = file.name.split('.').pop().toLowerCase();
    const reader = new FileReader();""", """    const ext = file.name.split('.').pop().toLowerCase();
    if (ext === 'dxf' || ext === 'svg') { snack('El Tutor solo pone imágenes de fondo (PNG o JPG)'); return; }
    const reader = new FileReader();""")
# Exportar: «Abrir en el Simulador» lleva el programa del Tutor
rep('<button class="btn-action sec" onclick="abrirEnSimulador()"', '<button class="btn-action sec" onclick="tuEnviarSimulador()"')
# El panel del Tutor, a la derecha del dibujo, con «➜ Simulador 3D» junto a «⬇ Guardar .nc» (como en el Calcador)
PANEL = leer(AQUI, 'tutor_panel.html')
assert PANEL.count('⬇ Guardar .nc</button>') == 1
PANEL = PANEL.replace('⬇ Guardar .nc</button>', '⬇ Guardar .nc</button>\n                        <button onclick="tuEnviarSimulador()" title="Abre el Simulador 3D con el plano y el programa, para verlo mecanizado">➜ Simulador 3D</button>')
rep('        <div class="right-panel">\n', PANEL + '        <div class="right-panel">\n')
# Nuevo, Abrir, Guardar y Ejemplos, en la barra de arriba (entre el nombre y la ayuda), como en el Calcador
rep('<input class="project-name" id="projectName" type="text" value="calco_sin_nombre" placeholder="Nombre del proyecto">',
    '<input class="project-name" id="projectName" type="text" value="calco_sin_nombre" placeholder="Nombre del proyecto">\n            <div class="c2-archivo">'
    '<button class="btn-manual" onclick="nuevo()" title="Empieza un dibujo nuevo (se puede deshacer). Si estás en un ejercicio, lo deja">🗋 Nuevo</button>'
    '<button class="btn-manual" onclick="document.getElementById(\'fileJSON\').click()" title="Abre un dibujo guardado o un ejercicio que te ha dado el profesor (.json). Si es un ejercicio, se abre en ✍ Practicar">📂 Abrir</button>'
    '<button class="btn-manual" onclick="exportarJSON()" title="Guarda tu dibujo en un archivo .json, para seguir otro día o abrirlo en el Simulador">💾 Guardar</button>'
    '<button class="btn-manual" onclick="tuAbrirEjemplos()" title="Piezas para ver su programa (los programas resueltos) y ejercicios para escribirlo tú (la biblioteca de inicio)">📚 Ejemplos</button></div>')
# Ventanas: ejemplos y ayuda
AYUDA = '''<div class="modal-overlay" id="tuModalEj" onclick="if(event.target===this) tuCerrarEjemplos()">
    <div class="modal"><div style="display:flex;justify-content:space-between;align-items:center"><h2 style="margin:0">📚 Ejemplos y ejercicios</h2><button onclick="tuCerrarEjemplos()">✕</button></div>
        <p class="ctx-nota">👁 <b>Ejemplos</b>: se abren en Aprender, con su programa. 🎓 <b>Ejercicios</b>: se abren en Practicar; el programa lo escribes tú, línea a línea, sacando las medidas de las cotas.</p>
        <div id="tuListaEj"></div></div>
</div>
<div class="modal-overlay" id="tuModalAyuda" onclick="if(event.target===this) tuCerrarAyuda()">
    <div class="modal"><div style="display:flex;justify-content:space-between;align-items:center"><h2 style="margin:0">🎓 Cómo funciona el Tutor G-Code</h2><button onclick="tuCerrarAyuda()">✕</button></div>
        <p>Dibuja una pieza como en un programa de dibujo y, a la derecha, el Tutor escribe su programa ISO (G-code) línea a línea, con un comentario en cada línea.</p>
        <h3>👁 Aprender</h3>
        <p>El programa se escribe solo mientras dibujas. Haz clic en una línea (o avanza con <b>▶▏</b> o la flecha <b>→</b>) y verás en el dibujo cómo se mueve la fresa y, debajo, qué hace cada palabra de la línea. Con <b>▶</b>, el recorrido entero.</p>
        <p>En <b>⚙️ Mecanizado</b> eliges cómo se escribe: <b>G90</b> (cada punto desde el cero pieza), <b>G91</b> (lo que se mueve la fresa) o <b>mixta</b>; la <b>compensación</b> G41/G42 (la fresa va desplazada su radio: por fuera de la pieza y por dentro de los agujeros); la fresa, la profundidad, las pasadas y los avances. Cambia una opción y mira cómo cambia el programa.</p>
        <p>En <b>📋 Puntos</b>, la tabla con las coordenadas de cada punto (y, en G91, lo que se mueve la fresa). En el dibujo, cada punto lleva su nombre: P1, P2… en el exterior; A1, A2… en los agujeros. Con compensación, la fresa baja en F1 (fuera del contorno) y entra en E1, en el medio de un lado.</p>
        <h3>✍ Practicar</h3>
        <p>El programa lo escribes tú. Escribe cada línea y pulsa <b>Intro</b>: si está bien, pasa a la siguiente; si no, el Tutor te dice qué falla (el signo, G90 o G91, el centro del arco…). En verde, en el dibujo, el tramo que toca. <b>💡 Pista</b> enseña el comentario de la línea y <b>👁 Ver la línea</b> la escribe por ti (cuenta como vista).</p>
        <p>Vale cualquier forma correcta: con o sin el G1 si ya venía de antes, el arco con I J o con R…</p>
        <h3>🎓 Ejercicios</h3>
        <p>Los ejercicios (los de la biblioteca de inicio o los que te dé el profesor en un .json) se abren en Practicar y no enseñan el programa ni las coordenadas: las sacas tú de las cotas del plano.</p>
        <h3>Para terminar</h3>
        <p>Arriba, junto al nombre: <b>📂 Abrir</b> abre tu dibujo guardado o un ejercicio del profesor (un ejercicio se abre solo en Practicar), <b>💾 Guardar</b> guarda tu dibujo (.json), <b>🗋 Nuevo</b> empieza otro y <b>📚 Ejemplos</b> abre las piezas de ejemplo y los ejercicios. Junto a <b>⬇ Guardar .nc</b>, <b>➜ Simulador 3D</b> abre el programa en el Simulador 3D, con el plano, para verlo mecanizado. El nivel de las herramientas de dibujo está arriba en la pestaña Dibujo.</p>
    </div>
</div>
'''
rep('<div class="modal-overlay" id="modalCal">', AYUDA + '<div class="modal-overlay" id="modalCal">')
# En el dibujo, los puntos los nombra el Tutor (P1, A1, E1…): sin la «E» de entrada del Calcador (sí su flecha de sentido)
rep("            texto(add(p0, add(mulv(nV, 1.3*h), mulv(dir, -0.9*h))), (cerrados.length > 1 ? 'E' + (k + 1) : 'E')",
    "            if (false) texto(add(p0, add(mulv(nV, 1.3*h), mulv(dir, -0.9*h))), (cerrados.length > 1 ? 'E' + (k + 1) : 'E')")
# Enganches: al cambiar el dibujo, al dibujar y con las flechas
rep("    actualizarLista(); actualizarEstado(); programarFresa(); render(); guardarAutoPronto();\n}",
    "    actualizarLista(); actualizarEstado(); programarFresa(); render(); guardarAutoPronto();\n    if (typeof tutorRefrescar === 'function') tutorRefrescar();\n}")
rep("    dibujarCaja();\n    dibujarSnap();\n}", "    dibujarCaja();\n    if (typeof tutorDibujar === 'function') tutorDibujar();\n    dibujarSnap();\n}")
rep("""        if (e.key === 'ArrowUp') simPlanoPlay(); else if (e.key === 'ArrowDown') simPlanoPausa();
        else if (e.shiftKey) (e.key === 'ArrowLeft' ? simPlanoInicio : simPlanoFin)();
        else simPlanoPaso(e.key === 'ArrowRight' ? 1 : -1);""", """        if (e.key === 'ArrowUp') { if (!TU.sim || !TU.sim.jugando) tuPlay(); } else if (e.key === 'ArrowDown') tuPausa();
        else if (e.shiftKey) (e.key === 'ArrowLeft' ? tuInicio : tuFin)();
        else tuPaso(e.key === 'ArrowRight' ? 1 : -1);""")
ENGANCHES = '''
// ── Enganches del Tutor en funciones del Calcador ──
const _tuAbrirJSONDatos = abrirJSONDatos;
abrirJSONDatos = function (d) { const r = _tuAbrirJSONDatos.apply(this, arguments); setTimeout(() => tuAlAbrirJSON(d), 0); return r; };
const _tuNuevo = nuevo;
nuevo = function () { const r = _tuNuevo.apply(this, arguments); if (!contornos.length && TU.ejercicio) { TU.ejercicio = null; TU.practica = null; tuGuardarEjercicio(); tuPintarMec(); tuRefrescar(true); tuModo('aprender'); } return r; };
const _tuSetHerramienta = setHerramienta;
setHerramienta = function (h) {
    if (TU.ejercicio && h !== 'medir') { if (h !== 'editar' && h !== herramienta) snack('En un ejercicio el dibujo no se cambia: solo se puede medir. Para dibujar, «✕ Dejar el ejercicio»'); if (herramienta === 'medir') return; h = 'medir'; arguments[0] = 'medir'; }
    const ok = TU_NIVELES[TU.nivel];
    if (h === 'texto' || (ok && !ok.includes(h) && document.querySelector(`#toolStrip .tool-btn[data-h="${h}"]`))) { snack(h === 'texto' ? 'El texto de grabado no está en el Tutor' : 'Esa herramienta se abre con más nivel (Herramientas de dibujo, arriba en la pestaña Dibujo)'); return; }
    return _tuSetHerramienta.apply(this, arguments);
};
function c2Pestana(b) { b.parentElement.querySelectorAll('button').forEach(x => { x.classList.toggle('activo', x === b); document.getElementById(x.dataset.p).hidden = x !== b; }); }
function tuPanelIzquierdo() {
    const ap = document.querySelector('.action-panel');
    const sec = t => { const l = [...ap.querySelectorAll(':scope > .section-label')].find(x => x.textContent.trim().toLowerCase() === t); return l ? [l, l.nextElementSibling] : []; };
    const dib = sec('dibujo'), ima = sec('imanes'), con = sec('construcción'), formas = sec('formas'), fondo = sec('fondo');
    // en Dibujo: arriba, el nivel de las herramientas; después, los imanes plegados
    if (dib.length) { const nl = document.getElementById('tuNivelLinea'); if (nl) dib[1].insertBefore(nl, dib[1].firstChild); }
    if (dib.length && ima.length) { const det = document.createElement('details'); det.className = 'c2-opciones c2-imanes'; det.innerHTML = '<summary>Imanes</summary>'; det.appendChild(ima[1]); ima[0].remove();
        const nl = document.getElementById('tuNivelLinea'); dib[1].insertBefore(det, nl ? nl.nextSibling : dib[1].firstChild); }
    const barra = (id, lista, una) => { const t = document.createElement('div'); t.className = 'tu-tabs c2-tabs-izq' + (una ? ' c2-una' : ''); t.id = id; t.setAttribute('role', 'tablist');
        lista.forEach(([sx, pid, nom], k) => { if (sx.length < 2) return; sx[1].id = pid; sx[1].classList.add('c2-pane'); if (k) sx[1].hidden = true; sx[0].remove();
            const b = document.createElement('button'); b.dataset.p = pid; b.textContent = nom; b.onclick = () => c2Pestana(b); if (!k) b.classList.add('activo'); t.appendChild(b); });
        return t; };
    const t2 = barra('c2Tabs2', [[dib, 'c2PaneDib', 'Dibujo'], [con, 'c2PaneCons', 'Construcción'], [formas, 'c2PaneFormas', 'Formas']]);
    const t3 = barra('c2Tabs3', [[fondo, 'c2PaneFondo', 'Fondo']], true);
    [t2, dib[1], con[1], formas[1], t3, fondo[1]].forEach(el => el && ap.appendChild(el));
}
// al elegir una forma o las auxiliares, se abre su pestaña
const _c2SetHerramienta = setHerramienta;
setHerramienta = function (h) { const r = _c2SetHerramienta.apply(this, arguments);
    const p = ['rectangulo', 'poligono', 'estrella', 'elipse'].includes(herramienta) ? 'c2PaneFormas' : herramienta === 'auxiliar' ? 'c2PaneCons' : 'c2PaneDib';
    const b = document.querySelector(`#c2Tabs2 button[data-p="${p}"]`); if (b && !b.classList.contains('activo')) c2Pestana(b); return r; };
window.addEventListener('load', () => setTimeout(() => { tuPanelIzquierdo(); tutorIniciar(); }, 0));
'''
rep('// ── Inicio ──\nleerColores();', TUTSIM + EJEMPLOS + 'const TU_C2 = false;      // (true en el Calcador2)\n' + leer(AQUI, 'tutor.js') + ENGANCHES + '\n// ── Inicio ──\nleerColores();')
open(os.path.join(d, 'tutor.html'), 'w', encoding='utf-8').write(s)
print(f'tutor.html generado desde el Calcador {vcal} → Tutor {VERSION_TUTOR} ({len(ej)} ejemplos, {len(s) // 1024} KB)')
