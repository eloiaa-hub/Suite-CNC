"""Dibujos de «La cabecera del programa»: la fresadora de mano (genérica) con lo que se prepara, G90 y G91, G40 y la F.
Usa la clase D de ../guia_iso/diagramas.py (mismo estilo que los apuntes). Uso: python3 diagramas.py  (los deja en diagramas/)"""
import os, math
AQUI = os.path.dirname(os.path.abspath(__file__))
src = open(os.path.join(AQUI, '..', 'guia_iso', 'diagramas.py'), encoding='utf-8').read()
src = src[:src.index('\nd = D(')].replace("os.path.join(os.path.dirname(os.path.abspath(__file__)), 'diagramas')", repr(os.path.join(AQUI, 'diagramas')))
exec(src)
os.makedirs(os.path.join(AQUI, 'diagramas'), exist_ok=True)
METAL, METAL2, CUERPO, CUERPO2 = '#dfe5eb', '#b9c3cd', '#d6e4f0', '#9db8d2'

def marca(d, n, c, hacia, col=NAR):
    """Un número en un círculo, con su línea hasta la pieza de la máquina."""
    d.linea(c, hacia, col, 1.3); d.punto(hacia, col, 3)
    x, y = d.P(*c); d.add(f'<circle cx="{x}" cy="{y}" r="11" fill="{col}" stroke="#fff" stroke-width="2"/>')
    d.texto(c, str(n), '#fff', 13, 'middle', '700', dy=4.5)

def P(d, pts):
    return ' '.join(f'{"M" if i == 0 else "L"}{d.P(*p)[0]},{d.P(*p)[1]}' for i, p in enumerate(pts))

# ── 1. La fresadora de mano (de lado, sobre la pieza) ──
d = D(640, 420, esc=1, x0=135, y0=12)
# la pieza, con la ranura que va haciendo
d.rect((0, 0), (330, 44), GRIS, MADERA, 1.2)
d.add(f'<path d="{P(d, [(157, 44), (157, 26), (171, 26), (171, 44)])}" fill="#e6cfa3" stroke="{MADERA2}" stroke-width="1"/>')
# la base (el plato que apoya en la pieza)
d.rect((70, 44), (270, 54), TINTA, METAL2, 1.4)
d.rect((76, 54), (264, 58), GRIS, METAL, 1)
# el cuerpo fijo (la base que sujeta el motor), con su ventana para ver la fresa
d.add(f'<path d="{P(d, [(104, 58), (104, 172), (224, 172), (224, 58)])}" fill="{METAL}" stroke="{TINTA}" stroke-width="1.4"/>')
d.add(f'<path d="{P(d, [(122, 62), (122, 118), (206, 118), (206, 62)])} Z" fill="#fff" stroke="{GRIS}" stroke-width="1.1"/>')
# la palanca de bloqueo
d.add(f'<path d="{P(d, [(104, 150), (70, 158), (66, 150), (104, 140)])} Z" fill="{TINTA}" stroke="{TINTA}" stroke-width="1"/>')
# la escala de profundidad (mm)
d.rect((226, 70), (244, 166), TINTA, '#fff', 1.2)
for k in range(0, 41, 2):
    y = 74 + k * 2.2; L = 9 if k % 10 == 0 else 5
    d.linea((226, y), (226 + L, y), TINTA, 0.9)
    if k % 10 == 0: d.texto((242, y), str(k), TINTA, 8.5, 'end', '600', dy=3)
d.texto((235, 168), 'mm', TINTA, 8.5, 'middle', '700', dy=-1)
# el motor (sube y baja dentro del cuerpo)
d.add(f'<path d="{P(d, [(118, 120), (118, 330), (210, 330), (210, 120)])} Z" fill="{CUERPO}" stroke="{TINTA}" stroke-width="1.5"/>')
for y in (300, 308, 316): d.linea((128, y), (200, y), CUERPO2, 2)        # rejillas de ventilación
d.add(f'<path d="{P(d, [(118, 330), (124, 344), (204, 344), (210, 330)])} Z" fill="{CUERPO2}" stroke="{TINTA}" stroke-width="1.4"/>')
# la rueda de velocidades, arriba
d.rect((150, 344), (178, 352), TINTA, '#fff', 1.2)
for i, x in enumerate(range(153, 177, 4)): d.linea((x, 344), (x, 352), TINTA, 0.8)
# el interruptor
d.rect((150, 250), (180, 270), TINTA, '#fff', 1.2); d.rect((152, 252), (165, 268), ROJO, ROJO, 0.8)
d.texto((158.5, 260), 'I', '#fff', 10, 'middle', '700', dy=4); d.texto((172.5, 260), 'O', TINTA, 10, 'middle', '700', dy=4)
# el cable
d.add(f'<path d="M{d.P(210, 320)[0]},{d.P(210, 320)[1]} C{d.P(250, 330)[0]},{d.P(250, 330)[1]} {d.P(270, 360)[0]},{d.P(270, 360)[1]} {d.P(300, 372)[0]},{d.P(300, 372)[1]}" fill="none" stroke="{TINTA}" stroke-width="5" stroke-linecap="round"/>')
# la pinza y la fresa
d.add(f'<path d="{P(d, [(154, 120), (154, 104), (159, 96), (169, 96), (174, 104), (174, 120)])} Z" fill="{METAL2}" stroke="{TINTA}" stroke-width="1.2"/>')
d.rect((160, 60), (168, 96), TINTA, '#c8d0d8', 1)
d.add(f'<path d="{P(d, [(158, 60), (158, 28), (164, 24), (170, 28), (170, 60)])} Z" fill="{NAR}" stroke="{TINTA}" stroke-width="1"/>')
# los números
marca(d, 1, (290, 140), (244, 120))
marca(d, 2, (290, 362), (176, 352))
marca(d, 3, (290, 260), (180, 260))
marca(d, 4, (40, 80), (158, 40))
marca(d, 5, (40, 210), (118, 210))
d.texto((290, 140), 'escala de profundidad, en mm', TINTA, 12.5, 'start', '600', dx=18, dy=4.5)
d.texto((290, 362), 'rueda de velocidades', TINTA, 12.5, 'start', '600', dx=18, dy=4.5)
d.texto((290, 260), 'interruptor', TINTA, 12.5, 'start', '600', dx=18, dy=4.5)
d.texto((40, 80), 'la fresa', TINTA, 12.5, 'end', '600', dx=-18, dy=-14)
d.texto((40, 80), 'en la pinza', TINTA, 12.5, 'end', '600', dx=-18, dy=1)
d.texto((40, 210), 'el motor:', TINTA, 12.5, 'end', '600', dx=-18, dy=-14)
d.texto((40, 210), 'lo empujas', TINTA, 12.5, 'end', '600', dx=-18, dy=1)
d.texto((165, 0), 'la pieza', GRIS, 11, 'middle', '700', dy=-6)
d.svg('fresadora', '82%')

# ── 2. G90 y G91: desde dónde se mide ──
PIEZA = [(0, 0), (60, 0), (60, 20), (90, 20), (90, 50), (0, 50)]
NOMBRES = ['P1', 'P2', 'P3', 'P4', 'P5', 'P6']
def pieza(d, col=AZUL):
    d.rect((-8, -8), (98, 58), GRIS, MADERA, 1)
    d.poli(PIEZA, col, 2.2, fill='rgba(0,90,156,.06)', cerrar=True)
d = D(380, 300, esc=2.6, x0=50, y0=80)
pieza(d); d.cero((0, 0))
for (x, y), n in zip(PIEZA, NOMBRES):
    if (x, y) == (0, 0): d.texto((0, 0), 'P1 X0 Y0', TINTA, 11, 'middle', '700', dy=22); continue
    d.linea((0, 0), (x, y), NAR, 1, dash='4 3', flecha=True); d.punto((x, y), NAR, 3.5)
    d.texto((x, y), f'{n} X{x} Y{y}', TINTA, 11, 'start' if x > 30 else 'middle', '700', dx=6 if x > 30 else 0, dy=-8 if y > 30 else 15)
d.texto((45, -8), 'G90 · ABSOLUTAS', NAR, 13, 'middle', '700', dy=26)
d.texto((45, -8), 'cada punto, medido desde el cero pieza', GRIS, 11, 'middle', dy=42)
d.svg('g90', '100%')
d = D(380, 300, esc=2.6, x0=50, y0=80)
pieza(d); d.cero((0, 0))
for k in range(len(PIEZA)):
    a, b = PIEZA[k], PIEZA[(k + 1) % len(PIEZA)]
    d.linea(a, b, NAR, 1.8, flecha=True)
    dx, dy = b[0] - a[0], b[1] - a[1]
    t = (f'X{dx:+d}'.replace('+', '+') if dx else '') + (' ' if dx and dy else '') + (f'Y{dy:+d}' if dy else '')
    m = ((a[0] + b[0]) / 2, (a[1] + b[1]) / 2)
    d.texto(m, t, TINTA, 11, 'middle', '700', dx=(14 if dy and not dx and b[0] > 30 else -16 if dy and not dx else 0), dy=(-6 if dx and not dy and a[1] > 10 else 14 if dx and not dy else 4))
for (x, y), n in zip(PIEZA, NOMBRES): d.punto((x, y), NAR, 3.5)
d.texto((45, -8), 'G91 · INCREMENTALES', NAR, 13, 'middle', '700', dy=26)
d.texto((45, -8), 'cada punto, medido desde el anterior', GRIS, 11, 'middle', dy=42)
d.svg('g91', '100%')

# ── 3. G40 y la F: la fresa sigue la línea del dibujo, a una velocidad ──
d = D(560, 275, esc=2.6, x0=60, y0=70)
d.rect((-12, -10), (160, 72), GRIS, MADERA, 1)
lin = [(0, 0), (110, 0), (140, 30), (140, 62)]
d.poli(lin, AZUL, 2.2)
d.circ((60, 0), 3, NAR, 1.6, fill='rgba(196,88,12,.25)')        # la fresa Ø6, con su centro sobre la línea
d.punto((60, 0), NAR, 2.5)
d.linea((70, 6), (102, 6), NAR, 2.2, flecha=True)
d.texto((86, 6), 'F1000: la fresa avanza a 1000 mm/min', NAR, 12, 'middle', '700', dy=-10)
d.texto((60, 0), 'el centro de la fresa, sobre la línea', TINTA, 11.5, 'middle', '600', dy=26)
d.texto((60, 0), 'G40 · sin compensación', AZUL, 12.5, 'middle', '700', dy=42)
d.texto((142, 46), 'la línea', AZUL, 11.5, 'start', '700', dx=8)
d.texto((142, 46), 'del dibujo', AZUL, 11.5, 'start', '700', dx=8, dy=14)
d.svg('g40_f', '90%')
print('dibujos en', os.path.join(AQUI, 'diagramas'))
