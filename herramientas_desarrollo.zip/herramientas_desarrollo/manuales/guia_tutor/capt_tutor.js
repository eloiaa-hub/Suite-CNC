// Capturas de la guía del Tutor G-Code (alumnado y profesorado)
// Uso: LANG=C.UTF-8 node capt_tutor.js        (deja las imágenes en img/)
const path = require('path'), fs = require('fs');
const { lanzar, SUITE } = require('../../pruebas/comun.js');
const { marcar, quitarMarcas } = require('../anidador_calculadora/comun_capt.js');
const OUT = path.join(__dirname, 'img'); fs.mkdirSync(OUT, { recursive: true });
const PIEZA_MAL = path.join(__dirname, '../../pruebas/tutor_compensacion.json');
(async () => {
  const b = await lanzar();
  const ctx = await b.newContext({ viewport: { width: 1360, height: 820 }, deviceScaleFactor: 2 });
  const nueva = async (f) => { const p = await ctx.newPage(); p.on('dialog', d => d.accept()); p.on('pageerror', e => console.log('ERR', e.message));
    await p.goto('file://' + path.join(SUITE, f || 'tutor.html')); await p.evaluate(() => localStorage.clear()); await p.reload(); await p.waitForTimeout(1500);
    await p.addStyleTag({ content: '#snackbar { display: none !important; }' }); return p; };
  const shot = (p, n, opt) => p.screenshot(Object.assign({ path: path.join(OUT, n) }, opt || {}));
  const el = async (p, sel, n, pad) => { const r = await p.evaluate(s => { const e = document.querySelector(s); const q = e.getBoundingClientRect(); return { x: q.x, y: q.y, width: q.width, height: q.height }; }, sel);
    const m = pad || 0; await shot(p, n, { clip: { x: Math.max(0, r.x - m), y: Math.max(0, r.y - m), width: r.width + 2 * m, height: r.height + 2 * m } }); };
  const opciones = (p, o) => p.evaluate(o => { Object.assign(cfgMec, o); tuPintarMec(); tuRefrescar(true); }, o);

  // 1. La pantalla, con las zonas numeradas (la pieza con muesca, en G90)
  let p = await nueva();
  await p.evaluate(() => tuCargarEjemplo(5)); await p.waitForTimeout(500);
  await opciones(p, { coord: 'G90', comp: 'G40', Fz: 150 });
  await p.evaluate(() => { encuadrar(); tuIrALinea(10); }); await p.waitForTimeout(500);
  await shot(p, 'pantalla_portada.png');
  await marcar(p, [{ n: 1, sel: '.c2-archivo', pos: 'c', oy: 26 }, { n: 2, sel: '#toolStrip', pos: 'tr', dy: 14, ox: 6 }, { n: 3, sel: '#c2Tabs2', pos: 'r', dy: 14, ox: 8 }, { n: 4, sel: '#canvasWrap', pos: 'c', oy: -200 },
    { n: 5, sel: '.tu-cab', pos: 'tr', dy: 20, ox: -6 }, { n: 6, sel: '#tuMec', pos: 'tr', dy: 14, ox: -10 }, { n: 7, sel: '#tutorPanel .tu-tabs', pos: 'tr', dy: 16, ox: -10 }, { n: 8, sel: '#tuLista', pos: 'tr', dy: 20, ox: -16 }, { n: 9, sel: '#tuExplicar', pos: 'tr', dy: 16, ox: -16 }]);
  await shot(p, 'pantalla.png'); await quitarMarcas(p);
  await el(p, '#tuMec', 'mecanizado.png', 4);
  // 2. Aprender en G91: la línea marcada, la fresa en el dibujo y la explicación
  await opciones(p, { coord: 'G91', comp: 'G40' }); await p.evaluate(() => { tuIrALinea(11); }); await p.waitForTimeout(400);
  await el(p, '#tutorPanel', 'aprender_panel.png');
  await shot(p, 'aprender.png');
  // 3. Compensación: entrada en E1 desde F1, el camino del centro de la fresa
  await opciones(p, { coord: 'G90', comp: 'auto' }); await p.evaluate(() => { encuadrar(); tuIrALinea(13); }); await p.waitForTimeout(500);
  await el(p, '#canvasWrap', 'compensacion.png');
  await p.evaluate(() => tuPestana('puntos')); await p.waitForTimeout(300);
  await el(p, '#tutorPanel', 'puntos.png');
  await p.evaluate(() => tuPestana('programa'));
  // 4. G41 del lado equivocado: el aviso y la franja en rojo
  await p.setInputFiles('#fileJSON', PIEZA_MAL); await p.waitForTimeout(600);
  await opciones(p, { coord: 'G90', comp: 'G41' }); await p.evaluate(() => { const e = document.getElementById('tuD'); e.value = 10; e.dispatchEvent(new Event('input')); encuadrar(); tuIrALinea(12); }); await p.waitForTimeout(600);
  await shot(p, 'aviso.png', { clip: { x: 430, y: 60, width: 930, height: 760 } });
  // 5. Practicar: líneas escritas, un error explicado
  p = await nueva();
  await p.evaluate(() => tuCargarEjemplo(4)); await p.waitForTimeout(400);
  await opciones(p, { coord: 'G90', comp: 'G40', Fz: 150 }); await p.evaluate(() => { encuadrar(); tuModo('practicar'); }); await p.waitForTimeout(300);
  for (const t of ['G71 G90', 'T101 M06', 'S12000 M03', 'G0 Z20', 'G0 X0 Y10', 'G1 Z-3 F150', 'G2 X10 Y0 I0 J-10 F1000', 'G1 X185 Y0']) { await p.fill('#tuEntrada', t); await p.press('#tuEntrada', 'Enter'); await p.waitForTimeout(120); }
  await p.fill('#tuEntrada', 'G2 X25 Y25 I25 J0'); await p.press('#tuEntrada', 'Enter'); await p.waitForTimeout(300);
  await shot(p, 'practicar.png');
  await el(p, '#tutorPanel', 'practicar_panel.png');
  await p.evaluate(() => { while (!TU.practica.fin) { const l = TU.prog.lineas[TU.practica.idx]; tuAceptar(l.cod, 'bien'); } tuMensaje('bien', ''); }); await p.waitForTimeout(300);
  await el(p, '#tuPractica', 'practicar_fin.png', 4);
  // 6. Ejemplos y ejercicios
  await p.evaluate(() => tuAbrirEjemplos()); await p.waitForTimeout(400);
  await el(p, '#tuModalEj .modal', 'ejemplos.png');
  await p.evaluate(() => tuCerrarEjemplos());
  // 7. Un ejercicio abierto: sin programa ni coordenadas
  await p.evaluate(() => { const i = TU_EJEMPLOS.findIndex(e => e.ejercicio && /203/.test(e.nombre)); tuCargarEjemplo(i >= 0 ? i : 20); }); await p.waitForTimeout(800);
  await shot(p, 'ejercicio.png');
  await el(p, '#tuEjercicio', 'ejercicio_aviso.png', 4);
  // 7b. El ejercicio hecho (con algún fallo y una pista) y su 🧾 informe para Aules: la ventana y la primera página del PDF
  await p.evaluate(() => { const L = TU.prog.lineas; let k = 0; while (!TU.practica.fin && k++ < 300) { const i = TU.practica.idx, cod = L[i].cod, e = () => document.getElementById('tuEntrada');
    if (i % 5 === 1) { e().value = 'G1 X'; tuComprobar(); } if (i % 4 === 2 && /X\d/.test(cod)) { e().value = cod.replace(/X(\d)/, 'X-$1'); tuComprobar(); } if (i % 7 === 3) tuPista(); e().value = cod; tuComprobar(); } });
  await p.evaluate(() => tuAbrirInforme()); await p.fill('#tuInfAlumno', 'Ana García'); await p.fill('#tuInfGrupo', '1.º DA'); await p.waitForTimeout(200);
  await el(p, '#tuModalInforme .modal', 'informe_ventana.png', 6);
  { const bs = await p.evaluate(async () => { tuActualizarInforme(); const b = tuPDFInforme(tuInf, tuInfImg); return [...new Uint8Array(await b.arrayBuffer())]; });
    const tmp = path.join(require('os').tmpdir(), 'informe_tutor_guia'); fs.writeFileSync(tmp + '.pdf', Buffer.from(bs));
    require('child_process').execSync(`pdftoppm -f 1 -l 1 -r 110 -png "${tmp}.pdf" "${tmp}"`); fs.copyFileSync(tmp + '-1.png', path.join(OUT, 'informe_pdf.png')); }
  await p.evaluate(() => tuCerrarInforme());
  // 8. En el Calcador: «🎓 Para el Tutor»
  p = await nueva('calcador.html');
  await el(p, '#c2PaneEj', 'calcador_para_tutor.png', 6);
  await b.close(); console.log('capturas en', OUT);
})();
