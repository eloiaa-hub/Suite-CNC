// Plan de la biblioteca de inicio: 4 niveles × 10 ejercicios, de menos a más.
// Cada ejercicio es [semilla, etapa]: la etapa fija los parámetros del generador (etapas de cada nivel)
// y la semilla, la pieza. Se eligieron mirando las hojas de contactos de candidatos.js.
module.exports = {
  niveles: [
    { clave:'rectas', n:1, nombre:'Nivel 1 - Rectas', titulo:'Rectas', base:1100,
      prog:['g90', 'g90', 'g90', 'g90', 'g90', 'g91', 'g91', 'g91', 'g91', 'g91'],
      etapas:[ { iMin:0, iMax:0, ext:['rectangulo'] }, { iMin:0, iMax:0, ext:['escalonada'] }, { iMin:1, iMax:2 } ],
      elegidas:[ [1100, 0], [1201, 1], [1220, 1], [1231, 1], [1203, 1], [1219, 1], [1224, 1], [1301, 2], [1306, 2], [1312, 2] ] },
    { clave:'inclinadas', n:2, nombre:'Nivel 2 - Rectas inclinadas', titulo:'Rectas inclinadas', base:2100,
      prog:['g90', 'g90', 'g90', 'g90', 'g90', 'mix', 'mix', 'mix', 'mix', 'mix'],
      etapas:[ { iMin:0, iMax:0, ext:['rectangulo'] }, { iMin:0, iMax:1 }, { iMin:1, iMax:2 } ],
      elegidas:[ [2105, 0], [2102, 0], [2125, 0], [2134, 0], [2201, 1], [2219, 1], [2222, 1], [2300, 2], [2314, 2], [2329, 2] ] },
    { clave:'tangentes', n:3, nombre:'Nivel 3 - Arcos sencillos', titulo:'Arcos sencillos', base:3100,
      prog:['g90', 'g90', 'g90', 'g90', 'g90', 'g90', 'g90', 'g90', 'g90', 'g90'],
      etapas:[ { iMin:0, iMax:0, ext:['rectangulo', 'ranura'] }, { iMin:1, iMax:1, ext:['rectangulo', 'escalonada'] }, { iMin:1, iMax:2, ext:['rectangulo', 'escalonada'] } ],
      elegidas:[ [3105, 0], [3116, 0], [3134, 0], [3208, 1], [3201, 1], [3219, 1], [3225, 1], [3300, 2], [3309, 2], [3318, 2] ] },
    { clave:'ij', n:4, nombre:'Nivel 4 - Arcos con I J', titulo:'Arcos con I J', base:4100,
      prog:['libre', 'libre', 'libre', 'libre', 'libre', 'libre', 'libre', 'libre', 'libre', 'libre'],
      etapas:[ { iMin:0, iMax:1, ext:['rectangulo', 'escalonada'] }, { iMin:1, iMax:2, ext:['rectangulo', 'escalonada', 'poligono'] }, { iMin:2, iMax:3, ext:['rectangulo', 'escalonada'] } ],
      elegidas:[ [4104, 0], [4132, 0], [4113, 0], [4209, 1], [4214, 1], [4206, 1], [4232, 1], [4302, 2], [4313, 2], [4322, 2] ] },
  ],
};
