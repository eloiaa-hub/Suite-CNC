// ── El profesor en la corrección masiva: su nota y su comentario, anterior / siguiente, guardar la corrección, devolución ──
// · it.notaProf (número o null) manda sobre la nota orientativa (que se guarda en it.v.notaAuto); it.comProf, su comentario.
//   Pasan a la tabla (✎), al CSV, al informe, a la hoja de devolución y a las notas para Aules.
// · En la corrección detallada de un alumno: ◀ ▶ (o Alt+← Alt+→) para ir al anterior o al siguiente, con la nota y el comentario a mano.
// · 💾 Guardar corrección / 📂 Abrir corrección: un .json con el ejercicio, las variantes, el reparto, los programas y lo del profesor.
// · 🖨 Devoluciones: la hoja para el alumno (su recorrido, lo que tiene que revisar, el comentario y la nota).
function aplicarProf(it) {
    if (!it || !it.v || it.v.veredicto === 'pendiente') return;
    if (it.v.notaAuto === undefined) it.v.notaAuto = it.v.nota;
    if (it.notaProf !== null && it.notaProf !== undefined && isFinite(+it.notaProf)) it.v.nota = Math.max(0, Math.min(10, +it.notaProf));
}
const _corregirAlumnoProf = corregirAlumno;
corregirAlumno = function (it) { const r = _corregirAlumnoProf.apply(this, arguments); aplicarProf(it); return r; };
const _corregirConVariantesProf = corregirConVariantes;
corregirConVariantes = function (items) { const r = _corregirConVariantesProf.apply(this, arguments); (items || []).forEach(aplicarProf); return r; };
const hayProf = () => masiva.lista.some(it => (it.notaProf !== null && it.notaProf !== undefined) || it.comProf);
function ponerProf(it, nota, com) {
    const n = String(nota ?? '').trim().replace(',', '.');
    it.notaProf = n === '' || !isFinite(+n) ? null : Math.max(0, Math.min(10, Math.round(+n * 100) / 100));
    it.comProf = String(com || '').trim();
    if (it.v) { if (it.v.notaAuto === undefined) it.v.notaAuto = it.v.nota; it.v.nota = it.notaProf !== null ? it.notaProf : it.v.notaAuto; }
}
function marcaProf(it) {
    const p = it.notaProf !== null && it.notaProf !== undefined, c = !!it.comProf;
    if (!p && !c) return '';
    const t = (p ? `Nota del profesor (la orientativa: ${nf(it.v && it.v.notaAuto !== undefined ? it.v.notaAuto : 0, 1)})` : '') + (c ? (p ? ' · ' : '') + 'Comentario: ' + it.comProf : '');
    return ` <span class="mv-prof" title="${String(t).replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;')}">${p ? '✎' : ''}${c ? '💬' : ''}</span>`;
}
// La ventana para la nota y el comentario (desde la lista)
function editarProf(k) {
    const it = masiva.lista[k]; if (!it) return;
    let ov = document.getElementById('modalProf');
    if (!ov) { ov = document.createElement('div'); ov.className = 'modal-overlay'; ov.id = 'modalProf'; ov.onclick = e => { if (e.target === ov) ov.classList.remove('visible'); }; document.body.appendChild(ov); }
    const esc = t => String(t).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/"/g, '&quot;');
    ov.innerHTML = `<div class="help-modal" style="width:min(520px,100%)"><div class="help-header"><h2>✎ ${esc(it.alumno)}</h2><button class="help-close" onclick="document.getElementById('modalProf').classList.remove('visible')">✕</button></div>
        <div class="help-content"><p class="ctx-nota" style="margin-top:0">Nota orientativa del Corrector: <b>${nf(it.v && it.v.notaAuto !== undefined ? it.v.notaAuto : (it.v ? it.v.nota : 0), 1)}</b>. Si pones la tuya, manda en la tabla, el CSV, los informes, la devolución y las notas para Aules (en blanco, la orientativa).</p>
        <label class="prof-l">Nota del profesor <input type="text" id="profNota" value="${it.notaProf ?? ''}" placeholder="—" style="width:70px"></label>
        <label class="prof-l">Comentario para el alumno<textarea id="profCom" rows="4" style="width:100%;box-sizing:border-box">${esc(it.comProf || '')}</textarea></label>
        <div class="btn-row"><button class="btn-action sec" id="profQuitar">Quitar lo mío</button><button class="btn-action" id="profOk">Guardar</button></div></div></div>`;
    const fin = () => { ov.classList.remove('visible'); corr = null; pintarMasiva(); };
    ov.querySelector('#profOk').onclick = () => { ponerProf(it, ov.querySelector('#profNota').value, ov.querySelector('#profCom').value); fin(); };
    ov.querySelector('#profQuitar').onclick = () => { ponerProf(it, '', ''); fin(); };
    ov.classList.add('visible'); setTimeout(() => ov.querySelector('#profNota').focus(), 50);
}
// ── La barra del alumno en la corrección detallada: ◀ ▶, su nota y su comentario ──
function ordenVista() { return listaOrdenada().map(o => o.k); }
function pintarBarraAlumno() {
    const b = document.getElementById('crAlumno'); if (!b) return;
    const k = masiva.viendo, it = k !== null && k !== undefined ? masiva.lista[k] : null;
    if (!it) { b.style.display = 'none'; return; }
    const o = ordenVista(), i = o.indexOf(k), esc = t => String(t).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/"/g, '&quot;');
    b.style.display = '';
    b.innerHTML = `<button class="btn-action sec" id="crAnt" ${i <= 0 ? 'disabled' : ''} title="El alumno anterior (Alt+←)">◀</button>
        <span class="cr-al-nom"><b>${esc(it.alumno)}</b> <small>${i + 1} de ${o.length}</small></span>
        <button class="btn-action sec" id="crSig" ${i >= o.length - 1 ? 'disabled' : ''} title="El alumno siguiente (Alt+→)">▶</button>
        <label title="En blanco, la nota orientativa del Corrector">Nota <input type="text" id="crNotaProf" value="${it.notaProf ?? ''}" placeholder="${it.v ? nf(it.v.notaAuto !== undefined ? it.v.notaAuto : it.v.nota, 1) : ''}"></label>
        <input type="text" id="crComProf" value="${esc(it.comProf || '')}" placeholder="Comentario para el alumno (sale en su devolución y en Aules)">
        <button class="btn-action sec" id="crDevol" title="Su hoja de devolución">🖨 Devolución</button>`;
    const guardar = () => ponerProf(it, b.querySelector('#crNotaProf').value, b.querySelector('#crComProf').value);
    b.querySelector('#crNotaProf').onchange = guardar; b.querySelector('#crComProf').onchange = guardar;
    b.querySelector('#crAnt').onclick = () => { guardar(); irAlumno(-1); };
    b.querySelector('#crSig').onclick = () => { guardar(); irAlumno(1); };
    b.querySelector('#crDevol').onclick = () => { guardar(); imprimirDevoluciones([k]); };
}
function irAlumno(paso) {
    const k = masiva.viendo; if (k === null || k === undefined) return;
    const o = ordenVista(), i = o.indexOf(k), j = i + paso; if (j < 0 || j >= o.length) return;
    const b = document.getElementById('crAlumno'); if (b && b.querySelector('#crNotaProf')) ponerProf(masiva.lista[k], b.querySelector('#crNotaProf').value, b.querySelector('#crComProf').value);
    volverAMasiva(); verAlumno(o[j]);
}
const _verAlumnoProf = verAlumno;
verAlumno = function (k) { const r = _verAlumnoProf.apply(this, arguments); pintarBarraAlumno(); return r; };
const _volverAMasivaProf = volverAMasiva;
volverAMasiva = function () { const b = document.getElementById('crAlumno'); const k = masiva.viendo;
    if (b && b.querySelector('#crNotaProf') && masiva.lista[k]) ponerProf(masiva.lista[k], b.querySelector('#crNotaProf').value, b.querySelector('#crComProf').value);
    const r = _volverAMasivaProf.apply(this, arguments); if (b) b.style.display = 'none'; return r; };
const _cerrarCorregirProf = cerrarCorregir;
cerrarCorregir = function () { const b = document.getElementById('crAlumno'); const k = masiva.viendo;
    if (b && b.style.display !== 'none' && b.querySelector('#crNotaProf') && masiva.lista[k]) ponerProf(masiva.lista[k], b.querySelector('#crNotaProf').value, b.querySelector('#crComProf').value);
    if (b) b.style.display = 'none'; return _cerrarCorregirProf.apply(this, arguments); };
document.addEventListener('keydown', e => {
    if (!e.altKey || (e.key !== 'ArrowLeft' && e.key !== 'ArrowRight')) return;
    const m = document.getElementById('modalCorregir'); if (!m || !m.classList.contains('visible') || masiva.viendo === null || masiva.viendo === undefined) return;
    e.preventDefault(); irAlumno(e.key === 'ArrowRight' ? 1 : -1);
});
// ── Guardar y abrir la corrección ──
function datosCorreccion() {
    let ej = null; try { ej = exportarJSON(true); } catch (e) {}
    return { tipo: 'correccion-calcador', version: 1, fecha: new Date().toISOString(), ejercicio: ej,
        variantes: (masiva.variantes || []).map(v => ({ id: v.id, etq: v.etq, letra: v.letra, datos: v.datos })), reparto: masiva.reparto || null, ids: masiva.ids || {},
        lista: masiva.lista.map(it => ({ alumno: it.alumno, archivo: it.archivo, texto: it.texto, ...(it.formato ? { formato: it.formato } : {}), ...(it.informe ? { informe: it.informe } : {}), ...(it.desdeInforme ? { desdeInforme: true } : {}),
            ...(it.notaProf !== null && it.notaProf !== undefined ? { notaProf: it.notaProf } : {}), ...(it.comProf ? { comProf: it.comProf } : {}) })) };
}
function guardarCorreccion() {
    if (!masiva.lista.length) { snack('No hay programas en la lista'); return; }
    const f = new Date(), dd = n => String(n).padStart(2, '0');
    descargar(JSON.stringify(datosCorreccion()), `${nombreProyecto()} - corrección ${f.getFullYear()}-${dd(f.getMonth() + 1)}-${dd(f.getDate())}.json`, 'application/json');
    snack(`Corrección guardada: ${masiva.lista.length} programa(s)${hayProf() ? ', con tus notas y comentarios' : ''}. Ábrela con 📂 Abrir corrección`);
}
function abrirDatosCorreccion(d) {
    if (!esObj(d) || d.tipo !== 'correccion-calcador' || !Array.isArray(d.lista)) { snack('Ese archivo no es una corrección guardada del Calcador'); return false; }
    if (d.ejercicio) abrirJSONDatos(d.ejercicio);
    masiva.variantes = Array.isArray(d.variantes) ? d.variantes : []; masiva.reparto = d.reparto || null; masiva.ids = esObj(d.ids) ? d.ids : {};
    masiva.lista = d.lista.map(x => ({ ...x }));
    sincronizarRequisitosMasiva(); recorregirMasiva(); abrirMasiva();
    snack(`Corrección abierta: ${masiva.lista.length} programa(s)${masiva.variantes.length ? `, con ${masiva.variantes.length} variantes` : ''}${hayProf() ? ', con tus notas y comentarios' : ''}`);
    return true;
}
function abrirCorreccionArchivo(input) {
    const f = input.files[0]; input.value = ''; if (!f) return;
    f.text().then(t => { let d; try { d = JSON.parse(t); } catch (e) { snack('El archivo no es un JSON válido'); return; } abrirDatosCorreccion(d); });
}
// ── La hoja de devolución (el informe, para el alumno) ──
let modoDevol = false;
function imprimirDevoluciones(ks) {
    modoDevol = true;
    try { imprimirInformes(ks || listaOrdenada().map(o => o.k)); } finally { modoDevol = false; }
}
// en las notas para Aules: la nota y el comentario del profesor
const _comentarioAulesProf = comentarioAules;
comentarioAules = function (it) {
    let t = _comentarioAulesProf.apply(this, arguments);
    if (it.notaProf !== null && it.notaProf !== undefined) t = t.replace(/^Nota orientativa del Corrector: [^.]+(?:\.\d)?[^.]*\./, `Nota: ${String(it.notaProf).replace('.', ',')} sobre 10 (orientativa del Corrector: ${String(Math.round((it.v.notaAuto ?? it.v.nota) * 10) / 10).replace('.', ',')}).`);
    return it.comProf ? `Comentario del profesor: ${it.comProf}\n${t}` : t;
};
