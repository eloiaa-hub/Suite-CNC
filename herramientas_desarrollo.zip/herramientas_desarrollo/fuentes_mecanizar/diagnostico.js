// ── Diagnóstico de dos errores típicos: la pieza en espejo y G90/G91 confundidos ──
// Si el programa no encaja con la pieza (y no es un desplazamiento), se prueba:
//  · la pieza en espejo (izquierda-derecha, arriba-abajo) o girada 180°, con o sin otro cero pieza: los vértices del
//    programa, reflejados, caen sobre los del plano, y corregido con la pieza reflejada sale bien;
//  · las coordenadas incrementales con G90 (o absolutas con G91): leídas en el otro modo, el trazado es el de la pieza.
// El primer error dice qué pasa. Los demás errores y la nota no cambian.
const TRANSF_ESPEJO = [
    { sx: -1, sy: 1, que: 'en espejo izquierda-derecha (las X con el signo cambiado)', corto: 'pieza en espejo' },
    { sx: 1, sy: -1, que: 'en espejo arriba-abajo (las Y con el signo cambiado)', corto: 'pieza en espejo' },
    { sx: -1, sy: -1, que: 'girada 180° (las X y las Y con el signo cambiado)', corto: 'pieza girada 180°' }];
const piezasDiag = () => contornos.filter(c => c.pts.length >= 2 && !c.texto && !c.deTexto && !soloFabricar(c));
function geometriaMal(r) { return (r.cobertura || 0) < 0.995 || r.hallazgos.some(h => h.tipo === 'error' && (h.cat === 'geometria' || h.cat === 'compensacion')); }
function geometriaBien(r) { return r && !r.error && (r.cobertura || 0) >= 0.95 && !r.hallazgos.some(h => h.tipo === 'error' && (h.cat === 'geometria' || h.cat === 'compensacion')); }
function corregirConPieza(texto, mover) {
    const antes = contornos, c0 = corr, base = typeof _corregirProgramaClase === 'function' ? _corregirProgramaClase : corregirPrograma;
    try { contornos = contornos.map(mover); memoTipos = null; return base(texto); }
    catch (e) { return null; } finally { contornos = antes; memoTipos = null; corr = c0; }
}
// La pieza en espejo o girada: programa p → plano q = T(p) + d
function buscarEspejo(r, texto) {
    const Q = [].concat(...piezasDiag().map(c => c.pts)), V = verticesCorte(r); if (V.length < 3 || !Q.length) return null;
    const tol = Math.max(0.05, +cfgCorr.tol || 0.02), cerca = (a, b) => Math.abs(a.x - b.x) <= tol && Math.abs(a.y - b.y) <= tol;
    let mejor = null; const S = tramosPlano();
    TRANSF_ESPEJO.forEach(T => {
        const tp = p => ({ x: T.sx * p.x, y: T.sy * p.y }), votos = new Map();
        V.forEach(p => { const a = tp(p); Q.forEach(q => { const k = (Math.round((q.x - a.x) * 100) / 100) + ',' + (Math.round((q.y - a.y) * 100) / 100); votos.set(k, (votos.get(k) || 0) + 1); }); });
        [...votos.entries()].sort((a, b) => b[1] - a[1]).slice(0, 8).forEach(([k]) => {
            const [dx, dy] = k.split(',').map(Number), d = { x: dx, y: dy };
            // si la pieza reflejada es la misma pieza (simétrica), no es un espejo
            if (Q.every(q => Q.some(q2 => cerca({ x: T.sx * (q.x - d.x), y: T.sy * (q.y - d.y) }, q2)))) return;
            const n = V.filter(p => sobreContorno({ x: T.sx * p.x + d.x, y: T.sy * p.y + d.y }, S, Math.max(0.1, tol * 2))).length;
            if (n >= Math.max(3, 0.6 * V.length) && (!mejor || n > mejor.n)) mejor = { T, d, n };
        });
    });
    if (!mejor) return null;
    const { T, d } = mejor, inv = T.sx * T.sy < 0;
    const r2 = corregirConPieza(texto, c => ({ ...c, pts: c.pts.map(q => ({ x: T.sx * (q.x - d.x), y: T.sy * (q.y - d.y) })), b: inv ? c.b.map(x => -(x || 0)) : c.b }));
    // (en espejo, la compensación queda al otro lado: G41 ↔ G42; eso no cuenta aquí)
    const ok = r2 && !r2.error && (r2.cobertura || 0) >= 0.95 && !r2.hallazgos.some(h => h.tipo === 'error' && h.cat === 'geometria');
    return ok ? { T, d, r2, comp: r2.hallazgos.some(h => h.tipo === 'error' && h.cat === 'compensacion') } : null;
}
// G90 / G91: reescribir las X Y como si el modo fuera el otro (todo en absolutas, con G90)
// «inc»: las X Y se leen como incrementales (se van sumando); «abs»: como absolutas. Se escribe todo en absolutas, con G90.
function convertirModo(texto, como) {
    let x = 0, y = 0; const out = [], f = v => String(+(+v).toFixed(4));
    String(texto).replace(/\r/g, '').split('\n').forEach(l => {
        const k = l.search(/[(;]/), com = k >= 0 ? l.slice(k) : '';
        let c = (k >= 0 ? l.slice(0, k) : l).replace(/G0*9[01](?!\d)/gi, '');
        const X = /X\s*([-+]?(?:\d+\.?\d*|\.\d+))/i.exec(c), Y = /Y\s*([-+]?(?:\d+\.?\d*|\.\d+))/i.exec(c);
        if (X) { x = como === 'inc' ? x + +X[1] : +X[1]; c = c.replace(X[0], 'X' + f(x)); }
        if (Y) { y = como === 'inc' ? y + +Y[1] : +Y[1]; c = c.replace(Y[0], 'Y' + f(y)); }
        out.push(c + com);
    });
    return 'G90\n' + out.join('\n');
}
function buscarModo(r, texto) {
    if (/G0*16(?!\d)/i.test(texto)) return null;      // (con polares, no)
    const hay91 = /G0*91(?!\d)/i.test(texto.replace(/\([^)]*\)|;.*$/gm, '')), como = hay91 ? 'abs' : 'inc';
    const r2 = (() => { const c0 = corr, base = typeof _corregirProgramaClase === 'function' ? _corregirProgramaClase : corregirPrograma; try { return base(convertirModo(texto, como)); } catch (e) { return null; } finally { corr = c0; } })();
    return geometriaBien(r2) ? { como, r2 } : null;
}
const _corregirProgramaDiag = corregirPrograma;
corregirPrograma = function (texto) {
    const r = _corregirProgramaDiag.apply(this, arguments);
    try {
        if (!r || r.error || r.piezaOk || r.desplazado || (r.trazado && r.trazado.ok) || !((r.resumen && r.resumen.cortes) || r.trazado) || !geometriaMal(r)) return r;
        const sinCorte = !!r.trazado;
        const m = buscarModo(r, texto);
        if (m) {
            r.diagnostico = { tipo: m.como === 'inc' ? 'g91' : 'g90', corto: 'G90 / G91 confundidos', cob: Math.min(1, m.r2.cobertura || 0) };
            r.hallazgos.unshift({ tipo: 'error', cat: 'diagnostico', linea: null,
                msg: m.como === 'inc'
                    ? 'Coordenadas incrementales con G90: el programa está en absolutas (G90), pero las X Y son incrementales (lo que se mueve desde el punto anterior). Leídas como incrementales, el trazado es el de la pieza: falta G91, o hay que escribir las coordenadas absolutas (desde el cero pieza). Los errores de debajo son, sobre todo, consecuencia de esto.'
                    : 'Coordenadas absolutas con G91: el programa está en incrementales (G91), pero las X Y son absolutas (desde el cero pieza). Leídas como absolutas, el trazado es el de la pieza: sobra G91 (con G90 estaría bien), o hay que escribir lo que se mueve desde el punto anterior. Los errores de debajo son, sobre todo, consecuencia de esto.',
                pista: m.como === 'inc' ? 'G90: X Y desde el cero pieza · G91: X Y desde el punto anterior' : 'G91: X Y desde el punto anterior · G90: X Y desde el cero pieza' });
        } else {
            const e = sinCorte ? (r._textoSinZ ? buscarEspejo(Object.assign({}, r, { prog: interpretarISO(r._textoSinZ), _sinZ: true }), r._textoSinZ) : null) : buscarEspejo(r, texto);
            if (e) {
                const sg = v => (v > 0 ? '+' : '') + fmt(v, 3), movido = Math.hypot(e.d.x, e.d.y) > 0.05;
                r.diagnostico = { tipo: 'espejo', corto: e.T.corto, sx: e.T.sx, sy: e.T.sy, cob: Math.min(1, e.r2.cobertura || 0) };
                r.hallazgos.unshift({ tipo: 'error', cat: 'diagnostico', linea: null,
                    msg: `Pieza ${e.T.que}: el recorrido tiene la forma de la pieza, pero ${e.T.sx < 0 && e.T.sy < 0 ? 'girada' : 'reflejada'}${movido ? ` y, además, con otro cero pieza (movida ${[Math.abs(e.d.x) > 0.005 ? 'X' + sg(-e.d.x) : '', Math.abs(e.d.y) > 0.005 ? 'Y' + sg(-e.d.y) : ''].filter(Boolean).join(' ')})` : ''}. Revisa el signo de ${e.T.sx < 0 && e.T.sy < 0 ? 'las X y las Y' : e.T.sx < 0 ? 'las X' : 'las Y'}: hacia la derecha y hacia arriba del cero pieza son positivas; hacia la izquierda y hacia abajo, negativas.${e.comp && e.T.sx * e.T.sy < 0 ? ' (Al reflejarla, además, la compensación queda al otro lado: G41 y G42 cambiados.)' : ''} Los errores de debajo son, sobre todo, consecuencia de esto.`,
                    pista: 'X+ a la derecha del cero pieza, X− a la izquierda; Y+ hacia arriba, Y− hacia abajo' });
            }
        }
        if (r.diagnostico) r.errores = r.hallazgos.filter(h => h.tipo === 'error').length;
    } catch (e) { console.warn(e); }
    return r;
};
const _extraVeredictoDiag = extraVeredicto;
extraVeredicto = function (it) {
    const dg = it && it.r && it.r.diagnostico;
    return _extraVeredictoDiag(it) + (dg ? ` <span class="mv-despl" title="${dg.tipo === 'espejo' ? 'El recorrido es la pieza ' + (dg.sx < 0 && dg.sy < 0 ? 'girada 180°' : 'en espejo') + ': revisa los signos' : 'Leídas en el otro modo (G90/G91), las coordenadas dan la pieza'}">· ${dg.corto}</span>` : '');
};
