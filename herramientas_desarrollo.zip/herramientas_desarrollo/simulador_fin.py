"""Simulador 3D V45: en la revisión, las mismas reglas del final del programa que el Corrector v48.
- Error: el programa arranca el husillo y no termina (sin M02 ni M30), o termina arrancándolo (M03/M04 después del
  último corte); termina con la fresa dentro del material (Z<0).
- Aviso: termina con la fresa abajo (Z<5); M30 con el husillo en marcha (falta M05); bajar en diagonal (entrar en el
  material moviéndose en X/Y desde arriba, o con más de 15° de pendiente); números de bloque de 1 en 1 o que no crecen.
  (Un programa sin M03 que no termina sigue siendo un aviso, como antes.)
Uso: python3 simulador_fin.py <carpeta de la suite>      (ya aplicado: no se vuelve a ejecutar)"""
import sys, os
RUTA = os.path.join(sys.argv[1] if len(sys.argv) > 1 else '.', 'simulador3d.html')
s = open(RUTA, encoding='utf-8').read()
def rep(a, b, cnt=1):
    global s
    assert s.count(a) == cnt, (a[:70], s.count(a)); s = s.replace(a, b)
rep("    const meta = { lineaComp: null, compFinal: 40, fin: false, comaDecimal: [], noSoportados: [], ciclosIncr: null, cambios: [], g28: null };",
    "    const meta = { lineaComp: null, compFinal: 40, fin: false, comaDecimal: [], noSoportados: [], ciclosIncr: null, cambios: [], g28: null, numeros: [], arranque: null };")
rep("""        const palabras = l.match(/[A-Za-z][-+]?(?:[0-9]+\\.?[0-9]*|\\.[0-9]+)/g) || [];
        const letras = {};""", """        const palabras = l.match(/[A-Za-z][-+]?(?:[0-9]+\\.?[0-9]*|\\.[0-9]+)/g) || [];
        { const nW = palabras.find(p => /^N/i.test(p)); if (nW) meta.numeros.push({ n: parseFloat(nW.slice(1)), linea: idx+1, et: 'N' + nW.slice(1) }); }
        const letras = {};""")
rep("""            if (m === 3 || m === 4) { husillo = true; if (m === 4 && !meta.m04) meta.m04 = idx + 1; }""",
    """            if (m === 3 || m === 4) { husillo = true; if (m === 4 && !meta.m04) meta.m04 = idx + 1; if (!meta.fin) meta.arranque = { linea: idx+1, m: m === 4 ? 'M04' : 'M03', nMoves: moves.length }; }""")
rep("""            else if (m === 30 || m === 2) { if (!meta.fin) meta.lineaFin = idx+1; meta.fin = true; }""",
    """            else if (m === 30 || m === 2) { if (!meta.fin) { meta.lineaFin = idx+1; meta.mFin = m; meta.husilloFin = husillo; meta.zFin = z; meta.arranqueAntes = meta.arranque; } meta.fin = true; }""")
rep("""    meta.compFinal = comp;
    moves.meta = meta;""", """    meta.compFinal = comp; meta.husilloFinal = husillo; meta.zFinal = z;
    moves.meta = meta;""")
rep("""    // 8) Fin de programa
    if (!meta.fin) add(gcodeMoves[gcodeMoves.length-1].linea, 'aviso', 'El programa no termina con M30 (o M2).');
""", """    // 8) Fin de programa: M05 y M30, o M02; la fresa, arriba
    const ultCorte = gcodeMoves.reduce((k, m, j) => m.tipo === 'corte' ? j : k, -1), arr = meta.fin ? meta.arranqueAntes : meta.arranque;
    const arrancaAlFinal = ultCorte >= 0 && arr && arr.nMoves > ultCorte && (meta.fin ? meta.husilloFin : meta.husilloFinal);
    const ultima = gcodeMoves[gcodeMoves.length-1].linea;
    if (arrancaAlFinal) add(arr.linea, 'error', arr.m + ' arranca el husillo, y el programa ya ha terminado de cortar. Para terminar se escribe M05 (parar el husillo) y M30 (fin de programa), o M02.');
    else if (!meta.fin && arr) add(ultima, 'error', 'El programa no termina: falta el fin de programa, M05 (parar el husillo) y M30 (o M02).');
    else if (!meta.fin) add(ultima, 'aviso', 'El programa no termina con M30 (o M2).');
    if (meta.fin && meta.mFin === 30 && meta.husilloFin && !arrancaAlFinal) add(meta.lineaFin, 'aviso', 'M30 con el husillo en marcha: escribe antes M05 para pararlo (M30 lo para en muchas máquinas, pero conviene escribirlo).');
    { const zF = meta.fin ? meta.zFin : meta.zFinal, lF = meta.fin ? meta.lineaFin : ultima;
      if (gcodeMoves.some(m => Math.min(m.fromZ, m.z) < -1e-6) && zF !== undefined && zF !== null) {
        if (zF < -1e-6) add(lF, 'error', 'El programa termina con la fresa dentro del material (Z' + (+zF.toFixed(3)) + '). Antes del fin, sube a la altura de seguridad (G0 Z20).');
        else if (zF < 5 - 1e-6) add(lF, 'aviso', 'El programa termina con la fresa abajo (Z' + (+zF.toFixed(3)) + '): antes del fin, sube a la altura de seguridad (G0 Z20).');
      } }
    // 9) Bajar en diagonal: entrar en el material moviéndose en X/Y, desde arriba o con mucha pendiente (una rampa suave sí vale)
    { const diag = gcodeMoves.filter(m => m.tipo === 'corte' && !m.deCiclo && tieneXY(m) && m.z < -1e-6 && m.z < m.fromZ - 1e-6
          && (m.fromZ > 1e-6 || Math.atan2(m.fromZ - m.z, Math.hypot(m.x - m.fromX, m.y - m.fromY)) > 15 * Math.PI / 180));
      if (diag.length) add(diag[0].linea, 'aviso', 'Baja en diagonal, de Z' + (+diag[0].fromZ.toFixed(3)) + ' a Z' + (+diag[0].z.toFixed(3)) + ' a la vez que se mueve en X/Y' + (diag.length > 1 ? ' (y ' + (diag.length - 1) + ' más)' : '') + '. La fresa no corta bien de punta en diagonal: primero se baja en vertical, con el avance de penetración (G1 Z… F300), y después se corta en X/Y. (Una rampa suave, de pocos grados, sí es una forma de entrar.)'); }
    // 10) Números de bloque (si los hay): de 10 en 10 y siempre creciendo
    if ((meta.numeros || []).length >= 3) {
        const N = meta.numeros, baja = N.find((x, k) => k && x.n <= N[k - 1].n);
        if (baja) { const k = N.indexOf(baja); add(baja.linea, 'aviso', baja.et + ': los números de bloque tienen que ir creciendo, y este va después de ' + N[k - 1].et + (baja.n === N[k - 1].n ? ' (repetido).' : '.')); }
        else if (N.every((x, k) => !k || x.n - N[k - 1].n === 1)) add(N[0].linea, 'aviso', 'Los números de bloque van de 1 en 1 (' + N[0].et + ', ' + N[1].et + ', ' + N[2].et + '…): es mejor de 10 en 10 (N10, N20, N30…), así se pueden intercalar líneas sin renumerar el programa.');
    }
""")
rep('vertical-align:middle">V44</span>', 'vertical-align:middle">V45</span>')
# (la ayuda del Simulador se cambió a mano: «El final del programa…», «Bajar en diagonal…», «Los números de bloque…»)
open(RUTA, 'w', encoding='utf-8').write(s)
print('Simulador V45: el final del programa, bajar en diagonal y los números de bloque')
